-- Basis data GrandCodex (SQLite). Dijalankan otomatis oleh backend/server.js saat mulai.
-- Tiap kumpulan data disimpan sebagai satu dokumen JSON per kunci, dibagi ke tiga tabel menurut kategorinya.
-- Pembagian kunci → tabel ada di backend/server.js (fungsi tableOf).

-- MASTER: data rujukan yang dipakai untuk membuat dokumen
--   st.pegawai  st.kampung  st.tarif  st.kode  st.pok.<tahun>  st.pokYears  st.template  st.templateRB  st.rekening  st.ptkp  st.suratFmt
CREATE TABLE IF NOT EXISTS master (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL CHECK (json_valid(value)),
  updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
) WITHOUT ROWID;

-- OUTPUT: hasil kerja aplikasi
--   st.records (surat tugas)  st.rincian (rincian biaya tiap surat, per _id)  st.massRows / st.massCommon (draf kolektif)  st.honor  st.surat (register nomor surat)
--   st.rab.<tahun>  st.rpd.<tahun> (+ rpdKet, rpdSup, rpdFin)  st.tup.<tahun>  st.up.<tahun>  st.revisi.<tahun>  st.tr.* (surat permintaan TUP)
CREATE TABLE IF NOT EXISTS output (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL CHECK (json_valid(value)),
  updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
) WITHOUT ROWID;

-- PENGATURAN: pilihan & penanda aplikasi (tahun aktif, tampilan daftar, penanda migrasi, …) — semua kunci lain
CREATE TABLE IF NOT EXISTS pengaturan (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL CHECK (json_valid(value)),
  updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
) WITHOUT ROWID;

-- USERS: akun login & hak akses (RBAC)
--   password    = hash scrypt ("scrypt$<salt>$<hash>"), tidak pernah disimpan sebagai teks asli
--   role        = 'Admin' (semua fitur + kelola user) atau 'User'
--   akses_fitur = daftar menu yang boleh dibuka, JSON array kode menu: ["form","list","rab",…]
CREATE TABLE IF NOT EXISTS users (
  username    TEXT PRIMARY KEY COLLATE NOCASE,
  password    TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'User' CHECK (role IN ('Admin', 'User')),
  akses_fitur TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(akses_fitur)),
  created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
) WITHOUT ROWID;

-- sesi login (kuki gc_sid); yang disimpan hash token-nya, bukan token aslinya
CREATE TABLE IF NOT EXISTS sessions (
  token    TEXT PRIMARY KEY,
  username TEXT NOT NULL COLLATE NOCASE,
  expires  INTEGER NOT NULL
) WITHOUT ROWID;

-- gabungan ketiga tabel, untuk dilihat sekaligus
DROP VIEW IF EXISTS semua;
CREATE VIEW semua AS
  SELECT 'master' AS kategori, key, length(value) AS ukuran, updated_at FROM master
  UNION ALL SELECT 'output', key, length(value), updated_at FROM output
  UNION ALL SELECT 'pengaturan', key, length(value), updated_at FROM pengaturan;
