// Gabungkan out/*.js (hasil tsc, urut nama berkas) menjadi satu skrip: js/app.js
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
const here = new URL(".", import.meta.url);
const files = readdirSync(new URL("out/", here)).filter(f => f.endsWith(".js")).sort();
const parts = files.map(f => `/* ---- ${f.slice(0, -3)}.ts ---- */\n` + readFileSync(new URL("out/" + f, here), "utf8").replace(/^"use strict";\n/, ""));
const bundle = '"use strict";\n' + parts.join("\n");
writeFileSync(new URL("js/app.js", here), bundle);
console.log(`ok · ${files.length} modul · ${bundle.length} karakter → js/app.js`);
