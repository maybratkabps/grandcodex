"use strict";
/* ---- 05_pokparse.ts ---- */
/* POK (Rincian Kertas Kerja Satker) text lines → [{mak, ro, roNama, komp, kompNama, sub, akun, nama, pagu, blokir, items:[{u,j,b}]}] */
/* nama RO bersih: buang sisa nama KRO ("Data dan Informasi Publik[Base Line]") / volume KRO yang ikut terbaca */
function cleanRoNama(n) {
    let t = String(n || "").replace(/\s+/g, " ").trim();
    if (/\[Base Line\]/i.test(t))
        t = t.replace(/^.*\[Base Line\]\s*/i, "");
    t = t.replace(/^(Data dan Informasi Publik|Peta, Data|dokumen,?)\s+/i, "").trim();
    const c = t.match(/^[^:]{3,100}?\s+:\s*(\S.*)$/);
    if (c)
        t = c[1].trim(); // "Data dan Informasi Lintas Bidang : LAYANAN STATISTIK TERPADU" → nama RO saja
    return t || String(n || "").trim();
}
function parsePOK(lines) {
    const amt = (s) => Number(String(s).replace(/,/g, "")) || 0;
    const out = {}, order = [], meta = {};
    let buf = [], need = 0, lastIt = null, roDone = false, keg = "", kegNama = "", ro = "", roNama = "", komp = "", kompNama = "", sub = "", akun = null, pending = "";
    const SKIP = /RINCIAN KERTAS KERJA|^\s*KEMEN|^\s*UNIT (ORG|KERJA)|Halaman\s*:|PROGRAM\/\s*KEGIATAN|^\s*KODE\s*$|SUBKOMP\/\s*DETIL|^\s*\(1\)|^\s*Catatan|^\s*\d\.\s*[UP*]\s*=|^\s*nip\s/i;
    /* Nama detil yang panjang ditulis beberapa baris, rata tengah terhadap baris angka:
       jumlah baris di atas baris angka = jumlah baris di bawahnya. Teks di antara dua baris angka
       dibagi: "need" baris pertama milik detil sebelumnya, sisanya awal nama detil berikutnya. */
    const give = (it, xs) => { if (!it || !xs.length)
        return; it.u = [it.u, ...xs.map(x => x.t)].filter(Boolean).join(" "); if (xs.some(x => x.star) && !it.b) {
        it.b = true;
        if (it._ak)
            it._ak.blokir += it.j;
    } };
    const closeAk = () => { if (lastIt) {
        give(lastIt, buf.splice(0, need));
    } if (buf.length)
        pending = buf.map(x => x.t).join(" "); buf = []; need = 0; lastIt = null; };
    for (const raw of lines) {
        const l = String(raw).replace(/\s+$/, "");
        if (!l.trim())
            continue;
        let m;
        if ((m = l.match(/^\s*ALOKASI\s+Rp\.?\s*([\d,]+)/))) {
            meta.alokasi = amt(m[1]);
            continue;
        }
        if ((m = l.match(/T\.A\.\s*(\d{4})/))) {
            meta.tahun = m[1];
            continue;
        }
        if ((m = l.match(/^\s*UNIT KERJA\s+\((\d+)\)\s+(.*)$/))) {
            meta.satker = m[2].trim();
            continue;
        }
        if ((m = l.match(/^\s*Maybrat,\s*(.+)$/i)) || (m = l.match(/^\s{40,}([A-Z][a-z]+,\s*\d{1,2}\s+\w+\s+\d{4})\s*$/))) {
            meta.tanggal = m[1].trim();
            continue;
        }
        if (SKIP.test(l))
            continue;
        if (akun && /\s{2,}(\d{1,3}(,\d{3})+|0)(\s|$)/.test(l) && (/^\s*(\d{4}(\.[A-Z]{3}(\.[A-Z0-9]{3})?)?|\d{6}|\d{3}|[A-Z]{1,2})(\s{2,}|\s*$)/.test(l) || /^\s*\d{3}\.\d{2}\.[A-Z]{2}\s/.test(l)))
            closeAk();
        if ((m = l.match(/^\s*(\d{4}\.[A-Z]{3}\.[A-Z0-9]{3})(?:\s{2,}(.*))?$/))) {
            ro = m[1];
            let nm = (m[2] || "").split(/\s{2,}/)[0].trim();
            if (/^[\d.,]+$/.test(nm))
                nm = "";
            roNama = (nm || pending).trim();
            roDone = false;
            komp = sub = "";
            akun = null;
            pending = "";
            continue;
        }
        if ((m = l.match(/^\s*(\d{4}\.[A-Z]{3})(\s|$)/))) {
            akun = null;
            pending = "";
            ro = "";
            roNama = "";
            continue;
        }
        if ((m = l.match(/^\s*\d{3}\.\d{2}\.[A-Z]{2}\s/))) {
            continue;
        }
        if ((m = l.match(/^\s*(\d{4})\s{2,}(\S.*)$/))) {
            keg = m[1];
            kegNama = m[2].split(/\s{2,}/)[0];
            akun = null;
            continue;
        }
        if ((m = l.match(/^\s*(\d{6})\s{2,}(\S.*?)\s{2,}([\d,]+)/))) {
            const mak = `${ro}.${komp}.${sub}.${m[1]}`;
            if (!out[mak]) {
                out[mak] = { mak, keg, kegNama, ro, roNama, komp, kompNama, sub, akun: m[1], nama: m[2].trim(), pagu: 0, blokir: 0, items: [] };
                order.push(mak);
            }
            akun = out[mak];
            akun.pagu += amt(m[3]);
            const sd = l.match(/\s{2,}(RM|PNBP|PNP|PLN|HLN|BLU|SBSN|PDN|HDN|RMP|BLUP)\s*$/);
            if (sd && !akun.sd)
                akun.sd = sd[1];
            continue;
        }
        if ((m = l.match(/^\s*(\d{3})\s{2,}(\S.*?)\s{2,}([\d,]+)/))) {
            komp = m[1];
            kompNama = m[2].trim();
            sub = "";
            akun = null;
            continue;
        }
        if ((m = l.match(/^\s*(\d{3})\s{2,}([\d,]{3,})(\s|$)/))) {
            komp = m[1];
            kompNama = pending || "";
            pending = "";
            sub = "";
            akun = null;
            continue;
        }
        if ((m = l.match(/^\s*([A-Z]{1,2})\s{2,}(\S.*?)\s{2,}([\d,]+)/))) {
            sub = m[1];
            akun = null;
            continue;
        }
        if ((m = l.match(/^\s*([A-Z]{1,2})\s{2,}([\d,]{3,})(\s|$)/))) {
            sub = m[1];
            akun = null;
            pending = "";
            continue;
        }
        if (!akun) {
            const t = l.trim().split(/\s{2,}/)[0];
            if (/^Lokasi/.test(t)) {
                pending = "";
                continue;
            }
            if (/^\(KPPN/.test(t) || /^[\d.,]+(\s|$)/.test(t))
                continue;
            if (ro && !komp && roNama && !pending && !roDone) {
                roNama += " " + t;
                roDone = true;
            }
            else
                pending = (pending ? pending + " " : "") + t;
            continue;
        }
        // detail lines under an akun: "... harga  jumlah [*]"
        if ((m = l.match(/^(.*?)\s{2,}([\d,]{3,})\s{2,}([\d,]{3,})(\s+\*)?\s*$/))) {
            const body = m[1].replace(/^\s*-(\s|$)/, " "), vs = body.match(/(?:^\s*|\s{2,})([\d.]+)\s+(\S.*?)\s*$/);
            const name = (vs ? body.slice(0, vs.index) : body).replace(/^\s*-\s*/, "").trim();
            const it = { u: "", j: amt(m[3]), b: !!m[4] };
            Object.defineProperty(it, "_ak", { value: akun, enumerable: false });
            if (vs) {
                it.v = Number(vs[1]) || 0;
                it.s = vs[2].trim();
            }
            it.h = amt(m[2]);
            give(lastIt, buf.splice(0, need));
            const pre = buf;
            buf = [];
            it.u = [...pre.map(x => x.t), name].filter(Boolean).join(" ");
            if (pre.some(x => x.star))
                it.b = true;
            need = pre.length;
            lastIt = it;
            if (!vs && !name)
                it._wantVol = true;
            akun.items.push(it);
            if (it.b)
                akun.blokir += it.j;
            continue;
        }
        if (!/^\s*-/.test(l) && (/^\s*\S.*?\s{2,}[\d.]+\s+\S.*?\s{2,}[\d,]{3,}\s*$/.test(l) || /^\s*[A-Za-z].*?\s{2,}\d+\.\d\s+[A-Za-z][\w,.\- ]*$/.test(l))) { // header line of the next RO (name + volume + total)
            closeAk();
            pending = l.trim().split(/\s{2,}/)[0];
            akun = null;
            continue;
        }
        const li = lastIt;
        if (li && li._wantVol && (m = l.match(/^\s*-\s+(.*?)\s{2,}([\d.]+)\s+(\S.*?)\s*$/))) { // baris angka terpisah dari baris nama+volume
            const lastIt = li;
            delete lastIt._wantVol;
            lastIt.v = Number(m[2]) || 0;
            lastIt.s = m[3].trim();
            if (m[1].trim())
                lastIt.u = [lastIt.u, m[1].trim()].filter(Boolean).join(" ");
            continue;
        }
        if (/^\s{70,}\S/.test(l))
            continue; // tanda tangan / catatan kaki halaman terakhir
        if (!/^\s*\(KPPN/.test(l)) { // potongan nama detil (di atas / di bawah baris angka)
            const t = l.replace(/^\s*-\s*/, "").replace(/\s{2,}[\d.]+\s+\S+.*$/, "").replace(/\s+\*\s*$/, "").trim();
            if (t && !/^[\d.]+\s+\S+$/.test(t))
                buf.push({ t, star: /\*\s*$/.test(l) });
        }
    }
    closeAk();
    for (const k of order)
        out[k].roNama = cleanRoNama(out[k].roNama);
    return { meta, akun: order.map(k => out[k]) };
}

/* ---- 06_pokxlsx.ts ---- */
function parsePOKRows(rows) {
    const S = (v) => v == null ? "" : String(v).trim();
    const isNum = (v) => typeof v === "number" || (typeof v === "string" && /^-?[\d.,]+$/.test(v.trim()) && /\d/.test(v));
    const N = (v) => typeof v === "number" ? v : Number(String(v).replace(/,/g, "")) || 0;
    const out = {}, order = [], meta = { src: "xlsx" };
    let prevCode = "", keg = "", kegNama = "", ro = "", roNama = "", roRaw = "", komp = "", kompNama = "", sub = "", akun = null, last = null, alokasi = 0;
    for (const r of rows) {
        if (!r || !r.length)
            continue;
        const c0 = S(r[0]), d = S(r[3]);
        const nums = r.slice(6).map((v, i) => [v, i + 6]).filter(([v]) => isNum(v) && !(typeof v === "string" && /^\d$/.test(v.trim())));
        const amt = nums.length ? N(nums[nums.length - 1][0]) : 0;
        const tgl = r.map(S).find(x => /^[A-Z][a-z]+,\s*\d{1,2}\s+\w+\s+\d{4}$/.test(x));
        if (tgl && !c0) {
            meta.tanggal = tgl.replace(/^[^,]+,\s*/, "");
            continue;
        }
        if (c0 && c0 === prevCode && !amt && d) { // kode sama diulang = lanjutan nama baris sebelumnya
            if (last === "ro") {
                roRaw = (roRaw + " " + d).replace(/\s+/g, " ").trim();
                roNama = cleanRoNama(roRaw);
                for (const k of order)
                    if (out[k].ro === ro)
                        out[k].roNama = roNama;
            }
            else if (last === "keg")
                kegNama = (kegNama + " " + d).replace(/\s+/g, " ");
            else if (akun && akun.akun === c0)
                akun.nama = (akun.nama + " " + d).replace(/\s+/g, " ");
            else if (c0 === komp)
                kompNama = (kompNama + " " + d).replace(/\s+/g, " ");
            continue;
        }
        if (c0)
            prevCode = c0;
        if (c0) {
            last = null;
            if (/^\d{3}\.\d{2}\.[A-Z]{2}$/.test(c0)) {
                alokasi += amt;
                continue;
            } // program
            if (/^\d{4}$/.test(c0)) {
                keg = c0;
                kegNama = d;
                last = "keg";
                akun = null;
                continue;
            } // kegiatan
            if (/^\d{4}\.[A-Z]{3}$/.test(c0)) {
                akun = null;
                continue;
            } // KRO
            if (/^\d{4}\.[A-Z]{3}\.[A-Z0-9]{3}$/.test(c0)) {
                ro = c0;
                roRaw = d;
                roNama = cleanRoNama(d);
                last = "ro";
                komp = sub = "";
                akun = null;
                continue;
            }
            if (/^\d{6}$/.test(c0)) {
                last = "akun";
                const mak = `${ro}.${komp}.${sub}.${c0}`;
                if (!out[mak]) {
                    out[mak] = { mak, keg, kegNama, ro, roNama, komp, kompNama, sub, akun: c0, nama: d, pagu: 0, blokir: 0, items: [] };
                    order.push(mak);
                }
                akun = out[mak];
                akun.pagu += amt;
                const sd = r.map(S).find(x => /^(RM|PNBP|PNP|PLN|HLN|BLU|SBSN|PDN|HDN|RMP|BLUP)$/.test(x));
                if (sd && !akun.sd)
                    akun.sd = sd;
                continue;
            }
            if (/^\d{3}$/.test(c0)) {
                komp = c0;
                kompNama = d;
                sub = "";
                akun = null;
                continue;
            } // komponen
            if (/^[A-Z]{1,2}$/.test(c0)) {
                sub = c0;
                akun = null;
                continue;
            } // sub komponen
            continue;
        }
        if (d === "-" && akun) { // detil
            const u = S(r[4]).replace(/\s+/g, " "), vs = S(r[6]).match(/^([\d.,]+)\s*(.*)$/);
            const it = { u, j: amt, b: r.some(v => S(v) === "*"), h: nums.length > 1 ? N(nums[0][0]) : amt };
            if (vs) {
                it.v = Number(vs[1].replace(/,/g, "")) || 0;
                it.s = vs[2].trim();
            }
            akun.items.push(it);
            if (it.b)
                akun.blokir += it.j;
            continue;
        }
        if (d && !/^\(KPPN|^Lokasi/i.test(d) && !r.slice(4).some(v => S(v))) { // lanjutan nama (kegiatan/RO)
            if (last === "keg")
                kegNama = (kegNama + " " + d).replace(/\s+/g, " ");
            else if (last === "ro") {
                roRaw = (roRaw + " " + d).replace(/\s+/g, " ").trim();
                roNama = cleanRoNama(roRaw);
                for (const k of order)
                    if (out[k].ro === ro)
                        out[k].roNama = roNama;
            }
        }
    }
    if (alokasi)
        meta.alokasi = alokasi;
    return { meta, akun: order.map(k => out[k]) };
}

/* ---- 10_core.ts ---- */
/* ================= storage & state ================= */
/* Data aplikasi disimpan di basis data lewat back end (/api/kv). Isi awalnya dimuat serentak oleh
   <script src="api/state.js"> (__GC_STATE: kunci → teks JSON), jadi pembacaan tetap sinkron; setiap
   perubahan dikirim ke server di latar belakang, berurutan, dan diulang bila gagal.
   Tampilan (tema, ukuran huruf, bilah samping) tetap per-browser di localStorage. */
const LOCAL_KEY = /^st\.(theme|scheme|fsize|font|light|padx|maxw|sideCollapsed|nav\..*)$/;
/* ---------- user yang login & hak akses menu ---------- */
const GC_USER = __GC_USER, isAdmin = GC_USER.role === "Admin";
/** boleh membuka menu ini? Beranda selalu boleh; Manajemen User khusus Admin; Admin boleh semuanya */
const can = (v) => v === "home" || isAdmin || (v !== "users" && GC_USER.fitur.includes(v));
/** sesi habis / keluar → kembali ke halaman login */
let gcLeaving = false;
function gcToLogin() { if (gcLeaving)
    return; gcLeaving = true; location.href = "login.html" + location.hash; }
const Remote = (() => {
    const cache = __GC_STATE;
    const pending = new Map(); // kunci → teks JSON terbaru (null = hapus)
    let busy = false, failed = false;
    async function flush() {
        if (busy)
            return;
        busy = true;
        while (pending.size) {
            const [k, v] = pending.entries().next().value;
            pending.delete(k);
            try {
                const r = await fetch("api/kv/" + encodeURIComponent(k), v === null ? { method: "DELETE" } : { method: "PUT", headers: { "Content-Type": "application/json" }, body: v });
                if (r.status === 401) {
                    pending.clear();
                    busy = false;
                    alert("Sesi login sudah berakhir. Perubahan terakhir belum tersimpan — silakan masuk lagi.");
                    gcToLogin();
                    return;
                }
                if (!r.ok)
                    throw new Error("HTTP " + r.status);
                if (failed) {
                    failed = false;
                    toast("Tersambung lagi — perubahan sudah tersimpan ke server.", "ok");
                }
            }
            catch (e) {
                if (!pending.has(k))
                    pending.set(k, v); // belum ada nilai yang lebih baru → antre ulang
                if (!failed) {
                    failed = true;
                    toast("Gagal menyimpan ke server: " + e.message + ". Akan dicoba lagi otomatis.", "err");
                }
                busy = false;
                setTimeout(flush, 4000);
                return;
            }
        }
        busy = false;
    }
    addEventListener("beforeunload", e => { if (!gcLeaving && (pending.size || busy))
        e.preventDefault(); }); // masih ada yang belum terkirim
    return {
        get: (k) => cache[k],
        set(k, v) { if (cache[k] === v)
            return; cache[k] = v; pending.set(k, v); void flush(); },
        del(k) { if (!(k in cache))
            return; delete cache[k]; pending.set(k, null); void flush(); }
    };
})();
const LS = {
    get(k, d) { try {
        const v = LOCAL_KEY.test(k) ? localStorage.getItem(k) : Remote.get(k);
        return v ? JSON.parse(v) : d;
    }
    catch (e) {
        return d;
    } },
    set(k, v) {
        try {
            const s = JSON.stringify(v);
            if (LOCAL_KEY.test(k))
                localStorage.setItem(k, s);
            else
                Remote.set(k, s);
            return true;
        }
        catch (e) {
            toast("Gagal menyimpan: " + e.message, "err");
            return false;
        }
    },
    del(k) { try {
        if (LOCAL_KEY.test(k))
            localStorage.removeItem(k);
        else
            Remote.del(k);
    }
    catch (e) { } }
};
const clone = (x) => JSON.parse(JSON.stringify(x));
let pegawai = LS.get("st.pegawai", null) || clone(SEED.pegawai);
/* Surat tugas disimpan dalam dua dokumen: st.records = data surat, st.rincian = rincian biaya tiap surat ({ _id: kolom biaya }).
   Di memori keduanya tetap satu rekaman per surat. Data lama (semuanya di st.records) tetap terbaca dan dipisah saat disimpan. */
const BIAYA_KEY = /^(LAMA_INAP|TDK_INAP_HOTEL|LAMA_UH|NILAI_UH|TOTAL_TRANS|TGL_KUI|No_Bend|HOTEL_TEMPAT|LAMA_HOTEL|TARIF_HOTEL|KetTransport_\d+|Nilai\d+|_perOrang|_riilLok|_riilBdr|_hotel2|_noBiaya|_pelExcl|_pelUH)$/;
function loadRecords() {
    const rs = LS.get("st.records", null);
    if (!rs)
        return clone(SEED.records);
    const rb = LS.get("st.rincian", {});
    for (const r of rs) {
        const b = r._id ? rb[r._id] : null;
        if (b)
            Object.assign(r, b);
    }
    return rs;
}
function saveRecords() {
    const st = [], rb = {};
    for (const r of records) {
        const a = {}, b = {};
        for (const k of Object.keys(r))
            (r._id && BIAYA_KEY.test(k) ? b : a)[k] = r[k];
        st.push(a);
        if (r._id && Object.keys(b).length)
            rb[r._id] = b;
    }
    return LS.set("st.rincian", rb) && LS.set("st.records", st);
}
let records = loadRecords();
const APP_VERSION = "2026.11.25";
let template = LS.get("st.template", null);
let templateRB = LS.get("st.templateRB", null);
let kampungDB = LS.get("st.kampung", null) || clone(SEED.kampung);
let tarifDB = LS.get("st.tarif", null) || clone(SEED.tarif);
let kodeDB = LS.get("st.kode", null) || clone(SEED.kode);
let massRows = LS.get("st.massRows", null) || [];
let massCommon = LS.get("st.massCommon", null) || {};
/* POK disimpan per tahun anggaran: st.pok.<tahun>; daftar tahun di st.pokYears; tahun aktif (dipakai ST/Honor) di st.pokYear */
const pokKey = (y) => "st.pok." + y, pokStore = {};
let pokYearsL = LS.get("st.pokYears", null) || [];
if (!Array.isArray(pokYearsL) || !pokYearsL.length) {
    const old = LS.get("st.pok", null);
    pokYearsL = [];
    if (old) {
        const y0 = String(old.meta?.tahun || new Date().getFullYear());
        pokStore[y0] = old;
        LS.set(pokKey(y0), old);
        pokYearsL.push(y0);
        LS.del("st.pok");
    }
    else {
        for (const [y, v] of Object.entries(SEED.pokY || { [SEED.pok.meta?.tahun || "2026"]: SEED.pok })) {
            pokStore[y] = clone(v);
            LS.set(pokKey(y), pokStore[y]);
            pokYearsL.push(y);
        }
        LS.set("st.pokXlsx", 2);
    }
    pokYearsL.sort();
    LS.set("st.pokYears", pokYearsL);
}
const pokGet = (y) => pokStore[y] || (pokStore[y] = LS.get(pokKey(y), null));
const pokYears = () => [...pokYearsL].sort();
function pokSave(y, data) { y = String(y); pokStore[y] = data; LS.set(pokKey(y), data); if (!pokYearsL.includes(y)) {
    pokYearsL.push(y);
    pokYearsL.sort();
    LS.set("st.pokYears", pokYearsL);
} }
function pokDrop(y) { y = String(y); delete pokStore[y]; LS.del(pokKey(y)); pokYearsL = pokYearsL.filter(x => x !== y); LS.set("st.pokYears", pokYearsL); }
let pokYear = String(LS.get("st.pokYear", ""));
if (!pokYearsL.includes(pokYear))
    pokYear = pokYearsL.includes(String(new Date().getFullYear())) ? String(new Date().getFullYear()) : pokYears().at(-1) ?? String(new Date().getFullYear());
let pokDB = pokGet(pokYear) || clone(SEED.pok);
function pokEnrich(p0, y) {
    if (!p0 || p0._v3)
        return;
    const S = {};
    for (const a of SEED.pok.akun) {
        S[a.mak] = a;
    }
    for (const a of p0.akun) {
        a.roNama = cleanRoNama(a.roNama);
        const b = S[a.mak];
        if (b && !a.sd)
            a.sd = b.sd;
        if (b)
            a.items.forEach(it => { if (it.h != null)
                return; const q = b.items.find(x => x.u === it.u && x.j === it.j); if (q) {
                it.v = q.v;
                it.s = q.s;
                it.h = q.h;
            } });
    }
    p0._v2 = p0._v3 = true;
    LS.set(pokKey(y), p0);
}
for (const y of pokYears())
    pokEnrich(pokGet(y), y);
const RULES_GRUP = "ATURAN TRANSPORT 2026";
const minLintasMobil = () => rule("LINTASAN MOBIL") || 500000; // minimal Biaya Lintasan Mobil — diatur di Pengaturan (bawaan Rp 500.000)
const RULE_DEFAULTS = [["LINTASAN ANTAR KAMPUNG", 150000], ["LINTASAN MOBIL (TRANSPORT JAUH)", 500000], ["INAP MOBIL PER MALAM", 250000], ["BATAS TRANSPORT JAUH (LEBIH DARI)", 1000000]];
for (const [n, v] of RULE_DEFAULTS)
    if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n))
        tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v });
const rule = (n) => { const t = tarifDB.find(t => t.grup === RULES_GRUP && t.nama.startsWith(n)); return t ? num(t.nilai) : 0; };
let _use = null; // cache: MAK → {j, n}
let editingId = null;
let chips = [];
/** isian formulir: pengeluaran riil transport lokal / mobil bandara, dan hotel tambahan */
let riilLok = [], riilBdr = [], hotel2 = [];
let perOrang = {};
const poOpen = new Set();
let members = []; // [kode pegawai]
/* tiap surat punya _id internal; nomor urut (NO) cukup unik per TAHUN tanggal terbit */
let _idSeq = 0;
/** akses kolom lewat nama dinamis (data-f, data-h …) — satu titik cast, bukan any tersebar */
const dyn = (o) => o;
const newId = () => "r" + Date.now().toString(36) + (++_idSeq).toString(36);
const ensureIds = (list = records) => { for (const r of list)
    if (!r._id)
        r._id = newId(); };
const stYear = (r) => {
    let d = parseTgl(r.TGL_TERBIT_ST);
    if (d)
        return d.getFullYear();
    const m = String(r.NoLengkap || "").match(/\/((?:19|20)\d\d)\s*$/);
    if (m)
        return +m[1];
    d = parseTgl(r.TGL_PERGI);
    if (d)
        return d.getFullYear();
    const m2 = String(r.TGL_PERGI || "").match(/\b((?:19|20)\d\d)\b/);
    return m2 ? +m2[1] : null;
};
const yrOf = (t) => { const d = parseTgl(t); return d ? d.getFullYear() : null; };
/* No. urut surat tugas boleh berakhiran huruf (504A). Kunci unik = angka tanpa nol di depan + akhiran huruf besar:
   "504", "0504" → "504";  "504A", "504 a" → "504A"  (504 dan 504A adalah dua nomor berbeda). */
const noNorm = (n) => String(n ?? "").trim().toUpperCase().replace(/\s+/g, "");
const noKey = (n) => { const t = noNorm(n), m = t.match(/^0*(\d+)(.*)$/); return m ? m[1] + m[2] : t; };
const noNum = (n) => parseInt(String(n ?? "").trim(), 10) || 0;
const recKey = (r) => (stYear(r) ?? "") + "|" + noKey(r.NO);
const byYearNo = (a, b) => (stYear(a) || 0) - (stYear(b) || 0) || noNum(a.NO) - noNum(b.NO) || noKey(a.NO).localeCompare(noKey(b.NO));
const persist = () => { ensureIds(); LS.set("st.pegawai", pegawai); saveRecords(); LS.set("st.kampung", kampungDB); LS.set("st.tarif", tarifDB); LS.set("st.kode", kodeDB); pokStore[pokYear] = pokDB; LS.set(pokKey(pokYear), pokDB); _use = null; _kIdx = null; _dataVer++; };
let _dataVer = 0;
/* cache hasil compute per surat — dibuang otomatis tiap data berubah (_dataVer) */
const _cc = new WeakMap();
function computeC(r) { const e = _cc.get(r); if (e && e.v === _dataVer)
    return e.F; const F = compute(r); _cc.set(r, { v: _dataVer, F, hay: null }); return F; }
function hayOf(r) { const F = computeC(r), e = _cc.get(r); if (e.hay == null)
    e.hay = [r.NO, F.NOMOR_ST, F.NAMA_PELAKSANA_SPD, F.MAKSUD__TUJUAN, F.TEMPAT_TUJUAN, F.kegiatan, F.TGL_TERBIT_ST, F.NAMALAMPIRAN_1, lampOf(r).map((c) => pegMap()[c]?.nama || "").join(" ")].join(" ").toLowerCase(); return e.hay; }
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const persistMass = () => { LS.set("st.massRows", massRows); LS.set("st.massCommon", massCommon); };
/* ================= helpers ================= */
/* Pencari elemen bertipe. Bawaan HTMLInputElement karena hampir semua elemen yang dicari adalah kolom isian;
   elemen lain diminta eksplisit, mis. $<HTMLSelectElement>("#x"). Elemen dijamin ada di halaman (markup statis). */
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
/** target event delegasi (klik/ketik di dalam tabel & daftar) sebagai elemen isian */
const tg = (e) => e.target;
const BULAN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
const fmtTgl = (iso) => { const [y, m, d] = iso.split("-").map(Number); return `${d} ${BULAN[m - 1]} ${y}`; };
const fmtDate = (d) => `${d.getDate()} ${BULAN[d.getMonth()]} ${d.getFullYear()}`;
const today = () => fmtDate(new Date());
/** tanggal pulang = tanggal pergi + (lama − 1) hari */
const tglPulang = (pergi, lama) => { const a = parseTgl(pergi), n = Math.max(1, Math.round(num(lama)) || 1); return a ? fmtDate(new Date(a.getFullYear(), a.getMonth(), a.getDate() + n - 1)) : ""; };
const parseTgl = (s) => {
    const m = String(s || "").trim().match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
    if (!m)
        return null;
    const mi = BULAN.findIndex(b => b.toLowerCase() === m[2].toLowerCase());
    return mi < 0 ? null : new Date(+m[3], mi, +m[1]);
};
const dayDiff = (a, b) => Math.round((+b - +a) / 864e5) + 1;
const num = (v) => { if (v === "" || v == null)
    return 0; let t = String(v).trim(); if (/^-?\d{1,3}(\.\d{3})+$/.test(t.replace(/^Rp\s*/i, "")))
    t = t.replace(/\./g, ""); const n = Number(t.replace(/[^\d.-]/g, "")); return isFinite(n) ? n : 0; };
/* ===== Kolom nominal (Rp) diberi pemisah ribuan otomatis: 1020000 → 1.020.000 =====
   Kolom angka uang (step 1000) diubah menjadi kolom teks bertanda data-money. Tampilan memakai titik,
   tetapi .value tetap memberi angka polos ("1020000"), sehingga semua perhitungan lama tidak berubah. */
const isoToDmy = (v) => { const m = String(v || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}` : ""; };
const fmtRibuan = (v) => { let t = String(v ?? "").replace(/[^\d-]/g, ""); const neg = t.startsWith("-"); t = t.replace(/-/g, "").replace(/^0+(?=\d)/, ""); return t ? (neg ? "-" : "") + t.replace(/\B(?=(\d{3})+(?!\d))/g, ".") : (neg ? "-" : ""); };
(() => {
    const D0 = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    /** akses nilai asli (tanpa pemisah ribuan) */
    const D = { get: D0.get, set: D0.set, enumerable: D0.enumerable };
    const norm = (v) => { if (typeof v === "number")
        return isFinite(v) ? String(Math.round(v)) : ""; let t = String(v ?? "").trim(); if (/^-?\d+[.,]\d{1,2}$/.test(t))
        t = String(Math.round(+t.replace(",", "."))); return t; };
    Object.defineProperty(HTMLInputElement.prototype, "value", { configurable: true, enumerable: D.enumerable,
        get() { const v = D.get.call(this); return this.hasAttribute("data-money") ? v.replace(/\./g, "") : v; },
        set(v) { D.set.call(this, this.hasAttribute("data-money") ? fmtRibuan(norm(v)) : String(v ?? "")); if (this._dmy)
            this._dmy.value = isoToDmy(D.get.call(this)); } });
    const SEL = 'input[type="number"][step="1000"]';
    const conv = (el) => { if (el.hasAttribute("data-money"))
        return; const v = D.get.call(el); el.type = "text"; el.inputMode = "numeric"; el.autocomplete = "off"; el.setAttribute("data-money", ""); D.set.call(el, fmtRibuan(norm(v))); };
    const scan = (root) => { if (!(root instanceof Element))
        return; if (root.matches(SEL))
        conv(root); root.querySelectorAll(SEL).forEach(conv); };
    scan(document.body);
    new MutationObserver(ms => { for (const m of ms)
        for (const n of m.addedNodes)
            scan(n); }).observe(document.body, { childList: true, subtree: true });
    /* ===== Kolom tanggal selalu DD/MM/YYYY (tidak tergantung bahasa browser) =====
       input[type=date] asli disembunyikan (tetap dipakai kode & kalender); yang terlihat kolom teks DD/MM/YYYY + tombol kalender. */
    const DSEL = 'input[type="date"]';
    const skipDate = (el) => !!el.closest(".row") || el.matches("[data-for],[data-hfor],[data-nsfor],[data-mfor],[data-kd]");
    const dmyToIso = (t) => {
        const m = String(t || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
        if (!m)
            return null;
        const d = +m[1], mo = +m[2], y = +m[3], dt = new Date(y, mo - 1, d);
        return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}` : null;
    };
    /** buka kalender bawaan browser (cadangan: fokus + klik) */
    const openPick = (el) => { if (el.disabled)
        return; try {
        el.showPicker();
    }
    catch (err) {
        el.focus();
        el.click();
    } };
    const fire = (el) => { el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
    const dconv = (el) => {
        if (el._dmy || skipDate(el))
            return;
        const w = document.createElement("span");
        w.className = "dmy";
        const t = document.createElement("input");
        t.type = "text";
        t.className = "dmy-t";
        t.inputMode = "numeric";
        t.placeholder = "DD/MM/YYYY";
        t.maxLength = 10;
        t.autocomplete = "off";
        if (el.getAttribute("aria-label"))
            t.setAttribute("aria-label", (el.getAttribute("aria-label") ?? "") + " (DD/MM/YYYY)");
        if (el.title)
            t.title = el.title;
        if (el.id)
            t.dataset.dmyFor = el.id;
        const bt = document.createElement("button");
        bt.type = "button";
        bt.className = "dmy-b";
        bt.tabIndex = -1;
        bt.title = "Pilih dari kalender";
        bt.setAttribute("aria-label", "Pilih dari kalender");
        bt.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>`;
        const hadFocus = document.activeElement === el;
        el.parentNode?.insertBefore(w, el);
        w.append(t, bt, el);
        el.classList.add("dmy-n");
        el.tabIndex = -1;
        el._dmy = t;
        t._native = el;
        t.value = isoToDmy(D.get.call(el));
        t.readOnly = true;
        t.classList.add("tgl-ro");
        if (el.disabled) {
            t.disabled = true;
            bt.disabled = true;
        }
        t.title = (el.title ? el.title + " — " : "") + "klik untuk memilih dari kalender";
        bt.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); openPick(el); });
        t.addEventListener("click", () => openPick(el));
        t.addEventListener("keydown", e => {
            if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") {
                e.preventDefault();
                openPick(el);
            }
            else if ((e.key === "Backspace" || e.key === "Delete") && D.get.call(el) && !el.required) {
                e.preventDefault();
                D.set.call(el, "");
                t.value = "";
                fire(el);
            }
        });
        el.addEventListener("input", () => { const v = isoToDmy(D.get.call(el)); if (t.value !== v && document.activeElement !== t)
            t.value = v; });
        el.addEventListener("change", () => { t.value = isoToDmy(D.get.call(el)); t.classList.remove("bad"); });
        t.addEventListener("input", e => {
            e.stopPropagation();
            let dg = t.value.replace(/\D/g, "").slice(0, 8);
            const f = dg.length > 4 ? `${dg.slice(0, 2)}/${dg.slice(2, 4)}/${dg.slice(4)}` : dg.length > 2 ? `${dg.slice(0, 2)}/${dg.slice(2)}` : dg;
            if (f !== t.value) {
                const end = t.selectionStart === t.value.length;
                t.value = f;
                if (end)
                    t.setSelectionRange(f.length, f.length);
            }
            const iso = dmyToIso(t.value);
            t.classList.toggle("bad", t.value.length === 10 && !iso);
            if (iso && iso !== D.get.call(el)) {
                D.set.call(el, iso);
                fire(el);
            }
            else if (!t.value && D.get.call(el)) {
                D.set.call(el, "");
                fire(el);
            }
        }, true);
        t.addEventListener("change", e => e.stopPropagation(), true);
        t.addEventListener("blur", () => { if (t.value && !dmyToIso(t.value)) {
            toast("Format tanggal DD/MM/YYYY, mis. 05/01/2027.", "warn");
            t.value = isoToDmy(D.get.call(el));
            t.classList.remove("bad");
        } });
        if (hadFocus)
            t.focus();
    };
    /* kolom teks tanggal ("7 November 2026") berpasangan dengan kalender kecil di sebelahnya (.row): teks hanya-baca, klik → kalender */
    const pconv = (el) => {
        if (el.dataset.tglp)
            return;
        const t = el.parentElement?.querySelector('input:not([type="date"])');
        if (!t)
            return;
        el.dataset.tglp = "1";
        const own = el.hasAttribute("data-tglfor"); // kalender dibuat otomatis untuk kolom data-tgl → isi teks sendiri
        if (own)
            el.addEventListener("change", () => { const v = D.get.call(el); if (!v)
                return; t.value = fmtTgl(v); t.dispatchEvent(new Event("input", { bubbles: true })); t.dispatchEvent(new Event("change", { bubbles: true })); });
        t.readOnly = true;
        t.classList.add("tgl-ro");
        if (el.disabled)
            t.disabled = true;
        if (!t.title)
            t.title = "Klik untuk memilih dari kalender";
        if (!t.placeholder)
            t.placeholder = "Pilih dari kalender";
        const open = () => { const d = parseTgl(t.value); if (d)
            D.set.call(el, `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`); openPick(el); };
        t.addEventListener("click", open);
        t.addEventListener("keydown", e => {
            if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") {
                e.preventDefault();
                open();
            }
            else if ((e.key === "Backspace" || e.key === "Delete") && t.value) {
                e.preventDefault();
                t.value = "";
                t.dispatchEvent(new Event("input", { bubbles: true }));
                t.dispatchEvent(new Event("change", { bubbles: true }));
            }
        });
    };
    /* kolom teks tanggal tanpa kalender (data-tgl) → beri kalender di sebelahnya */
    const tconv = (t) => {
        if (t.dataset.tglc)
            return;
        t.dataset.tglc = "1";
        const r = document.createElement("div");
        r.className = "row";
        t.parentNode?.insertBefore(r, t);
        const n = document.createElement("input");
        n.type = "date";
        n.setAttribute("data-tglfor", "");
        n.title = "Pilih tanggal";
        n.tabIndex = -1;
        r.append(t, n);
        pconv(n);
    };
    const dscan = (root) => {
        if (!(root instanceof Element))
            return;
        const all = [...(root.matches("input[data-tgl]") ? [root] : []), ...root.querySelectorAll("input[data-tgl]")];
        all.forEach(tconv);
        const ds = [...(root.matches(DSEL) ? [root] : []), ...root.querySelectorAll(DSEL)];
        for (const el of ds) {
            if (skipDate(el))
                pconv(el);
            else
                dconv(el);
        }
    };
    dscan(document.body);
    new MutationObserver(ms => { for (const m of ms)
        for (const n of m.addedNodes)
            dscan(n); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener("input", e => {
        const el = tg(e);
        if (!el.hasAttribute || !el.hasAttribute("data-money"))
            return;
        const raw = D.get.call(el), pos = el.selectionStart ?? raw.length, before = raw.slice(0, pos).replace(/\D/g, "").length, f = fmtRibuan(raw);
        if (f === raw)
            return;
        D.set.call(el, f);
        let i = 0, c = 0;
        while (i < f.length && c < before) {
            if (/\d/.test(f[i]))
                c++;
            i++;
        }
        try {
            el.setSelectionRange(i, i);
        }
        catch (err) { }
    }, true);
})();
const rupiah = (n) => Math.round(n).toLocaleString("id-ID");
const ESC_MAP = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ESC_MAP[c] ?? c);
const title = (s) => String(s ?? "").toLowerCase().replace(/(^|[\s\-'(\/])([a-z])/g, (_m, a, b) => a + b.toUpperCase());
function toast(msg, type) {
    const t = $("#toast"), m = String(msg ?? "");
    type ||= /gagal|error|tidak valid|tidak bisa/i.test(m) ? "err"
        : /^(pilih|isi\b|lengkapi|harap|mohon|belum|tidak ada|⚠|tanggal .* tidak|nomor .* sudah)/i.test(m) || /melebihi|bentrok|konflik|masih kosong/i.test(m) ? "warn"
            : /disimpan|diperbarui|berhasil|diekspor|diimpor|dihapus|ditambahkan|dipulihkan|disalin|diunduh|tersimpan|dikembalikan|dibuat|dipakai|dibersihkan|diganti|ditandai|diubah ke|diterapkan|✓/i.test(m) ? "ok" : "info";
    const ic = { ok: "✓", warn: "!", err: "✕", info: "i" }[type];
    t.className = "toast on " + type;
    t.innerHTML = `<span class="ti">${ic}</span><span class="tm"></span>`;
    t.querySelector(".tm").textContent = m;
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove("on"), Math.min(8000, 2600 + m.length * 35));
}
function terbilang(n0) {
    const n = Math.floor(Math.abs(num(n0)));
    const s = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"];
    const t = (x) => x < 12 ? s[x] : x < 20 ? t(x - 10) + " belas" : x < 100 ? t(Math.floor(x / 10)) + " puluh " + t(x % 10)
        : x < 200 ? "seratus " + t(x - 100) : x < 1000 ? t(Math.floor(x / 100)) + " ratus " + t(x % 100)
            : x < 2000 ? "seribu " + t(x - 1000) : x < 1e6 ? t(Math.floor(x / 1000)) + " ribu " + t(x % 1000)
                : x < 1e9 ? t(Math.floor(x / 1e6)) + " juta " + t(x % 1e6) : x < 1e12 ? t(Math.floor(x / 1e9)) + " miliar " + t(x % 1e9)
                    : t(Math.floor(x / 1e12)) + " triliun " + t(x % 1e12);
    if (n === 0)
        return "Nol";
    return t(n).replace(/\s+/g, " ").trim().replace(/\b\w/g, c => c.toUpperCase());
}
const pegMap = () => Object.fromEntries(pegawai.map(p => [String(p.kode), p]));
const codeOf = (v) => { const m = String(v ?? "").trim().match(/^(\d+)(\s|$|—)/); return m ? m[1] : String(v ?? "").trim(); };
const normName = (s) => String(s || "").toLowerCase().replace(/,.*$/, "").replace(/[^a-z\s]/g, " ").replace(/\s+/g, " ").trim();
function resolvePeg(text) {
    const t = String(text ?? "").trim();
    if (!t)
        return null;
    const P = pegMap(), c = codeOf(t);
    if (P[c])
        return c;
    const lq = t.toLowerCase();
    let hit = pegawai.find(p => p.nama.toLowerCase() === lq) || pegawai.find(p => normName(p.nama) === normName(t));
    if (!hit) {
        const hs = pegawai.filter(p => p.nama.toLowerCase().includes(lq) || normName(p.nama).includes(normName(t)));
        if (hs.length === 1)
            hit = hs[0];
    }
    return hit ? String(hit.kode) : null;
}
function splitPeople(s) {
    const toks = String(s || "").split(/[;\n]/).flatMap(x => x.split(",")).map(t => t.trim()).filter(Boolean), out = [];
    for (const t of toks) {
        if (out.length && !resolvePeg(t) && /^(s\.|s\s|a\.|m\.|sh\b|se\b|sst|ss\b|dr|ir\b|amd|skm|spd)/i.test(t))
            out[out.length - 1] += ", " + t;
        else
            out.push(t);
    }
    return out;
}
const pegLabel = (c) => { const p = pegMap()[c]; return p ? p.nama : String(c ?? ""); };
const isPegName = (v) => { const t = String(v || "").trim(); return !!t && pegawai.some(p => p.nama === t); };
/* kampung & tarif */
const kKey = (k) => k.distrik + "|" + k.kampung;
const kamByKey = () => Object.fromEntries(kampungDB.map(k => [kKey(k), k]));
/** kampung berlabel Lokal (kolom Lokal di Tarif Transport; bawaan dari keterangan "Lokal") */
const kamLokal = (k) => k.lokal ?? /lokal/i.test(k.ket ?? "");
/** kampung non-Lokal pada surat Lokal → pesan galat (null bila sah) */
function lokalErr(r) {
    if (!isLokal(r))
        return null;
    const M = kamByKey(), bad = normChips(r._kampung).map(c => M[c.k]).filter((k) => !!k && !kamLokal(k));
    return bad.length ? `Surat tugas Lokal tidak bisa dipilih: kampung ${bad.map(k => title(k.kampung)).join(", ")} bukan kampung Lokal. Ganti jenis ke Remote, atau beri label Lokal di Database › Tarif Transport.` : null;
}
const kamLabel = (k) => `${title(k.kampung)} — ${title(k.distrik)} · Rp ${rupiah(k.tarif)}${k.ket ? " · " + k.ket : ""}${kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? " · Lokal" : ""}`;
const MAXTR = 30, TR_BASE = 12; // baris transport: maksimal 30, 12 baris tampil di formulir & template
const AUTO_RE = /^(Transport (PP )?Kabupaten–Kampung |Biaya [Ll]intasan |Biaya [Ii]nap [Mm]obil |Biaya Transport (Lokal |Mobil )?dari )/;
const isLokal = (r) => String(r.JENIS || "").toLowerCase() === "lokal";
const isPelatihan = (r) => String(r.JENIS || "").toLowerCase() === "pelatihan";
/* Translok+Uhar: transport dihitung cara Lokal (tarif SK × hari) + uang harian boleh diisi; tanpa inap & hotel */
const JEN_TU = "Translok+Uhar";
const isTransUhar = (r) => String(r.JENIS || "").toLowerCase() === "translok+uhar";
const trLokal = (r) => isLokal(r) || isTransUhar(r); // transport memakai aturan Lokal
const noUH = (r) => isLokal(r) || isPelatihan(r); // uang harian = 0
const noInap = (r) => noUH(r) || isTransUhar(r); // inap & hotel = 0
const formNoUH = () => ["Lokal", "Pelatihan"].includes(form.JENIS.value);
const formNoInap = () => formNoUH() || form.JENIS.value === JEN_TU;
const formTrLokal = () => form.JENIS.value === "Lokal" || form.JENIS.value === JEN_TU;
const jenisOf = (v) => { const t = String(v ?? "").trim(); return /^trans/i.test(t) ? JEN_TU : /^lok/i.test(t) ? "Lokal" : /^rem/i.test(t) ? "Remote" : /^pel/i.test(t) ? "Pelatihan" : null; };
const riilRows = (v) => Array.isArray(v) ? v.filter((x) => Array.isArray(x)).map((x) => [String(x[0] ?? ""), x[1] === "" || x[1] == null ? "" : num(x[1])]) : [];
const riilFilled = (rows) => rows.filter(([k, v]) => k.trim() !== "" || v !== "");
const RIIL_LOK_RE = /^Biaya Transport Lokal dari /;
const hotelX = (r) => Array.isArray(r._hotel2) ? r._hotel2.filter(h => h && typeof h === "object").map(h => ({ t: String(h.t ?? "").trim(), l: num(h.l), n: num(h.n) })) : [];
const hotelXN = (r) => hotelX(r).reduce((s, h) => s + h.l, 0);
const kamText = (k, pp) => `Transport Kabupaten–Kampung ${title(k.kampung)} (${pp ? "PP" : "sekali jalan"})`;
const kamValue = (k, pp) => pp ? k.tarif : Math.round(k.tarif / 2);
const normChips = (a) => (Array.isArray(a) ? a : []).map((x) => typeof x === "string" ? { k: x, pp: true } : { k: x.k, pp: x.pp !== false });
let _kIdx = null;
function kIdx() {
    if (_kIdx && _kIdx.src === kampungDB && _kIdx.n === kampungDB.length)
        return _kIdx;
    const label = new Map(), name = new Map(), loose = new Map();
    for (const k of kampungDB) {
        label.set(kamLabel(k), k);
        const n = k.kampung.toLowerCase();
        if (!name.has(n))
            name.set(n, k);
        const l = n.replace(/[^a-z]/g, "");
        if (!loose.has(l))
            loose.set(l, k);
    }
    return _kIdx = { src: kampungDB, n: kampungDB.length, label, name, loose };
}
function findKampung(text) {
    const raw = String(text || "").trim(), q = raw.replace(/^(kampung|kp\.?|kelurahan)\s+/i, "").trim();
    if (!q)
        return null;
    const I = kIdx(), lq = q.toLowerCase().replace(/\s+/g, " ");
    return I.label.get(raw) || I.name.get(lq) || I.loose.get(lq.replace(/[^a-z]/g, "")) || null;
}
function parseKampungList(text) {
    const parts = String(text || "").split(/,|;|\bdan\b|&/i).map(s => s.trim()).filter(Boolean);
    const found = [], unknown = [];
    for (const p of parts) {
        const k = findKampung(p);
        if (k) {
            if (!found.includes(k))
                found.push(k);
        }
        else
            unknown.push(p);
    }
    return { found, unknown };
}
/* Deteksi kampung dari teks yang ditempel / diketik bebas, mis.
   "Kampung Fiane, Isme dan Semu", "Kp. Framu - Distrik Ayamaru", "Pendataan di Kampung Kambuskato serta Isusu",
   atau daftar per baris. Urutan kemunculan = urutan rute. */
let _kNames = null;
function kampungNameIndex() {
    if (_kNames && _kNames.src === kampungDB && _kNames.n === kampungDB.length)
        return _kNames.list;
    const seen = new Map();
    for (const k of kampungDB) {
        const nm = acNorm(k.kampung).replace(/['’]/g, "").replace(/\s+/g, " ").trim();
        if (nm && !seen.has(nm))
            seen.set(nm, k);
    }
    const list = [...seen.entries()].sort((a, b) => b[0].length - a[0].length); // nama terpanjang dulu (mis. "kambuskato utara" sebelum "kambuskato")
    _kNames = { src: kampungDB, n: kampungDB.length, list };
    return list;
}
function detectKampung(text) {
    let t = " " + acNorm(text).replace(/['’]/g, "").replace(/[\n\r\t]+/g, ", ") + " ";
    t = t.replace(/\(([^)]*)\)/g, " , $1 , ");
    t = t.replace(/\bdistrik\s+[a-z ]+?(?=,|;|\.|$| dan | serta )/g, " , "); // buang "Distrik …"
    t = t.replace(/[^a-z0-9]+/g, " ");
    const hits = [];
    for (const [nm, k] of kampungNameIndex()) {
        const re = new RegExp("(^| )" + nm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?= |$)", "g");
        let m;
        while ((m = re.exec(t))) {
            const start = m.index + m[1].length, end = start + nm.length;
            if (hits.some(h => start < h.end && end > h.start))
                continue; // sudah tertutup nama yang lebih panjang
            hits.push({ start, end, k });
        }
    }
    hits.sort((a, b) => a.start - b.start);
    const found = [];
    for (const h of hits)
        if (!found.includes(h.k))
            found.push(h.k);
    // potongan teks yang tidak dikenali (untuk info), abaikan kata umum
    let rest = t;
    for (const h of [...hits].sort((a, b) => b.start - a.start))
        rest = rest.slice(0, h.start) + " | " + rest.slice(h.end);
    const STOP = /^(kampung|kp|kel|kelurahan|desa|dan|serta|di|ke|dari|ke|kabupaten|kab|maybrat|lokasi|tujuan|pendataan|wilayah|sekitar|kota|dsb|dll|yang)$/;
    const unknown = rest.split("|").map(x => x.trim().split(" ").filter(w => w && !STOP.test(w) && !/^\d+$/.test(w)).join(" ")).filter(x => x.length > 2);
    return { found, unknown };
}
const tujuanText = (list) => {
    const n = list.map(k => title(k.kampung));
    if (!n.length)
        return "";
    return "Kampung " + (n.length < 3 ? n.join(" dan ") : n.slice(0, -1).join(", ") + ", dan " + n[n.length - 1]);
};
function otherTransRef() {
    const m = [];
    for (const t of tarifDB) {
        const g = t.grup.toUpperCase();
        if (g.startsWith("MOBIL BANDARA"))
            m.push(["Mobil bandara " + title(t.nama), t.nilai]);
        else if (g.startsWith("MOBIL"))
            m.push([/SEWA/i.test(t.nama) ? "Sewa mobil " + title(t.nama.replace(/-?\s*SEWA MOBIL/i, "")) : "Transport mobil " + title(t.nama), t.nilai]);
        else if (g.startsWith("TRANSLOK"))
            m.push(["Transport lokal " + t.nama.replace(/^TRANSLOK\s*/i, "").toLowerCase(), t.nilai]);
    }
    return m;
}
/* kode klasifikasi */
const kodeMap = () => Object.fromEntries(kodeDB.codes.map(c => [c.k, c]));
const kodeFromNL = (nl) => { const m = String(nl || "").match(/\/([A-Z]{2,3}\.\d{3,4})\//); return m ? m[1] : ""; };
const kodeGroup = (k) => kodeDB.groups[k.split(".")[0]] || k.split(".")[0];
function composeNL(code, cur0, tgl) {
    const y = (parseTgl(tgl) || new Date()).getFullYear();
    const cur = String(cur0 || "").trim();
    if (/^\/.*\/[A-Z]{2,3}\.\d{3,4}\/\d{4}$/.test(cur))
        return cur.replace(/[A-Z]{2,3}\.\d{3,4}(?=\/\d{4}$)/, code).replace(/\/\d{4}$/, "/" + y);
    return `/BPS/ST/9204/${code}/${y}`;
}
function lookupKode(q0) {
    const q = String(q0 || "").trim();
    if (!q)
        return { c: null, n: 0 };
    const c = kodeMap()[q.toUpperCase()];
    if (c)
        return { c, n: 1 };
    const hits = kodeDB.codes.filter(x => x.d.toLowerCase().includes(q.toLowerCase()));
    return { c: hits.length === 1 ? hits[0] : null, n: hits.length };
}

/* ---- 20_record.ts ---- */
/* ================= record model ================= */
const lampOf = (r) => Array.isArray(r.lampiran) ? r.lampiran.map(String).filter(Boolean)
    : [1, 2, 3, 4, 5].map(i => r["KodeLampiran" + i]).filter(v => v != null && String(v).trim() !== "").map(v => String(v).trim());
function setLamp(r, list) {
    r.lampiran = list.slice();
    for (let i = 1; i <= 5; i++) {
        if (list[i - 1] != null)
            r["KodeLampiran" + i] = String(list[i - 1]);
        else
            delete r["KodeLampiran" + i];
    }
}
/* rebuild SK-transport rows of a record from its _kampung list (manual rows kept, after SK rows) */
function applyKampungToRec(r) {
    const M = kamByKey(), list = normChips(r._kampung).map(c => ({ ...c, kam: M[c.k] })).filter(c => c.kam);
    const manual = [];
    for (let i = 1; i <= MAXTR; i++) {
        const ket = r["KetTransport_" + i], v = r["Nilai" + i];
        delete r["KetTransport_" + i];
        delete r["Nilai" + i];
        if (ket && AUTO_RE.test(ket))
            continue;
        if ((ket != null && ket !== "") || (v != null && v !== ""))
            manual.push([ket ?? "", v]);
    }
    const base = String(r.TEMPAT_BERANGKAT || "Kampung Semu").trim(), K = (c) => "Kampung " + title(c.kam.kampung);
    const rows = [], riilAuto = [];
    if (trLokal(r)) {
        // Lokal: tiap kampung = Biaya Transport Lokal dari <berangkat> ke <kampung> (tarif SK, PP / ½)
        // Lokal: tarif per hari × banyak hari perjalanan
        // beberapa kampung: lama hari dibagi rata, sisa pembagian ke kampung paling awal (4 hari, 3 kampung → 2, 1, 1)
        // kampung berlabel Lokal: tanpa bukti → Daftar Pengeluaran Riil baris "2. Uang Transport Lokal" (r._riilLok), bukan baris transport rincian
        const hari = Math.max(1, num(r.LAMA_JALAN) || 1), n = list.length, per = Math.floor(hari / n), sisa = hari % n;
        list.forEach((c, i) => {
            const h = per + (i < sisa ? 1 : 0);
            if (!h)
                return;
            const unit = kamValue(c.kam, c.pp);
            const row = [`Biaya Transport Lokal dari ${base} ke ${K(c)} (${h} hari x ${rupiah(unit)}${c.pp ? "" : ", sekali jalan"})`, unit * h];
            if (kamLokal(c.kam))
                riilAuto.push(row);
            else
                rows.push(row);
        });
    }
    else if (list.length) {
        // Remote: berangkat → kampung 1 (½ tarif SK), lintasan antar kampung, kampung terakhir → pulang (½ tarif SK)
        const first = list[0], last = list[list.length - 1];
        const mobil = list.some(c => c.kam.tarif > rule("BATAS TRANSPORT"));
        if (mobil) {
            // tarif SK > batas: Transport Mobil (tarif SK penuh, tidak dibagi dua), Lintasan Mobil antar kampung, Inap Mobil (lama − 1) malam
            rows.push([`Biaya Transport Mobil dari ${base} ke ${K(first)}`, kamValue(first.kam, true)]);
            for (let i = 1; i < list.length; i++)
                rows.push([`Biaya Lintasan Mobil dari ${K(list[i - 1])} ke ${K(list[i])}`, minLintasMobil()]);
            const nights = Math.max(0, num(r.LAMA_JALAN) - 1), im = rule("INAP MOBIL");
            if (nights)
                rows.push([`Biaya Inap Mobil (${nights} Malam x ${rupiah(im)})`, nights * im]);
        }
        else {
            rows.push([`Biaya Transport dari ${base} ke ${K(first)}`, kamValue(first.kam, false)]);
            for (let i = 1; i < list.length; i++)
                rows.push([`Biaya Lintasan dari ${K(list[i - 1])} ke ${K(list[i])}`, rule("LINTASAN ANTAR")]);
            rows.push([`Biaya Transport dari ${K(last)} ke ${base}`, kamValue(last.kam, false)]);
        }
    }
    rows.push(...manual);
    {
        const all = [...riilAuto, ...riilFilled(riilRows(r._riilLok)).filter(([k]) => !AUTO_RE.test(k))];
        if (all.length)
            r._riilLok = all;
        else
            delete r._riilLok;
    }
    rows.slice(0, MAXTR).forEach(([k, v], i) => { if (k !== "")
        r["KetTransport_" + (i + 1)] = k; if (v != null && v !== "")
        r["Nilai" + (i + 1)] = v; });
    return rows.length > MAXTR;
}
/** nilai turunan surat (nama, NIP, total biaya, terbilang) — kolom mengikuti MERGEFIELD template */
function compute(r) {
    const P = pegMap(), g = (k) => { const c = codeOf(r[k]); return c === "" ? null : (P[c] || null); };
    const o = {};
    o.NO = r.NO ?? "";
    o.NoLengkap = r.NoLengkap ?? "";
    o.NOSURTUG = "B-" + o.NO;
    o.NOMOR_ST = o.NOSURTUG + o.NoLengkap;
    o.NOMOR_SPD = o.NOMOR_ST;
    o.TGL_TERBIT_ST = r.TGL_TERBIT_ST ?? "";
    o.TGL_SPD = o.TGL_TERBIT_ST;
    for (const k of ["kegiatan", "MAKSUD__TUJUAN", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT", "TEMPAT_TUJUAN", "TGL_PERGI", "TGL_PULANG", "MAK", "TGL_KUI"])
        o[k] = r[k] ?? "";
    o.LAMA_JALAN = r.LAMA_JALAN ?? "";
    const pl = g("KD_NAMA_SPD");
    o.NAMA_PELAKSANA_SPD = pl ? pl.nama : "";
    o.NIP_PELAKSANA_SPD = pl ? pl.nip : "";
    o.JABATAN = pl ? pl.jabatan : "";
    o.PANGKAT = pl ? pl.pangkat : "";
    o.GOL = pl ? pl.gol : "";
    const ppk = g("No_PPK");
    o.PPK = ppk ? ppk.nama : "";
    o.NIP_PPK = ppk ? ppk.nip : "";
    const ka = g("KD_NAMA_KA_PLT_PLH");
    o.KAPLTPLH = ka ? ka.nama : "";
    const ks = g("KDSPPD");
    o.KepalaSPPD = ks ? ks.nama : "";
    o.NIPKepala = ks ? ks.nip : "";
    const be = g("No_Bend");
    o.BEND = be ? be.nama : "";
    o.NIP_BEND = be ? be.nip : "";
    const lamp = lampOf(r);
    o._lampN = lamp.length;
    {
        const M = kamByKey();
        o._kam = normChips(r._kampung).map(c => M[c.k]).filter((k) => !!k).map(k => title(k.kampung));
    }
    for (let i = 1; i <= Math.max(5, lamp.length); i++) {
        const p = lamp[i - 1] != null ? P[lamp[i - 1]] : null;
        o[i === 1 ? "NAMALAMPIRAN_1" : "NAMA_LAMPIRAN_" + i] = p ? p.nama : "";
        o["NIP_LAMPIRAN_" + i] = p ? p.nip : "";
        o["JABATAN_LAMPIRAN_" + i] = p ? p.jabatan : "";
        o["PANGKAT_LAMPIRAN_" + i] = p ? p.pangkat : "";
        o["GOL_LAMPIRAN_" + i] = p ? p.gol : "";
    }
    const lok = noUH(r), noI = noInap(r);
    const inap = noI ? 0 : num(r.LAMA_INAP), tdk = num(r.TDK_INAP_HOTEL), luh = lok ? 0 : num(r.LAMA_UH), nuh = num(r.NILAI_UH);
    let sumTr = 0;
    for (let i = 1; i <= MAXTR; i++) {
        o["KetTransport_" + i] = r["KetTransport_" + i] ?? "";
        const v = r["Nilai" + i];
        o["Nilai" + i] = (v === "" || v == null) ? "" : rupiah(num(v));
        sumTr += num(v);
    }
    const totInap = inap * tdk, totUH = luh * nuh;
    /* pengeluaran riil tanpa bukti (Daftar Pengeluaran Riil): 1. penginapan, 2. transport lokal, 3. mobil bandara */
    const rLok = riilFilled(riilRows(r._riilLok)), rBdr = riilFilled(riilRows(r._riilBdr));
    const totLok = rLok.reduce((s, x) => s + num(x[1]), 0), totBdr = rBdr.reduce((s, x) => s + num(x[1]), 0), totRiil = totInap + totLok + totBdr;
    const totTr = sumTr + totLok + totBdr; // seluruh transport: baris rincian (sumTr) + transport riil
    /* hotel dengan bukti: hotel pertama (HOTEL_TEMPAT / LAMA_HOTEL / TARIF_HOTEL) + hotel tambahan (_hotel2) */
    const th = num(r.TARIF_HOTEL), hotels = noI ? [] : [{ t: String(r.HOTEL_TEMPAT || "").trim(), l: num(r.LAMA_HOTEL), n: th }, ...hotelX(r)].filter(h => h.l > 0);
    const lh = hotels.reduce((s, h) => s + h.l, 0), totHotel = hotels.reduce((s, h) => s + h.l * h.n, 0);
    const jml = totInap + totUH + totTr + totHotel;
    Object.assign(o, {
        LAMA_INAP: String(inap), TDK_INAP_HOTEL: rupiah(tdk), TOTAL_BIAYA_TDK_INAP_HOTEL: rupiah(totInap), PENG_RIIL: rupiah(totRiil),
        Terbilang3: terbilang(totRiil), LAMA_UH: String(luh), NILAI_UH: rupiah(nuh), TOTAL_UH: rupiah(totUH),
        TOTAL_TRANS: rupiah(totTr), JUMLAH: rupiah(jml), TERBILANG: terbilang(jml),
        HOTEL_TEMPAT: String(r.HOTEL_TEMPAT || "").trim(), LAMA_HOTEL: String(lh), TARIF_HOTEL: rupiah(th), TOTAL_HOTEL: rupiah(totHotel)
    });
    o._hotels = hotels;
    o._riilLok = rLok;
    o._riilBdr = rBdr;
    const ps = personCodes(r, P), orang = Math.max(1, ps.length);
    let jmlTotal = jml * orang;
    if (!r._isPerson && r._perOrang && ps.length > 1)
        jmlTotal = ps.reduce((sum, c) => sum + compute(personRec(r, c))._num.jml, 0);
    o._num = { totInap, totUH, totTr, totHotel, lh0: noI ? 0 : num(r.LAMA_HOTEL) * th, totLok, totBdr, totRiil, lh, th, jml, sumTr, inap, tdk, luh, nuh, orang, jmlTotal };
    return o;
}
/* orang yang menerima rincian biaya: pelaksana (bukan "Terlampir") + semua anggota lampiran */
function personCodes(r, P = pegMap()) {
    const out = [], k = codeOf(r.KD_NAMA_SPD);
    if (k && k !== "999" && P[k] && !/^terlampir$/i.test(String(P[k].nama).trim()))
        out.push(k);
    for (const c of lampOf(r))
        if (P[c] && !out.includes(c))
            out.push(c);
    return out;
}
function teamOf(r, P = pegMap()) {
    const cs = personCodes(r, P), isPeg = (c) => !!P[c] && !isMitra(P[c]) && !isSystemPeg(P[c]);
    const peg = cs.filter(isPeg), mit = cs.filter(c => !isPeg(c)), pel = codeOf(r.KD_NAMA_SPD);
    const prio = isPeg(pel) ? 0 : peg.length ? 1 : 2;
    const first = isPeg(pel) ? pel : (peg[0] || cs[0]);
    const short = (c) => String(P[c]?.nama || "").split(",")[0];
    return { codes: cs, peg, mit, prio, label: first ? short(first) + (cs.length > 1 ? ` +${cs.length - 1}` : "") : "-", names: [...peg, ...mit].map(c => ({ c, nama: short(c), peg: isPeg(c) })) };
}
/* satu surat → satu rekaman per orang untuk dokumen Rincian Biaya */
/* rincian satu orang: nilai surat + nilai khusus orang tsb (r._perOrang[kode]) */
const PO_FIELDS = ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL", "HOTEL_TEMPAT"];
function personRec(r, c) {
    const o = (r._perOrang || {})[c] || {}, x = { ...r, KD_NAMA_SPD: c, _isPerson: true };
    delete x._perOrang;
    for (const k of PO_FIELDS)
        if (o[k] != null && o[k] !== "")
            x[k] = o[k];
    // malam hotel khusus orang ini → malam "tanpa hotel" ikut menyesuaikan (bila tidak diisi khusus & surat memakai hitungan otomatis)
    if (o.LAMA_HOTEL != null && o.LAMA_HOTEL !== "" && (o.LAMA_INAP == null || o.LAMA_INAP === "")) {
        const L = num(r.LAMA_JALAN), xN = hotelXN(r), autoBase = Math.max(0, L - 1 - num(r.LAMA_HOTEL) - xN);
        if (L && num(r.LAMA_INAP) === autoBase)
            x.LAMA_INAP = Math.max(0, L - 1 - num(o.LAMA_HOTEL) - xN);
    }
    if (Array.isArray(o.trans)) {
        for (let i = 1; i <= MAXTR; i++) {
            delete x["KetTransport_" + i];
            delete x["Nilai" + i];
        }
        o.trans.slice(0, MAXTR).forEach(([k, v], i) => { if (k)
            x["KetTransport_" + (i + 1)] = k; if (v !== "" && v != null)
            x["Nilai" + (i + 1)] = v; });
        delete x.TOTAL_TRANS;
    }
    if (Array.isArray(o.riilLok)) {
        if (o.riilLok.length)
            x._riilLok = o.riilLok;
        else
            delete x._riilLok;
    } // transport lokal riil khusus orang ini
    return x;
}
function biayaRecs(r) {
    const ps = personCodes(r);
    if (!ps.length)
        return [r];
    return ps.map(c => personRec(r, c));
}
const expandBiaya = (recs) => recs.flatMap(biayaRecs);

/* ---- 30_docx.ts ---- */
/* ================= DOCX generation ================= */
const WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
/** simpul XML berupa elemen (nodeType 1) */
const isEl = (n) => !!n && n.nodeType === 1;
const kids = (el, name) => [...el.childNodes].filter((n) => isEl(n) && n.namespaceURI === WNS && n.localName === name);
/** leluhur terdekat (termasuk n sendiri) bernama `name` di namespace w: */
const upTo = (n, name) => { for (let x = n; x; x = x.parentNode)
    if (isEl(x) && x.namespaceURI === WNS && x.localName === name)
        return x; return null; };
const xmlOut = (doc) => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + new XMLSerializer().serializeToString(doc).replace(/^<\?xml[^>]*\?>\s*/, "");
/* add rows to the Lampiran ST table when there are more than 5 members */
function growLampiran(doc, n) {
    if (n <= 5)
        return;
    const instr = [...doc.getElementsByTagNameNS(WNS, "instrText")].find(t => /NAMA_LAMPIRAN_5\b/.test(t.textContent));
    if (!instr)
        return;
    const tr = upTo(instr, "tr");
    if (!tr)
        return;
    let after = tr;
    for (let i = 6; i <= n; i++) {
        const c = tr.cloneNode(true);
        for (const t of c.getElementsByTagNameNS(WNS, "instrText"))
            t.textContent = t.textContent.replace(/_LAMPIRAN_5\b/g, "_LAMPIRAN_" + i);
        const firstCell = c.getElementsByTagNameNS(WNS, "tc")[0];
        if (firstCell)
            for (const t of firstCell.getElementsByTagNameNS(WNS, "t"))
                if (/^\s*5\.?\s*$/.test(t.textContent))
                    t.textContent = i + ".";
        after.parentNode.insertBefore(c, after.nextSibling);
        after = c;
    }
}
const ROMAN = (n) => { const v = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]; let s = ""; for (const [a, r] of v)
    while (n >= a) {
        s += r;
        n -= a;
    } return s; };
const cellText = (tc) => [...tc.getElementsByTagNameNS(WNS, "t")].map(t => t.textContent).join("").trim();
function setCellText(doc, tc, text, like) {
    const p = tc.getElementsByTagNameNS(WNS, "p")[0];
    if (!p)
        return;
    for (const r of [...kids(p, "r")])
        p.removeChild(r);
    const ppr = kids(p, "pPr")[0];
    if (ppr)
        for (const j of kids(ppr, "jc"))
            ppr.removeChild(j); // rata kiri
    const r = doc.createElementNS(WNS, "w:r"), lr = like && like.getElementsByTagNameNS(WNS, "r")[0], rp = lr && kids(lr, "rPr")[0];
    if (rp)
        r.appendChild(rp.cloneNode(true));
    const t = doc.createElementNS(WNS, "w:t");
    t.setAttribute("xml:space", "preserve");
    t.textContent = text;
    r.appendChild(t);
    p.appendChild(r);
}
/* Lampiran SPPD: pakai versi template 5-kolom, jumlah blok "Tiba di / Berangkat dari" = jumlah kampung tujuan */
function fitSppd(doc, kam, base) {
    /* tidak ada kampung yang dikenali di SK Transport → 4 blok tanda tangan kosong (tempat diisi tangan) */
    const n0 = kam.length, n = n0 || 4;
    const body = doc.getElementsByTagNameNS(WNS, "body")[0], nodes = [...body.childNodes];
    const marks = nodes.filter((x) => isEl(x) && x.localName === "p" && cellText(x) === "Lampiran SPPD");
    if (marks.length < 2)
        return;
    const i1 = nodes.indexOf(marks[0]), i2 = nodes.indexOf(marks[1]);
    const after = nodes.slice(i2 + 1).filter((x) => isEl(x) && x.localName === "tbl");
    const tStops = after[0], tEnd = after[1];
    if (!tStops || !tEnd)
        return;
    // buang versi 10-kolom (antara penanda pertama dan kedua)
    for (const x of nodes.slice(i1, i2))
        if (!(isEl(x) && x.localName === "p" && kids(x, "pPr")[0] && kids(kids(x, "pPr")[0], "sectPr")[0]))
            body.removeChild(x);
    const rows = kids(tStops, "tr"), isRoman = (tr) => { const c = kids(tr, "tc")[0]; return c && /^[IVX]+\.$/.test(cellText(c)); };
    const groups = [];
    let g = null;
    rows.forEach(tr => { if (isRoman(tr) && cellText(kids(tr, "tc")[0]) !== "I.") {
        g = [tr];
        groups.push(g);
    }
    else if (g)
        g.push(tr); });
    if (!groups.length)
        return;
    // semua blok disalin dari blok II supaya lebar kolom seragam
    while (groups.length > 1) {
        for (const tr of groups.pop())
            tStops.removeChild(tr);
    }
    while (groups.length < n) {
        const cl = groups[0].map(tr => tr.cloneNode(true));
        for (const tr of cl)
            tStops.appendChild(tr);
        groups.push(cl);
    }
    const nameOf = (i) => i < n ? (n0 ? "Kampung " + kam[i] : "") : base;
    // baris I: "Ke : kampung pertama"
    for (const tr of rows.slice(0, 6)) {
        const cs = kids(tr, "tc"), ix = cs.findIndex(c => cellText(c) === "Ke");
        if (ix >= 0 && cs[ix + 2]) {
            setCellText(doc, cs[ix + 2], nameOf(0), cs[ix]);
            break;
        }
    }
    groups.forEach((grp, i) => {
        setCellText(doc, kids(grp[0], "tc")[0], ROMAN(i + 2) + ".", kids(grp[0], "tc")[0]);
        for (const tr of grp) {
            const cs = kids(tr, "tc");
            cs.forEach((c, j) => {
                const t = cellText(c), v = cs[j + 2];
                if (!v || cellText(cs[j + 1] || c) !== ":")
                    return;
                if (t === "Tiba di" || t === "Berangkat dari")
                    setCellText(doc, v, nameOf(i), c);
                else if (t === "Ke")
                    setCellText(doc, v, nameOf(i + 1), c);
            });
        }
    });
    // nomor bagian penutup: Tiba kembali, Catatan, Perhatian
    let k = n + 2;
    for (const tr of kids(tEnd, "tr")) {
        const c = kids(tr, "tc")[0];
        if (c && /^[IVX]+\.$/.test(cellText(c)))
            setCellText(doc, c, ROMAN(k++) + ".", c);
    }
}
/* Lampiran SPPD: "Pada tanggal" berangkat (blok I) = tgl pergi, "Pada tanggal" tiba kembali = tgl pulang */
function fillSppdDates(doc, pergi, pulang) {
    const body = doc.getElementsByTagNameNS(WNS, "body")[0], nodes = [...body.childNodes];
    const start = nodes.findIndex(x => isEl(x) && x.localName === "p" && cellText(x) === "Lampiran SPPD");
    if (start < 0)
        return;
    const end = nodes.findIndex((x, i) => i > start && (x.textContent || "").includes("KUITANSI"));
    for (const t of nodes.slice(start, end < 0 ? undefined : end).filter((x) => isEl(x) && x.localName === "tbl")) {
        let mode = null, left = 0;
        for (const tr of kids(t, "tr")) {
            const cs = kids(tr, "tc"), tx = cs.map(cellText);
            if (tx.includes("Berangkat Dari")) {
                mode = pergi;
                left = 4;
            }
            else if (tx.includes("Tiba kembali di")) {
                mode = pulang;
                left = 4;
            }
            if (left-- > 0 && mode) {
                const j = tx.indexOf("Pada tanggal");
                if (j >= 0 && cs[j + 2] && tx[j + 1] === ":") {
                    setCellText(doc, cs[j + 2], mode, cs[j]);
                    mode = null;
                }
            }
        }
    }
}
/* Rincian baris 5: "Uang penginapan di … malam @ …" + jumlahnya; lebih dari satu hotel → baris ditambah */
function fillHotel(doc, F) {
    const RE = /^\s*Uang penginapan di\s+malam\s*@\s*$/;
    const t = [...doc.getElementsByTagNameNS(WNS, "t")].find(x => RE.test(x.textContent));
    if (!t)
        return;
    const tr = upTo(t, "tr");
    if (!tr)
        return;
    const hs = F._hotels || [];
    const put = (row, h, first) => {
        const tt = [...row.getElementsByTagNameNS(WNS, "t")].find(x => RE.test(x.textContent));
        if (tt && h) {
            tt.textContent = `Uang penginapan di ${h.t ? h.t + " " : ""}${h.l} malam @ ${rupiah(h.n)}`;
            tt.setAttribute("xml:space", "preserve");
        }
        const cells = kids(row, "tc");
        if (!first && cells[0])
            for (const x of cells[0].getElementsByTagNameNS(WNS, "t"))
                x.textContent = ""; // nomor "5." hanya di baris pertama
        const amt = cells.slice(2).map(c => [...c.getElementsByTagNameNS(WNS, "t")]).find(ts => ts.some(x => /^\s*0\s*$/.test(x.textContent)));
        if (amt) {
            const z = amt.find(x => /^\s*0\s*$/.test(x.textContent));
            z.textContent = z.textContent.replace("0", rupiah(h ? h.l * h.n : 0));
        }
    };
    const extra = hs.slice(1).map(() => tr.cloneNode(true));
    put(tr, hs[0], true);
    let after = tr;
    extra.forEach((row, i) => { put(row, hs[i + 1], false); after.parentNode.insertBefore(row, after.nextSibling); after = row; });
}
/* Daftar Pengeluaran Riil: "2. Uang Transport Lokal" dan "3. Uang Transport Mobil Bandara" — judul + satu baris per rincian (keterangan, Rp, nilai) */
function fillRiil(doc, F) {
    const t = [...doc.getElementsByTagNameNS(WNS, "t")].find(x => x.textContent.trim() === "Uang Transport Lokal");
    if (!t)
        return;
    const tr = upTo(t, "tr"), run = upTo(t, "r");
    if (!tr || !run)
        return;
    const rPr = kids(run, "rPr")[0] || null, lok = F._riilLok || [], bdr = F._riilBdr || [];
    const say = (tc, text) => {
        const p = tc?.getElementsByTagNameNS(WNS, "p")[0];
        if (!p)
            return;
        for (const r of [...kids(p, "r")])
            p.removeChild(r);
        if (text === "")
            return;
        const r = doc.createElementNS(WNS, "w:r");
        if (rPr)
            r.appendChild(rPr.cloneNode(true));
        const x = doc.createElementNS(WNS, "w:t");
        x.setAttribute("xml:space", "preserve");
        x.textContent = text;
        r.appendChild(x);
        p.appendChild(r);
    };
    /* tiga sel uraian (nama · banyaknya · @tarif) digabung jadi satu supaya keterangan panjang muat → sel: [no, uraian, Rp, nilai, ket, …] */
    const wide = (row) => {
        const cs = kids(row, "tc");
        if (cs.length < 6)
            return cs;
        const part = cs.slice(1, 4), pr = kids(part[0], "tcPr")[0];
        if (pr) {
            let w = 0, g = 0;
            for (const c of part) {
                const q = kids(c, "tcPr")[0], tw = q && kids(q, "tcW")[0], gs = q && kids(q, "gridSpan")[0];
                w += Number(tw?.getAttributeNS(WNS, "w") || 0);
                g += Number(gs?.getAttributeNS(WNS, "val") || 1);
            }
            const tw = kids(pr, "tcW")[0];
            if (tw)
                tw.setAttributeNS(WNS, "w:w", String(w));
            let gs = kids(pr, "gridSpan")[0];
            if (!gs) {
                gs = doc.createElementNS(WNS, "w:gridSpan");
                pr.insertBefore(gs, tw ? tw.nextSibling : pr.firstChild);
            }
            gs.setAttributeNS(WNS, "w:val", String(g));
            const bo = kids(pr, "tcBorders")[0];
            if (bo)
                for (const x of kids(bo, "right"))
                    bo.removeChild(x); // garis kanan mengikuti sel terakhir yang digabung
        }
        row.removeChild(part[1]);
        row.removeChild(part[2]);
        return kids(row, "tc");
    };
    const noNum = (tc) => { for (const p of tc ? [...tc.getElementsByTagNameNS(WNS, "numPr")] : [])
        p.parentNode.removeChild(p); };
    const detail = (row) => { const x = tr.cloneNode(true), cs = wide(x); noNum(cs[0]); say(cs[1], "- " + row[0].trim()); say(cs[2], "Rp."); say(cs[3], rupiah(num(row[1]))); return x; };
    const head2 = tr.cloneNode(true); // "3." — nomor otomatis mengikuti daftar bernomor template
    const out = [...lok.map(detail), head2, ...bdr.map(detail)];
    say(wide(head2)[1], "Uang Transport Mobil Bandara");
    wide(tr);
    let after = tr;
    for (const x of out) {
        after.parentNode.insertBefore(x, after.nextSibling);
        after = x;
    }
    if (lok.length || bdr.length)
        for (const x of doc.getElementsByTagNameNS(WNS, "t"))
            if (x.textContent.includes("pada angka 1 di atas"))
                x.textContent = x.textContent.replace("pada angka 1 di atas", "pada angka 1 s.d. 3 di atas");
}
function fillDoc(doc, F) {
    const runs = [...doc.getElementsByTagNameNS(WNS, "r")];
    const stack = [];
    for (const r of runs) {
        for (const fr of stack)
            fr.runs.push(r);
        for (const ch of [...r.childNodes]) {
            if (!isEl(ch) || ch.namespaceURI !== WNS)
                continue;
            if (ch.localName === "fldChar") {
                const ty = ch.getAttributeNS(WNS, "fldCharType");
                if (ty === "begin")
                    stack.push({ instr: "", phase: "instr", runs: [r], rPr: null });
                else if (ty === "separate" && stack.length)
                    stack[stack.length - 1].phase = "res";
                else if (ty === "end" && stack.length) {
                    const fr = stack.pop();
                    const m = fr.instr.trim().match(/^MERGEFIELD\s+"?([^\s"\\]+)/i);
                    if (!m)
                        continue;
                    const val = m[1] in F ? String(F[m[1]] ?? "") : "";
                    const nr = doc.createElementNS(WNS, "w:r");
                    const rp = fr.rPr || kids(fr.runs[0], "rPr")[0];
                    if (rp) {
                        const c = rp.cloneNode(true);
                        for (const h of kids(c, "highlight"))
                            c.removeChild(h);
                        nr.appendChild(c);
                    }
                    val.split("\n").forEach((line, i) => {
                        if (i)
                            nr.appendChild(doc.createElementNS(WNS, "w:br"));
                        const t = doc.createElementNS(WNS, "w:t");
                        t.setAttribute("xml:space", "preserve");
                        t.textContent = line;
                        nr.appendChild(t);
                    });
                    const first = fr.runs[0];
                    first.parentNode.insertBefore(nr, first);
                    for (const x of new Set(fr.runs))
                        if (x.parentNode)
                            x.parentNode.removeChild(x);
                    for (const o of stack)
                        o.runs.push(nr);
                }
            }
            else if (ch.localName === "instrText" && stack.length && stack[stack.length - 1].phase === "instr") {
                stack[stack.length - 1].instr += ch.textContent;
            }
            else if (ch.localName === "t" && stack.length) {
                const top = stack[stack.length - 1];
                if (top.phase === "res" && !top.rPr)
                    top.rPr = kids(r, "rPr")[0] || null;
            }
        }
    }
}
/* template sections: 0 = Surat Tugas, 1 = SPD, 2 = Lampiran SPPD + dokumen biaya, 3 = Lampiran ST.
   Section 2 is split at the KUITANSI block into "sppd" (hal. 3–5) and "biaya" (hal. 6–9). */
const PART_OF_SECTION = [["st"], ["spd"], ["sppd", "biaya"], ["lamp"]];
const FILE_ST = ["st", "spd", "sppd", "lamp"], FILE_BIAYA = ["biaya"];
function keepParts(doc, keep) {
    const body = doc.getElementsByTagNameNS(WNS, "body")[0];
    const secs = [];
    let cur = [];
    for (const n of [...body.childNodes]) {
        if (isEl(n) && n.namespaceURI === WNS && n.localName === "sectPr") {
            secs.push({ nodes: cur, sp: n, body: true });
            cur = [];
            continue;
        }
        cur.push(n);
        const sp = isEl(n) && n.localName === "p" && kids(n, "pPr")[0] ? kids(kids(n, "pPr")[0], "sectPr")[0] : undefined;
        if (sp) {
            secs.push({ nodes: cur, sp, body: false });
            cur = [];
        }
    }
    if (secs.length !== PART_OF_SECTION.length)
        return; // unknown template layout → keep all
    const kept = secs.map((s, i) => PART_OF_SECTION[i].some(p => keep.has(p)));
    if (!kept.some(Boolean))
        return;
    // partial keep inside the SPPD/biaya section
    const ks = secs[2];
    if (kept[2] && !(keep.has("sppd") && keep.has("biaya"))) {
        const cut = ks.nodes.findIndex(n => (n.textContent || "").includes("KUITANSI"));
        if (cut > 0) {
            const holder = ks.body ? null : ks.nodes[ks.nodes.length - 1]; // paragraph carrying the section break stays
            const drop = keep.has("sppd") ? ks.nodes.slice(cut) : ks.nodes.slice(0, cut);
            for (const n of drop)
                if (n !== holder && n.parentNode)
                    n.parentNode.removeChild(n);
        }
    }
    const lastKept = kept.lastIndexOf(true);
    secs.forEach((s, i) => { if (!kept[i])
        for (const n of s.nodes)
            if (n.parentNode)
                n.parentNode.removeChild(n); });
    const last = secs[secs.length - 1];
    if (!kept[secs.length - 1]) {
        const sp = secs[lastKept].sp;
        sp.parentNode.removeChild(sp);
        body.replaceChild(sp, last.sp);
    }
}
function fitTransport(doc, n) {
    const it = [...doc.getElementsByTagNameNS(WNS, "instrText")].find(x => /MERGEFIELD\s+"?KetTransport_1\b/.test(x.textContent));
    if (!it)
        return;
    const tc = upTo(it, "tc"), tr = tc?.parentNode;
    if (!tc || !isEl(tr) || tr.localName !== "tr")
        return;
    const K = kids(tc, "p").length;
    if (K < 2)
        return;
    const cells = kids(tr, "tc"), N = Math.max(K, n);
    const strip = (p) => {
        for (const c of [...p.childNodes])
            if (!(isEl(c) && c.namespaceURI === WNS && c.localName === "pPr"))
                p.removeChild(c);
        const pp = kids(p, "pPr")[0];
        if (pp)
            for (const x of kids(pp, "numPr"))
                pp.removeChild(x);
        return p;
    };
    const out = [];
    for (let j = 0; j < N; j++) {
        const nt = tr.cloneNode(false);
        for (const ch of [...tr.childNodes])
            if (!(isEl(ch) && ch.namespaceURI === WNS && ch.localName === "tc"))
                nt.appendChild(ch.cloneNode(true));
        for (const trPr of kids(nt, "trPr"))
            for (const h of kids(trPr, "trHeight"))
                trPr.removeChild(h);
        for (const c of cells) {
            const ps = kids(c, "p"), nc = c.cloneNode(false);
            for (const ch of [...c.childNodes])
                if (isEl(ch) && ch.namespaceURI === WNS && ch.localName === "tcPr")
                    nc.appendChild(ch.cloneNode(true));
            let pa;
            if (ps.length === K) {
                pa = ps[Math.min(j, K - 1)].cloneNode(true);
                if (c === tc)
                    for (const x of [...pa.getElementsByTagNameNS(WNS, "t")])
                        if (x.textContent.trim() === ".")
                            x.textContent = ""; // titik nyasar di template (baris 8)
                if (j >= K) {
                    for (const x of pa.getElementsByTagNameNS(WNS, "instrText"))
                        x.textContent = x.textContent.replace(/(KetTransport_|Nilai)\d+/, "$1" + (j + 1));
                    for (const x of pa.getElementsByTagNameNS(WNS, "t"))
                        if (!/^\s*Rp\.?\s*$/.test(x.textContent))
                            x.textContent = "";
                }
            }
            else
                pa = j === 0 ? ps[0].cloneNode(true) : strip(ps[0].cloneNode(true));
            nc.appendChild(pa);
            nt.appendChild(nc);
        }
        out.push(nt);
    }
    for (const r of out)
        tr.parentNode.insertBefore(r, tr);
    tr.parentNode.removeChild(tr);
}
/* template terpisah: Surat Tugas (ST, SPD, Lampiran SPPD, Lampiran ST) dan Rincian Biaya (kuitansi, rincian, pernyataan).
   Template lama (satu file berisi semuanya, tanpa .kind) tetap dipakai untuk keduanya sampai diganti. */
const tplB64 = (kind = "st") => kind === "rb" ? (templateRB ? templateRB.b64 : template && !template.kind ? template.b64 : TEMPLATE_RB_DEFAULT) : (template ? template.b64 : TEMPLATE_DEFAULT);
const ALL_PARTS = ["st", "spd", "sppd", "biaya", "lamp"];
async function buildDocx(rec, parts) {
    const F = compute(rec);
    const keep = new Set(parts || ALL_PARTS);
    if (isPelatihan(rec)) {
        keep.delete("spd");
        keep.delete("sppd");
    } // pelatihan: hanya Surat Tugas (+ Lampiran ST)
    if (!F._lampN)
        keep.delete("lamp");
    if (!keep.size)
        keep.add("st");
    const kind = [...keep].every(p => FILE_BIAYA.includes(p)) ? "rb" : "st";
    const zip = await JSZip.loadAsync(tplB64(kind), { base64: true });
    let nTr = 0;
    for (let i = 1; i <= MAXTR; i++)
        if (F["KetTransport_" + i] || F["Nilai" + i])
            nTr = i;
    for (const p of Object.keys(zip.files)) {
        if (!/^word\/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$/.test(p))
            continue;
        const x = await zip.file(p).async("string");
        if (!x.includes("MERGEFIELD") && p !== "word/document.xml")
            continue;
        const doc = new DOMParser().parseFromString(x, "application/xml");
        if (p === "word/document.xml") {
            growLampiran(doc, F._lampN);
            fitSppd(doc, F._kam, F.TEMPAT_BERANGKAT || "Kampung Semu");
            fillSppdDates(doc, F.TGL_PERGI, F.TGL_PULANG);
            fillHotel(doc, F);
            fillRiil(doc, F);
            keepParts(doc, keep);
            if (keep.has("biaya"))
                fitTransport(doc, nTr);
        }
        fillDoc(doc, F);
        zip.file(p, xmlOut(doc));
    }
    const sp = "word/settings.xml";
    if (zip.file(sp)) {
        let s = await zip.file(sp).async("string");
        s = s.replace(/<w:mailMerge>[\s\S]*?<\/w:mailMerge>/, "");
        zip.file(sp, s);
    }
    const rp = "word/_rels/settings.xml.rels";
    if (zip.file(rp)) {
        let s = await zip.file(rp).async("string");
        s = s.replace(/<Relationship [^>]*mailMergeSource[^>]*\/>/g, "");
        zip.file(rp, s);
    }
    return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
}
async function buildMerged(recs, parts, onProgress) {
    const docs = [];
    for (let i = 0; i < recs.length; i++) {
        docs.push(await buildDocx(recs[i], parts));
        onProgress && onProgress(i + 1);
    }
    const base = await JSZip.loadAsync(docs[0]);
    const docOf = async (z) => new DOMParser().parseFromString(await z.file("word/document.xml").async("string"), "application/xml");
    const bdoc = await docOf(base), bbody = bdoc.getElementsByTagNameNS(WNS, "body")[0];
    let lastSect = kids(bbody, "sectPr").pop();
    // penomoran daftar (mis. "Mengingat 1–8") harus mulai ulang di setiap surat → tiap salinan dapat w:num sendiri
    const numPath = "word/numbering.xml", ndoc = base.file(numPath) ? new DOMParser().parseFromString(await base.file(numPath).async("string"), "application/xml") : null;
    const nroot = ndoc && ndoc.documentElement;
    let maxNum = 0;
    const absOf = {}, startOf = {};
    if (nroot) {
        for (const n of kids(nroot, "num")) {
            const id = Number(n.getAttributeNS(WNS, "numId"));
            maxNum = Math.max(maxNum, id);
            const a = kids(n, "abstractNumId")[0];
            if (a)
                absOf[id] = a.getAttributeNS(WNS, "val") ?? "";
        }
        for (const a of kids(nroot, "abstractNum")) {
            const aid = a.getAttributeNS(WNS, "abstractNumId") ?? "";
            startOf[aid] = {};
            for (const l of kids(a, "lvl")) {
                const st = kids(l, "start")[0];
                startOf[aid][l.getAttributeNS(WNS, "ilvl") ?? ""] = st ? st.getAttributeNS(WNS, "val") ?? "1" : "1";
            }
        }
    }
    const cleanup = nroot && kids(nroot, "numIdMacAtCleanup")[0];
    function renumber(body) {
        if (!nroot || !ndoc)
            return;
        const map = {};
        for (const el of [...body.getElementsByTagNameNS(WNS, "numId")]) {
            const old = el.getAttributeNS(WNS, "val") ?? "";
            if (!(old in absOf))
                continue;
            if (!map[old]) {
                map[old] = String(++maxNum);
                const num = ndoc.createElementNS(WNS, "w:num");
                num.setAttributeNS(WNS, "w:numId", map[old]);
                const an = ndoc.createElementNS(WNS, "w:abstractNumId");
                an.setAttributeNS(WNS, "w:val", absOf[old]);
                num.appendChild(an);
                for (const [lv, st] of Object.entries(startOf[absOf[old]] || { 0: "1" })) {
                    const o = ndoc.createElementNS(WNS, "w:lvlOverride");
                    o.setAttributeNS(WNS, "w:ilvl", lv);
                    const so = ndoc.createElementNS(WNS, "w:startOverride");
                    so.setAttributeNS(WNS, "w:val", st);
                    o.appendChild(so);
                    num.appendChild(o);
                }
                cleanup ? nroot.insertBefore(num, cleanup) : nroot.appendChild(num);
            }
            el.setAttributeNS(WNS, "w:val", map[old]);
        }
    }
    for (let i = 1; i < docs.length; i++) {
        const d = await docOf(await JSZip.loadAsync(docs[i])), body = d.getElementsByTagNameNS(WNS, "body")[0];
        renumber(body);
        const p = bdoc.createElementNS(WNS, "w:p"), pPr = bdoc.createElementNS(WNS, "w:pPr");
        pPr.appendChild(lastSect.cloneNode(true));
        p.appendChild(pPr);
        bbody.insertBefore(p, lastSect);
        for (const n of [...body.childNodes]) {
            if (isEl(n) && n.localName === "sectPr")
                continue;
            bbody.insertBefore(bdoc.importNode(n, true), lastSect);
        }
        const ns = kids(body, "sectPr")[0];
        if (ns) {
            const imp = bdoc.importNode(ns, true);
            bbody.replaceChild(imp, lastSect);
            lastSect = imp;
        }
    }
    base.file("word/document.xml", xmlOut(bdoc));
    if (ndoc)
        base.file(numPath, xmlOut(ndoc));
    return base.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
}
const fileName = (rec, prefix = "ST") => {
    const F = compute(rec);
    return (prefix + " " + F.NOMOR_ST.replace(/\//g, "-") + " " + (F.NAMA_PELAKSANA_SPD || "")).replace(/[\\/:*?"<>|]+/g, "").replace(/\s+/g, " ").trim().slice(0, 120) + ".docx";
};
function download(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }
const pause = (ms) => new Promise(r => setTimeout(r, ms));
/* one surat → 2 files: Surat Tugas (hal. 1–5, 10) and Rincian Biaya (hal. 6–9) */
async function downloadRec(rec, which = "st") {
    try {
        if (which === "biaya") {
            if (rec._noBiaya)
                return toast("Rincian biaya surat ini belum dibuat — buka lewat Edit → Rincian Biaya, lalu Simpan.");
            const per = biayaRecs(rec);
            const blob = per.length > 1 ? await buildMerged(per, FILE_BIAYA) : await buildDocx(per[0], FILE_BIAYA);
            const nm = per.length > 1 ? fileName(rec, "Rincian Biaya").replace(/\.docx$/, ` (${per.length} orang).docx`) : fileName(per[0], "Rincian Biaya");
            download(blob, nm);
            toast(per.length > 1 ? `Rincian Biaya ${per.length} orang diunduh dalam satu file.` : "Rincian Biaya diunduh: " + nm);
        }
        else {
            download(await buildDocx(rec, FILE_ST), fileName(rec, "ST"));
            toast("Surat Tugas diunduh: " + fileName(rec, "ST"));
        }
    }
    catch (e) {
        console.error(e);
        toast("Gagal membuat dokumen: " + e.message);
    }
}
/* ================= print dialog ================= */
let printRecs = [];
function openPrint(recs, stOnly = false) {
    if (!recs.length)
        return toast("Pilih surat terlebih dahulu.");
    printRecs = recs;
    $("#pCount").textContent = String(recs.length);
    const nb = recs.filter(r => r._noBiaya).length;
    $('#dPrint [data-part="biaya"]').checked = !stOnly && !nb;
    $("#pNote").textContent = nb ? `${nb} surat belum punya rincian biaya (dibuat lewat Surat Tugas Kolektif) — File 2 tidak dicentang. Isi rinciannya lewat Daftar Surat Tugas → Edit → Rincian Biaya.` : "";
    $("#dPrint").showModal();
}
const chosen = (group) => $$("#dPrint [data-part]").map(c => c.checked ? c.dataset.part ?? "" : "").filter(p => p && group.includes(p));
$("#pCancel").onclick = () => $("#dPrint").close();
const rangeName = () => { const nos = printRecs.map(r => r.NO); return `${nos[0]}${nos.length > 1 ? "-" + nos[nos.length - 1] : ""} (${nos.length} surat)`; };
$$("#dPrint [data-go]").forEach(btn => btn.onclick = async () => {
    const go = btn.dataset.go;
    const jobs = [];
    if (go !== "biaya") {
        const p = chosen(FILE_ST);
        if (p.length)
            jobs.push(["Cetak Surat Tugas", p]);
        else if (go === "st")
            return toast("Centang minimal satu bagian File 1.");
    }
    if (go !== "st") {
        const p = chosen(FILE_BIAYA);
        if (p.length)
            jobs.push(["Cetak Rincian Biaya", p]);
        else if (go === "biaya")
            return toast("Centang bagian File 2.");
    }
    if (!jobs.length)
        return toast("Centang minimal satu bagian.");
    const btns = $$("#dPrint .df button");
    btns.forEach(b => b.disabled = true);
    const label = btn.textContent;
    try {
        for (const [name, parts] of jobs) {
            const list = name.includes("Rincian") ? expandBiaya(printRecs) : printRecs;
            const blob = await buildMerged(list, parts, i => btn.textContent = `${name.replace("Cetak ", "")} ${i}/${list.length}…`);
            download(blob, `${name} ${rangeName()}.docx`);
            await pause(400);
        }
        $("#dPrint").close();
        toast(jobs.length > 1 ? "2 file cetak siap — buka masing-masing di Word lalu Ctrl+P." : "File cetak siap — buka di Word lalu Ctrl+P.");
    }
    catch (e) {
        console.error(e);
        toast("Gagal: " + e.message);
    }
    btns.forEach(b => b.disabled = false);
    btn.textContent = label;
});
$("#pZip").onclick = async () => {
    const pS = chosen(FILE_ST), pB = chosen(FILE_BIAYA);
    if (!pS.length && !pB.length)
        return toast("Centang minimal satu bagian.");
    const btn = $("#pZip");
    btn.disabled = true;
    try {
        const z = new JSZip(), fS = z.folder("Surat Tugas"), fB = z.folder("Rincian Biaya");
        for (let i = 0; i < printRecs.length; i++) {
            btn.textContent = `Menyiapkan ${i + 1}/${printRecs.length}…`;
            if (pS.length)
                fS.file(fileName(printRecs[i], "ST"), await buildDocx(printRecs[i], pS));
            if (pB.length) {
                const per = biayaRecs(printRecs[i]);
                fB.file(fileName(printRecs[i], "Rincian Biaya").replace(/\.docx$/, per.length > 1 ? ` (${per.length} orang).docx` : ".docx"), per.length > 1 ? await buildMerged(per, pB) : await buildDocx(per[0], pB));
            }
        }
        download(await z.generateAsync({ type: "blob" }), `Surat Tugas ${rangeName()}.zip`);
        $("#dPrint").close();
    }
    catch (e) {
        toast("Gagal: " + e.message);
    }
    btn.disabled = false;
    btn.textContent = "Per surat (.zip)";
};

/* ---- 40_form.ts ---- */
/* ================= FORM ================= */
const form = $("#f");
(function buildTransRows() {
    let t = "";
    for (let i = 1; i <= MAXTR; i++)
        t += `<tr data-i="${i}"${i > TR_BASE ? " hidden" : ""}><td class="muted">${i}</td><td><input name="KetTransport_${i}" list="dl-trans" placeholder="Keterangan transport"></td><td class="src"></td><td><input name="Nilai${i}" type="number" min="0" step="1000" style="text-align:right"></td><td><button class="btn sm" type="button" data-clr="${i}" title="Kosongkan baris">×</button></td></tr>`;
    $("#trans").innerHTML = t;
})();
/* ---- pengeluaran riil tanpa bukti (B3): 2. transport lokal · 3. mobil bandara; hotel tambahan (B2) ---- */
const riilOf = (w) => w === "bdr" ? riilBdr : riilLok;
function renderRiil() {
    for (const w of ["lok", "bdr"]) {
        $(w === "lok" ? "#rlLok" : "#rlBdr").innerHTML = riilOf(w).map(([k, v], i) => `<tr><td class="muted">${i + 1}</td><td><input data-rl="${w}" data-i="${i}" data-k="0" value="${esc(k)}" placeholder="${w === "lok" ? "mis. Biaya Transport Lokal dari Kampung Semu ke Kampung …" : "mis. Mobil bandara DEO Sorong – Kota Sorong"}"></td><td class="src">${AUTO_RE.test(k) ? `<span class="tag">SK</span>` : ""}</td><td><input data-rl="${w}" data-i="${i}" data-k="1" type="number" min="0" step="1000" value="${esc(v)}" style="text-align:right"></td><td><button class="btn sm" type="button" data-rlx="${w}" data-i="${i}" title="Hapus baris">×</button></td></tr>`).join("")
            || `<tr><td colspan="5" class="muted" style="text-align:center;padding:10px">Belum ada rincian${w === "lok" ? " — terisi otomatis bila kampung tujuan berlabel Lokal, atau tambah manual" : " — klik tambah, isi rincian perjalanan & nominalnya"}.</td></tr>`;
    }
}
function renderHx() {
    const dis = formNoInap() ? " disabled" : "";
    $("#hxRows").innerHTML = hotel2.map((h, i) => `<div class="grid" style="margin-top:8px"><div class="c4"><input data-hx="${i}" data-k="t" value="${esc(h.t)}" placeholder="Nama hotel / penginapan ke-${i + 2}" list="dl-hotel"${dis}></div><div class="c2"><input data-hx="${i}" data-k="l" type="number" min="0" value="${h.l || ""}" placeholder="malam"${dis}></div><div class="c3"><input data-hx="${i}" data-k="n" type="number" min="0" step="1000" value="${h.n || ""}" placeholder="tarif per malam"${dis}></div><div class="c3"><div class="row"><input readonly tabindex="-1" data-hxsub="${i}"><button class="btn sm" type="button" data-hxx="${i}" style="flex:none" title="Hapus hotel ini">×</button></div></div></div>`).join("");
    $("#hxAdd").disabled = !!dis;
}
/** jumlah malam semua hotel di formulir (hotel pertama + tambahan) */
const formHotelN = () => num(form.LAMA_HOTEL.value) + hotel2.reduce((s, h) => s + num(h.l), 0);
$("#riilCard").addEventListener("input", e => { const d = tg(e).dataset, row = d.rl ? riilOf(d.rl)[Number(d.i)] : null; if (!row)
    return; if (d.k === "0")
    row[0] = tg(e).value;
else
    row[1] = tg(e).value === "" ? "" : Number(tg(e).value); });
$("#riilCard").addEventListener("click", e => {
    const d = tg(e).closest("[data-rladd],[data-rlx]")?.dataset;
    if (!d)
        return;
    if (d.rladd) {
        const rows = riilOf(d.rladd);
        rows.push(["", ""]);
        renderRiil();
        refresh();
        $(`#riilCard [data-rl="${d.rladd}"][data-i="${rows.length - 1}"][data-k="0"]`)?.focus();
    }
    else if (d.rlx) {
        riilOf(d.rlx).splice(Number(d.i), 1);
        renderRiil();
        refresh();
    }
});
$("#riilCard").addEventListener("change", e => {
    const w = tg(e).dataset.rlpreset;
    if (!w)
        return;
    const ref = riilPresets(w)[+tg(e).value];
    tg(e).value = "";
    if (!ref)
        return;
    riilOf(w).push([ref[0], num(ref[1])]);
    renderRiil();
    refresh();
});
const riilPresets = (w) => otherTransRef().filter(([k]) => w === "bdr" ? /^Mobil bandara /.test(k) : /^Transport lokal /.test(k));
$("#hxRows").addEventListener("input", e => { const d = tg(e).dataset, h = d.hx != null ? hotel2[Number(d.hx)] : null; if (!h)
    return; if (d.k === "t")
    h.t = tg(e).value;
else if (d.k === "l")
    h.l = num(tg(e).value);
else
    h.n = num(tg(e).value); });
$("#hxRows").addEventListener("click", e => { const i = tg(e).closest("[data-hxx]")?.dataset.hxx; if (i == null)
    return; hotel2.splice(Number(i), 1); renderHx(); refresh(); });
$("#hxAdd").onclick = () => { hotel2.push({ t: "", l: 0, n: 0 }); renderHx(); refresh(); $(`#hxRows [data-hx="${hotel2.length - 1}"][data-k="t"]`)?.focus(); };
/** kolom isian bernama di formulir (tanpa pemilih tanggal asli) */
const FIELDS = () => [...form.elements].filter(e => e.name && e.type !== "date");
function readForm() {
    const r = {};
    for (const e of FIELDS()) {
        let v = e.value.trim();
        if (e.classList.contains("pick"))
            v = resolvePeg(v) ?? v;
        if (v === "")
            continue;
        r[e.name] = e.type === "number" || e.hasAttribute("data-money") ? Number(v) : v;
    }
    r.NO = noNorm(r.NO);
    if (chips.length)
        r._kampung = clone(chips);
    if ($("#kegLain").checked)
        r._kegLain = true;
    if (pelExcl.length)
        r._pelExcl = pelExcl.slice();
    if (Object.keys(pelUH).length)
        r._pelUH = clone(pelUH);
    setLamp(r, members);
    {
        const a = riilFilled(riilLok), b = riilFilled(riilBdr), h = hotel2.filter(x => x.t.trim() || x.l || x.n);
        if (a.length)
            r._riilLok = clone(a);
        if (b.length)
            r._riilBdr = clone(b);
        if (h.length)
            r._hotel2 = clone(h);
    }
    delete r.TOTAL_TRANS;
    {
        const ps = personCodes(r), po = {};
        for (const c of ps)
            if (perOrang[c] && Object.keys(perOrang[c]).length)
                po[c] = clone(perOrang[c]);
        if (Object.keys(po).length)
            r._perOrang = po;
    }
    return r;
}
function fillForm(r) {
    for (const e of FIELDS()) {
        let v = r[e.name] ?? "";
        if (e.classList.contains("pick") && v !== "")
            v = pegLabel(v);
        e.value = v;
    }
    chips = normChips(r._kampung);
    members = lampOf(r);
    $("#trSyncInfo").textContent = "";
    perOrang = clone(r._perOrang || {});
    poOpen.clear();
    riilLok = riilRows(r._riilLok);
    riilBdr = riilRows(r._riilBdr);
    hotel2 = hotelX(r);
    renderRiil();
    renderHx();
    if (!r.JENIS)
        form.JENIS.value = "Remote";
    form.JENIS.dataset.touched = r.JENIS ? "1" : "";
    // otomatis bila surat baru / belum ada rincian / nilainya memang sama dengan hitungan otomatis
    const L = num(r.LAMA_JALAN);
    if (!num(form.LAMA_JALAN.value)) {
        const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value);
        if (a && b && b >= a)
            form.LAMA_JALAN.value = dayDiff(a, b);
    }
    $("#autoLama").checked = true;
    _editMoved = false;
    pelExcl = Array.isArray(r._pelExcl) ? r._pelExcl.slice() : [];
    pelUH = r._pelUH ? clone(r._pelUH) : {};
    kegMode(form.kegiatan, $("#kegLain"), r._kegLain || (r.kegiatan && !pokJudul(akunST(r)).has(String(r.kegiatan).trim())));
    setTimeout(() => {
        const t = form.TEMPAT_TUJUAN.value.trim(), d = t ? detectKampung(t) : { found: [] }, M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
        $("#h-tujuan").innerHTML = list.length ? `Kampung SK: ${list.map((k, i) => `${i + 1}. ${esc(title(k.kampung))} <span class="muted">(${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)})</span>`).join(" → ")}` : (t && !d.found.length ? `<span class="muted">Tidak ada kampung SK Transport di teks ini — transport diisi manual.</span>` : "");
    }, 0);
    if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0)
        form.NILAI_UH.value = defUH();
    if (form.TDK_INAP_HOTEL.value === "" || num(form.TDK_INAP_HOTEL.value) === 0)
        form.TDK_INAP_HOTEL.value = defInap();
    applyJenis();
    renderChips();
    renderMembers();
    if (r._noBiaya) {
        syncLama();
        applyKampung();
        toast("Rincian biaya diisi otomatis dari kampung, jenis & lama hari — periksa lalu Simpan.");
    }
    else {
        if ($("#autoLama").checked)
            syncLama();
        if (chips.length)
            applyKampung(true);
        else
            refresh(); // aturan transport terbaru (mis. Lokal × hari)
    }
}
function nextNo(extra = [], year = new Date().getFullYear()) {
    const max = [...records.filter(r => stYear(r) === year).map(r => r.NO), ...extra].reduce((m, n) => Math.max(m, parseInt(String(n), 10) || 0), 0);
    return String(max + 1).padStart(3, "0");
}
const KEEP = ["NoLengkap", "No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "No_Bend", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT"];
const DEF_TARIF = 150000;
const defUH = () => num(tarifDB.find(t => t.nama.toUpperCase() === "UHAR PERJADIN")?.nilai) || DEF_TARIF;
const defInap = () => num(tarifDB.find(t => t.nama.toUpperCase() === "INAP PERJADIN")?.nilai) || DEF_TARIF;
function defaults() {
    const last = records[records.length - 1] || {};
    const r = { TGL_TERBIT_ST: today() };
    for (const k of KEEP)
        if (last[k] != null)
            r[k] = last[k];
    r.ALAT_ANGKUTAN_YANG_DIGUNAKAN ??= "Darat";
    r.TEMPAT_BERANGKAT ??= "Kampung Semu";
    r.NILAI_UH = defUH();
    r.TDK_INAP_HOTEL = defInap();
    if (r.NoLengkap)
        r.NoLengkap = r.NoLengkap.replace(/\/\d{4}$/, "/" + new Date().getFullYear());
    for (const [f, rs] of SIGN_FIELDS) {
        const h = roleHolders(rs);
        if (h.length && !roleOk(codeOf(r[f]), rs))
            r[f] = (rs.includes("KEPALA") ? (h.find(p => hasRole(p, ["KEPALA"])) || h[0]) : h[0]).kode;
        else if (h.length && !r[f])
            r[f] = h[0].kode;
    }
    return r;
}
let _noYear = null;
function newForm() { trShown = TR_BASE; editingId = null; const d = defaults(); _noYear = yrOf(d.TGL_TERBIT_ST) || new Date().getFullYear(); fillForm({ ...d, NO: nextNo([], _noYear) }); setEditFlag(); showSub("data"); }
function setEditFlag() { const f = $("#editFlag"), r = editingId && records.find(x => x._id === editingId); f.hidden = !r; f.textContent = r ? `Mengubah surat No. ${r.NO}${stYear(r) ? " · tahun " + stYear(r) : ""}` : ""; }
/* surat baru: tahun tanggal terbit berubah → nomor urut ikut tahun itu */
let _editMoved = false;
function autoNoForYear() {
    const y0 = yrOf(form.TGL_TERBIT_ST.value);
    if (editingId) { // surat lama dipindah ke tahun lain → nomor ikut urutan tahun itu (mulai 001)
        const old = records.find(x => x._id === editingId);
        if (!old || !y0)
            return;
        if (y0 === stYear(old)) {
            if (_editMoved) {
                form.NO.value = old.NO;
                _editMoved = false;
                refresh();
                toast(`Kembali ke tahun ${y0} — No. urut dikembalikan ke ${old.NO}.`);
            }
            return;
        }
        const nx = nextNo([], y0);
        if (!_editMoved || noKey(form.NO.value) !== noKey(nx)) {
            form.NO.value = nx;
            _editMoved = true;
            refresh();
            toast(`Tahun terbit ${y0}: No. urut disesuaikan menjadi ${nx} — penomoran tiap tahun mulai dari 001.`);
        }
        return;
    }
    const y = y0;
    if (!y || y === _noYear)
        return;
    const wasAuto = _noYear == null || noKey(form.NO.value) === noKey(nextNo([], _noYear));
    _noYear = y;
    if (wasAuto || records.some(x => stYear(x) === y && noKey(x.NO) === noKey(form.NO.value))) {
        form.NO.value = nextNo([], y);
        refresh();
    }
}
form.TGL_TERBIT_ST.addEventListener("change", autoNoForYear);
form.TGL_TERBIT_ST.addEventListener("input", () => setTimeout(autoNoForYear, 0));
function personText(p) { return p ? [p.nama, p.nip && p.nip !== "-" ? "NIP " + p.nip : "", p.jabatan, [p.pangkat, p.gol].filter(x => x && x !== "-").join(" ")].filter(Boolean).join(" · ") : ""; }
function refresh() {
    if (!formNoInap() && $("#autoLama").checked) {
        const L = num(form.LAMA_JALAN.value);
        form.LAMA_UH.value = L || "";
        form.LAMA_INAP.value = L ? Math.max(0, L - 1 - formHotelN()) : "";
    }
    const r = readForm(), P = pegMap();
    const F = compute(r), n = F._num;
    $("#totTrans").value = "Rp " + rupiah(n.sumTr);
    $("#riilTot").textContent = `Jumlah pengeluaran riil (penginapan + transport): Rp ${rupiah(n.totRiil)}`;
    $$("[data-hxsub]").forEach(e => { const h = hotel2[Number(e.dataset.hxsub)]; e.value = h ? "Rp " + rupiah(num(h.l) * num(h.n)) : ""; });
    {
        let cnt = 0;
        for (let i = 1; i <= MAXTR; i++)
            if (num(form["Nilai" + i].value))
                cnt++;
        $("#h-trans").textContent = `Jumlah ${cnt} baris transport — dihitung ulang otomatis`;
    }
    form.NOMOR_ST.value = F.NOMOR_ST;
    angLockUI();
    {
        const n = $("#makPelNote");
        if (n)
            n.textContent = formPel() ? "· Pelatihan: boleh juga 521213" : "";
    }
    {
        const kg = form.kegiatan.value.trim(), h = $("#h-keg");
        if (h) {
            const ros = rosOfJudul(kg, ST_AKUN(formPel())), mro = pokMap()[normMak(form.MAK.value)]?.ro, ro = mro && ros.includes(mro) ? mro : ros.join(" / ");
            h.innerHTML = $("#kegLain").checked ? `<span class="muted">Kegiatan lainnya — diisi manual; MAK tetap dipilih dari POK (akun perjalanan dinas).</span>` : !kg ? "" : !ro ? `<span class="bad">Bukan judul RO di POK — pilih dari daftar, atau centang "Kegiatan lainnya"</span>` : `RO ${esc(ro)}` + (form.MAK.value && mro && !ros.includes(mro) ? ` · <span class="bad">MAK bukan dari RO ini</span>` : "");
        }
    }
    {
        const y = yrOf(form.TGL_TERBIT_ST.value) || new Date().getFullYear(), nx = nextNo([], y), h = $("#h-no");
        if (h)
            h.innerHTML = editingId ? "" : (parseInt(form.NO.value, 10) > parseInt(nx, 10) ? `<span class="bad">Harus berurutan — nomor berikutnya tahun ${y}: ${nx}</span>` : `Nomor berikutnya tahun ${y}: ${nx}`);
    }
    const kk = kodeFromNL(form.NoLengkap.value), kc = kodeMap()[kk];
    if (document.activeElement !== $("#kodeKlas"))
        $("#kodeKlas").value = kk;
    $("#h-kode").textContent = kc ? `${kc.d} · ${kodeGroup(kk)}` : (form.NoLengkap.value ? "Kode tidak dikenali di daftar klasifikasi" : "");
    $("#h-kode").classList.toggle("bad", !kc && !!form.NoLengkap.value);
    $$("#f .person").forEach(d => {
        const raw = form[d.dataset.p ?? ""].value.trim();
        const p = P[resolvePeg(raw) ?? ""];
        d.textContent = !raw ? "" : p ? personText(p) : "Kode tidak ditemukan di Data Pegawai";
        d.classList.toggle("bad", !!raw && !p);
    });
    $('[data-out="TOTAL_UH"]').value = "Rp " + F.TOTAL_UH;
    $('[data-out="PENG_RIIL"]').value = "Rp " + rupiah(n.totInap);
    const calc = { uh: `${n.luh} hari × Rp ${rupiah(n.nuh)}`, inap: `${n.inap} malam × Rp ${rupiah(n.tdk)}`, hotel: !n.lh ? "tidak ada" : F._hotels.length > 1 ? `${F._hotels.length} hotel · ${n.lh} malam` : `${n.lh} malam × Rp ${rupiah(F._hotels[0].n)}${F._hotels[0].t ? " · " + F._hotels[0].t : ""}`,
        lok: F._riilLok.length ? `${F._riilLok.length} rincian` : "tidak ada", bdr: F._riilBdr.length ? `${F._riilBdr.length} rincian` : "tidak ada", tr: `${[...Array(MAXTR)].filter((_, i) => form["KetTransport_" + (i + 1)].value || form["Nilai" + (i + 1)].value).length} baris` };
    $$("[data-calc]").forEach(e => e.textContent = calc[e.dataset.calc ?? ""]);
    const sums = { uh: n.totUH, inap: n.totInap, hotel: n.totHotel, lok: n.totLok, bdr: n.totBdr, tr: n.sumTr, jml: n.jml, tot: n.jmlTotal };
    $('[data-out="TOTAL_HOTEL"]').value = "Rp " + F.TOTAL_HOTEL;
    {
        const L = num(form.LAMA_JALAN.value), lim = Math.max(0, L - 1), tot = n.inap + n.lh, h = $('[data-calc="hotel"]');
        if (h && L && tot > lim)
            h.innerHTML = `<span class="bad">Malam hotel (${n.lh}) + malam tanpa hotel (${n.inap}) melebihi ${lim} malam perjalanan</span>`;
    }
    $$("[data-sum]").forEach(e => e.textContent = "Rp " + rupiah(sums[e.dataset.sum ?? ""]));
    $('[data-out-text="TERBILANG"]').textContent = "Terbilang: " + F.TERBILANG + " Rupiah";
    $("#sumJumlah").textContent = $("#tabSum").textContent = "Rp " + rupiah(n.jmlTotal) + (n.orang > 1 ? ` (${n.orang} orang)` : "");
    {
        const ps = personCodes(readForm(), P);
        $$("[data-multi]").forEach(e => e.hidden = ps.length < 2);
        $$("[data-orang]").forEach(e => e.textContent = String(ps.length));
        $$("[data-orang-list]").forEach(e => e.textContent = ps.map(c => (P[c]?.nama || "").split(",")[0]).join(", "));
        $("#rbPer").hidden = ps.length < 2;
        $("#rbPer").innerHTML = ps.length < 2 ? "" : `<b>Rincian biaya dibuat untuk tiap orang (${ps.length} orang):</b> ${ps.map(c => esc((P[c]?.nama || "").split(",")[0])).join(" · ")}. Satu file Rincian Biaya berisi kuitansi, rincian &amp; pernyataan untuk masing-masing.`;
    }
    $("#lamaInfo").textContent = `Lama perjalanan: ${num(form.LAMA_JALAN.value) || "–"} hari`;
    // transport source tags
    for (let i = 1; i <= MAXTR; i++) {
        const ket = form["KetTransport_" + i].value;
        const src = /^Biaya Transport Mobil/.test(ket) ? `<span class="tag warn">SK · mobil</span>` : /^Biaya lintasan mobil/i.test(ket) ? (num(form["Nilai" + i].value) < minLintasMobil() ? `<span class="tag warn" style="color:var(--danger)">min Rp ${rupiah(minLintasMobil())}</span>` : `<span class="tag warn">lintasan mobil</span>`) : /^Biaya inap mobil/i.test(ket) ? `<span class="tag warn">inap mobil</span>` : /^Biaya [Ll]intasan/.test(ket) ? `<span class="tag">lintasan</span>`
            : /^Biaya Transport Lokal/.test(ket) ? `<span class="tag ok">SK · lokal</span>` : /^Biaya Transport dari/.test(ket) ? `<span class="tag">SK · ½</span>`
                : AUTO_RE.test(ket) ? `<span class="tag ${/sekali jalan/.test(ket) ? "warn" : ""}">SK · ${/sekali jalan/.test(ket) ? "½" : "PP"}</span>` : (ket || form["Nilai" + i].value ? `<span class="tag ok">manual</span>` : "");
        $(`#trans tr[data-i="${i}"] .src`).innerHTML = src;
    }
    trRows();
    {
        const pel = form.JENIS.value === "Pelatihan";
        $("#tabPel").hidden = !pel;
        $('.subtabs [data-s="biaya"]').hidden = pel;
        if (!pel && $("#s-pel").classList.contains("on"))
            showSub("biaya");
        if (pel && $("#s-biaya").classList.contains("on"))
            showSub("pel");
        if (pel)
            renderPelTab();
    }
    const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value);
    $("#h-lama").innerHTML = (a && b) ? (b < a ? `<span class="bad">Tanggal pulang sebelum tanggal pergi</span>` : `${a.getDate()} ${BULAN[a.getMonth()].slice(0, 3)} – ${fmtDate(b)}`) : (form.TGL_PERGI.value && !a ? `<span class="bad">Tanggal pergi tidak terbaca — tulis mis. 5 Januari 2026</span>` : "Isi tanggal pergi & pulang");
    $("#h-mak").innerHTML = budgetHtml(form.MAK.value, n.jmlTotal, editingId);
    {
        const le = lokalErr(r), h = $("#h-lokal");
        if (h) {
            h.hidden = !le;
            h.textContent = le ? "⚠ " + le : "";
        }
    }
    renderPerOrang();
    const cf = findConflicts(readForm(), records, editingId), dw = $("#dupWarn");
    const ob = obConflicts(readForm());
    dw.hidden = !cf.length && !ob.length;
    if (!cf.length && ob.length)
        dw.innerHTML = `<b>⚠ Petugas sedang dalam rentang OB/kontrak honor:</b><ul style="margin:6px 0 0;padding-left:20px">${ob.slice(0, 8).map(o => `<li>${esc(obMsg(o))}</li>`).join("")}</ul>`;
    if (cf.length)
        dw.innerHTML = `<b>⚠ Surat tugas tidak bisa dibuat — petugas sudah bertugas pada tanggal yang sama:</b><ul style="margin:6px 0 0;padding-left:20px">${cf.slice(0, 8).map(c => `<li>${esc(c.nama)} — ST ${esc(c.nomor)} (${esc(c.tgl)})</li>`).join("")}</ul>`;
}
form.addEventListener("input", e => {
    const n = tg(e).name;
    if (n === "TGL_PERGI")
        autoPulang();
    if (n === "TGL_PULANG")
        autoLama();
    if (n === "LAMA_JALAN") {
        if (num(form.LAMA_JALAN.value) >= 1)
            autoPulang();
        else
            autoUH();
    }
    if (["LAMA_JALAN", "TGL_PERGI", "TGL_PULANG", "TEMPAT_BERANGKAT"].includes(n) && chips.length)
        applyKampung();
    if (n === "TGL_TERBIT_ST") {
        const d = parseTgl(tg(e).value);
        if (d)
            form.NoLengkap.value = form.NoLengkap.value.replace(/\/\d{4}$/, "/" + d.getFullYear());
    }
    refresh();
});
form.addEventListener("change", e => {
    const m = (tg(e).name || "").match(/^KetTransport_(\d+)$/);
    if (!m)
        return;
    const t = tg(e).value.trim();
    const ref = otherTransRef().find(([k]) => k === t);
    if (ref) {
        form["Nilai" + m[1]].value = ref[1];
        refresh();
        return;
    }
    const k = findKampung(t.replace(/^Transport (PP )?Kabupaten–Kampung /, "").replace(/\s*\(.*\)$/, ""));
    if (k && /kampung/i.test(t)) {
        const pp = !/sekali jalan/i.test(t);
        form["Nilai" + m[1]].value = kamValue(k, pp);
        refresh();
    }
});
let trShown = TR_BASE;
function trRows() {
    let last = 0;
    for (let i = 1; i <= MAXTR; i++)
        if (form["KetTransport_" + i].value || form["Nilai" + i].value)
            last = i;
    const show = Math.min(MAXTR, Math.max(TR_BASE, trShown, last));
    for (let i = 1; i <= MAXTR; i++)
        $(`#trans tr[data-i="${i}"]`).hidden = i > show;
    $("#trAdd").disabled = show >= MAXTR;
    $("#trRowInfo").textContent = show > TR_BASE ? `${show} baris ditampilkan (maks. ${MAXTR}). Surat Word ikut menambah baris otomatis.` : `Lebih dari ${TR_BASE} baris? Klik tambah — maks. ${MAXTR} baris.`;
}
$("#bPelXls").onclick = () => downloadPelatihan(readForm()).catch((e) => toast("Gagal: " + e.message));
/* tab 3 · transport pelatihan lokal: transport per orang tersimpan sebagai rincian khusus anggota */
const PEL_KET = "Transport lokal pelatihan";
const pelLunas = (r) => String(r.TGL_PULANG || r.TGL_PERGI || "").trim(); // pelatihan: lunas = tanggal terakhir surat tugas
/** pelatihan: kode yang dikeluarkan dari daftar; uang harian fullday/fullboard per kode */
let pelExcl = [], pelUH = {};
$("#pelTbl").addEventListener("input", e => {
    const k = tg(e).dataset.peluh;
    if (!k)
        return;
    const c = tg(e).dataset.c ?? "", o = pelUH[c] ||= {};
    o[k] = tg(e).value === "" ? 0 : num(tg(e).value);
    if (!o.full && !o.board)
        delete pelUH[c];
    const tr = tg(e).closest("tr"), x = pelatihanRows(readForm()).find(y => y.c === c);
    if (x)
        tr.querySelector("[data-pj]").innerHTML = `<b>${rupiah(x.full + x.board + x.tr)}</b>`;
    refresh();
});
$$("[data-pelapply]").forEach(b => b.onclick = () => {
    const k = b.dataset.pelapply, v = num($(k === "full" ? "#pelAllFull" : "#pelAllBoard").value);
    for (const x of pelatihanRows(readForm())) {
        const o = pelUH[x.c] ||= {};
        o[k] = v;
        if (!o.full && !o.board)
            delete pelUH[x.c];
    }
    refresh();
    renderPelTab();
    toast(`Uang harian ${k === "full" ? "fullday" : "fullboard"} Rp ${rupiah(v)} diterapkan ke semua petugas.`);
});
$("#pelTbl").addEventListener("click", e => { const c = tg(e).closest("[data-pelx]")?.dataset.pelx; if (!c)
    return; document.activeElement?.blur(); if (!pelExcl.includes(c))
    pelExcl.push(c); refresh(); renderPelTab(); toast("Dihapus dari daftar transport pelatihan — tetap tercantum di surat tugas."); });
$("#pelExcl").addEventListener("click", e => { const c = tg(e).closest("[data-pelback]")?.dataset.pelback; if (!c)
    return; pelExcl = pelExcl.filter(x => x !== c); refresh(); renderPelTab(); });
const pelSync = (src, field) => { const c = resolvePeg(src.value); if (c) {
    form[field].value = pegLabel(c);
    src.value = pegLabel(c);
}
else if (!src.value.trim())
    form[field].value = ""; refresh(); };
$("#pelBend").addEventListener("change", e => pelSync(tg(e), "No_Bend"));
$("#pelPpk").addEventListener("change", e => pelSync(tg(e), "No_PPK"));
$("#bPelPrev").onclick = () => { const r = readForm(); openPreview([r], `Pratinjau daftar transport pelatihan`, false, "pel"); };
function renderPelTab() {
    const r = readForm(), rows = pelatihanRows(r), tot = rows.reduce((a, x) => a + x.full + x.board + x.tr, 0), tr = rows.reduce((a, x) => a + x.tr, 0);
    $("#pelCount").textContent = rows.length + " petugas";
    $("#tabPelSum").textContent = "Rp " + rupiah(tot);
    $("#sumJumlah").textContent = "Rp " + rupiah(tot) + (rows.length > 1 ? ` (${rows.length} orang)` : "");
    $("#pelTgl").value = tglLong(r.TGL_PERGI, r.TGL_PULANG);
    if (!$("#pelTbl").contains(document.activeElement)) {
        $("#pelTbl tbody").innerHTML = rows.map((x, i) => `<tr data-c="${esc(x.c)}"><td class="muted">${i + 1}</td><td>${esc(x.nama)}${perOrang[x.c]?.trans ? ` <span class="tag warn">khusus</span>` : ""}</td><td>${esc(x.gol || "–")}</td><td>${esc(x.nip)}</td><td>${esc(x.jab)}</td><td class="num">${x.lama}</td>
      <td><input type="number" min="0" step="1000" data-peluh="full" data-c="${esc(x.c)}" value="${x.full}" style="text-align:right"></td>
      <td><input type="number" min="0" step="1000" data-peluh="board" data-c="${esc(x.c)}" value="${x.board}" style="text-align:right"></td>
      <td><input type="number" min="0" step="1000" data-pel="${esc(x.c)}" value="${x.tr}" style="text-align:right"></td><td class="num" data-pj><b>${rupiah(x.full + x.board + x.tr)}</b></td><td><button type="button" class="ib del" data-pelx="${esc(x.c)}" title="Hapus dari daftar transport (tetap di surat tugas)">${IC.del}</button></td></tr>`).join("")
            || `<tr><td colspan="11" class="muted" style="text-align:center;padding:18px">Isi pelaksana / anggota tim di tab 1 · Data Surat.</td></tr>`;
    }
    $("#pelFoot").innerHTML = rows.length ? `<tr><td></td><td colspan="5"><b>Jumlah</b></td><td class="num"><b>${rupiah(rows.reduce((a, x) => a + x.full, 0))}</b></td><td class="num"><b>${rupiah(rows.reduce((a, x) => a + x.board, 0))}</b></td><td class="num"><b>${rupiah(tr)}</b></td><td class="num"><b>${rupiah(tot)}</b></td><td></td></tr>` : "";
    {
        const P = pegMap(), ex = pelExcl.filter(c => P[c]);
        $("#pelExcl").innerHTML = ex.length ? `Tidak dimasukkan ke daftar: ${ex.map(c => `<span class="chip">${esc(P[c].nama.split(",")[0])}<button type="button" class="x" data-pelback="${esc(c)}" title="Masukkan lagi">↺</button></span>`).join(" ")}` : "";
    }
    const act = document.activeElement;
    if (act !== $("#pelBend"))
        $("#pelBend").value = form.No_Bend.value;
    if (act !== $("#pelPpk"))
        $("#pelPpk").value = form.No_PPK.value;
    $("#pelKui").value = pelLunas(r);
    $("#pelTerb").textContent = rows.length ? "Terbilang: " + capFirst(terbilang(tot)) + " Rupiah" : "";
    $("#pelInfo").textContent = r.MAK ? (pokMap()[normMak(r.MAK)] ? "" : "MAK tidak ditemukan di POK — baris Program–Akun tidak lengkap.") : "MAK belum diisi (tab 1) — baris Program–Akun kosong.";
}
function setPelTr(c, v) {
    const base = readForm();
    delete base._perOrang;
    const baseTr = compute({ ...base, KD_NAMA_SPD: c })._num.totTr;
    const o = perOrang[c] ||= {};
    if (v === "" || num(v) === baseTr)
        delete o.trans;
    else
        o.trans = [[PEL_KET, num(v)]];
    poClean(c);
}
$("#pelTbl").addEventListener("input", e => {
    const c = tg(e).dataset.pel;
    if (c == null)
        return;
    setPelTr(c, tg(e).value);
    refresh();
    renderPerOrang(true);
    const tr = tg(e).closest("tr"), x = pelatihanRows(readForm()).find(y => y.c === c);
    if (x)
        tr.querySelector("[data-pj]").innerHTML = `<b>${rupiah(x.full + x.board + x.tr)}</b>`;
});
$("#pelTbl").addEventListener("focusout", () => setTimeout(() => { if (!$("#pelTbl").contains(document.activeElement))
    renderPelTab(); }, 0));
$("#pelApply").onclick = () => {
    const v = $("#pelAll").value;
    if (v === "")
        return toast("Isi nominal transport dulu.");
    for (const x of pelatihanRows(readForm()))
        setPelTr(x.c, v);
    refresh();
    renderPerOrang(true);
    renderPelTab();
    toast(`Transport lokal Rp ${rupiah(num(v))} diterapkan ke semua petugas.`);
};
$("#pelAsal").addEventListener("input", () => LS.set("st.pelAsal", $("#pelAsal").value.trim()));
{
    const a = LS.get("st.pelAsal", null);
    if (a)
        $("#pelAsal").value = a;
}
{
    const d = LS.get("st.pelTrDef", "");
    if (d !== "" && d != null)
        $("#pelAll").value = d;
}
$("#trAdd").onclick = () => { let last = 0; for (let i = 1; i <= MAXTR; i++)
    if (!$(`#trans tr[data-i="${i}"]`).hidden)
        last = i; trShown = Math.min(MAXTR, last + 1); trRows(); form["KetTransport_" + trShown].focus(); };
$("#trans").addEventListener("click", e => { const i = tg(e).dataset.clr; if (!i)
    return; form["KetTransport_" + i].value = ""; form["Nilai" + i].value = ""; refresh(); });
/* tanggal pergi / lama berubah → tanggal pulang = pergi + lama − 1 (lama kosong → 1 hari) */
function autoPulang() {
    const a = parseTgl(form.TGL_PERGI.value);
    if (!a) {
        form.TGL_PULANG.value = "";
        return;
    }
    if (!(num(form.LAMA_JALAN.value) >= 1))
        form.LAMA_JALAN.value = 1;
    form.TGL_PULANG.value = tglPulang(form.TGL_PERGI.value, form.LAMA_JALAN.value);
    autoUH();
}
/* tanggal pulang diisi dari luar (impor / data lama) → lama dihitung dari kedua tanggal */
function autoLama() {
    const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value);
    if (a && b && b >= a) {
        form.LAMA_JALAN.value = dayDiff(a, b);
        autoUH();
    }
    else if (a && !form.TGL_PULANG.value.trim())
        autoPulang();
}
function autoUH() { syncLama(); }
const tarifDefault = (n) => { const t = tarifDB.find(t => t.nama.toUpperCase() === n); return t ? t.nilai : ""; };
/* Remote + otomatis: lama UH = lama perjalanan, inap = lama − 1, tarif kosong → tarif perjadin */
function syncLama() {
    if (formNoUH()) {
        form.LAMA_UH.value = 0;
        form.LAMA_INAP.value = 0;
        return;
    }
    const L = num(form.LAMA_JALAN.value);
    if (form.JENIS.value === JEN_TU) { // Translok+Uhar: inap 0; uang harian diisi sendiri (bawaan = lama perjalanan, tarif perjadin)
        form.LAMA_INAP.value = 0;
        if (form.LAMA_UH.value === "")
            form.LAMA_UH.value = L || "";
        if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0)
            form.NILAI_UH.value = defUH();
        return;
    }
    if (!$("#autoLama").checked)
        return;
    form.LAMA_UH.value = L || "";
    form.LAMA_INAP.value = L ? Math.max(0, L - 1 - formHotelN()) : "";
    if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0)
        form.NILAI_UH.value = defUH();
    if (form.TDK_INAP_HOTEL.value === "" || num(form.TDK_INAP_HOTEL.value) === 0)
        form.TDK_INAP_HOTEL.value = defInap();
}
$("#autoLama").addEventListener("change", () => { applyJenis(); syncLama(); refresh(); });
function applyJenis() {
    const lok = formNoUH(), noI = formNoInap(), tu = form.JENIS.value === JEN_TU, jen = form.JENIS.value, auto = $("#autoLama").checked;
    form.LAMA_UH.disabled = lok;
    form.LAMA_INAP.disabled = noI;
    form.LAMA_HOTEL.disabled = form.TARIF_HOTEL.disabled = form.HOTEL_TEMPAT.disabled = noI;
    form.LAMA_UH.readOnly = !lok && !tu && auto;
    form.LAMA_INAP.readOnly = !noI && auto;
    $$("[data-remote]").forEach(e => e.hidden = noI);
    $$("[data-autohint]").forEach(e => { const uh = e.dataset.autohint === "uh"; e.textContent = (uh ? lok : noI) ? jen + " = 0" : uh && tu ? "Diisi sendiri — bawaan = lama perjalanan" : auto ? (uh ? "Otomatis = lama perjalanan" : "Otomatis = lama perjalanan − 1 − malam hotel") : "Diisi manual"; });
    $$("[data-lokal]").forEach(e => e.hidden = !lok);
    $$("[data-noinap]").forEach(e => e.hidden = !noI);
    $$("[data-jenlbl]").forEach(e => e.textContent = jen);
    renderHx();
    $("#trMode").textContent = tu ? "— Translok+Uhar: transport lokal tiap kampung = banyak hari × tarif SK (kampung berlabel Lokal masuk ke B3 · Uang Transport Lokal), ditambah uang harian" : jen === "Lokal" ? "— Lokal: Biaya Transport Lokal tiap kampung = banyak hari × tarif SK (klik PP untuk ½); tercatat di B3 · Uang Transport Lokal" : jen === "Pelatihan" ? "— Pelatihan: transport berangkat & pulang (½ tarif SK masing-masing) + lintasan; tanpa uang harian & inap" : "— Remote: berangkat & pulang masing-masing ½ tarif SK, ditambah biaya lintasan antar kampung";
    $("#h-jenis").textContent = lok ? `${jen}: uang harian & inap = 0` : tu ? "Transport lokal + uang harian (bisa diisi); inap & hotel = 0" : "";
}
form.JENIS.addEventListener("change", () => { form.JENIS.dataset.touched = "1"; if (form.JENIS.value === JEN_TU)
    form.LAMA_UH.value = num(form.LAMA_JALAN.value) || ""; autoUH(); applyJenis(); applyKampung(); });
$$('#f input[type=date][data-for]').forEach(d => d.addEventListener("change", () => {
    if (!d.value)
        return;
    const t = form[d.dataset.for ?? ""];
    t.value = fmtTgl(d.value);
    t.dispatchEvent(new Event("input", { bubbles: true }));
}));
$$("#f .pick").forEach(i => i.addEventListener("change", () => { const c = resolvePeg(i.value); if (c)
    i.value = pegLabel(c); refresh(); }));
/* presets (uang harian / inap) */
function fillPresets() {
    $$("select.preset").forEach(s => {
        const re = new RegExp(s.dataset.re ?? "", "i");
        s.innerHTML = `<option value="">Pilih tarif…</option>` + tarifDB.filter(t => re.test(t.grup)).map(t => `<option value="${t.nilai}">${esc(title(t.nama))} — ${rupiah(num(t.nilai))}</option>`).join("");
    });
    for (const w of ["lok", "bdr"])
        $(w === "lok" ? "#rlLokPreset" : "#rlBdrPreset").innerHTML = `<option value="">+ Tambah dari tarif ${w === "lok" ? "translok" : "mobil bandara"}…</option>` + riilPresets(w).map(([k, v], i) => `<option value="${i}">${esc(k)} — Rp ${rupiah(num(v))}</option>`).join("");
    $("#trPreset").innerHTML = `<option value="">+ Tambah baris dari tarif lain (mobil, bandara, translok)…</option>` + otherTransRef().map(([k, v], i) => `<option value="${i}">${esc(k)} — Rp ${rupiah(num(v))}</option>`).join("");
}
$$("#f select.preset").forEach(s => s.addEventListener("change", () => { if (!s.value)
    return; form[s.dataset.for ?? ""].value = s.value; s.value = ""; refresh(); }));
$("#trPreset").addEventListener("change", e => {
    const ref = otherTransRef()[+tg(e).value];
    tg(e).value = "";
    if (!ref)
        return;
    for (let i = 1; i <= MAXTR; i++)
        if (!form["KetTransport_" + i].value && !form["Nilai" + i].value) {
            form["KetTransport_" + i].value = ref[0];
            form["Nilai" + i].value = ref[1];
            refresh();
            return;
        }
    toast(`Rincian transport sudah penuh (${MAXTR} baris).`);
});
/* kode klasifikasi */
$("#kodeKlas").addEventListener("input", e => { const c = kodeMap()[tg(e).value.trim().toUpperCase()]; if (c) {
    form.NoLengkap.value = composeNL(c.k, form.NoLengkap.value, form.TGL_TERBIT_ST.value);
    refresh();
} });
$("#kodeKlas").addEventListener("change", e => {
    const { c, n } = lookupKode(tg(e).value);
    if (c) {
        tg(e).value = c.k;
        form.NoLengkap.value = composeNL(c.k, form.NoLengkap.value, form.TGL_TERBIT_ST.value);
    }
    else if (n)
        toast(`${n} kode cocok — pilih dari daftar.`);
    refresh();
});
/* kampung chips (rendered in Data Surat and Rincian Biaya) */
function renderChips() {
    const M = kamByKey();
    const html = chips.map((c, i) => {
        const k = M[c.k];
        if (!k)
            return `<span class="chip">${esc(c.k)} <small class="bad">tidak ada di SK</small><button type="button" class="x" data-x="${i}">×</button></span>`;
        const lok = formTrLokal();
        return `<span class="chip"><b style="color:var(--muted);font-size:11px">${i + 1}</b> ${esc(title(k.kampung))} <small>${esc(title(k.distrik))} · SK Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""}</small>${lok ? `<button type="button" class="pp ${c.pp ? "" : "half"}" data-pp="${i}" title="Klik untuk ganti PP / sekali jalan">${c.pp ? "PP" : "½ sekali jalan"}</button>` : ""}${i ? `<button type="button" class="x" data-left="${i}" title="Pindah ke kiri (urutan rute)">‹</button>` : ""}<button type="button" class="x" data-x="${i}" title="Hapus">×</button></span>`;
    }).join("");
    $$(".kchips").forEach(d => d.innerHTML = html);
}
function applyKampung(keepTujuan) {
    const r = readForm();
    const over = applyKampungToRec(r);
    for (let i = 1; i <= MAXTR; i++) {
        form["KetTransport_" + i].value = r["KetTransport_" + i] ?? "";
        form["Nilai" + i].value = r["Nilai" + i] ?? "";
    }
    riilLok = riilRows(r._riilLok);
    renderRiil();
    const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
    if (keepTujuan !== true) {
        setTujuanText();
        $("#h-tujuan").textContent = "";
    }
    if (over)
        toast(`Rincian transport lebih dari ${MAXTR} baris — sebagian tidak masuk.`);
    renderChips();
    refresh();
}
/* "Kegiatan lainnya": kegiatan diketik manual (tidak harus judul RO POK); MAK tetap akun perjalanan dinas */
function kegMode(inp, chk, lain) {
    chk.checked = !!lain;
    const lbl = inp.closest("div").querySelector(".keghd > label");
    if (lain) {
        delete inp.dataset.ac;
        inp.setAttribute("list", "dl-kegiatan");
        inp.placeholder = "Tulis nama kegiatan, mis. Rapat koordinasi BPS Provinsi";
        if (lbl)
            lbl.textContent = "Kegiatan — lainnya (diisi manual)";
    }
    else {
        inp.dataset.ac = "pokj";
        inp.removeAttribute("list");
        inp.placeholder = "Cari RO di POK, mis. angkatan kerja atau 2905.BMA.004";
        if (lbl)
            lbl.textContent = "Kegiatan — judul RO dari POK";
    }
}
$("#kegLain").addEventListener("change", e => { kegMode(form.kegiatan, tg(e), tg(e).checked); if (!tg(e).checked && form.kegiatan.value && !pokJudul(ST_AKUN(formPel())).has(form.kegiatan.value.trim()))
    form.kegiatan.value = ""; form.kegiatan.focus(); refresh(); });
$("#mKegLain").addEventListener("change", e => { const inp = mIn("kegiatan"); kegMode(inp, tg(e), tg(e).checked); if (!tg(e).checked && inp.value && !pokJudul().has(inp.value.trim()))
    inp.value = ""; massCommon = readCommon(); persistMass(); updateMassInfo(); inp.focus(); });
let tujLuar = []; // (tidak dipakai lagi — tujuan ditulis sebagai teks biasa)
function renderLuar() { }
function setTujuanText() { const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean); if (!form.TEMPAT_TUJUAN.value.trim() && list.length)
    form.TEMPAT_TUJUAN.value = tujuanText(list); }
function addKampung() {
    const inp = $("#kamPick"), q = inp.value.trim();
    if (!q)
        return;
    // 1) pilihan dari daftar (label lengkap) atau satu nama persis — huruf besar/kecil tidak berpengaruh
    let list = [];
    const one = kIdx().label.get(q) || findKampung(q);
    if (one)
        list = [one];
    else {
        // 2) teks tempelan / beberapa nama sekaligus: "KAMBUSKATO UTARA, kambuskato dan IsUsU"
        const d = detectKampung(q);
        if (d.found.length) {
            list = d.found;
            if (d.unknown.length)
                setTimeout(() => toast(`Tidak dikenali di SK: ${d.unknown.slice(0, 3).join(", ")}`), 1600);
        }
        else {
            // 3) potongan nama (mis. "kambus") → kalau hanya satu yang cocok, pakai itu
            const lq = acNorm(q).replace(/^(kampung|kp\.?|kelurahan)\s+/, "");
            const hits = kampungDB.filter(x => acNorm(x.kampung).includes(lq));
            if (hits.length === 1)
                list = hits;
            else if (hits.length > 1) {
                toast(`${hits.length} kampung cocok — pilih dari daftar.`);
                return;
            }
            else { // bukan kampung SK → tetap jadi tujuan (chip kuning "luar SK"), transport diisi manual
                if (!tujLuar.some(t => acNorm(t) === acNorm(q)))
                    tujLuar.push(q);
                inp.value = "";
                renderLuar();
                setTujuanText();
                $("#h-tujuan").innerHTML = `"${esc(q)}" bukan kampung di SK Transport — tetap ditulis sebagai tujuan; biaya transportnya diisi manual di Rincian Biaya.`;
                refresh();
                return;
            }
        }
    }
    inp.value = "";
    const add = list.filter(k => !chips.some(c => c.k === kKey(k)));
    if (!add.length)
        return toast(list.length > 1 ? "Semua kampung itu sudah dipilih." : "Kampung sudah dipilih.");
    for (const k of add)
        chips.push({ k: kKey(k), pp: true });
    if (add.length > 1)
        toast(`${add.length} kampung ditambahkan: ${add.map(k => title(k.kampung)).join(", ")}`);
    if (!form.JENIS.dataset.touched) { // usulan otomatis: semua kampung bertanda "Lokal" di SK → Lokal
        const M = kamByKey(), all = chips.map(c => M[c.k]).filter(Boolean);
        const want = all.length && all.every(x => kamLokal(x)) ? "Lokal" : "Remote";
        if (form.JENIS.value !== want) {
            form.JENIS.value = want;
            autoUH();
            applyJenis();
            toast(`Jenis perjalanan diset ${want} (sesuai keterangan SK). Bisa diubah.`);
        }
    }
    applyKampung();
}
function suggestJenis() {
    if (form.JENIS.dataset.touched)
        return;
    const M = kamByKey(), all = chips.map(c => M[c.k]).filter(Boolean);
    const want = all.length && all.every(x => kamLokal(x)) ? "Lokal" : "Remote";
    if (form.JENIS.value !== want) {
        form.JENIS.value = want;
        autoUH();
        applyJenis();
    }
}
/* Tempat tujuan → kampung tujuan (saat teks ditempel, Enter, atau pindah kolom) */
function tujuanToChips(showToast) {
    const txt = form.TEMPAT_TUJUAN.value.trim(), h = $("#h-tujuan");
    const { found, unknown } = txt ? detectKampung(txt) : { found: [], unknown: [] };
    const old = new Map(chips.map(c => [c.k, c.pp]));
    const next = found.map(k => ({ k: kKey(k), pp: old.get(kKey(k)) ?? true }));
    const luar = unknown.filter(u => !/^(dan|ke|di|kampung|distrik|kab(upaten)?)$/i.test(u.trim()));
    h.innerHTML = !txt ? "" : (found.length ? `Terdeteksi <b>${found.length} kampung SK</b>: ${found.map((k, i) => `${i + 1}. ${esc(title(k.kampung))} <span class="muted">(${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""})</span>`).join(" → ")}` : `<span class="muted">Tidak ada kampung SK Transport di teks ini — biaya transport diisi manual di Rincian Biaya.</span>`)
        + (found.length && luar.length ? ` · <span class="bad">di luar SK (transport manual): ${esc(luar.slice(0, 4).map(u => title(u)).join(", "))}</span>` : "");
    const same = next.length === chips.length && next.every((c, i) => c.k === chips[i].k);
    if (same)
        return;
    chips = next;
    suggestJenis();
    applyKampung(true);
    if (showToast && found.length)
        toast(`${found.length} kampung tujuan terdeteksi dari teks.`);
}
/* tombol di Rincian Biaya → C · Transport */
$("#trSync").onclick = () => {
    const txt = form.TEMPAT_TUJUAN.value.trim(), info = $("#trSyncInfo");
    let found = [], unknown = [];
    if (txt)
        ({ found, unknown } = detectKampung(txt));
    if (!found.length && !chips.length) {
        info.innerHTML = `<span class="bad">Tidak ada kampung yang dikenali dari Tempat tujuan${txt ? ` ("${esc(txt.slice(0, 60))}")` : " (kolom masih kosong)"}.</span> Isi Tempat tujuan di tab Data Surat, mis. "Kampung Fiane, Isme dan Semu".`;
        return toast("Tempat tujuan belum berisi kampung yang dikenali.");
    }
    if (found.length) {
        const old = new Map(chips.map(c => [c.k, c.pp]));
        chips = found.map(k => ({ k: kKey(k), pp: old.get(kKey(k)) ?? true }));
        suggestJenis();
    }
    // transport khusus anggota ikut disamakan?
    const custom = Object.entries(perOrang).filter(([, o]) => o.trans).map(([c]) => c);
    if (custom.length && confirm(`${custom.length} anggota punya transport khusus. Samakan juga dengan transport hasil penyesuaian ini?`)) {
        for (const c of custom) {
            delete perOrang[c].trans;
            delete perOrang[c].riilLok;
            poClean(c);
        }
    }
    applyKampung(true);
    const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
    let manual = 0;
    for (let i = 1; i <= MAXTR; i++) {
        const k = form["KetTransport_" + i].value;
        if (k && !AUTO_RE.test(k))
            manual++;
    }
    info.innerHTML = `Disesuaikan dengan <b>${list.length} kampung</b>: ${list.map(k => esc(title(k.kampung))).join(" → ")} · jenis <b>${esc(form.JENIS.value)}</b>, ${num(form.LAMA_JALAN.value) || 1} hari`
        + (unknown.length ? ` · <span class="bad">tidak dikenali: ${esc(unknown.slice(0, 4).join(", "))}</span>` : "")
        + (manual ? ` · ${manual} baris manual tetap dipertahankan` : "")
        + (!found.length ? " · (Tempat tujuan tidak berisi kampung SK — memakai kampung yang sudah dipilih)" : "");
    $("#h-tujuan").innerHTML = found.length ? `Terdeteksi <b>${found.length} kampung</b>: ${found.map(k => esc(title(k.kampung))).join(" → ")}` : "";
    toast("Transport disesuaikan dengan kampung tujuan.");
};
form.TEMPAT_TUJUAN.addEventListener("paste", () => setTimeout(() => tujuanToChips(true), 0));
form.TEMPAT_TUJUAN.addEventListener("change", () => tujuanToChips(false));
form.TEMPAT_TUJUAN.addEventListener("keydown", (e) => { if (e.key === "Enter") {
    e.preventDefault();
    tujuanToChips(true);
} });
form.TEMPAT_TUJUAN.addEventListener("input", debounce(() => tujuanToChips(false), 350));
document.addEventListener("click", e => {
    if (!tg(e).closest(".kchips"))
        return;
    const x = tg(e).dataset.x, pp = tg(e).dataset.pp;
    if (x != null) {
        chips.splice(+x, 1);
        applyKampung();
    }
    const lf = tg(e).dataset.left;
    if (lf != null) {
        const i = +lf;
        [chips[i - 1], chips[i]] = [chips[i], chips[i - 1]];
        applyKampung();
    }
    if (pp != null) {
        chips[+pp].pp = !chips[+pp].pp;
        applyKampung();
    }
});
/* anggota tim — hanya bila pelaksana "Terlampir" (kosong → otomatis Terlampir saat anggota ditambah) */
function angLocked() { const v = form.KD_NAMA_SPD.value.trim(); if (!v)
    return false; const c = resolvePeg(v); return !(c === "999" || /^terlampir$/i.test(v) || /terlampir/i.test(pegMap()[c ?? ""]?.nama || "")); }
function angLockUI() {
    const L = angLocked();
    $("#angPick").disabled = L;
    $("#angAdd").disabled = L;
    $("#angPick").placeholder = L ? "Pelaksana bukan Terlampir — anggota lampiran tidak bisa dipilih" : "Ketik nama anggota lalu pilih / Enter (boleh lebih dari 5 orang)";
    $("#angLockNote").hidden = !L;
}
function renderMembers() {
    const P = pegMap();
    $("#angTbl tbody").innerHTML = members.map((c, i) => {
        const p = P[c];
        return `<tr><td>${i + 1}.</td><td>${p ? esc(p.nama) : `<span class="bad">Kode ${esc(c)} tidak ditemukan</span>`}</td><td>${esc(p?.nip)}</td><td>${esc([p?.pangkat, p?.gol].filter(x => x && x !== "-").join(" / "))}</td><td>${esc(p?.jabatan)}</td>
    <td style="white-space:nowrap"><button class="btn sm" type="button" data-up="${i}" ${i ? "" : "disabled"}>↑</button> <button class="btn sm" type="button" data-dn="${i}" ${i < members.length - 1 ? "" : "disabled"}>↓</button> <button class="btn sm del" type="button" data-rm="${i}">×</button></td></tr>`;
    }).join("")
        || `<tr><td colspan="6" class="muted">Belum ada anggota — surat untuk satu orang tidak memerlukan lampiran.</td></tr>`;
    $("#angCount").textContent = members.length + " orang";
}
function addMember() {
    const inp = $("#angPick"), c = resolvePeg(inp.value);
    if (!inp.value.trim())
        return;
    if (angLocked()) {
        inp.value = "";
        return toast("Anggota lampiran hanya bisa dipilih bila Pelaksana diisi Terlampir.", "warn");
    }
    if (!c)
        return toast("Pegawai tidak ditemukan. Tambahkan di tab Pegawai.");
    inp.value = "";
    if (members.includes(c))
        return toast(`${pegMap()[c]?.nama || "Petugas ini"} sudah ada di daftar anggota — petugas yang sama tidak boleh dipilih dua kali.`, "warn");
    const cf = findConflicts({ ...readForm(), KD_NAMA_SPD: c, lampiran: [], KodeLampiran1: undefined }, records, editingId);
    if (cf.length)
        toast(`⚠ ${cf[0].nama.split(",")[0]} sudah bertugas ${cf[0].tgl} (ST ${cf[0].nomor}).`);
    members.push(c);
    if (!form.KD_NAMA_SPD.value.trim() && pegMap()["999"])
        form.KD_NAMA_SPD.value = pegLabel("999");
    renderMembers();
    refresh();
}
$("#angAdd").onclick = addMember;
$("#angPick").addEventListener("keydown", e => { if (e.key === "Enter") {
    e.preventDefault();
    addMember();
} });
$("#angPick").addEventListener("input", e => { if (isPegName(tg(e).value))
    addMember(); });
$("#angTbl").addEventListener("click", e => {
    const d = tg(e).dataset;
    let i;
    if (d.rm != null)
        members.splice(+d.rm, 1);
    else if (d.up != null) {
        i = +d.up;
        [members[i - 1], members[i]] = [members[i], members[i - 1]];
    }
    else if (d.dn != null) {
        i = +d.dn;
        [members[i + 1], members[i]] = [members[i], members[i + 1]];
    }
    else
        return;
    renderMembers();
    refresh();
});
/* ---- petugas ganda: nama sama + tanggal bertumpuk ---- */
function personsOf(r, P = pegMap()) {
    const codes = [...new Set([r.KD_NAMA_SPD, ...lampOf(r)].map(codeOf).filter(c => c && c !== "999"))];
    return codes.map(c => P[c]).filter(p => p && !/^terlampir$/i.test(p.nama.trim())).map(p => ({ key: normName(p.nama), nama: p.nama }));
}
/* ---- OB / kontrak honor: petugas terikat pada rentang tanggal tertentu ---- */
const makRO = (m) => { const p = normMak(m).split("."); return p.length >= 3 ? p.slice(0, 3).join(".") : ""; }; // mis. 2902.FAN.ZZI
const isoOf = (t) => { const d = parseTgl(t); return d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}` : ""; };
function obConflicts(r) {
    const R0 = rangeOf(r);
    if (!R0 || !R0.a || typeof honorDB === "undefined")
        return [];
    const P = pegMap(), people = new Set(personCodes(r, P)), out = [], ro = makRO(r.MAK);
    for (const h of honorDB) {
        if (!(h.rows || []).some(x => x.unit === "OB"))
            continue;
        const fr = (h.rows || []).map(x => parseTgl(x.obFrom)?.getTime()).filter((t) => t != null), to = (h.rows || []).map(x => parseTgl(x.obTo)?.getTime()).filter((t) => t != null);
        const a = parseTgl(h.obFrom) || (fr.length ? new Date(Math.min(...fr)) : null), b = parseTgl(h.obTo) || (to.length ? new Date(Math.max(...to)) : a);
        if (!a || !b)
            continue;
        for (const x of h.rows) {
            if (!x.c || !people.has(String(x.c)))
                continue;
            if (!(R0.a <= b && a <= R0.b))
                continue;
            const p = P[x.c] || {}, hro = makRO(h.MAK), same = !!hro && hro === ro, mit = isMitra(p);
            if (mit ? same : (same && isPelatihan(r)))
                continue; // mitra: MAK kegiatan sama; pegawai: Pelatihan + MAK kegiatan sama
            out.push({ nama: String(p.nama || x.nama || x.c).split(",")[0], mit, judul: h.judul2 || h.judul1 || "honor", per: `${fmtDate(a)} – ${fmtDate(b)}`, hro });
        }
    }
    return out;
}
const obMsg = (o) => o.mit
    ? `${o.nama} (mitra) terikat OB/kontrak "${o.judul}" pada ${o.per} — surat tugas di rentang ini hanya boleh dengan MAK kegiatan yang sama (${o.hro || "MAK honor belum diisi"}).`
    : `${o.nama} (pegawai) terikat OB/kontrak "${o.judul}" pada ${o.per} — hanya boleh surat tugas jenis Pelatihan dengan MAK kegiatan yang sama (${o.hro || "MAK honor belum diisi"}).`;
function rangeOf(r) {
    const a = parseTgl(r.TGL_PERGI);
    const b = parseTgl(r.TGL_PULANG) || a;
    if (a && b)
        return { a, b: b < a ? a : b };
    return r.TGL_PERGI ? { raw: String(r.TGL_PERGI).trim().toLowerCase() + "|" + String(r.TGL_PULANG || "").trim().toLowerCase() } : null;
}
const overlaps = (x, y) => !!(x && y) && (x.a && y.a ? x.a <= y.b && y.a <= x.b : !!x.raw && x.raw === y.raw);
function findConflicts(r, pool, excludeNO, P = pegMap()) {
    const R0 = rangeOf(r);
    if (!R0)
        return [];
    const mine = personsOf(r, P);
    if (!mine.length)
        return [];
    const keys = new Set(mine.map(p => p.key)), out = [];
    for (const x of pool) {
        if (excludeNO != null && x._id === excludeNO)
            continue;
        if (!overlaps(R0, rangeOf(x)))
            continue;
        for (const p of personsOf(x, P))
            if (keys.has(p.key))
                out.push({ nama: p.nama, no: x.NO, nomor: "B-" + x.NO + (x.NoLengkap || ""), tgl: (x.TGL_PERGI || "") + (x.TGL_PULANG && x.TGL_PULANG !== x.TGL_PERGI ? " – " + x.TGL_PULANG : "") });
    }
    return out;
}
/* ---- anggaran POK ---- */
const normMak = (s) => String(s || "").replace(/\s+/g, "").toUpperCase();
const PJ_AKUN = ["524111", "524113", "524114"], HO_AKUN = ["521213"];
const akunOf = (m) => normMak(m).split(".").pop() ?? "";
/* akun MAK yang boleh untuk surat tugas: perjalanan dinas; jenis Pelatihan juga boleh akun honor 521213 */
const ST_AKUN = (pel) => pel ? [...PJ_AKUN, ...HO_AKUN] : PJ_AKUN;
const akunST = (r) => ST_AKUN(isPelatihan(r));
const akunTxt = (ak) => ak.join(" / ");
const formPel = () => form.JENIS.value === "Pelatihan";
const acPel = (el) => !el ? false : el.closest("#f") ? formPel() : el.closest("#mCommon") ? massRows.some(r => r.jenis === "Pelatihan") : false;
const pokJudul = (ak = PJ_AKUN) => new Set(pokDB.akun.filter(a => ak.includes(a.akun)).map(a => String(a.roNama).trim()));
/** semua kode RO yang berjudul t (judul RO bisa sama di beberapa kegiatan, mis. 8130.BMA.007 & 2910.BMA.007) */
const rosOfJudul = (t, ak = PJ_AKUN) => [...new Set(pokDB.akun.filter(a => ak.includes(a.akun) && String(a.roNama).trim() === String(t || "").trim()).map(a => a.ro))];
const roOfJudul = (t, ak = PJ_AKUN) => { const a = pokDB.akun.find(a => ak.includes(a.akun) && String(a.roNama).trim() === String(t || "").trim()); return a ? a.ro : null; };
const pokMap = () => Object.fromEntries(pokDB.akun.map(a => [a.mak, a]));
function usage() {
    if (_use)
        return _use;
    _use = {};
    for (const r of records) {
        const k = normMak(r.MAK);
        if (!k)
            continue;
        const u = _use[k] ||= { j: 0, n: 0 };
        u.j += computeC(r)._num.jmlTotal;
        u.n++;
    }
    for (const h of (honorDB || [])) {
        const k = normMak(h.MAK);
        if (!k)
            continue;
        const u = _use[k] ||= { j: 0, n: 0 };
        u.j += hoTot(h).bruto;
        u.n++;
    }
    return _use;
}
function budgetOf(mak, excludeNO) {
    const k = normMak(mak), a = pokMap()[k];
    if (!a)
        return null;
    let j = usage()[k]?.j || 0, n = usage()[k]?.n || 0;
    if (excludeNO != null) {
        const r = records.find(x => x._id === excludeNO);
        if (r && normMak(r.MAK) === k) {
            j -= compute(r)._num.jml;
            n--;
        }
    }
    return { a, pagu: a.pagu, blokir: a.blokir, terpakai: j, n, sisa: a.pagu - a.blokir - j };
}
function budgetHtml(mak, add, excludeNO, addLabel = "surat ini") {
    if (!mak)
        return "";
    const b = budgetOf(mak, excludeNO);
    if (!b)
        return `<span class="neg">MAK tidak ditemukan di POK ${esc(pokDB.meta?.tanggal || "")}</span>`;
    const after = b.sisa - add;
    return `<b>${esc(b.a.nama)}</b> · ${esc(b.a.roNama)} · ${esc(b.a.kompNama)}<br>Pagu Rp ${rupiah(b.pagu)}${b.blokir ? ` · Blokir Rp ${rupiah(b.blokir)}` : ""} · Terpakai Rp ${rupiah(b.terpakai)} (${b.n} ST) · Sisa <b>Rp ${rupiah(b.sisa)}</b>`
        + (add ? ` → setelah ${addLabel} (Rp ${rupiah(add)}): <span class="${after < 0 ? "neg" : "pos"}">Rp ${rupiah(after)}${after < 0 ? " — anggaran tidak cukup" : ""}</span>` : "");
}
const pad3 = (n) => String(n).padStart(3, "0");
function validate(r, others = records, editNo = null, seq = true) {
    if (!r.NO)
        return "No. urut wajib diisi.";
    if (!/^\d+[A-Za-z]{0,3}$/.test(String(r.NO).trim()))
        return `No. urut "${r.NO}" tidak sah — isi angka, boleh diikuti huruf (mis. 504 atau 504A).`;
    if (seq) { // nomor harus berurutan: setelah 530 wajib 531 dulu
        const y = stYear(r), n = parseInt(String(r.NO), 10), old = editNo ? others.find(x => x._id === editNo) : undefined;
        if (n && (!old || noKey(old.NO) !== noKey(r.NO) || stYear(old) !== y)) {
            const max = others.filter(x => x._id !== editNo && stYear(x) === y).reduce((m, x) => Math.max(m, parseInt(String(x.NO), 10) || 0), 0);
            if (n > max + 1)
                return `Nomor harus berurutan: nomor terakhir${y ? " tahun " + y : ""} adalah ${pad3(max)}, jadi surat berikutnya No. ${pad3(max + 1)} (tidak boleh langsung ${r.NO}).`;
        }
    }
    if (!r.MAKSUD__TUJUAN)
        return "Maksud / tujuan wajib diisi.";
    if (!r.KD_NAMA_SPD)
        return "Pelaksana SPD wajib diisi.";
    {
        const lp = lampOf(r).map(codeOf).filter(Boolean), pl = codeOf(r.KD_NAMA_SPD);
        if (lp.length && pl !== "999" && !/terlampir/i.test(pegMap()[pl]?.nama || ""))
            return "Anggota lampiran hanya boleh diisi bila Pelaksana = Terlampir. Kosongkan anggota atau ganti Pelaksana menjadi Terlampir.";
        if (new Set(lp).size !== lp.length)
            return "Ada petugas yang sama lebih dari sekali di anggota lampiran.";
    }
    {
        const le = lokalErr(r);
        if (le)
            return le;
    }
    {
        const y = stYear(r);
        if (others.some(x => x._id !== editNo && noKey(x.NO) === noKey(r.NO) && stYear(x) === y))
            return `Nomor ${r.NO} sudah dipakai${y ? " pada tahun " + y : ""}.`;
    }
    const cf = findConflicts(r, others, editNo);
    if (cf.length)
        return `Tidak bisa dibuat: ${cf[0].nama.split(",")[0]} sudah punya surat tugas ${cf[0].nomor} pada ${cf[0].tgl}.`;
    return null;
}
function signErr(r, old) {
    for (const [f, rs, lbl] of SIGN_FIELDS) {
        const c = codeOf(r[f]);
        if (!c)
            continue;
        if (old && codeOf(old[f]) === c)
            continue; // surat lama: penanda tangan yang tidak diubah tetap boleh
        if (!roleOk(c, rs))
            return `${lbl}: ${pegMap()[c]?.nama || c} tidak punya peran ${rs.map(x => ROLE_NAME[x]).join(" / ")}. Pilih dari daftar, atau atur perannya di Database → Pegawai.`;
    }
    return null;
}
function save() {
    const r = readForm();
    {
        const old = editingId ? records.find(x => x._id === editingId) : undefined, key = (x) => JSON.stringify([x.TGL_PERGI, x.TGL_PULANG, normMak(x.MAK), x.JENIS, personCodes(x)]);
        if (!old || key(old) !== key(r)) {
            const ob = obConflicts(r);
            if (ob.length) {
                toast("⚠ " + obMsg(ob[0]) + (ob.length > 1 ? ` (+${ob.length - 1} lainnya)` : ""));
                showSub("data");
                return null;
            }
        }
    }
    for (let i = 1; i <= MAXTR; i++)
        if (/^Biaya Lintasan Mobil/i.test(r["KetTransport_" + i] || "") && num(r["Nilai" + i]) < minLintasMobil()) {
            toast(`Baris transport ${i}: Biaya Lintasan Mobil minimal Rp ${rupiah(minLintasMobil())} (atur di Pengaturan → Tarif bawaan).`);
            showSub("biaya");
            return null;
        }
    {
        const e = signErr(r, editingId == null ? null : records.find(x => x._id === editingId));
        if (e) {
            toast(e);
            return null;
        }
    }
    {
        const old = editingId && records.find(x => x._id === editingId);
        if (!old || String(old.kegiatan || "").trim() !== String(r.kegiatan || "").trim()) {
            if (!r.kegiatan) {
                toast(r._kegLain ? "Tulis nama kegiatan." : "Kegiatan wajib dipilih dari judul RO POK, atau centang \"Kegiatan lainnya\".");
                return null;
            }
            if (!r._kegLain && !pokJudul(akunST(r)).has(String(r.kegiatan).trim())) {
                toast(`"${r.kegiatan}" bukan judul RO di POK — pilih dari daftar.`);
                return null;
            }
        }
        if (r.MAK && (!old || normMak(old.MAK) !== normMak(r.MAK) || old.JENIS !== r.JENIS) && !akunST(r).includes(akunOf(r.MAK))) {
            toast(isPelatihan(r) ? `MAK surat tugas Pelatihan harus akun ${akunTxt(akunST(r))}.` : `MAK surat tugas harus akun perjalanan dinas ${akunTxt(PJ_AKUN)} (akun 521213 hanya untuk jenis Pelatihan).`);
            return null;
        }
        if (r.MAK && (!old || normMak(old.MAK) !== normMak(r.MAK) || old.kegiatan !== r.kegiatan)) {
            const ros = rosOfJudul(r.kegiatan, akunST(r)), ro = ros.join(" / "), mro = pokMap()[normMak(r.MAK)]?.ro;
            if (ros.length && mro && !ros.includes(mro)) {
                toast(`MAK ${r.MAK} bukan bagian dari RO ${ro} (${r.kegiatan}).`);
                return null;
            }
        }
    }
    const err = validate(r, records, editingId);
    if (err) {
        toast(err);
        refresh();
        return null;
    }
    const b = budgetOf(r.MAK, editingId), jml = compute(r)._num.jml;
    if (b && b.sisa - jml < 0 && !confirm(`Sisa anggaran MAK ${r.MAK} hanya Rp ${rupiah(b.sisa)}, sedangkan surat ini Rp ${rupiah(jml)}.\n\nTetap simpan?`))
        return null;
    if (r.MAK && !b && !confirm(`MAK "${r.MAK}" tidak ada di POK. Tetap simpan?`))
        return null;
    const i = editingId ? records.findIndex(x => x._id === editingId) : -1;
    if (i >= 0) {
        r._id = editingId ?? undefined;
        records[i] = r;
    }
    else {
        r._id = newId();
        records.push(r);
    }
    editingId = r._id ?? null;
    persist();
    setEditFlag();
    renderList();
    buildLists();
    toast("Tersimpan: " + compute(r).NOMOR_ST);
    return r;
}
const savedMsg = (r, extra = "") => `${compute(r).NOMOR_ST} — ${compute(r).NAMA_PELAKSANA_SPD || "-"} berhasil disimpan${extra}. Kembali ke Beranda atau tetap di halaman ini?`;
$("#bSave").onclick = () => { const r = save(); if (r)
    toast(`✓ Berhasil disimpan ke Daftar: ${compute(r).NOMOR_ST}`); };
let dlRec = null;
$("#bSaveDl").onclick = () => {
    const r = save();
    if (!r)
        return;
    dlRec = r;
    const F = compute(r);
    $("#dlMsg").textContent = `${F.NOMOR_ST} — ${F.NAMA_PELAKSANA_SPD || "-"} sudah tersimpan. Pilih dokumen yang ingin diunduh:`;
    $$("#dDl [data-dl]").forEach(b => b.disabled = false);
    const pel = isPelatihan(r), bb = $('#dDl [data-dl="biaya"]');
    bb.dataset.orig ||= bb.innerHTML;
    bb.innerHTML = pel ? `<span><b>Daftar Transport Pelatihan</b><br><small class="muted">Daftar bayar transport semua petugas (.xlsx)</small></span>` : bb.dataset.orig;
    $('#dDl [data-dl="both"] small').textContent = pel ? "Surat Tugas + daftar transport" : "2 file terpisah";
    $("#dlStNote").textContent = pel ? "Surat Tugas & Lampiran ST (pelatihan: tanpa SPD & Lampiran SPPD)" : "ST, SPD, Lampiran SPPD, Lampiran ST";
    $("#dDl").showModal();
};
$$("#dDl [data-dl]").forEach(b => b.onclick = async () => {
    const w = b.dataset.dl, r = dlRec;
    if (!r)
        return;
    $$("#dDl [data-dl]").forEach(x => x.disabled = true);
    if (w === "st" || w === "both")
        await downloadRec(r, "st");
    if (w === "both")
        await pause(400);
    if (w === "biaya" || w === "both") {
        if (isPelatihan(r))
            await downloadPelatihan(r).catch(e => toast("Gagal: " + e.message));
        else
            await downloadRec(r, "biaya");
    }
    $("#dDl").close();
    const what = w === "st" ? " dan Surat Tugas diunduh" : w === "biaya" ? (isPelatihan(r) ? " dan daftar transport pelatihan diunduh" : " dan Rincian Biaya diunduh") : w === "both" ? " dan kedua dokumen diunduh" : "";
    afterSave("Surat tugas tersimpan", savedMsg(r, what));
});
function formHasContent() { const r = readForm(); return !!(r.MAKSUD__TUJUAN || r.kegiatan || r.KD_NAMA_SPD || r.TGL_PERGI || chips.length || members.length); }
$("#bNewSt").onclick = () => {
    if (formHasContent() && !confirm(editingId ? `Buat surat tugas baru? Perubahan pada surat No. ${form.NO.value} yang belum disimpan akan hilang.` : "Buat surat tugas baru? Isian yang belum disimpan akan hilang."))
        return;
    newForm();
    window.scrollTo(0, 0);
    toast("Formulir surat tugas baru siap diisi.", "ok");
};
$("#bClear").onclick = () => {
    if (formHasContent() && !confirm(editingId ? `Bersihkan formulir? Perubahan pada surat No. ${form.NO.value} yang belum disimpan akan hilang.` : "Bersihkan formulir? Isian yang belum disimpan akan hilang."))
        return;
    newForm();
    window.scrollTo(0, 0);
    toast("Surat Tugas Personal dibersihkan — siap untuk surat baru.");
};
function showSub(s) { $$(".subtabs button").forEach(b => b.classList.toggle("on", b.dataset.s === s)); $$(".sub").forEach(x => x.classList.toggle("on", x.id === "s-" + s)); }
$$("[data-back]").forEach(b => b.onclick = () => { show("list"); window.scrollTo(0, 0); });
$$(".subtabs button[data-s]").forEach(b => b.onclick = () => { showSub(b.dataset.s ?? "data"); window.scrollTo(0, 0); });
/* ================= RINCIAN PER ANGGOTA ================= */
/** baris transport surat: [keterangan, nilai] × MAXTR */
function poBaseRows(r) { const rows = []; for (let i = 1; i <= MAXTR; i++)
    rows.push([r["KetTransport_" + i] ?? "", r["Nilai" + i] ?? ""]); return rows; }
function renderPerOrang(force) {
    const card = $("#poCard");
    if (!card)
        return;
    const r = readForm(), P = pegMap(), ps = personCodes(r, P);
    card.hidden = ps.length < 2;
    if (ps.length < 2)
        return;
    $("#poCount").textContent = ps.length + " orang";
    if (!force && $("#poBody").contains(document.activeElement) && document.activeElement?.tagName === "INPUT")
        return updatePoNums(r, ps);
    const lok = noUH(r), noI = noInap(r), base = { ...r };
    delete base._perOrang;
    const inp = (c, f, val, ph, cls = "") => `<input type="number" min="0" step="${/NILAI|TDK/.test(f) ? 1000 : 1}" class="${cls}${val != null && val !== "" ? " custom" : ""}" data-pc="${c}" data-f="${f}" value="${val ?? ""}" placeholder="${ph ?? ""}" ${(/_UH$/.test(f) ? lok : noI) ? "disabled" : ""}>`;
    $("#poBody").innerHTML = ps.map((c, i) => {
        const o = perOrang[c] || {}, nm = (P[c]?.nama || c).split(",")[0];
        let html = `<tr data-c="${c}"><td>${i + 1}.</td><td>${esc(nm)}${Object.keys(o).length ? ` <span class="tag warn">khusus</span>` : ""}</td>
      <td><div class="pair">${inp(c, "LAMA_UH", o.LAMA_UH, base.LAMA_UH)} × ${inp(c, "NILAI_UH", o.NILAI_UH, base.NILAI_UH, "w")}</div><div class="calc" data-o="uh"></div></td>
      <td><div class="pair">${inp(c, "LAMA_INAP", o.LAMA_INAP, base.LAMA_INAP)} × ${inp(c, "TDK_INAP_HOTEL", o.TDK_INAP_HOTEL, base.TDK_INAP_HOTEL, "w")}</div><div class="calc" data-o="inap"></div></td>
      <td><div class="pair">${inp(c, "LAMA_HOTEL", o.LAMA_HOTEL, base.LAMA_HOTEL || 0)} × ${inp(c, "TARIF_HOTEL", o.TARIF_HOTEL, base.TARIF_HOTEL || 0, "w")}</div><div class="calc" data-o="hotel"></div></td>
      <td style="white-space:nowrap"><span data-o="tr"></span> ${o.trans ? `<span class="tag warn">khusus</span>` : ""} <button class="btn sm" type="button" data-potr="${c}">${poOpen.has(c) ? "Tutup" : "Ubah"}</button></td>
      <td class="num"><b data-o="jml"></b></td>
      <td><button class="btn sm" type="button" data-poreset="${c}" title="Samakan dengan rincian utama" ${Object.keys(o).length ? "" : "disabled"}>↺</button></td></tr>`;
        if (poOpen.has(c)) {
            const rows = o.trans || poBaseRows(base);
            let lf = -1;
            rows.forEach(([k, v], j) => { if (k || (v !== "" && v != null))
                lf = j; });
            const vis = Math.max(3, lf + 1);
            html += `<tr class="potr" data-c="${c}"><td></td><td colspan="7"><div style="font-size:12px;margin-bottom:6px" class="muted">Baris transport untuk <b>${esc(nm)}</b>${o.trans ? " (khusus)" : " (sama dengan rincian utama — ubah salah satu baris untuk membuat versi khusus)"}</div>
        <table class="tight"><tbody>${rows.map(([k, v], j) => j <= vis ? `<tr><td class="muted" style="width:24px">${j + 1}</td><td><input class="k" data-pc="${c}" data-tk="${j}" value="${esc(k)}" placeholder="Keterangan transport"></td><td style="width:150px"><input class="w" type="number" min="0" step="1000" data-pc="${c}" data-tv="${j}" value="${v ?? ""}"></td></tr>` : "").join("")}</tbody></table>
        ${o.trans ? `<button class="btn sm" type="button" data-potrreset="${c}" style="margin-top:6px">Samakan transport dengan rincian utama</button>` : ""}</td></tr>`;
        }
        return html;
    }).join("");
    updatePoNums(r, ps);
}
function updatePoNums(r, ps) {
    for (const c of ps) {
        const tr = $(`#poBody tr[data-c="${c}"]:not(.potr)`);
        if (!tr)
            continue;
        const n = compute(personRec(r, c))._num;
        tr.querySelector('[data-o="uh"]').textContent = `= Rp ${rupiah(n.totUH)}`;
        tr.querySelector('[data-o="inap"]').textContent = `= Rp ${rupiah(n.totInap)}`;
        tr.querySelector('[data-o="hotel"]').textContent = `= Rp ${rupiah(n.totHotel)}`;
        tr.querySelector('[data-o="tr"]').textContent = `Rp ${rupiah(n.totTr)}`;
        tr.querySelector('[data-o="jml"]').textContent = `Rp ${rupiah(n.jml)}`;
    }
}
function poClean(c) { const o = perOrang[c]; if (o && !Object.keys(o).length)
    delete perOrang[c]; }
$("#poBody").addEventListener("input", e => {
    const t = tg(e), c = t.dataset.pc;
    if (!c)
        return;
    const o = perOrang[c] ||= {};
    if (t.dataset.f) {
        if (t.value === "")
            delete o[t.dataset.f];
        else
            o[t.dataset.f] = Number(t.value);
        t.classList.toggle("custom", t.value !== "");
    }
    else if (t.dataset.tk != null || t.dataset.tv != null) {
        if (!o.trans) {
            const base = readForm();
            delete base._perOrang;
            o.trans = poBaseRows(base);
        }
        while (o.trans.length < MAXTR)
            o.trans.push(["", ""]);
        const j = Number(t.dataset.tk ?? t.dataset.tv);
        if (t.dataset.tk != null)
            o.trans[j][0] = t.value;
        else
            o.trans[j][1] = t.value === "" ? "" : Number(t.value);
    }
    poClean(c);
    refresh();
});
$("#poBody").addEventListener("focusout", e => { if (!$("#poBody").contains(e.relatedTarget))
    setTimeout(() => { if (!$("#poBody").contains(document.activeElement))
        renderPerOrang(); }, 0); });
$("#poBody").addEventListener("click", e => {
    const d = tg(e).dataset;
    if (d.potr) {
        poOpen.has(d.potr) ? poOpen.delete(d.potr) : poOpen.add(d.potr);
        renderPerOrang(true);
    }
    else if (d.poreset) {
        delete perOrang[d.poreset];
        refresh();
        renderPerOrang(true);
    }
    else if (d.potrreset) {
        if (perOrang[d.potrreset]) {
            delete perOrang[d.potrreset].trans;
            delete perOrang[d.potrreset].riilLok;
        }
        poClean(d.potrreset);
        refresh();
        renderPerOrang(true);
    }
});
$("#poResetAll").onclick = () => { if (!Object.keys(perOrang).length)
    return toast("Semua anggota sudah sama dengan rincian utama."); if (confirm("Samakan rincian semua anggota dengan rincian utama?")) {
    perOrang = {};
    poOpen.clear();
    refresh();
    renderPerOrang(true);
} };

/* ---- 50_massal.ts ---- */
/* ================= MASSAL ================= */
const mIn = (k) => $(`#mCommon [data-m="${k}"]`);
var _mY = null;
/** isian "data bersama" surat kolektif ([data-m]) + kegLain */
function readCommon() { const o = {}; $$("#mCommon [data-m]").forEach(e => { if (e.dataset.m)
    o[e.dataset.m] = e.value.trim(); }); o.kegLain = $("#mKegLain").checked; return o; }
function fillCommon(o) {
    $$("#mCommon [data-m]").forEach(e => { const k = e.dataset.m ?? ""; if (o[k] != null)
        e.value = o[k]; });
    const kl = o.kegLain != null ? !!o.kegLain : !!(o.kegiatan && !pokJudul().has(String(o.kegiatan).trim()));
    kegMode(mIn("kegiatan"), $("#mKegLain"), kl);
}
function commonFrom(r) {
    const o = { kode: kodeFromNL(r.NoLengkap), NoLengkap: r.NoLengkap || "", TGL_TERBIT_ST: r.TGL_TERBIT_ST || today(), kegiatan: r.kegiatan || "", MAK: r.MAK || "", MAKSUD__TUJUAN: r.MAKSUD__TUJUAN || "",
        ALAT_ANGKUTAN_YANG_DIGUNAKAN: r.ALAT_ANGKUTAN_YANG_DIGUNAKAN || "Darat", TEMPAT_BERANGKAT: r.TEMPAT_BERANGKAT || "Kampung Semu", NILAI_UH: r.NILAI_UH ?? "", TDK_INAP_HOTEL: r.TDK_INAP_HOTEL ?? "", TGL_KUI: r.TGL_KUI || "" };
    for (const k of ["No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "No_Bend"])
        o[k] = r[k] != null ? pegLabel(r[k]) : "";
    return o;
}
function massRecords() {
    const c = readCommon(), mY = yrOf(c.TGL_TERBIT_ST) || new Date().getFullYear(), nxN = parseInt(nextNo([], mY), 10);
    const startN = parseInt(c.start, 10) || nxN;
    const pad = Math.max(3, String(c.start || "").length);
    const PJ_JUDUL = pokJudul(ST_AKUN(true));
    const out = massRows.map((row, idx) => {
        const errs = [];
        if (startN > nxN)
            errs.push(`nomor harus berurutan — No. urut mulai seharusnya ${pad3(nxN)}`);
        for (const [f, rs, lbl] of SIGN_FIELDS.slice(0, 3)) {
            const cc = resolvePeg(c[f]);
            if (cc && !roleOk(cc, rs))
                errs.push(`${lbl} harus pegawai berperan ${rs.map(x => ROLE_NAME[x]).join(" / ")}`);
        }
        if (!c.kegiatan)
            errs.push(c.kegLain ? "kegiatan belum diisi di data bersama" : "kegiatan (judul RO POK) belum dipilih di data bersama");
        else if (!c.kegLain && !PJ_JUDUL.has(c.kegiatan.trim()))
            errs.push("kegiatan harus judul RO dari POK (atau centang Kegiatan lainnya)");
        else if (!c.kegLain && c.MAK && pokMap()[normMak(c.MAK)] && !rosOfJudul(c.kegiatan, ST_AKUN(true)).includes(pokMap()[normMak(c.MAK)].ro))
            errs.push("MAK bukan dari RO kegiatan");
        const r = { NO: String(startN + idx).padStart(pad, "0"), ...(c.kegLain ? { _kegLain: true } : {}), NoLengkap: c.NoLengkap, TGL_TERBIT_ST: c.TGL_TERBIT_ST, kegiatan: c.kegiatan, MAK: c.MAK, MAKSUD__TUJUAN: String(row.maksud || "").trim() || c.MAKSUD__TUJUAN,
            ALAT_ANGKUTAN_YANG_DIGUNAKAN: c.ALAT_ANGKUTAN_YANG_DIGUNAKAN, TEMPAT_BERANGKAT: c.TEMPAT_BERANGKAT, TGL_PERGI: row.pergi || "", TGL_PULANG: row.pulang || "", _noBiaya: true };
        for (const k of ["No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD"]) {
            const v = resolvePeg(c[k]);
            if (v)
                r[k] = v;
        }
        migrateRow(row);
        const lampCodes = row.ang.filter((c) => pegMap()[c]);
        row.angBad.forEach((a) => errs.push(`anggota "${a}" tidak dikenal`));
        setLamp(r, lampCodes);
        const pl = row.peg ? resolvePeg(row.peg) : (lampCodes.length && pegMap()["999"] ? "999" : null);
        if (pl)
            r.KD_NAMA_SPD = pl;
        else
            errs.push(row.peg ? `pelaksana "${row.peg}" tidak dikenal` : "pelaksana kosong");
        if (pl && pl !== "999" && lampCodes.length)
            errs.push("anggota lampiran hanya boleh diisi bila Pelaksana Terlampir (kosongkan Pelaksana)");
        const KM = kamByKey(), found = row.kam.map((k) => KM[k]).filter(Boolean), unknown = row.kamBad.slice();
        r._kampung = found.map(k => ({ k: kKey(k), pp: true }));
        r.TEMPAT_TUJUAN = found.length ? tujuanText(found) + (unknown.length ? ", " + unknown.join(", ") : "") : unknown.join(", ");
        r.JENIS = ["Lokal", "Remote", "Pelatihan", JEN_TU].includes(row.jenis) ? row.jenis : (found.length && found.every(k => kamLokal(k)) ? "Lokal" : "Remote");
        {
            const le = lokalErr(r);
            if (le)
                errs.push(le.replace(/\.$/, ""));
        }
        if (c.MAK && !akunST(r).includes(akunOf(c.MAK)))
            errs.push(isPelatihan(r) ? `MAK harus akun ${akunTxt(akunST(r))}` : `MAK harus akun ${akunTxt(PJ_AKUN)} (521213 hanya untuk Pelatihan)`);
        const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG);
        if (r.TGL_PERGI && !a)
            errs.push("tgl pergi tidak terbaca");
        if (r.TGL_PULANG && !b)
            errs.push("tgl pulang tidak terbaca");
        if (a && b && b < a)
            errs.push("tgl pulang sebelum tgl pergi");
        const L = a && b && b >= a ? dayDiff(a, b) : (a && !r.TGL_PULANG ? 1 : 0);
        if (L)
            r.LAMA_JALAN = L;
        if (!r.TGL_PERGI)
            errs.push("tanggal pergi kosong");
        return { r, errs, L, luar: unknown };
    });
    // aturan yang sama dengan Formulir: wajib isi, nomor unik, petugas tidak bentrok tanggal
    const P = pegMap(), done = [];
    for (const x of out) {
        for (const o of obConflicts(x.r))
            x.errs.push(obMsg(o));
        const v = validate(x.r, records, null, false);
        if (v && !/sudah punya surat tugas/.test(v))
            x.errs.push(v.replace(/\.$/, ""));
        for (const cf of findConflicts(x.r, records, null, P))
            x.errs.push(`${cf.nama.split(",")[0]} sudah bertugas ${cf.tgl} (ST ${cf.nomor})`);
        for (const cf of findConflicts(x.r, done, null, P))
            x.errs.push(`${cf.nama.split(",")[0]} bentrok dengan baris No. ${cf.no} (${cf.tgl})`);
        x.errs = [...new Set(x.errs)];
        done.push(x.r);
    }
    return out;
}
/* ---- chip picker (anggota & kampung) per baris massal ---- */
/** baris lama (teks anggota/kampung) → daftar kode */
function migrateRow(row) {
    if (!Array.isArray(row.ang)) {
        const ang = [], angBad = [];
        for (const a of splitPeople(row.anggota)) {
            const c = resolvePeg(a);
            if (c) {
                if (!ang.includes(c))
                    ang.push(c);
            }
            else
                angBad.push(a);
        }
        row.ang = ang;
        row.angBad = angBad;
    }
    if (!Array.isArray(row.kam)) {
        if (row.kamTxt == null && row.kampung)
            row.kamTxt = String(row.kampung);
        const pk = parseKampungList(row.kampung);
        row.kam = pk.found.map(kKey);
        row.kamBad = pk.unknown;
    }
    delete row.anggota;
    delete row.kampung;
    return row;
}
function cpickHtml(row, kind) {
    migrateRow(row);
    const P = pegMap(), M = kamByKey();
    const good = kind === "ang"
        ? row.ang.map((c, j) => `<span class="mchip" title="${esc(P[c]?.jabatan || "")}">${esc((P[c]?.nama || "Kode " + c).split(",")[0])}<button type="button" data-cx="ang" data-ci="${j}" title="Hapus">×</button></span>`)
        : row.kam.map((k, j) => { const x = M[k]; return `<span class="mchip"><small>${j + 1}</small>${esc(x ? title(x.kampung) : k)}<button type="button" data-cx="kam" data-ci="${j}" title="Hapus">×</button></span>`; });
    const bad = (kind === "ang" ? row.angBad : row.kamBad).map((t, j) => `<span class="mchip bad" title="Tidak dikenal">${esc(t)}<button type="button" data-cx="${kind}Bad" data-ci="${j}">×</button></span>`);
    return `<div class="cpick">${good.join("")}${bad.join("")}<input class="cp-in" data-cp="${kind}" ${kind === "ang" ? 'data-ac="peg" autocomplete="off"' : 'data-ac="kam" autocomplete="off"'} placeholder="${kind === "ang" ? (row.ang.length ? "+ tambah" : "ketik nama…") : (row.kam.length ? "+ kampung" : "ketik nama kampung…")}"></div>`;
}
/** tambah anggota / kampung dari teks; kembalikan jumlah yang ditambahkan */
function cpAdd(i, kind, text) {
    const row = massRows[i];
    if (!row)
        return 0;
    let n = 0;
    {
        const lk = kind === "kam" ? kIdx().label.get(String(text).trim()) : undefined; // dipilih dari daftar saran → kampung itu saja
        if (lk) {
            if (row.kam.includes(kKey(lk))) {
                toast("Kampung sudah dipilih.");
                return 0;
            }
            row.kam.push(kKey(lk));
            return 1;
        }
    }
    if (kind === "kam" && !kIdx().label.has(String(text).trim())) { // teks bebas / tempelan → deteksi semua kampung di dalamnya
        const d = detectKampung(text);
        if (d.found.length) {
            for (const k of d.found)
                if (!row.kam.includes(kKey(k))) {
                    row.kam.push(kKey(k));
                    n++;
                }
            if (d.unknown.length)
                toast(`Tidak dikenali di SK: ${d.unknown.slice(0, 3).join(", ")}`);
            else if (!n)
                toast("Kampung sudah dipilih.");
            return n;
        }
    }
    const parts = kind === "ang" ? splitPeople(text) : String(text).split(/,|;/).map(t => t.trim()).filter(Boolean);
    for (const t of parts) {
        if (kind === "ang" && row.peg && resolvePeg(row.peg) && resolvePeg(row.peg) !== "999") {
            toast("Anggota lampiran hanya bisa dipilih bila Pelaksana kosong / Terlampir.", "warn");
            return n;
        }
        if (kind === "ang") {
            const c = resolvePeg(t);
            if (!c) {
                toast(`"${t}" tidak ditemukan di Pegawai & Mitra.`);
                continue;
            }
            if (row.ang.includes(c)) {
                toast(`${pegMap()[c]?.nama || "Petugas"} sudah ada di anggota — tidak boleh dipilih dua kali.`, "warn");
                continue;
            }
            row.ang.push(c);
            n++;
        }
        else if (parts.length === 1 && detectKampung(t).found.length > 1) {
            for (const k of detectKampung(t).found) {
                if (!row.kam.includes(kKey(k))) {
                    row.kam.push(kKey(k));
                    n++;
                }
            }
        }
        else {
            let k = findKampung(t);
            if (!k) {
                const d = detectKampung(t).found;
                if (d.length === 1)
                    k = d[0];
            }
            if (!k) {
                const hs = kampungDB.filter(x => x.kampung.toLowerCase().includes(t.toLowerCase()));
                if (hs.length === 1)
                    k = hs[0];
                else {
                    toast(hs.length ? `${hs.length} kampung cocok untuk "${t}" — pilih dari daftar.` : `Kampung "${t}" tidak ada di SK.`);
                    continue;
                }
            }
            if (row.kam.includes(kKey(k))) {
                toast("Kampung sudah dipilih.");
                continue;
            }
            row.kam.push(kKey(k));
            n++;
        }
    }
    return n;
}
function cpRefresh(i, kind, focus) {
    const td = $(`#mTbl .mrow[data-i="${i}"] .cp-cell[data-c="${kind}"]`);
    if (!td)
        return;
    td.querySelector(".cpick").outerHTML = cpickHtml(massRows[i], kind === "ang" ? "ang" : "kam");
    persistMass();
    updateMassInfo();
    if (focus)
        td.querySelector(".cp-in").focus();
}
/** baris lama (pergi + pulang) → lama hari; pulang selalu = pergi + lama − 1 */
/** teks kampung tujuan → kampung SK Transport (urut sesuai teks) + yang tidak dikenali */
function massKamParse(row) {
    const t = String(row.kamTxt || "").trim();
    if (!t) {
        row.kam = [];
        row.kamBad = [];
        return;
    }
    const d = detectKampung(t), keys = [];
    for (const k of d.found) {
        const kk = kKey(k);
        if (!keys.includes(kk))
            keys.push(kk);
    }
    row.kam = keys;
    row.kamBad = d.unknown.map(u => u.trim()).filter(u => u && !/^(dan|ke|di|kampung|distrik|kab(upaten)?|serta)$/i.test(u));
}
function massLama(row) {
    const a = parseTgl(row.pergi), b = parseTgl(row.pulang);
    if (!(num(row.lama) >= 1))
        row.lama = a && b && b >= a ? dayDiff(a, b) : a ? 1 : "";
    if (a && num(row.lama) >= 1)
        row.pulang = tglPulang(row.pergi, row.lama);
}
function renderMass() {
    massRows.forEach(r => { massLama(r); migrateRow(r); if (r.kamTxt == null) {
        const M = kamByKey(), ks = r.kam.map(k => M[k]).filter((k) => !!k);
        r.kamTxt = [tujuanText(ks), ...r.kamBad].filter(Boolean).join(", ");
    } });
    $("#mTbl").innerHTML = massRows.map((row, i) => `<div class="mrow" data-i="${i}">
    <div class="mhead"><span class="mno"></span><span class="mjml"></span><span class="minfo" data-info="lama"></span><span class="spacer"></span>
      <button class="btn sm" type="button" data-pv="${i}" title="Pratinjau surat ini">Pratinjau</button><button class="btn sm" type="button" data-dup="${i}" title="Duplikat surat ini">Duplikat</button><button class="btn sm del" type="button" data-rm="${i}" title="Hapus surat ini">Hapus</button></div>
    <div class="mgrid">
      <div><label>Pelaksana</label><input data-k="peg" data-ac="pel" autocomplete="off" value="${esc(row.peg)}" placeholder="nama (kosong = Terlampir)"><div class="info" data-info="peg"></div></div>
      <div><label>Jenis</label><select data-k="jenis">${["Otomatis", "Remote", "Lokal", JEN_TU, "Pelatihan"].map(o => `<option ${(row.jenis || "Otomatis") === o ? "selected" : ""}>${o}</option>`).join("")}</select><div class="info" data-info="jenis"></div></div>
      <div><label>Tanggal pergi</label><div class="row"><input data-k="pergi" value="${esc(row.pergi)}" placeholder="26 Januari 2026"><input type="date" data-kd="pergi"></div></div>
      <div><label>Lama (hari) · pulang otomatis</label><div class="mlama"><input type="number" min="1" step="1" data-k="lama" value="${esc(row.lama || "")}" placeholder="hari" title="Lama perjalanan (hari)"><input data-k="pulang" value="${esc(row.pulang)}" readonly tabindex="-1" data-autopulang placeholder="tanggal pulang" title="Dihitung otomatis: tanggal pergi + lama − 1"></div></div>
      <div class="full"><label>Maksud / tujuan <span class="muted" data-info="maksud" style="text-transform:none;letter-spacing:0"></span></label><textarea data-k="maksud" rows="1" placeholder="Isi maksud / tujuan">${esc(row.maksud || readCommon().MAKSUD__TUJUAN || "")}</textarea></div>
      <div class="half cp-cell" data-c="ang"><label>Anggota tim (Lampiran)</label>${cpickHtml(row, "ang")}<div class="info" data-info="anggota"></div></div>
      <div class="half" data-c="kam"><label>Kampung tujuan (urut rute)</label><input data-k="kamTxt" value="${esc(row.kamTxt || "")}" autocomplete="off" placeholder="mis. Kampung Isir dan Frawebo" title="Tulis nama kampung seperti biasa — kampung SK Transport terbaca otomatis sesuai urutan"><div class="info" data-info="kampung"></div></div>
    </div>
    <div class="merr" hidden></div></div>`).join("")
        || `<div class="mempty muted">Belum ada surat. Klik <b>+ Tambah surat</b>, atau <b>Impor Excel</b> memakai template.</div>`;
    updateMassInfo();
}
function updateMassInfo() {
    const P = pegMap(), recs = massRecords();
    let total = 0, bad = 0;
    $$("#mTbl .merr").forEach(e => e.hidden = true);
    recs.forEach(({ r, errs, L, luar }, i) => {
        const tr = $(`#mTbl .mrow[data-i="${i}"]`);
        if (!tr)
            return;
        if (errs.length)
            bad++;
        else
            total++;
        const q = (sel) => tr.querySelector(sel);
        q(".mno").innerHTML = `<b>${esc(r.NO)}</b>`;
        q(".mjml").innerHTML = errs.length ? `<span class="tag warn">perbaiki</span>` : `<span class="tag ok">siap</span>`;
        const er = q(".merr");
        er.hidden = !errs.length;
        er.textContent = errs.length ? "⚠ " + errs.join("; ") : "";
        tr.classList.toggle("bad", !!errs.length);
        tr.classList.toggle("ok", !errs.length);
        const pl = P[r.KD_NAMA_SPD];
        q('[data-info="peg"]').textContent = pl ? pl.nama + (pl.jabatan ? " · " + pl.jabatan : "") : "";
        const lc = lampOf(r), angL = !!r.KD_NAMA_SPD && r.KD_NAMA_SPD !== "999";
        {
            const ci = tr.querySelector('.cp-cell[data-c="ang"] .cp-in');
            if (ci) {
                ci.disabled = angL;
                ci.placeholder = angL ? "Pelaksana bukan Terlampir — anggota tidak bisa dipilih" : ci.dataset.ph || ci.placeholder;
            }
        }
        q('[data-info="anggota"]').textContent = lc.length ? `${lc.length} orang` : "";
        const ks = normChips(r._kampung).map(c => kamByKey()[c.k]);
        q('[data-info="kampung"]').textContent = [ks.length ? `${ks.length} kampung: ${ks.map(k => title(k.kampung)).join(" → ")}` : "", luar?.length ? `di luar SK (transport manual): ${luar.join(", ")}` : ""].filter(Boolean).join(" · ");
        q('[data-info="lama"]').textContent = [r.TGL_PERGI ? tglRange(r) : "", L ? `${L} hari` : "", r.JENIS].filter(Boolean).join(" · ");
        const mk = q('[data-k="maksud"]'), cm = readCommon().MAKSUD__TUJUAN || "", own = !!String(massRows[i].maksud || "").trim();
        if (!own && document.activeElement !== mk && mk.value !== cm)
            mk.value = cm; // ikut data bersama sampai diubah di baris ini
        q('[data-info="maksud"]').textContent = own ? "· khusus surat ini" : cm ? "· dari data bersama — bisa diubah di sini" : "";
        q('[data-info="jenis"]').textContent = (massRows[i].jenis || "Otomatis") === "Otomatis" ? "→ " + r.JENIS : "";
    });
    $("#mCount").textContent = `${massRows.length} surat${bad ? ` · ${bad} perlu diperbaiki` : ""}`;
    $("#mCount").className = "tag" + (bad ? " warn" : "");
    $("#mTotal").textContent = `${total} surat`;
    {
        const ms = $("#mSumm");
        if (ms)
            ms.innerHTML = massRows.length ? `<b>${massRows.length}</b> surat · <span class="${bad ? "bad" : ""}">${bad} perlu diperbaiki</span> · <b>${total}</b> siap dibuat` : "Belum ada surat di daftar.";
    }
    const c = readCommon(), kc = kodeMap()[kodeFromNL(c.NoLengkap)];
    $("#mh-mak").innerHTML = budgetHtml(c.MAK, 0, null);
    $("#mh-kode").textContent = kc ? kc.d : "";
    const mY = yrOf(c.TGL_TERBIT_ST) || new Date().getFullYear();
    const s = parseInt(c.start, 10) || parseInt(nextNo([], mY), 10), e = s + Math.max(0, massRows.length - 1);
    const clash = records.filter(x => { const n = noNum(x.NO); return stYear(x) === mY && n >= s && n <= e && noKey(x.NO) === String(n); }).map(x => x.NO);
    const nxS = parseInt(nextNo([], mY), 10);
    $("#mh-start").innerHTML = s > nxS ? `<span class="bad">Harus berurutan: mulai dari ${pad3(nxS)} (nomor terakhir tahun ${mY} = ${pad3(nxS - 1)})</span>` : clash.length ? `<span class="bad">Nomor ${esc(clash.slice(0, 5).join(", "))}${clash.length > 5 ? "…" : ""} sudah dipakai tahun ${mY}</span>` : (massRows.length ? `Nomor ${String(s).padStart(3, "0")} s.d. ${String(e).padStart(3, "0")} · tahun ${mY}` : `Kosong = lanjut dari nomor terakhir tahun ${mY}`);
}
$("#mTbl").addEventListener("paste", e => {
    const inp = tg(e).closest(".cp-in[data-cp=kam]");
    if (!inp)
        return;
    setTimeout(() => { const i = Number(inp.closest(".mrow").dataset.i); if (inp.value.trim() && cpAdd(i, "kam", inp.value))
        cpRefresh(i, "kam", true); }, 0);
});
$("#mTbl").addEventListener("keydown", e => {
    const inp = tg(e).closest(".cp-in");
    if (!inp)
        return;
    const i = Number(inp.closest(".mrow").dataset.i), kind = inp.dataset.cp ?? "";
    if ((e.key === "Enter" || e.key === "Tab" && inp.value.trim()) && inp.value.trim()) {
        e.preventDefault();
        if (cpAdd(i, kind, inp.value))
            cpRefresh(i, kind, true);
        else
            inp.select();
    }
    else if (e.key === "Backspace" && !inp.value) {
        const row = massRows[i], arr = row[kind];
        if (arr.length) {
            arr.pop();
            cpRefresh(i, kind, true);
        }
    }
});
$("#mTbl").addEventListener("input", e => {
    const inp = tg(e).closest(".cp-in");
    if (inp) { // memilih langsung dari daftar pilihan
        const v = inp.value, kind = inp.dataset.cp ?? "", i = Number(inp.closest(".mrow").dataset.i);
        const exact = kind === "ang" ? isPegName(v) : kIdx().label.has(v);
        if (exact && cpAdd(i, kind, v))
            cpRefresh(i, kind, true);
        return;
    }
    const tr = tg(e).closest(".mrow");
    const k = tg(e).dataset.k;
    if (!tr || !k || tg(e).tagName === "SELECT")
        return;
    const row = massRows[Number(tr.dataset.i)];
    if (k === "maksud") {
        const v = tg(e).value, cm = String(readCommon().MAKSUD__TUJUAN || "");
        row.maksud = v.trim() === cm.trim() ? "" : v;
        persistMass();
        updateMassInfo();
        return;
    }
    if (k === "kamTxt") {
        row.kamTxt = tg(e).value;
        massKamParse(row);
        persistMass();
        updateMassInfo();
        return;
    }
    if (k === "lama") {
        row.lama = num(tg(e).value) >= 1 ? Math.round(num(tg(e).value)) : "";
        if (row.lama)
            row.pulang = tglPulang(row.pergi, row.lama);
        tr.querySelector('[data-k="pulang"]').value = row.pulang || "";
        persistMass();
        updateMassInfo();
        return;
    }
    if (k === "pulang") {
        row.pulang = tg(e).value;
        row.lama = "";
        massLama(row);
        tr.querySelector('[data-k="lama"]').value = String(row.lama || "");
        persistMass();
        updateMassInfo();
        return;
    } // diisi dari luar
    row[k] = tg(e).type === "checkbox" ? tg(e).checked : tg(e).value;
    if (k === "pergi") {
        massLama(row);
        tr.querySelector('[data-k="lama"]').value = String(row.lama || "");
        tr.querySelector('[data-k="pulang"]').value = row.pulang || "";
    }
    persistMass();
    updateMassInfo();
});
$("#mTbl").addEventListener("change", e => {
    const tr = tg(e).closest(".mrow");
    if (!tr)
        return;
    const row = massRows[Number(tr.dataset.i)];
    const kd = tg(e).dataset.kd;
    if (kd && tg(e).value) {
        row[kd] = fmtTgl(tg(e).value);
        tr.querySelector(`[data-k="${kd}"]`).value = row[kd];
        if (kd === "pergi") {
            massLama(row);
            tr.querySelector('[data-k="lama"]').value = String(row.lama || "");
            tr.querySelector('[data-k="pulang"]').value = row.pulang || "";
        }
    }
    if (tg(e).dataset.k === "pp") {
        row.pp = tg(e).checked;
    }
    if (tg(e).dataset.k === "jenis") {
        row.jenis = tg(e).value;
    }
    persistMass();
    updateMassInfo();
});
$("#mTbl").addEventListener("click", e => {
    const d = tg(e).dataset;
    if (d.cx != null) {
        const i = Number(tg(e).closest(".mrow").dataset.i);
        massRows[i][d.cx].splice(Number(d.ci), 1);
        cpRefresh(i, d.cx.replace("Bad", ""), true);
        return;
    }
    const cp = tg(e).closest(".cpick");
    if (cp && tg(e) === cp) {
        cp.querySelector(".cp-in").focus();
        return;
    }
    if (d.rm != null) {
        massRows.splice(+d.rm, 1);
        persistMass();
        renderMass();
    }
    if (d.dup != null) {
        massRows.splice(+d.dup + 1, 0, clone(massRows[+d.dup]));
        persistMass();
        renderMass();
    }
    if (d.pv != null) {
        const x = massRecords()[+d.pv];
        if (x)
            openPreview([x.r], `Pratinjau ST No. ${x.r.NO}` + (x.errs.length ? " — masih ada yang perlu diperbaiki" : ""));
    }
});
$("#mPreview").onclick = () => { const xs = massRecords(); if (!xs.length)
    return toast("Belum ada baris."); openPreview(xs.map(x => x.r), `Pratinjau ${xs.length} surat (Surat Tugas Kolektif)`); };
$("#mAdd").onclick = () => {
    const last = massRows[massRows.length - 1];
    massRows.push({ peg: "", ang: [], angBad: [], kam: [], kamBad: [], pp: true, pergi: last?.pergi || "", lama: last?.lama || "", pulang: last?.pulang || "" });
    persistMass();
    renderMass();
    $(`#mTbl .mrow[data-i="${massRows.length - 1}"]`)?.scrollIntoView({ block: "center" });
    $(`#mTbl .mrow[data-i="${massRows.length - 1}"] [data-k="peg"]`).focus();
};
function resetMass() {
    massRows = [];
    $("#mKegLain").checked = false;
    $$("#mCommon [data-m]").forEach(e => { e.value = e instanceof HTMLSelectElement ? (e.options[0] ? e.options[0].value : "") : ""; });
    fillCommon(commonFrom(defaults()));
    massCommon = readCommon();
    persistMass();
    renderMass();
}
$("#mNewSt").onclick = () => {
    const c = readCommon(), has = massRows.length || c.kegiatan || c.MAK || c.MAKSUD__TUJUAN;
    if (has && !confirm("Buat surat tugas kolektif baru? Data bersama dan semua baris yang belum disimpan akan dikosongkan."))
        return;
    resetMass();
    window.scrollTo(0, 0);
    toast("Surat tugas kolektif baru siap diisi.", "ok");
};
$$("[data-newst]").forEach(b => b.onclick = () => $(b.dataset.newst === "mass" ? "#mNewSt" : "#bNewSt").click());
$("#mClear").onclick = () => {
    const c = readCommon(), has = massRows.length || c.kegiatan || c.MAK || c.MAKSUD__TUJUAN;
    if (has && !confirm("Bersihkan Surat Tugas Kolektif? Data bersama dan semua baris akan dikosongkan."))
        return;
    resetMass();
    window.scrollTo(0, 0);
    toast("Surat Tugas Kolektif dibersihkan.");
};
/* template & impor Excel untuk daftar surat kolektif */
const MASS_HDR = ["Pelaksana", "Anggota tim (pisahkan dengan ;)", "Kampung tujuan (pisahkan dengan ,)", "Tanggal pergi", "Tanggal pulang", "Jenis (Otomatis / Remote / Lokal / Translok+Uhar / Pelatihan)", "Maksud / tujuan (kosong = data bersama)"];
$("#mTplXls").onclick = () => {
    const P = pegawai.filter(p => !isSystemPeg(p)), mit = P.filter(isMitra), peg = P.filter(p => !isMitra(p)), K = kampungDB.slice(0, 6).map(k => title(k.kampung));
    const nm = (arr, i) => (arr[i] || arr[0])?.nama || "";
    const ex = [
        [nm(peg, 1), "", K[0] || "", "5 Januari 2026", "6 Januari 2026", "Otomatis", ""],
        ["Terlampir", [nm(mit, 0), nm(mit, 1), nm(mit, 2)].filter(Boolean).join("; "), [K[1], K[2]].filter(Boolean).join(", "), "12 Januari 2026", "15 Januari 2026", "Remote", "Pendataan lapangan (contoh — maksud khusus baris ini)"],
        [nm(mit, 3), "", "Kota Sorong", "20 Januari 2026", "22 Januari 2026", "Pelatihan", "Pelatihan petugas (contoh)"]
    ];
    const ws = XLSX.utils.aoa_to_sheet([MASS_HDR, ...ex]);
    ws["!cols"] = [34, 46, 36, 18, 18, 22, 46].map(w => ({ wch: w }));
    const info = XLSX.utils.aoa_to_sheet([["Petunjuk pengisian"], [""],
        ["1. Satu baris = satu surat tugas. Hapus baris contoh sebelum mengisi."], ["2. Pelaksana: nama persis seperti di Database → Pegawai & Mitra. Isi \"Terlampir\" bila surat untuk tim (anggota diisi di kolom Anggota)."],
        ["3. Anggota tim: beberapa nama dipisah titik koma ( ; )."], ["4. Kampung tujuan: nama kampung SK Transport, beberapa kampung dipisah koma sesuai urutan rute. Tujuan di luar SK ditulis apa adanya."],
        ["5. Tanggal: tulis mis. 5 Januari 2026 atau format tanggal Excel."], ["6. Jenis: Otomatis (mengikuti SK), Remote, Lokal, Translok+Uhar, atau Pelatihan."], ["7. Maksud kosong = memakai maksud di Data bersama."],
        [""], ["Data bersama (kode klasifikasi, tanggal terbit, kegiatan, MAK, penanda tangan) diisi di aplikasi, bagian 1."]]);
    info["!cols"] = [{ wch: 110 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Daftar Surat");
    XLSX.utils.book_append_sheet(wb, info, "Petunjuk");
    XLSX.writeFile(wb, "Template Surat Tugas Kolektif.xlsx");
    toast("Template Excel diunduh — isi lalu klik Impor Excel.");
};
$("#fMassImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
        let rows = null, H = [];
        for (const sn of wb.SheetNames) {
            const a = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: true });
            const hi = a.findIndex(r => r.some(c => /^pelaksana/i.test(String(c).trim())));
            if (hi >= 0) {
                H = a[hi].map(c => String(c).trim().toLowerCase());
                rows = a.slice(hi + 1);
                break;
            }
        }
        if (!rows)
            return toast("Kolom 'Pelaksana' tidak ditemukan. Pakai Unduh template Excel.");
        const ix = (re) => H.findIndex(h => re.test(h)), cP = ix(/^pelaksana/), cA = ix(/^anggota/), cK = ix(/^kampung|^tempat tujuan/), cG = ix(/pergi/), cU = ix(/pulang/), cJ = ix(/^jenis/), cM = ix(/^maksud/);
        const cell = (r, i) => { const v = i < 0 ? "" : r[i]; return v instanceof Date ? fmtDate(new Date(v.getTime() + 12 * 36e5)) : String(v ?? "").trim(); };
        const sd = (v) => { const m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); return m ? `${+m[1]} ${BULAN[+m[2] - 1]} ${m[3]}` : v; };
        let n = 0;
        for (const r of rows) {
            const peg = cell(r, cP), ang = cell(r, cA), kam = cell(r, cK);
            if (!peg && !ang && !kam)
                continue;
            const j = cell(r, cJ);
            massRows.push({ peg: /^terlampir$/i.test(peg) ? "" : peg, anggota: ang.replace(/\s*;\s*/g, "; "), kampung: kam, pergi: sd(cell(r, cG)), pulang: sd(cell(r, cU) || cell(r, cG)), maksud: cell(r, cM), pp: true,
                jenis: jenisOf(j) || "Otomatis" });
            n++;
        }
        persistMass();
        renderMass();
        toast(n ? `${n} surat diimpor dari ${f.name}. Periksa baris bertanda kuning.` : "Tidak ada baris yang terisi di file.");
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
});
$("#mPaste").onclick = () => { $("#pasteBox").value = ""; $("#dPaste").showModal(); $("#pasteBox").focus(); };
$("#pasteCancel").onclick = () => $("#dPaste").close();
$("#pasteGo").onclick = () => {
    const lines = $("#pasteBox").value.split(/\r?\n/).filter(l => l.trim());
    const sd = (v0) => { const v = String(v0 || "").trim(); const m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); return m ? `${+m[1]} ${BULAN[+m[2] - 1]} ${m[3]}` : v; };
    for (const l of lines) {
        const c = l.split("\t");
        massRows.push({ peg: (c[0] || "").trim(), maksud: (c[7] || "").trim(), kampung: (c[1] || "").trim(), pergi: sd(c[2]), pulang: sd(c[3] || c[2]), anggota: (c[4] || "").trim(), pp: true, jenis: (() => { const j = [c[5], c[6]].map(x => String(x || "").trim()).find(x => /^(lok|rem|pel|trans)/i.test(x)) || ""; return jenisOf(j) || "Otomatis"; })() });
    }
    persistMass();
    renderMass();
    $("#dPaste").close();
    toast(`${lines.length} baris ditambahkan.`);
};
$("#mCommon").addEventListener("input", e => {
    const k = tg(e).dataset.m;
    if (k === "kode") {
        const c = kodeMap()[tg(e).value.trim().toUpperCase()];
        if (c)
            mIn("NoLengkap").value = composeNL(c.k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value);
    }
    if (k === "TGL_TERBIT_ST") {
        const d = parseTgl(tg(e).value);
        if (d) {
            mIn("NoLengkap").value = mIn("NoLengkap").value.replace(/\/\d{4}$/, "/" + d.getFullYear());
            if (_mY != null && d.getFullYear() !== _mY && mIn("start").value.trim()) {
                mIn("start").value = "";
                toast(`Tahun terbit ${d.getFullYear()}: No. urut mulai disesuaikan otomatis (${nextNo([], d.getFullYear())}).`);
            }
            _mY = d.getFullYear();
        }
    }
    massCommon = readCommon();
    persistMass();
    updateMassInfo();
});
$("#mCommon").addEventListener("change", e => {
    const mf = tg(e).dataset.mfor ?? "";
    if (mf && tg(e).type === "date" && tg(e).value) {
        mIn(mf).value = fmtTgl(tg(e).value);
        mIn(mf).dispatchEvent(new Event("input", { bubbles: true }));
    }
    if (tg(e).matches("select.preset") && tg(e).value) {
        mIn(mf).value = tg(e).value;
        tg(e).value = "";
    }
    if (tg(e).dataset.m === "kode") {
        const { c, n } = lookupKode(tg(e).value);
        if (c) {
            tg(e).value = c.k;
            mIn("NoLengkap").value = composeNL(c.k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value);
        }
        else if (n > 1)
            toast(`${n} kode cocok — pilih dari daftar.`);
    }
    if (["No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "No_Bend"].includes(tg(e).dataset.m ?? "")) {
        const c = resolvePeg(tg(e).value);
        if (c)
            tg(e).value = pegLabel(c);
    }
    massCommon = readCommon();
    persistMass();
    updateMassInfo();
});
$("#mFromForm").onclick = () => { const s = mIn("start").value; fillCommon({ ...commonFrom(readForm()), start: s }); massCommon = readCommon(); persistMass(); updateMassInfo(); toast("Data bersama disalin dari Surat Tugas Personal."); };
function saveMass() {
    if (!massRows.length) {
        toast("Belum ada baris.");
        return null;
    }
    const recs = massRecords(), bad = recs.filter(x => x.errs.length);
    if (bad.length) {
        toast(`${bad.length} baris belum bisa dibuat: No. ${bad[0].r.NO} — ${bad[0].errs[0]}`);
        return null;
    }
    const mak = readCommon().MAK, b = budgetOf(mak);
    if (mak && !b && !confirm(`MAK "${mak}" tidak ada di POK. Tetap simpan?`))
        return null;
    const clash = recs.find(x => records.some(y => recKey(y) === recKey(x.r)));
    if (clash) {
        toast(`Nomor ${clash.r.NO} sudah dipakai pada tahun ${stYear(clash.r)}. Ubah “No. urut mulai”.`);
        return null;
    }
    const out = recs.map(x => x.r);
    ensureIds(out);
    records.push(...out);
    persist();
    renderList();
    buildLists();
    resetMass(); // isian kembali kosong seperti awal
    toast(`${out.length} surat tugas tersimpan (No. ${out[0].NO}–${out[out.length - 1].NO}). Rincian biaya dibuat lewat Daftar Surat Tugas → Edit.`);
    return out;
}
const mSaveList = () => { const out = saveMass(); if (out)
    toast(`✓ Berhasil menyimpan ${out.length} surat tugas ke Daftar (No. ${out[0].NO} s.d. ${out[out.length - 1].NO}).`); };
const mSavePrint = () => { const out = saveMass(); if (out)
    openPrint(out, true); };
const mSaveXls = () => { const out = saveMass(); if (out) {
    exportST(out, `Surat Tugas ${out[0].NO}-${out[out.length - 1].NO} (${out.length} surat).xlsx`);
    afterSave(`${out.length} surat tugas tersimpan`, `No. ${out[0].NO} s.d. ${out[out.length - 1].NO} sudah masuk ke Daftar Surat Tugas dan diekspor ke Excel. Kembali ke Beranda atau tetap di halaman ini?`, "list");
} };
$("#mSaveAll").onclick = () => {
    if (!massRows.length)
        return toast("Belum ada baris.");
    const recs = massRecords(), bad = recs.filter(x => x.errs.length);
    if (bad.length)
        return toast(`${bad.length} baris belum bisa dibuat: No. ${bad[0].r.NO} — ${bad[0].errs[0]}`);
    $("#msMsg").textContent = `${recs.length} surat tugas siap disimpan (No. ${recs[0].r.NO} s.d. ${recs[recs.length - 1].r.NO}). Pilih tindakan:`;
    $("#dMassSave").showModal();
};
$$("#dMassSave [data-ms]").forEach(b => b.onclick = () => {
    $("#dMassSave").close();
    ({ list: mSaveList, print: mSavePrint, xls: mSaveXls }[b.dataset.ms ?? ""]?.());
});

/* ---- 55_preview.ts ---- */
/* ================= PREVIEW ================= */
const PREV_MAX = 15;
let prev = { recs: [], part: "st", zoom: 1, blob: null, tpl: false };
async function renderPreview() {
    const host = $("#prevDoc");
    host.innerHTML = `<p style="color:#fff;padding:24px">Menyiapkan pratinjau…</p>`;
    try {
        let blob;
        if (prev.tpl)
            blob = await (await JSZip.loadAsync(tplB64(), { base64: true })).generateAsync({ type: "blob" });
        else if (prev.part === "pel") {
            prev.blob = null;
            host.innerHTML = prev.recs.filter(isPelatihan).slice(0, PREV_MAX).map(r => `<div class="hp-page" style="margin-bottom:18px">${pelatihanHtml(r)}</div>`).join("") || `<p style="color:#fff;padding:24px">Tidak ada surat Pelatihan.</p>`;
            applyZoom();
            $("#prevDl").textContent = "Unduh .xlsx";
            return;
        }
        else {
            const parts = prev.part === "st" ? FILE_ST : FILE_BIAYA, rs = prev.recs.slice(0, PREV_MAX);
            const list = prev.part === "st" ? rs : expandBiaya(rs).slice(0, PREV_MAX * 3);
            blob = list.length === 1 ? await buildDocx(list[0], parts) : await buildMerged(list, parts);
        }
        prev.blob = blob;
        host.innerHTML = "";
        $("#prevDl").textContent = "Unduh .docx";
        await docx.renderAsync(blob, host, host, { inWrapper: true, breakPages: true, ignoreLastRenderedPageBreak: true, experimental: true, className: "docx" });
        applyZoom();
    }
    catch (e) {
        console.error(e);
        host.innerHTML = `<p style="color:#fff;padding:24px">Gagal membuat pratinjau: ${esc(e.message)}</p>`;
    }
}
function applyZoom() { const h = $("#prevDoc"); h.style.transform = `scale(${prev.zoom})`; h.style.width = prev.zoom < 1 ? (100 / prev.zoom) + "%" : ""; h.style.marginLeft = prev.zoom < 1 ? `${-(100 / prev.zoom - 100) / 2}%` : ""; }
function openPreview(recs, title, tpl = false, part = "st") {
    prev = { recs, part, zoom: prev.zoom || 1, blob: null, tpl };
    if (!tpl && !recs.length)
        return toast("Tidak ada surat untuk dipratinjau.");
    if (innerWidth < 900)
        prev.zoom = Math.max(0.4, (innerWidth - 40) / 820);
    $("#prevTitle").textContent = title;
    const nb = !tpl && recs.every(r => r._noBiaya);
    $("#prevTabs").hidden = tpl;
    $('#prevTabs [data-pv="biaya"]').disabled = nb;
    $('#prevTabs [data-pv="pel"]').hidden = tpl || !recs.some(isPelatihan);
    $('#prevTabs [data-pv="biaya"]').hidden = !tpl && recs.length > 0 && recs.every(isPelatihan);
    $$("#prevTabs button").forEach(b => b.classList.toggle("on", b.dataset.pv === prev.part));
    $("#prevNote").textContent = tpl ? "Template mentah (kolom data masih berupa «MERGEFIELD»)" : (recs.length > PREV_MAX ? `Menampilkan ${PREV_MAX} dari ${recs.length} surat` : "") + (nb ? " · Rincian biaya belum dibuat" : "") + " · Tata letak final mengikuti Word";
    $("#dPrev").showModal();
    renderPreview();
}
$$("#prevTabs button").forEach(b => b.onclick = () => { if (b.disabled)
    return; prev.part = b.dataset.pv ?? "st"; $$("#prevTabs button").forEach(x => x.classList.toggle("on", x === b)); renderPreview(); });
$("#prevClose").onclick = () => { $("#dPrev").close(); $("#prevDoc").innerHTML = ""; };
$("#prevZoomIn").onclick = () => { prev.zoom = Math.min(2, +(prev.zoom + 0.1).toFixed(2)); applyZoom(); };
$("#prevZoomOut").onclick = () => { prev.zoom = Math.max(0.3, +(prev.zoom - 0.1).toFixed(2)); applyZoom(); };
$("#prevDl").onclick = () => {
    if (prev.part === "pel") {
        const r = prev.recs.find(isPelatihan);
        if (r)
            downloadPelatihan(r).catch((e) => toast("Gagal: " + e.message));
        return;
    }
    if (!prev.blob)
        return;
    const r = prev.recs[0];
    download(prev.blob, prev.tpl ? (template ? template.name : "SURAT_TUGAS_2026.docx") : prev.recs.length === 1 ? fileName(r, prev.part === "st" ? "ST" : "Rincian Biaya") : `Pratinjau ${prev.part === "st" ? "Surat Tugas" : "Rincian Biaya"} (${Math.min(PREV_MAX, prev.recs.length)} surat).docx`);
};
$("#bPreview").onclick = () => { const r = readForm(); openPreview([r], `Pratinjau ST No. ${r.NO || "-"}`); };
/* ================= TEMPLATE EDITOR ================= */
const MC = "http://schemas.openxmlformats.org/markup-compatibility/2006";
let tplState = null;
const PART_NAMES = ["Surat Tugas", "SPD", "Lampiran SPPD", "Rincian Biaya", "Lampiran ST"];
function ancestor(n, ns, name) { for (let x = n.parentNode; x; x = x.parentNode)
    if (x instanceof Element && x.namespaceURI === ns && x.localName === name)
        return x; return null; }
function paraText(p) {
    let out = "", inF = 0, instr = "", phase = "";
    for (const el of p.getElementsByTagNameNS(WNS, "*")) {
        if (el.localName === "fldChar") {
            const t = el.getAttributeNS(WNS, "fldCharType");
            if (t === "begin") {
                inF++;
                instr = "";
                phase = "i";
            }
            else if (t === "separate")
                phase = "r";
            else if (t === "end") {
                const m = instr.match(/MERGEFIELD\s+"?([^\s"\\]+)/);
                if (m)
                    out += "«" + m[1] + "»";
                inF = Math.max(0, inF - 1);
                phase = "";
            }
        }
        else if (el.localName === "instrText" && phase === "i")
            instr += el.textContent;
        else if (el.localName === "t" && !inF)
            out += el.textContent;
        else if (el.localName === "tab" && !inF)
            out += "\t";
    }
    return out;
}
async function loadTplEditor() {
    const zip = await JSZip.loadAsync(tplB64(), { base64: true });
    const doc = new DOMParser().parseFromString(await zip.file("word/document.xml").async("string"), "application/xml");
    const body = doc.getElementsByTagNameNS(WNS, "body")[0];
    const partOf = new Map();
    let sec = 0, seenKu = false;
    for (const n of [...body.childNodes]) {
        if (sec === 2 && !seenKu && (n.textContent || "").includes("KUITANSI"))
            seenKu = true;
        const part = sec === 0 ? 0 : sec === 1 ? 1 : sec === 2 ? (seenKu ? 3 : 2) : 4;
        partOf.set(n, part);
        if (n instanceof Element && n.localName === "p" && kids(n, "pPr")[0] && kids(kids(n, "pPr")[0], "sectPr")[0])
            sec++;
    }
    const top = (p) => { let x = p; while (x.parentNode && x.parentNode !== body)
        x = x.parentNode; return x; };
    const paras = [];
    for (const p of [...doc.getElementsByTagNameNS(WNS, "p")]) {
        if (ancestor(p, MC, "Fallback"))
            continue;
        if (p.getElementsByTagNameNS(WNS, "p").length)
            continue; // only innermost paragraphs
        const text = paraText(p);
        if (!/[A-Za-z0-9«]/.test(text))
            continue;
        const fields = /«[^»]+»/.test(text) || p.getElementsByTagNameNS(WNS, "instrText").length > 0;
        let fb = null;
        const ch = ancestor(p, MC, "Choice");
        if (ch) {
            const ac = ch.parentNode, f = [...ac.childNodes].find((x) => x instanceof Element && x.localName === "Fallback");
            if (f) {
                const inner = [...ch.getElementsByTagNameNS(WNS, "p")].filter(x => !x.getElementsByTagNameNS(WNS, "p").length), idx = inner.indexOf(p);
                const fps = [...f.getElementsByTagNameNS(WNS, "p")].filter(x => !x.getElementsByTagNameNS(WNS, "p").length);
                fb = fps[idx] || null;
            }
        }
        paras.push({ p, part: partOf.get(top(p)) ?? 0, orig: text, text, fields, fb });
    }
    tplState = { zip, doc, paras, dirty: new Set() };
    $("#tplPart").innerHTML = `<option value="">Semua bagian</option>` + PART_NAMES.map((n, i) => `<option value="${i}">${n}</option>`).join("");
    renderTplEditor();
}
function renderTplEditor() {
    if (!tplState)
        return;
    const st = tplState;
    const q = $("#tplQ").value.trim().toLowerCase(), part = $("#tplPart").value, showF = $("#tplFields").checked;
    const rows = st.paras.map((x, i) => [x, i]).filter(([x]) => (showF || !x.fields) && (part === "" || String(x.part) === part) && (!q || x.text.toLowerCase().includes(q)));
    $("#tplCount").textContent = `${rows.length} baris`;
    $("#tTpl tbody").innerHTML = rows.map(([x, i]) => `<tr><td class="muted" style="font-size:12px">${PART_NAMES[x.part]}</td><td>${x.fields
        ? `<div class="muted" style="white-space:pre-wrap">${esc(x.text)}</div>`
        : `<textarea data-ti="${i}" rows="${Math.min(4, Math.ceil(x.text.length / 110))}" style="min-height:34px${st.dirty.has(i) ? ";border-color:var(--warn)" : ""}">${esc(x.text)}</textarea>`}</td></tr>`).join("")
        || `<tr><td colspan="2" class="muted">Tidak ada teks yang cocok.</td></tr>`;
    $("#tplDirty").hidden = !st.dirty.size;
    $("#bTplSave").disabled = $("#bTplUndo").disabled = !st.dirty.size;
    $("#tplName").textContent = template ? template.name : "SURAT_TUGAS_2026.docx (bawaan)";
}
$("#tTpl").addEventListener("input", e => {
    const i = tg(e).dataset.ti;
    if (i == null || !tplState)
        return;
    const x = tplState.paras[+i];
    x.text = tg(e).value.replace(/\n/g, " ");
    x.text === x.orig ? tplState.dirty.delete(+i) : tplState.dirty.add(+i);
    tg(e).style.borderColor = tplState.dirty.has(+i) ? "var(--warn)" : "";
    $("#tplDirty").hidden = !tplState.dirty.size;
    $("#bTplSave").disabled = $("#bTplUndo").disabled = !tplState.dirty.size;
});
["#tplQ", "#tplPart", "#tplFields"].forEach(id => $(id).addEventListener(id === "#tplQ" ? "input" : "change", () => renderTplEditor()));
function setParaText(p, text) {
    const ts = [...p.getElementsByTagNameNS(WNS, "t")];
    if (!ts.length)
        return;
    // keep tabs as they were: put text segments around existing tabs
    const segs = text.split("\t");
    const tabsRuns = [...p.getElementsByTagNameNS(WNS, "tab")].filter(t => t.parentNode?.localName === "r");
    if (segs.length > 1 && tabsRuns.length === segs.length - 1) {
        // assign each segment to the first <w:t> before the matching tab
        const order = [...p.getElementsByTagNameNS(WNS, "*")].filter(e => (e.localName === "t" || e.localName === "tab") && e.parentNode?.localName === "r");
        let seg = 0, used = false;
        for (const e of order) {
            if (e.localName === "tab") {
                seg++;
                used = false;
                continue;
            }
            e.textContent = used ? "" : segs[seg];
            e.setAttribute("xml:space", "preserve");
            used = true;
        }
    }
    else {
        ts[0].textContent = text.replace(/\t/g, " ");
        ts[0].setAttribute("xml:space", "preserve");
        ts.slice(1).forEach(t => t.textContent = "");
    }
}
$("#bTplSave").onclick = async () => {
    if (!tplState || !tplState.dirty.size)
        return;
    const st = tplState;
    for (const i of st.dirty) {
        const x = st.paras[i];
        setParaText(x.p, x.text);
        if (x.fb)
            setParaText(x.fb, x.text);
        x.orig = x.text;
    }
    st.zip.file("word/document.xml", xmlOut(st.doc));
    const b64 = await st.zip.generateAsync({ type: "base64", compression: "DEFLATE" });
    const n = st.dirty.size;
    template = { name: (template ? template.name : "SURAT_TUGAS_2026.docx").replace(/( \(diedit\))?\.docx$/i, "") + " (diedit).docx", b64 };
    if (!LS.set("st.template", template))
        toast("Template dipakai sementara (terlalu besar untuk disimpan permanen).");
    st.dirty.clear();
    tplInfo();
    renderTplEditor();
    toast(`${n} teks template disimpan. Surat berikutnya memakai template ini.`);
};
$("#bTplUndo").onclick = () => { if (!tplState)
    return; const st = tplState; for (const i of st.dirty) {
    const x = st.paras[i];
    x.text = x.orig;
} st.dirty.clear(); renderTplEditor(); };
$("#bTplDown").onclick = async () => { const blob = await (await JSZip.loadAsync(tplB64(), { base64: true })).generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }); download(blob, template ? template.name : "SURAT_TUGAS_2026.docx"); };
$("#bTplPrev").onclick = () => openPreview([], "Pratinjau template", true);
$("#fTpl2").addEventListener("change", e => { const f = tg(e).files?.[0]; if (!f)
    return; const dt = new DataTransfer(); dt.items.add(f); $("#fTpl").files = dt.files; $("#fTpl").dispatchEvent(new Event("change")); tg(e).value = ""; });
$("#bTplReset2").onclick = () => { if (!template || confirm("Kembali ke template bawaan? Perubahan template akan hilang."))
    $("#bTplReset").click(); };

/* ---- 60_list.ts ---- */
/* ================= LIST ================= */
const sel = new Set();
let listYear = LS.get("st.listYear", null);
/** isi pilihan tahun pada <select>; kembalikan tahun terpilih (atau "semua") */
function yearOptions(sel, cur) {
    const years = [...new Set(records.map(stYear).filter((y) => !!y))].sort((a, b) => b - a), cnt = {};
    for (const r of records) {
        const y = stYear(r) || "?";
        cnt[y] = (cnt[y] || 0) + 1;
    }
    const opts = [...years.map(String), "semua"];
    if (!cur || !opts.includes(cur))
        cur = opts.includes(String(new Date().getFullYear())) ? String(new Date().getFullYear()) : opts[0];
    sel.innerHTML = opts.map(y => `<option value="${y}" ${y === cur ? "selected" : ""}>${y === "semua" ? `Semua tahun (${records.length})` : `Tahun ${y} (${cnt[y] || 0})`}</option>`).join("");
    return cur;
}
let listLimit = 100;
function listFilter() {
    const q = $("#q").value.trim().toLowerCase(), Y = listYear;
    const toks = q.split(/\s+/).filter(Boolean);
    return (r) => { if (Y && Y !== "semua" && String(stYear(r)) !== Y)
        return false; if (!toks.length)
        return true; const h = hayOf(r); return toks.every(t => h.includes(t)); };
}
function renderList() {
    $("#cnt").textContent = String(records.length);
    listYear = yearOptions($("#qYear"), listYear);
    const ok = listFilter(), P = pegMap();
    const rows = [];
    let nShow = 0, sumShow = 0;
    const all = [...records].sort(byYearNo).reverse().filter(ok);
    for (const r of all) {
        nShow++;
        sumShow += computeC(r)._num.jmlTotal || 0;
    }
    all.slice(0, listLimit).forEach(r => {
        const F = computeC(r);
        const tm = teamOf(r, P), y = stYear(r), noB = r._noBiaya;
        const tags = (isLokal(r) ? `<span class="tag ok">Lokal</span>` : isTransUhar(r) ? `<span class="tag ok">Translok+Uhar</span>` : isPelatihan(r) ? `<span class="tag ok">Pelatihan</span>` : "") + (noB && !isPelatihan(r) ? `<span class="tag warn">belum ada rincian</span>` : "");
        rows.push(`<tr data-no="${esc(r._id)}" class="${sel.has(r._id ?? "") ? "on" : ""}"><td><input type="checkbox" class="ck" ${sel.has(r._id ?? "") ? "checked" : ""}></td>
      <td class="no"><b>${esc(r.NO)}</b><div class="lsub">${y || ""}</div></td>
      <td><div><span class="lt-title" data-a="edit" title="Buka &amp; ubah">${esc(F.MAKSUD__TUJUAN || "(tanpa maksud)")}</span>${tags}</div><div class="lsub one" title="${esc(F.NOMOR_ST + (F.TEMPAT_TUJUAN ? " · " + F.TEMPAT_TUJUAN : ""))}">${esc(F.NOMOR_ST)}${F.TEMPAT_TUJUAN ? " · " + esc(F.TEMPAT_TUJUAN) : ""}</div>
        <div class="lcp"><button type="button" class="cpst" data-cpst="${esc(F.NOMOR_ST)}" title="Salin nomor surat tugas: ${esc(F.NOMOR_ST)}">${IC_CP}<span>No. ST</span></button>${F.TGL_TERBIT_ST ? `<button type="button" class="cpst" data-cptgl="${esc(F.TGL_TERBIT_ST)}" title="Salin tanggal surat tugas: ${esc(F.TGL_TERBIT_ST)}">${IC_CP}<span>${esc(F.TGL_TERBIT_ST)}</span></button>` : ""}</div></td>
      <td><div title="${esc(tm.names.map(x => x.nama).join(", "))}">${esc(tm.label)}</div>${tm.codes.length > 1 ? `<div class="lsub">${tm.peg.length} pegawai${tm.mit.length ? ` · ${tm.mit.length} mitra` : ""}</div>` : ""}</td>
      <td class="hide-sm" style="font-size:13px;white-space:nowrap">${esc(tglRange(r))}</td>
      <td class="num">${isPelatihan(r) ? (pr => pr.length ? "Rp " + esc(rupiah(pr.reduce((a, x) => a + x.full + x.board + x.tr, 0))) + (pr.length > 1 ? `<div class="lsub">${pr.length} orang</div>` : "") : `<span class="muted">–</span>`)(pelatihanRows(r)) : F._num.jml ? "Rp " + esc(rupiah(F._num.jmlTotal)) + (F._num.orang > 1 ? `<div class="lsub">${F._num.orang} orang</div>` : "") : `<span class="muted">–</span>`}</td>
      <td class="acts"><button class="btn sm pri" data-a="doc" title="Unduh Surat Tugas (ST, SPD, Lampiran SPPD, Lampiran ST)">ST</button><button class="btn sm${noB ? "" : " pri"}" data-a="biaya" title="${noB ? "Rincian biaya belum dibuat — buka Edit → Rincian Biaya" : "Unduh Rincian Biaya"}"${isPelatihan(r) ? " hidden" : ""}>Rincian</button>${isPelatihan(r) ? `<button class="btn sm pri" data-a="pel" title="Daftar transport pelatihan (.xlsx)">Transport</button>` : ""}
        <button class="ib" data-a="edit" title="Edit">${IC.edit}</button><button class="ib" data-a="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-a="del" title="Hapus">${IC.del}</button></td></tr>`);
    });
    $("#tList tbody").innerHTML = rows.join("") || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">Tidak ada surat tugas${listYear && listYear !== "semua" ? " pada tahun " + esc(listYear) : ""}.</td></tr>`;
    if (all.length > listLimit)
        $("#tList tbody").insertAdjacentHTML("beforeend", `<tr><td colspan="7" style="text-align:center;padding:12px"><button class="btn" type="button" id="listMore">Tampilkan ${Math.min(200, all.length - listLimit)} lagi (${all.length - listLimit} tersisa)</button></td></tr>`);
    $("#listInfo").textContent = nShow ? `${nShow} surat cocok${all.length > listLimit ? ` · ${listLimit} ditampilkan` : ""} · total Rp ${rupiah(sumShow)}` : "";
    updSelBtns();
}
function updSelBtns() { $("#selBar").hidden = !sel.size; $("#selInfo").textContent = `${sel.size} surat dipilih`; }
const IC = { edit: `<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
    dup: `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>`,
    del: `<svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>` };
function tglRange(r) {
    const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG), M = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
    if (!a)
        return r.TGL_PERGI || "–";
    const f = (d, y) => d.getDate() + " " + M[d.getMonth()] + (y ? " " + d.getFullYear() : "");
    if (!b || +b === +a)
        return f(a, true);
    if (a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth())
        return `${a.getDate()}–${f(b, true)}`;
    return `${f(a, a.getFullYear() !== b.getFullYear())} – ${f(b, true)}`;
}
$("#q").addEventListener("input", debounce(() => { listLimit = 100; renderList(); }, 160));
$("#qYear").addEventListener("change", e => { listYear = tg(e).value; LS.set("st.listYear", listYear); sel.clear(); listLimit = 100; renderList(); });
$("#tList").addEventListener("click", async (e) => {
    if (tg(e).id === "listMore") {
        listLimit += 200;
        renderList();
        return;
    }
    {
        const c = tg(e).closest("[data-cpst],[data-cptgl]");
        if (c) {
            e.preventDefault();
            e.stopPropagation();
            return salin(c.dataset.cpst ?? c.dataset.cptgl, c.dataset.cpst != null ? "Nomor surat tugas" : "Tanggal surat tugas");
        }
    }
    const tr = tg(e).closest("tr[data-no]");
    if (!tr)
        return;
    const no = tr.dataset.no ?? "", rec = records.find(r => r._id === no);
    if (!rec)
        return;
    if (tg(e).classList.contains("ck")) {
        tg(e).checked ? sel.add(no) : sel.delete(no);
        tr.classList.toggle("on", tg(e).checked);
        updSelBtns();
        return;
    }
    const a = tg(e).closest("[data-a]")?.dataset.a;
    if (!a)
        return;
    if (a === "doc")
        await downloadRec(rec, "st");
    if (a === "biaya")
        await downloadRec(rec, "biaya");
    if (a === "pel")
        await downloadPelatihan(rec).catch((err) => toast("Gagal: " + err.message));
    if (a === "edit") {
        editingId = no;
        fillForm(rec);
        setEditFlag();
        show("form");
        showSub("data");
        window.scrollTo(0, 0);
    }
    if (a === "dup") {
        const c = { ...clone(rec), NO: nextNo(), TGL_TERBIT_ST: "", TGL_PERGI: "", TGL_PULANG: "", TGL_KUI: "", TGL_SPD: "" };
        delete c._id;
        editingId = null;
        _noYear = new Date().getFullYear();
        fillForm(c);
        setEditFlag();
        show("form");
        showSub("data");
        window.scrollTo(0, 0);
        toast("Salinan dibuat — tanggal dikosongkan, pilih tanggal baru lalu simpan.");
    }
    if (a === "del" && confirm(`Hapus surat ${compute(rec).NOMOR_ST}?`)) {
        records = records.filter(r => r._id !== no);
        sel.delete(no);
        persist();
        renderList();
        if (editingId === no)
            newForm();
    }
});
$("#chkAll").addEventListener("change", e => { $$("#tList tbody tr[data-no]").forEach(tr => tg(e).checked ? sel.add(tr.dataset.no ?? "") : sel.delete(tr.dataset.no ?? "")); renderList(); });
const selected = () => records.filter(r => sel.has(r._id ?? "")).sort(byYearNo);
$("#bPrint").onclick = () => openPrint(selected());
$("#bSelClr").onclick = () => { sel.clear(); $("#chkAll").checked = false; renderList(); };
$("#bXls").onclick = () => {
    let rs = selected();
    if (!rs.length)
        rs = records.filter(listFilter()).sort(byYearNo); // semua yang cocok, termasuk yang belum ditampilkan
    if (!rs.length)
        return toast("Tidak ada surat untuk diekspor.");
    const nos = rs.map(r => parseInt(String(r.NO), 10) || 0).sort((a, b) => a - b);
    const ys = [...new Set(rs.map(stYear).filter(Boolean))];
    exportST(rs, `Surat Tugas ${ys.length === 1 ? ys[0] + " " : ""}${nos[0]}-${nos[nos.length - 1]} (${rs.length} surat).xlsx`);
    toast(`${rs.length} surat diekspor ke Excel.`);
};
/** baris pratinjau impor surat tugas */
let recImport = [];
function riRefresh() {
    const mode = $("#riMode input:checked").value;
    const nNew = recImport.filter(x => !x.exists).length, nOld = recImport.length - nNew;
    $("#riGo").disabled = !(nNew || (mode === "update" && nOld) || pendingRB);
    $("#riGo").textContent = `Impor ${nNew + (mode === "update" ? nOld : 0)} surat` + (pendingRB ? " + rincian biaya" : "");
}
let recImpMode = "st";
$("#fRecImp").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f)
    importSTFile(f); });
async function importSTFile(f, wbIn) {
    try {
        const wb = wbIn || XLSX.read(await f.arrayBuffer(), { cellDates: true });
        if (!wbIn)
            pendingRB = null;
        let got = parseSTSheet(wb);
        if (!got || !got.recs.length) {
            const g = parseSurtugWorkbook(wb);
            got = { ...g, mode: "legacy" };
        }
        recImpMode = got.mode ?? "st";
        if (!got.recs.length)
            return toast("Tidak ada sheet surat tugas yang dikenali. Pakai file hasil Ekspor surat tugas.");
        const have = new Set(records.map(recKey));
        recImport = got.recs.map(r => ({ r, exists: have.has(recKey(r)) }));
        const nNew = recImport.filter(x => !x.exists).length;
        $("#riSum").innerHTML = `File <b>${esc(f.name)}</b> (sheet <i>${esc(got.sheet)}</i>): ${recImport.length} surat — <span class="tag ok">${nNew} nomor baru</span> <span class="tag warn">${recImport.length - nNew} nomor sudah ada</span>`;
        $("#riRows").innerHTML = [...recImport.filter(x => !x.exists), ...recImport.filter(x => x.exists)].slice(0, 300).map(({ r, exists }) => {
            const F = compute(r);
            return `<tr><td><span class="tag ${exists ? "warn" : "ok"}">${exists ? "sudah ada" : "baru"}</span></td><td style="white-space:nowrap">${esc(F.NOMOR_ST)}</td><td>${esc((F.NAMA_PELAKSANA_SPD || "-").split(",")[0])}${F._lampN ? ` <span class="tag">+${F._lampN}</span>` : ""}</td><td>${esc(F.MAKSUD__TUJUAN).slice(0, 70)}</td><td style="white-space:nowrap">${esc(F.TGL_PERGI)}</td><td class="num">${rupiah(F._num.jmlTotal)}</td></tr>`;
        }).join("");
        $("#riNote").innerHTML = (got.unknown?.length ? `<span class="bad">${got.unknown.length} nama tidak ditemukan di Pegawai & Mitra</span> (mis. ${esc(got.unknown.slice(0, 3).join(", "))}) — impor Pegawai & Mitra dulu agar nama tampil benar. ` : "") + `Surat dicocokkan dengan nomor urut (NO) + tahun tanggal terbit. Kampung tujuan dicocokkan otomatis dengan SK Transport: ${recImport.filter(x => normChips(x.r._kampung).length).length} dari ${recImport.length} surat terhubung ke kampung SK.` + (pendingRB ? " <b>File juga berisi sheet Rincian Biaya</b> — rincian surat yang cocok ikut diperbarui." : "");
        $("#riMode input[value=skip]").checked = true;
        riRefresh();
        $("#dRecImp").showModal();
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
}
$$("#riMode input").forEach(i => i.addEventListener("change", () => riRefresh()));
$("#riCancel").onclick = () => { pendingRB = null; $("#dRecImp").close(); };
$("#riGo").onclick = () => {
    const mode = $("#riMode input:checked").value;
    let nb = 0, nu = 0;
    for (const { r, exists } of recImport) {
        if (!exists) {
            if (recImpMode === "st")
                r._noBiaya = true;
            r._id = newId();
            records.push(r);
            nb++;
        }
        else if (mode === "update") {
            const i = records.findIndex(x => recKey(x) === recKey(r));
            if (i < 0)
                continue;
            if (recImpMode === "st") {
                const old = records[i];
                for (const k of ST_KEYS)
                    delete old[k];
                for (const k of ST_KEYS)
                    if (r[k] != null)
                        old[k] = r[k];
            } // hanya data surat tugas, rincian tetap
            else {
                r._id = records[i]._id;
                records[i] = r;
            }
            nu++;
        }
    }
    records.sort(byYearNo);
    persist();
    renderList();
    buildLists();
    $("#dRecImp").close();
    const msg = `Impor selesai: ${nb} surat ditambahkan${nu ? `, ${nu} diperbarui` : ""}.`;
    if (pendingRB) {
        const w = pendingRB;
        pendingRB = null;
        importRBwb(w, false, msg + " ");
        return;
    }
    toast(msg + (recImpMode === "st" && nb ? " Rincian biaya surat baru dibuat lewat Edit / Impor." : ""));
};
$("#bDelSel").onclick = () => {
    const rs = selected();
    if (!rs.length)
        return;
    const nos = rs.map(r => r.NO + (stYear(r) ? "/" + stYear(r) : ""));
    if (!confirm(`Hapus ${rs.length} surat tugas terpilih?\n\nNo. ${nos.slice(0, 12).join(", ")}${nos.length > 12 ? ", …" : ""}\n\nTindakan ini tidak bisa dibatalkan (kecuali dari file cadangan).`))
        return;
    const del = new Set(rs.map(r => r._id));
    records = records.filter(r => !del.has(r._id));
    sel.clear();
    if (editingId && del.has(editingId))
        newForm();
    persist();
    renderList();
    buildLists();
    toast(`${rs.length} surat dihapus.`);
};
/* perbaiki nomor urut surat terpilih: lanjut dari nomor terakhir (surat lain di tahun yang sama), urut tanggal terbit */
$("#bRenum").onclick = () => {
    const rs = selected();
    if (!rs.length)
        return toast("Centang surat yang nomornya akan diperbaiki.", "warn");
    const pad = (n, w) => String(n).padStart(Math.max(3, String(w || "").length), "0"), plan = [];
    const byY = new Map();
    for (const r of rs) {
        const y = stYear(r) || 0, g = byY.get(y);
        if (g)
            g.push(r);
        else
            byY.set(y, [r]);
    }
    for (const [y, g] of byY) {
        const ids = new Set(g.map(r => r._id)), base = records.filter(r => !ids.has(r._id) && (stYear(r) || 0) === y).reduce((m, r) => Math.max(m, parseInt(String(r.NO), 10) || 0), 0);
        g.sort((a, b) => (+(parseTgl(a.TGL_TERBIT_ST) || 0) - +(parseTgl(b.TGL_TERBIT_ST) || 0)) || (parseInt(String(a.NO), 10) || 0) - (parseInt(String(b.NO), 10) || 0));
        g.forEach((r, i) => plan.push({ r, old: String(r.NO), neu: pad(base + 1 + i, String(r.NO)) }));
    }
    const chg = plan.filter(x => x.old !== x.neu);
    if (!chg.length)
        return toast("Nomor urut surat terpilih sudah berurutan dari nomor terakhir.", "ok");
    const lines = chg.slice(0, 15).map(x => `${x.old} → ${x.neu}  (${String(x.r.MAKSUD__TUJUAN || "").slice(0, 40)})`).join("\n");
    if (!confirm(`Perbaiki nomor urut ${chg.length} surat tugas (lanjut dari nomor terakhir, urut tanggal terbit)?\n\n${lines}${chg.length > 15 ? "\n…" : ""}\n\nNomor surat tugas (B-…) ikut berubah.`))
        return;
    for (const x of chg)
        x.r.NO = x.neu;
    records.sort(byYearNo);
    persist();
    renderList();
    buildLists();
    toast(`${chg.length} nomor surat tugas diperbaiki.`, "ok");
};
$("#bZip").onclick = () => { const rs = selected(); if (!rs.length)
    return toast("Centang surat terlebih dahulu."); openPrint(rs); };

/* ---- 65_pegawai.ts ---- */
/* ================= PEGAWAI & MITRA ================= */
let pegTab = "pegawai";
const selPeg = new Set();
/* peran penanda tangan pegawai: PPK, Bendahara Pengeluaran, Plt Kepala, Kepala Kantor */
const ROLES = [["KEPALA", "Kepala Kantor"], ["PLT", "Plt / Plh Kepala"], ["PPK", "PPK"], ["BEND", "Bendahara Pengeluaran"]];
const ROLE_NAME = Object.fromEntries(ROLES);
const hasRole = (p, rs) => !!p && Array.isArray(p.roles) && p.roles.some(r => rs.includes(r));
const roleHolders = (rs) => pegawai.filter(p => hasRole(p, rs));
/* sah bila pegawai punya peran itu; bila belum ada satu pun pegawai berperan tsb, semua pegawai boleh (supaya tidak macet) */
const roleOk = (code, rs) => { const h = roleHolders(rs); return !code || !h.length || h.some(p => String(p.kode) === String(code)); };
const SIGN_FIELDS = [["No_PPK", ["PPK"], "PPK"], ["KD_NAMA_KA_PLT_PLH", ["KEPALA", "PLT"], "Kepala / Plt / Plh"], ["KDSPPD", ["KEPALA", "PLT"], "Kepala pada Lampiran SPPD"], ["No_Bend", ["BEND"], "Bendahara Pengeluaran"]];
const isSystemPeg = (p) => String(p.kode) === "999" || /^terlampir$/i.test(String(p.nama).trim());
const isMitra = (p) => !isSystemPeg(p) && (!String(p.pangkat || "").trim() || /^-+$/.test(String(p.pangkat).trim()));
function pegUsage() {
    const u = {};
    for (const r of records)
        for (const c of new Set([r.KD_NAMA_SPD, r.No_PPK, r.KD_NAMA_KA_PLT_PLH, r.KDSPPD, r.No_Bend, ...lampOf(r)].map(codeOf).filter(Boolean)))
            u[c] = (u[c] || 0) + 1;
    return u;
}
function pegShown() {
    const q = $("#qp").value.trim().toLowerCase();
    return pegawai.filter(p => (pegTab === "mitra" ? isMitra(p) : !isMitra(p)) && (!q || Object.values(p).join(" ").toLowerCase().includes(q)));
}
function renderPeg() {
    const U = pegUsage(), rows = pegShown();
    $("#cPeg").textContent = String(pegawai.filter(p => !isMitra(p) && !isSystemPeg(p)).length);
    $("#cMit").textContent = String(pegawai.filter(isMitra).length);
    $("#tPeg tbody").innerHTML = rows.map(p => {
        const sys = isSystemPeg(p);
        return `<tr data-k="${esc(p.kode)}"><td>${sys ? "" : `<input type="checkbox" class="pk" ${selPeg.has(p) ? "checked" : ""}>`}</td>${["nama", "nip", "pangkat", "gol", "jabatan"].map(f => `<td>${sys ? esc(dyn(p)[f]) : `<input class="pe" data-f="${f}" value="${esc(dyn(p)[f])}" placeholder="${f === "pangkat" ? (pegTab === "mitra" ? "kosong = mitra" : "") : ""}">`}</td>`).join("")}<td class="rolecol">${sys || isMitra(p) ? "" : `<div class="rlgrid">` + ROLES.map(([k, n]) => `<button type="button" class="rl ${hasRole(p, [k]) ? "on" : ""}" data-role="${k}" title="${hasRole(p, [k]) ? "Hapus" : "Beri"} peran ${n}">${k === "BEND" ? "Bendahara" : k === "PLT" ? "Plt" : k === "KEPALA" ? "Kepala" : "PPK"}</button>`).join("") + `</div>`}</td><td class="num muted">${U[p.kode] || ""}</td><td>${sys ? `<span class="tag">sistem</span>` : `<button class="btn sm del" data-a="del">Hapus</button>`}</td></tr>`;
    }).join("")
        || `<tr><td colspan="8" class="muted">Tidak ada data.</td></tr>`;
    $("#pegAll").checked = rows.length > 0 && rows.filter(p => !isSystemPeg(p)).every(p => selPeg.has(p));
    $("#pegSel").textContent = selPeg.size ? `${selPeg.size} dipilih` : "";
    $("#bPegDel").disabled = !selPeg.size;
    $("#bPegDel").textContent = selPeg.size ? `Hapus terpilih (${selPeg.size})` : "Hapus terpilih";
    $("#bPegAdd").textContent = pegTab === "mitra" ? "+ Tambah mitra" : "+ Tambah pegawai";
    $$("#tPeg .rolecol").forEach(c => c.hidden = pegTab === "mitra");
    $("#roleSum").hidden = pegTab === "mitra";
    $("#roleSum").innerHTML = `<b>Penanda tangan</b> <span class="muted">— hanya pegawai dengan peran ini yang bisa dipilih di Surat Tugas, Rincian Biaya &amp; Honor:</span><div class="rsgrid">` + ROLES.map(([k, n]) => {
        const h = roleHolders([k]);
        return `<div><small>${esc(n)}</small>${h.length ? h.map(p => `<span>${esc(p.nama.split(",")[0])}</span>`).join("") : `<span class="muted">belum ada — semua pegawai boleh dipilih</span>`}</div>`;
    }).join("") + `</div>`;
}
$("#tPeg").addEventListener("click", e => {
    const b = tg(e).closest("button[data-role]");
    if (!b)
        return;
    const p = pegawai.find(x => x.kode === b.closest("tr").dataset.k);
    if (!p)
        return;
    const k = b.dataset.role, rs = new Set(p.roles || []);
    rs.has(k) ? rs.delete(k) : rs.add(k);
    p.roles = ROLES.map(([x]) => x).filter(x => rs.has(x));
    if (!p.roles.length)
        delete p.roles;
    persist();
    renderPeg();
    toast(`${p.nama.split(",")[0]}: ${rs.has(k) ? "diberi" : "dilepas dari"} peran ${ROLE_NAME[k]}.`);
});
$("#qp").addEventListener("input", () => renderPeg());
$$("#pegTabs button").forEach(b => b.onclick = () => { pegTab = b.dataset.pt ?? "pegawai"; $$("#pegTabs button").forEach(x => x.classList.toggle("on", x === b)); selPeg.clear(); renderPeg(); });
$("#tPeg").addEventListener("change", e => {
    if (!tg(e).classList.contains("pk"))
        return;
    const p = pegawai.find(x => x.kode === tg(e).closest("tr").dataset.k);
    if (!p)
        return;
    tg(e).checked ? selPeg.add(p) : selPeg.delete(p);
    renderPeg();
});
$("#pegAll").addEventListener("change", e => { for (const p of pegShown())
    if (!isSystemPeg(p))
        tg(e).checked ? selPeg.add(p) : selPeg.delete(p); renderPeg(); });
function deletePeople(list) {
    if (!list.length)
        return;
    const U = pegUsage(), used = list.filter(p => U[p.kode]);
    const msg = `Hapus ${list.length} ${pegTab === "mitra" ? "mitra" : "pegawai"}?` + (used.length ? `\n\n${used.length} di antaranya dipakai di surat tugas (${used.slice(0, 3).map(p => p.nama.split(",")[0]).join(", ")}${used.length > 3 ? ", …" : ""}). Nama mereka akan kosong di surat tersebut.` : "");
    if (!confirm(msg))
        return;
    const del = new Set(list);
    pegawai = pegawai.filter(p => !del.has(p));
    list.forEach(p => selPeg.delete(p));
    persist();
    renderPeg();
    buildLists();
    toast(`${list.length} data dihapus.`);
}
$("#bPegDel").onclick = () => deletePeople([...selPeg]);
$("#tPeg").addEventListener("change", e => {
    const inp = tg(e).closest("input.pe");
    if (!inp)
        return;
    const p = pegawai.find(x => x.kode === inp.closest("tr").dataset.k);
    if (!p)
        return;
    const v = inp.value.trim(), f = inp.dataset.f ?? "";
    if (dyn(p)[f] === v)
        return;
    if (f === "nama" && !v) {
        toast("Nama tidak boleh kosong.");
        inp.value = p.nama;
        return;
    }
    dyn(p)[f] = v;
    persist();
    buildLists();
    inp.style.borderColor = "var(--ok)";
    setTimeout(() => inp.style.borderColor = "", 900);
    if (f === "pangkat" && isMitra(p) !== (pegTab === "mitra")) {
        selPeg.delete(p);
        renderPeg();
        toast(`${p.nama.split(",")[0]} dipindah ke tab ${isMitra(p) ? "Mitra" : "Pegawai"}.`);
    }
});
$("#tPeg").addEventListener("click", e => {
    if (tg(e).dataset.a !== "del")
        return;
    const k = tg(e).closest("tr").dataset.k;
    const p = pegawai.find(x => x.kode === k);
    if (p)
        deletePeople([p]);
});
/* ---- ekspor & impor pegawai / mitra ---- */
const PEG_HDR = ["NO", "NAMA LENGKAP", "NIP BARU", "NIP LAMA", "PANGKAT", "GOLONGAN", "JABATAN", "STATUS"];
$("#bPegExp").onclick = () => {
    const row = (p) => [/^\d+$/.test(p.kode) ? +p.kode : p.kode, p.nama, p.nip, "", p.pangkat, p.gol, p.jabatan, isSystemPeg(p) ? "Sistem" : isMitra(p) ? "Mitra" : "Pegawai", (p.roles || []).map(r => ROLE_NAME[r]).join("; ")];
    const mitra = pegTab === "mitra", list = pegawai.filter(p => !isSystemPeg(p) && isMitra(p) === mitra), nm = mitra ? "Mitra" : "Pegawai";
    const ws = XLSX.utils.aoa_to_sheet([[...PEG_HDR, "Peran Tanda Tangan"], ...list.map(row)]);
    ws["!cols"] = [6, 38, 22, 12, 22, 10, 40, 10, 34].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, nm);
    XLSX.writeFile(wb, `${nm} (${list.length} orang).xlsx`);
    toast(`${list.length} ${nm.toLowerCase()} diekspor.`);
};
let pegImport = [];
const normNip = (v) => String(v ?? "").replace(/\D/g, "");
function readPegSheet(wb) {
    const out = [];
    for (const sn of wb.SheetNames) {
        if (/^hanya/i.test(sn) && wb.SheetNames.some(n => /^pegawai$/i.test(n)))
            continue; // ekspor aplikasi: cukup baca sheet utama
        const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: false });
        const hi = rows.findIndex(r => r.some(c => /nama/i.test(String(c))));
        if (hi < 0)
            continue;
        const H = rows[hi].map(c => String(c).trim().toUpperCase());
        const col = (...re) => H.findIndex(h => re.some(x => x.test(h)));
        const cNama = col(/^NAMA/), cNip = col(/^NIP( BARU)?$/, /^NIP/), cPkt = col(/^PANGKAT/), cGol = col(/^GOL/), cJab = col(/^JABATAN/), cSt = col(/^STATUS/);
        if (cNama < 0)
            continue;
        for (const r of rows.slice(hi + 1)) {
            const nama = String(r[cNama] ?? "").trim();
            if (!nama || /^terlampir$/i.test(nama))
                continue;
            const st = cSt >= 0 ? String(r[cSt]).trim() : "";
            if (/^sistem$/i.test(st))
                continue;
            let pangkat = cPkt >= 0 ? String(r[cPkt]).trim() : "";
            if (/^mitra$/i.test(st))
                pangkat = pangkat && pangkat !== "-" ? pangkat : "-";
            out.push({ nama, nip: cNip >= 0 ? String(r[cNip]).trim() || "-" : "-", pangkat: pangkat || "-", gol: cGol >= 0 ? String(r[cGol]).trim() || "-" : "-", jabatan: cJab >= 0 ? String(r[cJab]).trim() : (/^mitra$/i.test(st) ? "Mitra Statistik" : "") });
        }
        if (out.length)
            break;
    }
    return out;
}
function matchPeg(x) {
    const nip = normNip(x.nip);
    if (nip.length >= 8) {
        const m = pegawai.find(p => normNip(p.nip) === nip);
        if (m)
            return m;
    }
    return pegawai.find(p => p.nama.trim().toLowerCase() === x.nama.toLowerCase()) || pegawai.find(p => normName(p.nama) === normName(x.nama)) || null;
}
$("#fPegImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
        const list = readPegSheet(wb);
        if (!list.length)
            return toast("Tidak ditemukan kolom NAMA di file ini.");
        const seen = new Set();
        pegImport = list.filter(x => { const k = normNip(x.nip).length >= 8 ? normNip(x.nip) : normName(x.nama); if (seen.has(k))
            return false; seen.add(k); return true; }).map(x => {
            const m = matchPeg(x);
            const nv = (v) => { const t = String(v ?? "").trim(); return /^-+$/.test(t) ? "" : t; };
            const changed = m && ["nama", "nip", "pangkat", "gol", "jabatan"].some(k => nv(dyn(m)[k]) !== nv(dyn(x)[k]));
            return { x, m, status: !m ? "baru" : changed ? "diperbarui" : "sama" };
        });
        const c = (k) => pegImport.filter(i => i.status === k).length;
        $("#piSum").innerHTML = `File <b>${esc(f.name)}</b>: ${pegImport.length} orang — <span class="tag ok">${c("baru")} baru</span> <span class="tag warn">${c("diperbarui")} diperbarui</span> <span class="tag">${c("sama")} sama</span>`;
        const show = pegImport.filter(i => i.status !== "sama").concat(pegImport.filter(i => i.status === "sama")).slice(0, 300);
        $("#piRows").innerHTML = show.map(({ x, m, status }) => `<tr><td><span class="tag ${status === "baru" ? "ok" : status === "diperbarui" ? "warn" : ""}">${status}</span></td><td>${esc(x.nama)}${m && m.nama !== x.nama ? `<div class="muted" style="font-size:11px">sebelumnya: ${esc(m.nama)}</div>` : ""}</td><td>${esc(x.nip)}</td><td>${esc([x.pangkat, x.gol].filter(v => v && v !== "-").join(" / ") || "Mitra")}</td><td>${esc(x.jabatan)}</td></tr>`).join("");
        $("#piGo").disabled = !c("baru") && !c("diperbarui");
        $("#dPegImp").showModal();
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
});
$("#piCancel").onclick = () => $("#dPegImp").close();
$("#piGo").onclick = () => {
    let max = pegawai.reduce((m, p) => (+p.kode < 999 ? Math.max(m, +p.kode || 0) : m), 0), nb = 0, nu = 0;
    for (const { x, m, status } of pegImport) {
        if (status === "baru") {
            pegawai.push({ kode: String(++max === 999 ? ++max : max), ...x });
            nb++;
        }
        else if (status === "diperbarui" && m) {
            Object.assign(m, x);
            nu++;
        }
    }
    persist();
    renderPeg();
    buildLists();
    $("#dPegImp").close();
    toast(`Impor selesai: ${nb} ditambahkan, ${nu} diperbarui.`);
};
$("#bPegAdd").onclick = () => {
    const max = pegawai.reduce((m, p) => (+p.kode < 999 ? Math.max(m, +p.kode || 0) : m), 0);
    pegawai.push(pegTab === "mitra" ? { kode: String(max + 1), nama: "Nama mitra baru", nip: "-", pangkat: "-", gol: "-", jabatan: "Mitra Statistik" }
        : { kode: String(max + 1), nama: "Nama pegawai baru", nip: "", pangkat: "Isi pangkat", gol: "", jabatan: "" });
    persist();
    $("#qp").value = "";
    renderPeg();
    buildLists();
    const last = $("#tPeg tbody tr:last-child input[data-f=nama]");
    if (last) {
        last.scrollIntoView({ block: "center" });
        last.focus();
        last.select();
    }
};
/* ================= datalists ================= */
function buildLists() {
    $("#dl-peg").innerHTML = pegawai.map(p => `<option value="${esc(p.nama)}">${esc([p.jabatan, p.nip && p.nip !== "-" && p.nip !== "Terlampir" ? "NIP " + p.nip : ""].filter(Boolean).join(" · "))}</option>`).join("");
    const uniq = (k) => [...new Set(records.map(r => r[k]).filter(Boolean).map(String))].sort();
    const set = (id, k) => $(id).innerHTML = uniq(k).map(v => `<option value="${esc(v)}">`).join("");
    set("#dl-nolengkap", "NoLengkap");
    set("#dl-kegiatan", "kegiatan");
    set("#dl-angkut", "ALAT_ANGKUTAN_YANG_DIGUNAKAN");
    set("#dl-berangkat", "TEMPAT_BERANGKAT");
    set("#dl-hotel", "HOTEL_TEMPAT");
    set("#dl-tujuan", "TEMPAT_TUJUAN");
    const U = usage();
    $("#dl-mak").innerHTML = [...pokDB.akun].sort((x, y) => (+/^5241/.test(y.akun) - +/^5241/.test(x.akun))).map(a => {
        const sisa = a.pagu - a.blokir - (U[a.mak]?.j || 0);
        return `<option value="${esc(a.mak)}">${esc(a.nama)} · ${esc(a.roNama)} · sisa Rp ${rupiah(sisa)}</option>`;
    }).join("");
    $("#dl-kode").innerHTML = kodeDB.codes.map(c => `<option value="${esc(c.k)}">${esc(c.d)} — ${esc(kodeGroup(c.k))}</option>`).join("");
    $("#dl-kampung").innerHTML = kampungDB.map(k => `<option value="${esc(kamLabel(k))}">`).join("");
    $("#dl-kampung-nama").innerHTML = kampungDB.map(k => `<option value="${esc(title(k.kampung))}">${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)}</option>`).join("");
    if (!$("#dl-trans"))
        document.body.insertAdjacentHTML("beforeend", `<datalist id="dl-trans"></datalist>`);
    $("#dl-trans").innerHTML = otherTransRef().map(([t, v]) => `<option value="${esc(t)}">Rp ${rupiah(num(v))}</option>`).join("");
    fillPresets();
}
/* ================= referensi ================= */
const selKam = new Set(), selKode = new Set();
function renderKam() {
    const q = $("#qk").value.trim().toLowerCase();
    const rows = kampungDB.map((k, i) => [k, i]).filter(([k]) => !q || (k.distrik + " " + k.kampung).toLowerCase().includes(q));
    $("#kInfo").textContent = `${rows.length} dari ${kampungDB.length} kampung`;
    $("#kamAll").checked = rows.length > 0 && rows.every(([k]) => selKam.has(k));
    $("#bKamTarif").disabled = !selKam.size;
    $("#bKamTarif").textContent = selKam.size ? `Ubah tarif terpilih (${selKam.size})…` : "Ubah tarif terpilih…";
    $("#bKamDel").disabled = !selKam.size;
    $("#bKamDel").textContent = selKam.size ? `Hapus terpilih (${selKam.size})` : "Hapus terpilih";
    $("#tKam tbody").innerHTML = rows.map(([k, i]) => `<tr data-i="${i}"><td><input type="checkbox" class="kk" ${selKam.has(k) ? "checked" : ""}></td><td contenteditable="true" data-f="distrik">${esc(k.distrik)}</td><td contenteditable="true" data-f="kampung">${esc(k.kampung)}</td><td class="num"><input type="number" class="tarif-in" min="0" step="1000" value="${k.tarif}" style="width:140px;text-align:right" title="Tarif PP — ketik lalu Enter / klik di luar"></td><td class="num muted">${rupiah(k.tarif / 2)}</td><td style="text-align:center"><input type="checkbox" class="kl" ${kamLokal(k) ? "checked" : ""} title="Kampung Lokal — boleh dipakai surat tugas Lokal"></td><td contenteditable="true" data-f="ket">${esc(k.ket)}</td><td><button class="btn sm del" data-a="del">Hapus</button></td></tr>`).join("");
}
$("#qk").addEventListener("input", () => renderKam());
$("#tKam").addEventListener("focusout", e => {
    const td = tg(e).closest("td[data-f]");
    if (!td)
        return;
    const k = kampungDB[Number(td.parentNode.dataset.i)];
    if (!k)
        return;
    const f = td.dataset.f ?? "", v = td.textContent.trim();
    dyn(k)[f] = f === "tarif" ? num(v.replace(/\./g, "")) : (f === "ket" ? v : v.toUpperCase());
    if (f === "tarif") {
        td.textContent = rupiah(k.tarif);
        td.nextElementSibling.textContent = rupiah(k.tarif / 2);
    }
    persist();
    buildLists();
    renderChips();
});
$("#tKam").addEventListener("click", e => {
    if (tg(e).dataset.a !== "del")
        return;
    const i = Number(tg(e).closest("tr").dataset.i);
    if (confirm("Hapus kampung " + title(kampungDB[i].kampung) + "?")) {
        selKam.delete(kampungDB[i]);
        kampungDB.splice(i, 1);
        persist();
        renderKam();
        buildLists();
    }
});
$("#tKam").addEventListener("change", e => {
    if (tg(e).classList.contains("tarif-in")) {
        const k = kampungDB[Number(tg(e).closest("tr").dataset.i)];
        if (!k)
            return;
        k.tarif = Math.max(0, num(tg(e).value));
        tg(e).closest("td").nextElementSibling.textContent = rupiah(k.tarif / 2);
        persist();
        buildLists();
        renderChips();
        toast(`Tarif PP ${title(k.kampung)} = Rp ${rupiah(k.tarif)}`);
        return;
    }
    if (tg(e).classList.contains("kl")) {
        const k = kampungDB[Number(tg(e).closest("tr").dataset.i)];
        if (!k)
            return;
        k.lokal = tg(e).checked;
        persist();
        buildLists();
        _dataVer++;
        toast(`${title(k.kampung)} ${k.lokal ? "diberi" : "dilepas dari"} label Lokal.`);
        return;
    }
    if (!tg(e).classList.contains("kk"))
        return;
    const k = kampungDB[Number(tg(e).closest("tr").dataset.i)];
    tg(e).checked ? selKam.add(k) : selKam.delete(k);
    renderKam();
});
$("#kamAll").addEventListener("change", e => { const q = $("#qk").value.trim().toLowerCase(); kampungDB.filter(k => !q || (k.distrik + " " + k.kampung).toLowerCase().includes(q)).forEach(k => tg(e).checked ? selKam.add(k) : selKam.delete(k)); renderKam(); });
$("#bKamTarif").onclick = () => {
    if (!selKam.size)
        return;
    const v = prompt(`Tarif PP baru (Rp) untuk ${selKam.size} kampung terpilih:\n(boleh juga +50000 / -50000 untuk menaikkan / menurunkan)`, "");
    if (v == null || !v.trim())
        return;
    const t = v.trim().replace(/\./g, ""), rel = /^[+-]/.test(t), d = num(t);
    if (!rel && !(d >= 0))
        return toast("Nilai tidak valid.");
    for (const k of selKam)
        k.tarif = Math.max(0, rel ? k.tarif + d : d);
    persist();
    renderKam();
    buildLists();
    renderChips();
    toast(`Tarif ${selKam.size} kampung diperbarui.`);
};
$("#bKamDel").onclick = () => {
    if (!selKam.size || !confirm(`Hapus ${selKam.size} kampung dari SK Transport?`))
        return;
    const n = selKam.size;
    kampungDB = kampungDB.filter(k => !selKam.has(k));
    selKam.clear();
    persist();
    renderKam();
    buildLists();
    renderChips();
    toast(`${n} kampung dihapus.`);
};
$("#bKamAdd").onclick = () => {
    kampungDB.push({ distrik: "DISTRIK", kampung: "KAMPUNG BARU", tarif: 0, ket: "" });
    persist();
    $("#qk").value = "";
    renderKam();
    buildLists();
    const td = $("#tKam tbody tr:last-child td[data-f=kampung]");
    td.scrollIntoView({ block: "center" });
    td.focus();
    document.execCommand && document.execCommand("selectAll", false);
};
function renderTarif() {
    const grups = [...new Set(tarifDB.map(t => t.grup))];
    $("#tTarif tbody").innerHTML = tarifDB.map((t, i) => {
        const rule = t.grup === RULES_GRUP;
        return `<tr data-i="${i}"><td>${rule ? `<span class="muted">${esc(t.grup)}</span>` : `<input class="tf" data-f="grup" value="${esc(t.grup)}" list="dl-tgrup">`}</td>
      <td>${rule ? `${esc(t.nama)} <span class="tag" title="Dipakai aturan biaya otomatis — uraian tidak bisa diubah">aturan</span>` : `<input class="tf" data-f="nama" value="${esc(t.nama)}">`}</td>
      <td><input class="tf" data-f="nilai" type="number" min="0" step="1000" value="${t.nilai}" style="text-align:right"></td>
      <td>${rule ? "" : `<button class="btn sm del" data-tdel="${i}">Hapus</button>`}</td></tr>`;
    }).join("");
    if (!$("#dl-tgrup"))
        document.body.insertAdjacentHTML("beforeend", `<datalist id="dl-tgrup"></datalist>`);
    $("#dl-tgrup").innerHTML = [...new Set(["MOBIL 2026", "MOBIL BANDARA 2026", "UHAR 2026", "INAP 2026", "TRANSLOK 2026", ...grups.filter(g => g !== RULES_GRUP)])].map(g => `<option value="${esc(g)}">`).join("");
}
$("#tTarif").addEventListener("change", e => {
    const inp = tg(e).closest("input.tf");
    if (!inp)
        return;
    const t = tarifDB[Number(inp.closest("tr").dataset.i)];
    if (!t)
        return;
    const f = inp.dataset.f === "grup" ? "grup" : inp.dataset.f === "nilai" ? "nilai" : "nama", v = inp.value.trim();
    if (f === "nilai")
        t.nilai = Math.max(0, num(v));
    else {
        if (!v) {
            toast((f === "grup" ? "Grup" : "Uraian") + " tidak boleh kosong.");
            inp.value = t[f];
            return;
        }
        t[f] = v.toUpperCase();
        inp.value = t[f];
    }
    persist();
    buildLists();
    inp.style.borderColor = "var(--ok)";
    setTimeout(() => inp.style.borderColor = "", 900);
});
$("#tTarif").addEventListener("click", e => {
    const i = tg(e).dataset.tdel;
    if (i == null)
        return;
    const t = tarifDB[+i];
    if (!confirm(`Hapus tarif "${t.nama}" (${t.grup})?`))
        return;
    tarifDB.splice(+i, 1);
    persist();
    renderTarif();
    buildLists();
    toast("Tarif dihapus.");
});
$("#bTarifAdd").onclick = () => {
    const at = tarifDB.findIndex(t => t.grup === RULES_GRUP);
    const t = { grup: "MOBIL 2026", nama: "URAIAN BARU", nilai: 0 };
    at < 0 ? tarifDB.push(t) : tarifDB.splice(at, 0, t);
    persist();
    renderTarif();
    buildLists();
    const inp = $(`#tTarif tr[data-i="${tarifDB.indexOf(t)}"] input[data-f=nama]`);
    inp.scrollIntoView({ block: "center" });
    inp.focus();
    inp.select();
};
function renderKode() {
    const q = $("#qc").value.trim().toLowerCase();
    const all = kodeDB.codes.filter(c => !q || (c.k + " " + c.d + " " + kodeGroup(c.k)).toLowerCase().includes(q)), rows = all.slice(0, 400);
    $("#cInfo").textContent = `${all.length} dari ${kodeDB.codes.length} kode${all.length > 400 ? " (400 pertama ditampilkan — persempit pencarian)" : ""}`;
    $("#kodeAll").checked = rows.length > 0 && rows.every(c => selKode.has(c));
    $("#bKodeDel").disabled = !selKode.size;
    $("#bKodeDel").textContent = selKode.size ? `Hapus terpilih (${selKode.size})` : "Hapus terpilih";
    $("#tKode tbody").innerHTML = rows.map(c => `<tr data-ci="${kodeDB.codes.indexOf(c)}"><td><input type="checkbox" class="kc" ${selKode.has(c) ? "checked" : ""}></td><td style="white-space:nowrap;padding-left:${8 + (c.l || 0) * 14}px" contenteditable="true" data-f="k"><b>${esc(c.k)}</b></td><td contenteditable="true" data-f="d">${esc(c.d)}</td><td class="muted">${esc(kodeGroup(c.k))}</td><td style="white-space:nowrap"><button class="btn sm" data-k="${esc(c.k)}" data-to="form">Pakai di Personal</button> <button class="btn sm" data-k="${esc(c.k)}" data-to="mass">Massal</button></td></tr>`).join("");
}
$("#qc").addEventListener("input", () => renderKode());
$("#tKode").addEventListener("change", e => { if (!tg(e).classList.contains("kc"))
    return; const c = kodeDB.codes[Number(tg(e).closest("tr").dataset.ci)]; tg(e).checked ? selKode.add(c) : selKode.delete(c); renderKode(); });
$("#kodeAll").addEventListener("change", e => { const q = $("#qc").value.trim().toLowerCase(); kodeDB.codes.filter(c => !q || (c.k + " " + c.d + " " + kodeGroup(c.k)).toLowerCase().includes(q)).slice(0, 400).forEach(c => tg(e).checked ? selKode.add(c) : selKode.delete(c)); renderKode(); });
$("#tKode").addEventListener("focusout", e => {
    const td = tg(e).closest("td[data-f]");
    if (!td)
        return;
    const c = kodeDB.codes[Number(td.parentNode.dataset.ci)];
    if (!c)
        return;
    const f = td.dataset.f, v = td.textContent.trim();
    if (f === "k") {
        const k = v.toUpperCase().replace(/\s+/g, "");
        if (k === c.k)
            return;
        if (!/^[A-Z]{2,3}\.\d{3,4}$/.test(k)) {
            toast("Format kode harus seperti VS.330");
            td.innerHTML = `<b>${esc(c.k)}</b>`;
            return;
        }
        if (kodeDB.codes.some(x => x !== c && x.k === k)) {
            toast("Kode " + k + " sudah ada.");
            td.innerHTML = `<b>${esc(c.k)}</b>`;
            return;
        }
        c.k = k;
        td.innerHTML = `<b>${esc(k)}</b>`;
        td.nextElementSibling.nextElementSibling.textContent = kodeGroup(k);
    }
    else {
        if (v === c.d)
            return;
        c.d = v;
    }
    persist();
    buildLists();
});
$("#bKodeDel").onclick = () => {
    if (!selKode.size || !confirm(`Hapus ${selKode.size} kode klasifikasi?`))
        return;
    const n = selKode.size;
    kodeDB.codes = kodeDB.codes.filter(c => !selKode.has(c));
    selKode.clear();
    persist();
    renderKode();
    buildLists();
    toast(`${n} kode dihapus.`);
};
$("#bKodeAdd").onclick = () => {
    let i = 1, k = "";
    do {
        k = "XX." + String(i++).padStart(3, "0");
    } while (kodeDB.codes.some(c => c.k === k));
    const c = { k, l: 0, d: "Uraian kode baru" };
    kodeDB.codes.unshift(c);
    persist();
    $("#qc").value = "";
    renderKode();
    buildLists();
    const td = $("#tKode tbody tr:first-child td[data-f=k]");
    td.scrollIntoView({ block: "center" });
    td.focus();
    document.execCommand && document.execCommand("selectAll", false);
    toast("Ketik kode baru (mis. VS.340) lalu uraiannya.");
};
$("#tKode").addEventListener("click", e => {
    const k = tg(e).dataset.k;
    if (!k)
        return;
    if (tg(e).dataset.to === "mass") {
        mIn("kode").value = k;
        mIn("NoLengkap").value = composeNL(k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value);
        massCommon = readCommon();
        persistMass();
        updateMassInfo();
        show("mass");
    }
    else {
        form.NoLengkap.value = composeNL(k, form.NoLengkap.value, form.TGL_TERBIT_ST.value);
        refresh();
        show("form");
        showSub("data");
    }
    window.scrollTo(0, 0);
    toast("Kode " + k + " dipakai pada nomor surat.");
});
function parseKodeSheet(rows) {
    const groups = { KP: "Kepegawaian", KU: "Keuangan" }, codes = [], seen = new Set();
    let cur = null;
    for (const r of rows) {
        const v = Array.from({ length: 7 }, (_, i) => r[i] == null ? "" : String(r[i]).replace(/\s+/g, " ").trim());
        if (!v.some(Boolean))
            continue;
        const g = v[0], rest = v.slice(1);
        if (!g) {
            const m = rest[0].match(/\(([A-Z]{2,3})\)\s*$/);
            if (m) {
                cur = m[1];
                continue;
            }
        }
        const idx = rest.findIndex(x => /^\d{3,4}$/.test(x));
        if (/^[A-Z]{2,3}$/.test(g)) {
            cur = g;
            if (idx < 0) {
                groups[g] = title(rest[0]);
                continue;
            }
        }
        if (idx < 0 || !cur)
            continue;
        const k = cur + "." + rest[idx];
        if (seen.has(k))
            continue;
        seen.add(k);
        let d = rest.slice(idx + 1).find(Boolean) || "";
        const raw = r[idx + 2];
        if (raw && /\s{6,}/.test(String(raw)))
            d = String(raw).trim().split(/\s{6,}/)[0].trim();
        d = d.replace(/\.$/, "");
        if (d === d.toUpperCase())
            d = title(d);
        codes.push({ k, l: idx, d });
    }
    return { groups, codes };
}
function parseTransSheet(rows) {
    const h = rows[0].map(x => String(x ?? ""));
    const tc = h.map((x, i) => [x, i]).filter(([x]) => /transport.*\(pp\)/i.test(x)).pop();
    const ci = tc ? tc[1] : 3;
    const kam = [], tar = [];
    let sect = null;
    for (const r of rows.slice(1)) {
        if (r[0] && r[1])
            kam.push({ distrik: String(r[0]).trim(), kampung: String(r[1]).trim(), tarif: num(r[ci]), ket: String(r[ci + 1] ?? "").trim() });
        const lab = r[ci + 2];
        if (!lab)
            continue;
        if (r[ci + 3] == null || r[ci + 3] === "") {
            sect = String(lab).trim();
            continue;
        }
        const nv = r[ci + 3];
        if (typeof nv === "number")
            tar.push({ grup: sect || "MOBIL", nama: String(lab).trim(), nilai: nv });
    }
    return { kam, tar };
}

/* ---- 70_excel.ts ---- */
/* ================= excel import/export ================= */
const COLS = ["NO", "NOSURTUG", "NoLengkap", "NOMOR_ST", "TGL_TERBIT_ST", "KD_NAMA_SPD", "NAMA_PELAKSANA_SPD", "NIP_PELAKSANA_SPD", "JABATAN", "PANGKAT", "GOL", "kegiatan", "MAKSUD__TUJUAN", "NOMOR_SPD", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT", "TEMPAT_TUJUAN", "LAMA_JALAN", "TGL_PERGI", "TGL_PULANG", "MAK", "TGL_SPD", "No_PPK", "PPK", "NIP_PPK", "KD_NAMA_KA_PLT_PLH", "KAPLTPLH", "KDSPPD", "KepalaSPPD", "NIPKepala", "LAMA_INAP", "TDK_INAP_HOTEL", "TOTAL_BIAYA_TDK_INAP_HOTEL", "PENG_RIIL", "Terbilang3", "LAMA_UH", "NILAI_UH", "TOTAL_UH", "TOTAL_TRANS", "JUMLAH", "TERBILANG", "TGL_KUI", "No)Bend", "BEND", "NIP_BEND",
    ...[1, 2, 3, 4, 5].flatMap(i => [`KodeLampiran${i}`, i === 1 ? "NAMALAMPIRAN_1" : `NAMA_LAMPIRAN_${i}`, `NIP_LAMPIRAN_${i}`, `JABATAN_LAMPIRAN_${i}`, `PANGKAT_LAMPIRAN_${i}`, `GOL_LAMPIRAN_${i}`]),
    ...Array.from({ length: MAXTR }, (_, i) => [`KetTransport_${i + 1}`, `Nilai${i + 1}`]).flat(), "KodeLampiranLain", "NamaLampiranLain", "KampungSK", "JENIS", "RINCIAN", "PER_ORANG", "HOTEL_TEMPAT", "LAMA_HOTEL", "TARIF_HOTEL", "TOTAL_HOTEL"];
function exportXlsxLegacy(recs, fname) {
    const aoa = [COLS];
    for (const r of recs) {
        const F = compute(r), lamp = lampOf(r);
        aoa.push(COLS.map(c => {
            if (c === "No)Bend")
                return r.No_Bend ?? "";
            if (c === "KodeLampiranLain")
                return lamp.slice(5).join(", ");
            if (c === "JENIS")
                return r.JENIS || "";
            if (c === "RINCIAN")
                return r._noBiaya ? "Belum dibuat" : "Ada";
            if (c === "HOTEL_TEMPAT")
                return r.HOTEL_TEMPAT || "";
            if (c === "LAMA_HOTEL")
                return r.LAMA_HOTEL == null ? "" : num(r.LAMA_HOTEL);
            if (c === "TARIF_HOTEL")
                return r.TARIF_HOTEL == null ? "" : num(r.TARIF_HOTEL);
            if (c === "TOTAL_HOTEL")
                return F._num.totHotel || "";
            if (c === "PER_ORANG")
                return r._perOrang ? JSON.stringify(Object.fromEntries(Object.entries(r._perOrang).map(([k, v]) => [pegMap()[k]?.nama || k, v]))) : "";
            if (c === "NamaLampiranLain")
                return lamp.slice(5).map(x => pegMap()[x]?.nama || x).join("; ");
            if (c === "KampungSK")
                return normChips(r._kampung).map(x => x.k + (x.pp ? "" : "|1/2")).join("; ");
            const ml = c.match(/^KodeLampiran(\d)$/);
            if (ml) {
                const v = lamp[+ml[1] - 1];
                return v == null ? "" : (/^\d+$/.test(v) ? +v : v);
            }
            if (/^(KD_NAMA_SPD|No_PPK|KD_NAMA_KA_PLT_PLH|KDSPPD)$/.test(c))
                return r[c] != null && /^\d+$/.test(r[c]) ? +r[c] : (r[c] ?? "");
            const nums = { TDK_INAP_HOTEL: num(r.TDK_INAP_HOTEL), TOTAL_BIAYA_TDK_INAP_HOTEL: F._num.totInap, PENG_RIIL: F._num.totRiil, NILAI_UH: num(r.NILAI_UH), TOTAL_UH: F._num.totUH, TOTAL_TRANS: F._num.totTr, JUMLAH: F._num.jml };
            if (c in nums)
                return nums[c];
            if (/^Nilai\d+$/.test(c))
                return r[c] == null ? "" : num(r[c]);
            if (["LAMA_JALAN", "LAMA_INAP", "LAMA_UH"].includes(c))
                return r[c] == null ? (c === "LAMA_JALAN" ? "" : num(F[c])) : num(r[c]);
            return F[c] ?? "";
        }));
    }
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "Surtug 2026");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["NO", "NAMA LENGKAP", "NIP BARU", "NIP LAMA", "PANGKAT", "GOLONGAN", "JABATAN"], ...pegawai.map(p => [/^\d+$/.test(p.kode) ? +p.kode : p.kode, p.nama, p.nip, "", p.pangkat, p.gol, p.jabatan])]), "Pegawai");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["Distrik", "Kampung", "Transport Kabupaten-Kampung (PP) 2026", "Keterangan"], ...kampungDB.map(k => [k.distrik, k.kampung, k.tarif, kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? [k.ket, "Lokal"].filter(Boolean).join(" · ") : !kamLokal(k) && /lokal/i.test(k.ket ?? "") ? String(k.ket).replace(/\s*·?\s*lokal/ig, "").trim() : k.ket])]), "SK TRANS 2026");
    // sheet ringkas yang mudah dibaca
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["No", "Nomor Surat Tugas", "Tanggal Terbit", "Pelaksana", "NIP", "Anggota Tim", "Kegiatan", "Maksud / Tujuan", "Jenis", "Tempat Tujuan", "Tgl Pergi", "Tgl Pulang", "Lama (hari)", "MAK", "Uang Harian", "Penginapan riil", "Penginapan hotel", "Transport", "Jumlah per orang", "Jumlah orang", "Total biaya", "Status Rincian"],
        ...recs.map(r => { const F = compute(r); return [r.NO, F.NOMOR_ST, F.TGL_TERBIT_ST, F.NAMA_PELAKSANA_SPD, F.NIP_PELAKSANA_SPD, lampOf(r).map(c => pegMap()[c]?.nama || c).join("; "), F.kegiatan, F.MAKSUD__TUJUAN, r.JENIS || "Remote", F.TEMPAT_TUJUAN, F.TGL_PERGI, F.TGL_PULANG, num(r.LAMA_JALAN) || "", F.MAK, F._num.totUH, F._num.totInap, F._num.totHotel, F._num.totTr, F._num.jml, F._num.orang, F._num.jmlTotal, r._noBiaya ? "Belum dibuat" : "Ada"]; })]), "Daftar Surat Tugas");
    wb.SheetNames.unshift(wb.SheetNames.pop());
    XLSX.writeFile(wb, fname);
}
/* ---------- SURAT TUGAS: satu sheet ---------- */
const ST_HDR = ["No", "Nomor Surat Tugas", "Akhiran Nomor", "Tanggal Terbit", "Pelaksana", "NIP Pelaksana", "Anggota Tim", "Kegiatan", "Maksud / Tujuan", "Lokal / Remote", "Alat Angkutan", "Tempat Berangkat", "Tempat Tujuan", "Kampung Tujuan (SK)", "Tgl Pergi", "Tgl Pulang", "Lama (hari)", "MAK", "PPK", "Kepala / Plt / Plh", "Kepala Lampiran SPPD", "Status Rincian"];
function kamCellText(r) { const M = kamByKey(); return normChips(r._kampung).map(c => { const k = M[c.k]; return k ? `${title(k.kampung)} (${title(k.distrik)})${c.pp ? "" : " ½"}` : c.k; }).join("; "); }
function exportST(recs, fname) {
    const P = pegMap();
    const rows = recs.map(r => {
        const F = compute(r);
        return [r.NO, F.NOMOR_ST, r.NoLengkap || "", F.TGL_TERBIT_ST, F.NAMA_PELAKSANA_SPD, F.NIP_PELAKSANA_SPD, lampOf(r).map(c => P[c]?.nama || c).join("; "), F.kegiatan, F.MAKSUD__TUJUAN, r.JENIS || "Remote", F.ALAT_ANGKUTAN_YANG_DIGUNAKAN, F.TEMPAT_BERANGKAT, F.TEMPAT_TUJUAN, kamCellText(r), F.TGL_PERGI, F.TGL_PULANG, num(r.LAMA_JALAN) || "", F.MAK, F.PPK, F.KAPLTPLH, F.KepalaSPPD, r._noBiaya ? "Belum dibuat" : "Ada"];
    });
    const ws = XLSX.utils.aoa_to_sheet([ST_HDR, ...rows]);
    ws["!cols"] = [6, 30, 24, 16, 30, 22, 40, 26, 44, 12, 10, 16, 34, 40, 18, 18, 8, 28, 28, 28, 28, 12].map(w => ({ wch: w }));
    if (!fname)
        return ws;
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Surat Tugas");
    XLSX.writeFile(wb, fname);
}
function findKampungCell(txt) {
    const m = String(txt).trim().match(/^(.*?)\s*(?:\(([^)]*)\))?\s*(½|1\/2)?$/);
    const nm = (m ? m[1] : txt).trim(), ds = m && m[2] ? m[2].trim().toLowerCase() : "";
    const k = (ds && kampungDB.find(x => x.kampung.toLowerCase() === nm.toLowerCase() && x.distrik.toLowerCase() === ds)) || findKampung(nm);
    return k ? { k: kKey(k), pp: !(m && m[3]) } : null;
}
function parseSTSheet(wb) {
    for (const sn of wb.SheetNames) {
        const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: false });
        const hi = rows.findIndex(r => r.some(c => /^nomor surat tugas$/i.test(String(c).trim())) && r.some(c => /^pelaksana$/i.test(String(c).trim())));
        if (hi < 0)
            continue;
        const H = rows[hi].map(c => String(c).trim().toLowerCase()), col = (name) => H.indexOf(name.toLowerCase());
        const get = (row, name) => { const i = col(name); return i < 0 ? "" : String(row[i] ?? "").trim(); };
        const unknown = new Set(), recs = [];
        const byName = (nm) => { if (!nm)
            return null; if (/^terlampir$/i.test(nm))
            return pegMap()["999"] ? "999" : null; const c = resolvePeg(nm); if (!c)
            unknown.add(nm); return c; };
        for (const row of rows.slice(hi + 1)) {
            const NO = get(row, "No");
            if (!NO || !get(row, "Maksud / Tujuan"))
                continue;
            const r = { NO: String(NO), NoLengkap: get(row, "Akhiran Nomor"), TGL_TERBIT_ST: get(row, "Tanggal Terbit"), kegiatan: get(row, "Kegiatan"), MAKSUD__TUJUAN: get(row, "Maksud / Tujuan"),
                JENIS: ((v) => jenisOf(v) || "Remote")(get(row, "Lokal / Remote") || get(row, "Jenis Perjalanan")), ALAT_ANGKUTAN_YANG_DIGUNAKAN: get(row, "Alat Angkutan"), TEMPAT_BERANGKAT: get(row, "Tempat Berangkat"), TEMPAT_TUJUAN: get(row, "Tempat Tujuan"),
                TGL_PERGI: get(row, "Tgl Pergi"), TGL_PULANG: get(row, "Tgl Pulang"), MAK: get(row, "MAK") };
            const L = num(get(row, "Lama (hari)"));
            if (L)
                r.LAMA_JALAN = L;
            for (const [k, h] of [["KD_NAMA_SPD", "Pelaksana"], ["No_PPK", "PPK"], ["KD_NAMA_KA_PLT_PLH", "Kepala / Plt / Plh"], ["KDSPPD", "Kepala Lampiran SPPD"]]) {
                const c = byName(get(row, h));
                if (c)
                    r[k] = c;
            }
            setLamp(r, get(row, "Anggota Tim").split(";").map(x => x.trim()).filter(Boolean).map(byName).filter((c) => !!c));
            const ks = get(row, "Kampung Tujuan (SK)").split(";").map(x => x.trim()).filter(Boolean).map(findKampungCell).filter((c) => !!c);
            if (ks.length)
                r._kampung = ks;
            else if (r.TEMPAT_TUJUAN) {
                const d = detectKampung(r.TEMPAT_TUJUAN);
                if (d.found.length)
                    r._kampung = d.found.map(k => ({ k: kKey(k), pp: true }));
            }
            for (const k of Object.keys(r))
                if (r[k] === "")
                    delete r[k];
            recs.push(r);
        }
        return { recs, sheet: sn, unknown: [...unknown], mode: "st" };
    }
    return null;
}
const ST_KEYS = ["NoLengkap", "TGL_TERBIT_ST", "KD_NAMA_SPD", "kegiatan", "MAKSUD__TUJUAN", "JENIS", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT", "TEMPAT_TUJUAN", "TGL_PERGI", "TGL_PULANG", "LAMA_JALAN", "MAK", "No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "_kampung", "lampiran", "KodeLampiran1", "KodeLampiran2", "KodeLampiran3", "KodeLampiran4", "KodeLampiran5"];
/* ---------- RINCIAN BIAYA: satu sheet ---------- */
const rbHdr = (nT) => ["No", "Nomor Surat Tugas", "Untuk", "Jenis", "Lama Perjalanan", "Lama Uang Harian", "Tarif Uang Harian", "Lama Inap (tanpa hotel)", "Tarif Inap", "Hotel / Tempat", "Malam Hotel", "Tarif Hotel",
    ...Array.from({ length: nT }, (_, i) => [`Keterangan Transport ${i + 1}`, `Nilai Transport ${i + 1}`]).flat(), "Hotel lain (dengan bukti)", "Transport Lokal (riil)", "Mobil Bandara (riil)", "Jumlah", "Tanggal Kuitansi", "Bendahara"];
const lastTr = (r) => { let n = 0; for (let i = 1; i <= MAXTR; i++)
    if ((r["KetTransport_" + i] ?? "") !== "" || (r["Nilai" + i] ?? "") !== "")
        n = i; return n; };
function rbRow(r, untuk, F, nT) {
    return [r.NO, F.NOMOR_ST, untuk, r.JENIS || "Remote", num(r.LAMA_JALAN) || "", F._num.luh, F._num.nuh, F._num.inap, F._num.tdk, F.HOTEL_TEMPAT, F._num.lh || "", F._num.th || "",
        ...Array.from({ length: nT }, (_, i) => [r["KetTransport_" + (i + 1)] ?? "", r["Nilai" + (i + 1)] === "" || r["Nilai" + (i + 1)] == null ? "" : num(r["Nilai" + (i + 1)])]).flat(),
        Math.max(0, F._num.totHotel - F._num.lh0) || "", F._num.totLok || "", F._num.totBdr || "", F._num.jml, F.TGL_KUI, F.BEND];
}
function rbSheet(recs) {
    const P = pegMap(), items = [];
    for (const r of recs) {
        if (r._noBiaya)
            continue;
        const ps = personCodes(r, P), F = compute(r);
        items.push([r, ps.length > 1 ? `Semua anggota (${ps.length} orang)` : (F.NAMA_PELAKSANA_SPD || ""), F]);
        if (ps.length > 1)
            for (const c of ps) {
                const x = personRec(r, c);
                items.push([x, P[c]?.nama || c, compute(x)]);
            }
    }
    if (!items.length)
        return null;
    const nT = Math.max(TR_BASE, ...items.map(([x]) => lastTr(x)));
    const ws = XLSX.utils.aoa_to_sheet([rbHdr(nT), ...items.map(([x, u, F]) => rbRow(x, u, F, nT))]);
    ws["!cols"] = [6, 30, 32, 10, 8, 8, 12, 8, 12, 26, 8, 12, ...Array.from({ length: nT }, () => [46, 12]).flat(), 14, 14, 14, 14, 18, 28].map(w => ({ wch: w }));
    return ws;
}
$("#bAllExp").onclick = () => {
    if (!records.length)
        return toast("Belum ada surat tugas.");
    const recs = [...records].sort(byYearNo), wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportST(recs), "Surat Tugas");
    const rb = rbSheet(recs);
    if (rb)
        XLSX.utils.book_append_sheet(wb, rb, "Rincian Biaya");
    const nb = recs.filter(r => !r._noBiaya).length;
    XLSX.writeFile(wb, `Surat Tugas & Rincian Biaya (${recs.length} surat).xlsx`);
    toast(`${recs.length} surat tugas & rincian biaya ${nb} surat diekspor dalam satu file.`);
};
let pendingRB = null;
$("#fAllImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const buf = await f.arrayBuffer(), wbST = XLSX.read(buf, { cellDates: true }), wbRB = XLSX.read(buf, { type: "array" });
        const hasST = (parseSTSheet(wbST)?.recs.length || 0) > 0, hasRB = !!rbRowsOf(wbRB);
        if (!hasST && !hasRB)
            return toast("Tidak ditemukan sheet 'Surat Tugas' atau 'Rincian Biaya'. Pakai file hasil Ekspor.");
        if (hasST) {
            pendingRB = hasRB ? wbRB : null;
            importSTFile(f, wbST);
        }
        else
            importRBwb(wbRB, true);
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
});
function rbRowsOf(wb) {
    for (const sn of wb.SheetNames) {
        const a = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: true });
        const hi = a.findIndex(r => r.some(c => String(c).trim() === "Untuk") && r.some(c => String(c).trim() === "Tarif Uang Harian"));
        if (hi >= 0)
            return a.slice(hi);
    }
    return null;
}
function importRBwb(wb, ask = true, prefix = "") {
    try {
        let rows = rbRowsOf(wb);
        if (!rows)
            return toast("Tidak ditemukan sheet Rincian Biaya (kolom 'Untuk', 'Tarif Uang Harian', …). Pakai file hasil Ekspor rincian biaya.");
        const H = rows[0].map(c => String(c).trim()), ix = (n) => H.indexOf(n), val = (row, n) => { const i = ix(n); return i < 0 ? "" : row[i]; };
        const toRec = (row) => {
            const o = { LAMA_UH: num(val(row, "Lama Uang Harian")), NILAI_UH: num(val(row, "Tarif Uang Harian")), LAMA_INAP: num(val(row, "Lama Inap (tanpa hotel)")), TDK_INAP_HOTEL: num(val(row, "Tarif Inap")),
                HOTEL_TEMPAT: String(val(row, "Hotel / Tempat") || "").trim(), LAMA_HOTEL: num(val(row, "Malam Hotel")), TARIF_HOTEL: num(val(row, "Tarif Hotel")), trans: [] };
            for (let i = 1; i <= MAXTR; i++) {
                const k = String(val(row, `Keterangan Transport ${i}`) ?? "").trim(), v = val(row, `Nilai Transport ${i}`);
                o.trans.push([k, v === "" || v == null ? "" : num(v)]);
            }
            return o;
        };
        const groups = new Map();
        for (const row of rows.slice(1)) {
            const no = String(val(row, "No") ?? "").trim();
            if (!no)
                continue;
            const g = no + "|" + String(val(row, "Nomor Surat Tugas") ?? "").trim();
            const g0 = groups.get(g);
            if (g0)
                g0.push(row);
            else
                groups.set(g, [row]);
        }
        let nOk = 0;
        const missing = [];
        const plan = [];
        for (const [g, rs] of groups) {
            const [no, nomor] = [g.slice(0, g.indexOf("|")), g.slice(g.indexOf("|") + 1)];
            const rec = (nomor && records.find(r => compute(r).NOMOR_ST === nomor)) || records.find(r => noKey(r.NO) === noKey(no) && (!nomor || !/\/(\d{4})$/.test(nomor) || String(stYear(r)) === nomor.match(/\/(\d{4})$/)[1]));
            if (!rec) {
                missing.push(no);
                continue;
            }
            const baseRow = rs.find(r => /^semua anggota/i.test(String(val(r, "Untuk")))) || rs[0];
            plan.push({ rec, base: toRec(baseRow), baseRow, people: rs.filter(r => r !== baseRow).map(r => ({ code: resolvePeg(String(val(r, "Untuk"))), o: toRec(r) })).filter((x) => !!x.code) });
        }
        if (!plan.length)
            return toast(`Tidak ada nomor surat yang cocok${missing.length ? ` (mis. No. ${missing.slice(0, 3).join(", ")})` : ""}.`);
        if (ask && !confirm(`Perbarui rincian biaya ${plan.length} surat dari file?${missing.length ? `\n\n${missing.length} nomor tidak ditemukan dan dilewati.` : ""}`))
            return;
        for (const { rec, base, baseRow, people } of plan) {
            for (const k of ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL"])
                rec[k] = base[k];
            if (base.HOTEL_TEMPAT)
                rec.HOTEL_TEMPAT = base.HOTEL_TEMPAT;
            else
                delete rec.HOTEL_TEMPAT;
            for (let i = 1; i <= MAXTR; i++) {
                const [k, v] = base.trans[i - 1];
                if (k)
                    rec["KetTransport_" + i] = k;
                else
                    delete rec["KetTransport_" + i];
                if (v !== "")
                    rec["Nilai" + i] = v;
                else
                    delete rec["Nilai" + i];
            }
            const kui = String(val(baseRow, "Tanggal Kuitansi") || "").trim();
            if (kui)
                rec.TGL_KUI = kui;
            const bd = resolvePeg(String(val(baseRow, "Bendahara") || ""));
            if (bd)
                rec.No_Bend = bd;
            delete rec._noBiaya;
            delete rec.TOTAL_TRANS;
            const po = {};
            for (const { code, o } of people) {
                const d = {};
                for (const k of ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL"])
                    if (o[k] !== base[k])
                        d[k] = o[k];
                if (o.HOTEL_TEMPAT !== base.HOTEL_TEMPAT)
                    d.HOTEL_TEMPAT = o.HOTEL_TEMPAT;
                if (JSON.stringify(o.trans) !== JSON.stringify(base.trans))
                    d.trans = o.trans;
                if (Object.keys(d).length)
                    po[code] = d;
            }
            if (Object.keys(po).length)
                rec._perOrang = po;
            else
                delete rec._perOrang;
            nOk++;
        }
        persist();
        renderList();
        buildLists();
        toast(prefix + `Rincian biaya ${nOk} surat diperbarui${missing.length ? `, ${missing.length} nomor dilewati` : ""}.`);
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file rincian: " + err.message);
    }
}
/* baca sheet "Surtug …" (format mail merge / hasil ekspor aplikasi) → rekaman surat tugas.
   Kode pegawai dicocokkan ulang lewat NAMA bila kolom nama tersedia, supaya aman dipakai di perangkat lain. */
function parseSurtugWorkbook(wb) {
    const ds = (v) => v instanceof Date ? fmtDate(v) : v;
    const sn = wb.SheetNames.find(n => /surtug/i.test(n) && wb.Sheets[n]["A1"] && /^NO$/i.test(String(wb.Sheets[n]["A1"].v).trim()))
        || wb.SheetNames.find(n => { const a = wb.Sheets[n]["A1"], b = wb.Sheets[n]["B1"]; return a && /^NO$/i.test(String(a.v).trim()) && b && /NOSURTUG|NOMOR/i.test(String(b.v)); });
    if (!sn)
        return { recs: [], sheet: null };
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { defval: null });
    const IN = ["NO", "NoLengkap", "TGL_TERBIT_ST", "KD_NAMA_SPD", "kegiatan", "MAKSUD__TUJUAN", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT", "TEMPAT_TUJUAN", "LAMA_JALAN", "TGL_PERGI", "TGL_PULANG", "MAK", "No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_UH", "NILAI_UH", "TOTAL_TRANS", "TGL_KUI", "No)Bend", "HOTEL_TEMPAT", "LAMA_HOTEL", "TARIF_HOTEL", "KodeLampiran1", "KodeLampiran2", "KodeLampiran3", "KodeLampiran4", "KodeLampiran5", ...Array.from({ length: MAXTR }, (_, i) => [`KetTransport_${i + 1}`, `Nilai${i + 1}`]).flat()];
    const CODES = /^(KD_NAMA_SPD|No_PPK|KD_NAMA_KA_PLT_PLH|KDSPPD|No_Bend|KodeLampiran\d)$/;
    const NAMECOL = { KD_NAMA_SPD: "NAMA_PELAKSANA_SPD", No_PPK: "PPK", KD_NAMA_KA_PLT_PLH: "KAPLTPLH", KDSPPD: "KepalaSPPD", No_Bend: "BEND", KodeLampiran1: "NAMALAMPIRAN_1", KodeLampiran2: "NAMA_LAMPIRAN_2", KodeLampiran3: "NAMA_LAMPIRAN_3", KodeLampiran4: "NAMA_LAMPIRAN_4", KodeLampiran5: "NAMA_LAMPIRAN_5" };
    const P = pegMap(), unknown = new Set(), recs = [];
    const byName = (nm) => { const t = String(nm ?? "").trim(); if (!t || t === "0")
        return null; if (/^terlampir$/i.test(t))
        return P["999"] ? "999" : null; const c = resolvePeg(t); if (!c)
        unknown.add(t); return c; };
    for (const row of rows) {
        if (!row.MAKSUD__TUJUAN)
            continue;
        const r = {};
        for (const k of IN) {
            let v = ds(row[k]);
            if (v == null || v === "")
                continue;
            const key = k === "No)Bend" ? "No_Bend" : k;
            r[key] = CODES.test(key) ? String(v).trim() : (typeof v === "number" ? v : String(v));
        }
        for (const [k, nc] of Object.entries(NAMECOL)) {
            if (row[nc] == null || row[nc] === "")
                continue;
            const c = byName(row[nc]);
            if (c)
                r[k] = c;
        }
        r.NO = String(r.NO ?? "").trim();
        let extra = String(row.KodeLampiranLain ?? "").split(/[,;]/).map(x => x.trim()).filter(Boolean);
        const extraN = String(row.NamaLampiranLain ?? "").split(";").map(x => x.trim()).filter(Boolean);
        if (extraN.length)
            extra = extraN.map((n, i) => byName(n) || extra[i]).filter(Boolean);
        if (extra.length || r.KodeLampiran1)
            setLamp(r, [...[1, 2, 3, 4, 5].map(i => r["KodeLampiran" + i]).filter(Boolean), ...extra]);
        if (row.JENIS)
            r.JENIS = String(row.JENIS);
        if (/belum/i.test(String(row.RINCIAN ?? "")))
            r._noBiaya = true;
        if (row.PER_ORANG) {
            try {
                const po = {};
                for (const [nm, v] of Object.entries(JSON.parse(String(row.PER_ORANG)))) {
                    const c = byName(nm) || nm;
                    po[c] = v;
                }
                if (Object.keys(po).length)
                    r._perOrang = po;
            }
            catch (e) { }
        }
        if (row.KampungSK)
            r._kampung = String(row.KampungSK).split(";").map(x => x.trim()).filter(Boolean).map(x => ({ k: x.replace(/\|1\/2$/, ""), pp: !/\|1\/2$/.test(x) }));
        else if (r.TEMPAT_TUJUAN) {
            const d = detectKampung(String(r.TEMPAT_TUJUAN));
            if (d.found.length)
                r._kampung = d.found.map(k => ({ k: kKey(k), pp: true }));
        }
        if (r.NO)
            recs.push(r);
    }
    return { recs, sheet: sn, unknown: [...unknown] };
}
$("#fXls").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
        const ds = (v) => v instanceof Date ? fmtDate(v) : v;
        const aoa = (n) => XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: null, raw: true });
        const msg = [];
        let nR = 0, nU = 0;
        if (wb.Sheets.Pegawai) {
            const rows = aoa("Pegawai").slice(1);
            const np = rows.filter(r => r[0] != null && r[1] != null).map(r => ({ kode: String(r[0]).trim(), nama: String(r[1]).trim(), nip: String(r[2] ?? "").trim(), pangkat: String(r[4] ?? "").trim(), gol: String(r[5] ?? "").trim(), jabatan: String(r[6] ?? "").trim() }));
            if (np.length) {
                pegawai = np;
                msg.push(`${np.length} pegawai`);
            }
        }
        const tsn = wb.SheetNames.filter(n => /^SK\s*TRANS/i.test(n)).sort().pop();
        if (tsn) {
            const { kam, tar } = parseTransSheet(aoa(tsn));
            if (kam.length) {
                kampungDB = kam;
                msg.push(`${kam.length} kampung`);
            }
            if (tar.length)
                tarifDB = tar;
        }
        const ksn = wb.SheetNames.find(n => /KODE\s*ARSIP/i.test(n));
        if (ksn) {
            const kd = parseKodeSheet(aoa(ksn));
            if (kd.codes.length) {
                kodeDB = kd;
                msg.push(`${kd.codes.length} kode klasifikasi`);
            }
        }
        const got = parseSurtugWorkbook(wb);
        for (const r of got.recs) {
            const i = records.findIndex(x => recKey(x) === recKey(r));
            if (i >= 0) {
                r._id = records[i]._id;
                records[i] = r;
                nU++;
            }
            else {
                records.push(r);
                nR++;
            }
        }
        if (nR || nU)
            msg.push(`${nR} surat baru, ${nU} diperbarui`);
        persist();
        renderAll();
        toast(msg.length ? "Impor selesai: " + msg.join(", ") + "." : "Tidak ada sheet yang dikenali di file ini.");
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca Excel: " + err.message);
    }
    tg(e).value = "";
});
$("#bBackup").onclick = () => download(new Blob([JSON.stringify({ pegawai, records, kampung: kampungDB, tarif: tarifDB, kode: kodeDB, pok: pokDB, pokY: Object.fromEntries(pokYears().map(y => [y, pokGet(y)])), pokYear, honor: honorDB, rekening: rekMap, surat: suratDB, suratFmt: nsFmt, ang: (() => { persistAng(); const o = {}; for (const y of angYearsOpt()) {
            const v = Object.fromEntries(ANG_N.map(n => [n, LS.get(angK(n, y), null)]).filter(x => x[1] != null));
            if (Object.keys(v).length)
                o[y] = v;
        } return o; })(), angYear }, null, 1)], { type: "application/json" }), "cadangan-surat-tugas.json");
$("#fJson").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    if (!f)
        return;
    try {
        const d = JSON.parse(await f.text());
        if (!Array.isArray(d.records) || !Array.isArray(d.pegawai))
            throw new Error("format tidak dikenali");
        pegawai = d.pegawai;
        records = d.records;
        if (Array.isArray(d.kampung))
            kampungDB = d.kampung;
        if (Array.isArray(d.tarif))
            tarifDB = d.tarif;
        if (d.kode && Array.isArray(d.kode.codes))
            kodeDB = d.kode;
        if (d.pokY && typeof d.pokY === "object") {
            for (const [y, v] of Object.entries(d.pokY))
                if (v && Array.isArray(v.akun))
                    pokSave(y, v);
            if (d.pokYear && pokGet(String(d.pokYear)))
                pokYear = String(d.pokYear);
            pokDB = pokGet(pokYear) || pokDB;
            LS.set("st.pokYear", pokYear);
        }
        else if (d.pok && Array.isArray(d.pok.akun)) {
            pokYear = String(d.pok.meta?.tahun || pokYear);
            pokDB = d.pok;
            pokSave(pokYear, pokDB);
            LS.set("st.pokYear", pokYear);
        }
        if (Array.isArray(d.honor)) {
            honorDB = d.honor;
            if (d.rekening)
                rekMap = d.rekening;
            persistHonor();
        }
        if (d.ang && typeof d.ang === "object") {
            for (const [y, v] of Object.entries(d.ang))
                for (const n of ANG_N)
                    if (v[n] != null)
                        LS.set(angK(n, y), v[n]);
            angLoad(angYear);
        }
        else {
            if (d.rpd)
                rpdDB = d.rpd;
            if (d.rpdKet)
                rpdKet = d.rpdKet;
            if (d.tup)
                tupDB = d.tup;
            if (d.up)
                upDB = d.up;
            if (Array.isArray(d.revisi))
                revDB = d.revisi;
            persistAng();
        }
        if (Array.isArray(d.surat)) {
            suratDB = d.surat;
            if (d.suratFmt)
                nsFmt = { ...NS_FMT0, ...d.suratFmt };
            persistSurat();
        }
        persist();
        renderAll();
        newForm();
        toast("Cadangan dipulihkan.");
    }
    catch (err) {
        toast("Gagal memulihkan: " + err.message);
    }
    tg(e).value = "";
});
async function importTemplate(f, kind) {
    const buf = await f.arrayBuffer(), b = new Uint8Array(buf);
    let s = "";
    for (let i = 0; i < b.length; i += 0x8000)
        s += String.fromCharCode(...b.subarray(i, i + 0x8000));
    let xml = "";
    try {
        xml = await (await JSZip.loadAsync(buf)).file("word/document.xml").async("string");
    }
    catch (e) {
        return toast("File bukan dokumen Word (.docx) yang valid.");
    }
    const hasST = /MERGEFIELD\s+"?(NOMOR_ST|MAKSUD__TUJUAN)\b/.test(xml), hasRB = /MERGEFIELD\s+"?KetTransport_1\b/.test(xml);
    if (kind === "rb" && !hasRB && !confirm("File ini tidak berisi kolom «KetTransport_1» — sepertinya bukan template Rincian Biaya. Tetap pakai?"))
        return;
    if (kind === "st" && !hasST && !confirm("File ini tidak berisi kolom «NOMOR_ST» — sepertinya bukan template Surat Tugas. Tetap pakai?"))
        return;
    const t = { name: f.name, b64: btoa(s), kind };
    if (kind === "rb") {
        templateRB = t;
        if (!LS.set("st.templateRB", t))
            toast("Template dipakai sementara (terlalu besar untuk disimpan permanen).");
    }
    else {
        if (template && !template.kind && !templateRB) {
            templateRB = { ...template, kind: "rb" };
            LS.set("st.templateRB", templateRB);
        } // template lama tetap dipakai untuk rincian
        template = t;
        if (!LS.set("st.template", t))
            toast("Template dipakai sementara (terlalu besar untuk disimpan permanen).");
    }
    tplInfo();
    toast(`Template ${kind === "rb" ? "Rincian Biaya" : "Surat Tugas"} diganti: ${f.name}`);
}
$("#fTpl").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f)
    importTemplate(f, "st").catch((err) => toast("Gagal impor template: " + err.message)); });
$("#fTplRB").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f)
    importTemplate(f, "rb").catch((err) => toast("Gagal impor template: " + err.message)); });
async function exportTemplate(kind = "st") {
    const zip = await JSZip.loadAsync(tplB64(kind), { base64: true });
    for (const p of Object.keys(zip.files)) {
        if (!/^word\/(document|header\d*|footer\d*)\.xml$/.test(p))
            continue;
        const x = await zip.file(p).async("string");
        if (!x.includes("MERGEFIELD") && p !== "word/document.xml")
            continue;
        const doc = new DOMParser().parseFromString(x, "application/xml");
        if (p === "word/document.xml")
            keepParts(doc, new Set(kind === "rb" ? FILE_BIAYA : FILE_ST));
        const stack = [];
        for (const r of [...doc.getElementsByTagNameNS(WNS, "r")]) {
            for (const fr of stack)
                if (fr.runs[fr.runs.length - 1] !== r)
                    fr.runs.push(r);
            for (const ch of [...r.childNodes]) {
                if (!isEl(ch) || ch.namespaceURI !== WNS)
                    continue;
                if (ch.localName === "fldChar") {
                    const ty = ch.getAttributeNS(WNS, "fldCharType");
                    if (ty === "begin")
                        stack.push({ instr: "", phase: "i", res: [], begin: r, runs: [r] });
                    else if (ty === "separate" && stack.length)
                        stack[stack.length - 1].phase = "r";
                    else if (ty === "end" && stack.length) {
                        const f = stack.pop(), m = f.instr.match(/MERGEFIELD\s+"?([^\s"\\]+)/);
                        if (!m)
                            continue;
                        if (!f.res.length) { // field tanpa hasil di template → tambahkan hasil «NAMA» sebelum akhir field
                            const mk = (fld) => {
                                const nr = doc.createElementNS(WNS, "w:r"), rp0 = kids(f.begin, "rPr")[0];
                                if (rp0)
                                    nr.appendChild(rp0.cloneNode(true));
                                if (fld) {
                                    const fc = doc.createElementNS(WNS, "w:fldChar");
                                    fc.setAttributeNS(WNS, "w:fldCharType", fld);
                                    nr.appendChild(fc);
                                }
                                return nr;
                            };
                            if (f.phase !== "r")
                                r.parentNode.insertBefore(mk("separate"), r);
                            const nr = mk(null), t = doc.createElementNS(WNS, "w:t");
                            t.setAttribute("xml:space", "preserve");
                            nr.appendChild(t);
                            r.parentNode.insertBefore(nr, r);
                            f.res.push(t);
                        }
                        // tampilkan «NAMA_KOLOM» + sorot kuning di hasil field
                        f.res.forEach((t, i) => { t.textContent = i ? "" : "«" + m[1] + "»"; });
                        for (const rr of new Set([...f.runs, ...f.res.map(t => t.parentNode).filter(isEl)])) {
                            let rp = kids(rr, "rPr")[0];
                            if (!rp) {
                                rp = doc.createElementNS(WNS, "w:rPr");
                                rr.insertBefore(rp, rr.firstChild);
                            }
                            for (const h of kids(rp, "highlight"))
                                rp.removeChild(h);
                            const h = doc.createElementNS(WNS, "w:highlight");
                            h.setAttributeNS(WNS, "w:val", "yellow");
                            // urutan elemen rPr wajib sesuai skema OOXML: highlight sebelum u/effect/bdr/shd/…/lang
                            const AFTER = ["u", "effect", "bdr", "shd", "fitText", "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath", "rPrChange"];
                            const before = [...rp.childNodes].find(n => isEl(n) && n.namespaceURI === WNS && AFTER.includes(n.localName));
                            rp.insertBefore(h, before || null);
                        }
                    }
                }
                else if (ch.localName === "instrText" && stack.length && stack[stack.length - 1].phase === "i")
                    stack[stack.length - 1].instr += ch.textContent;
                else if (ch.localName === "t" && stack.length && stack[stack.length - 1].phase === "r")
                    stack[stack.length - 1].res.push(ch);
            }
        }
        zip.file(p, xmlOut(doc));
    }
    const blob = await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
    download(blob, kind === "rb" ? "Template Rincian Biaya.docx" : "Template Surat Tugas.docx");
    toast(`Template ${kind === "rb" ? "Rincian Biaya" : "Surat Tugas"} diekspor — bagian kuning «…» adalah kolom data otomatis.`);
}
$("#bTplExp").onclick = () => exportTemplate("st").catch((e) => toast("Gagal ekspor template: " + e.message));
$("#bTplExpRB").onclick = () => exportTemplate("rb").catch((e) => toast("Gagal ekspor template: " + e.message));
/* ---------- tarif bawaan (Pengaturan) ---------- */
/** [nama tarif, label, petunjuk, grup?, cocokkan awalan?] */
const DEF_TARIF_FIELDS = [
    ["UHAR PERJADIN", "Uang harian per hari", "Remote & Translok+Uhar; Lokal & Pelatihan tetap 0", "UHAR 2026"],
    ["INAP PERJADIN", "Uang inap per malam (tanpa hotel)", "pengeluaran riil tidak menginap di hotel", "INAP 2026"],
    ["LINTASAN ANTAR KAMPUNG", "Biaya lintasan antar kampung", "Remote biasa: kampung ke-2 dst.", RULES_GRUP, true],
    ["LINTASAN MOBIL (TRANSPORT JAUH)", "Biaya lintasan mobil", "transport mobil: nilai otomatis sekaligus batas minimal Biaya Lintasan Mobil", RULES_GRUP, true],
    ["INAP MOBIL PER MALAM", "Biaya inap mobil per malam", "transport mobil: (lama perjalanan − 1) malam", RULES_GRUP, true],
    ["BATAS TRANSPORT JAUH (LEBIH DARI)", "Batas tarif SK transport mobil", "tarif SK di atas nilai ini → Transport Mobil (tidak dibagi dua) + Inap Mobil", RULES_GRUP, true],
    ["__UP", "Total UP setahun (T.A. aktif)", "nominal baku Uang Persediaan setahun — batas Catat UP tiap bulan"],
    ["__PTKP", "Batas honor PTKP (mitra)", "honor mitra (bruto) di atas nilai ini → PPh 21 otomatis 5%"],
    ["__PEL", "Transport pelatihan per orang", "isi awal tab Transport Pelatihan (kosong = ikut rincian transport)"]
];
const tarifRow = (n, g, pre) => tarifDB.find(t => (pre ? t.nama.startsWith(n) : t.nama.toUpperCase() === n) && (!g || t.grup === g)) || tarifDB.find(t => pre ? t.nama.startsWith(n) : t.nama.toUpperCase() === n);
function renderDefTarif() {
    $("#defTarif").innerHTML = DEF_TARIF_FIELDS.map(([n, lbl, hint, g, pre]) => {
        const v = n === "__PEL" ? LS.get("st.pelTrDef", "") : n === "__UP" ? (upTotal() || "") : n === "__PTKP" ? ptkpBatas() : num(tarifRow(n, g, pre)?.nilai);
        return `<div class="c4"><label>${esc(n === "__UP" ? lbl.replace("T.A. aktif", "T.A. " + angYear) : lbl)} (Rp)</label><input type="number" min="0" step="1000" data-dt="${esc(n)}" value="${v === "" ? "" : v}" style="text-align:right"><div class="hint">${esc(hint)}</div></div>`;
    }).join("");
}
$("#bDefTarif").onclick = () => {
    let n = 0;
    for (const e of $$("#defTarif [data-dt]")) {
        const k = e.dataset.dt ?? "", f = DEF_TARIF_FIELDS.find(x => x[0] === k);
        if (!f)
            continue;
        if (k === "__UP") {
            const all = upTotalAll();
            if (e.value === "")
                delete all[angYear];
            else
                all[angYear] = num(e.value);
            LS.set("st.upTotal", all);
            n++;
            continue;
        }
        if (k === "__PTKP") {
            LS.set("st.ptkp", e.value === "" ? 4500000 : num(e.value));
            n++;
            continue;
        }
        if (k === "__PEL") {
            LS.set("st.pelTrDef", e.value === "" ? "" : num(e.value));
            $("#pelAll").value = e.value;
            n++;
            continue;
        }
        if (e.value === "")
            continue;
        let t = tarifRow(k, f[3], f[4]);
        if (!t) {
            t = { grup: f[3] || "", nama: k, nilai: 0 };
            tarifDB.push(t);
        }
        const v = num(e.value);
        if (num(t.nilai) !== v) {
            t.nilai = v;
            n++;
        }
    }
    persist();
    renderTarif();
    buildLists();
    if (!editingId)
        newForm();
    renderDefTarif();
    toast(`Tarif bawaan disimpan — berlaku untuk surat tugas baru.`);
};
/* ---------- ekspor & impor tarif ---------- */
$("#bTarExp").onclick = () => {
    const wb = XLSX.utils.book_new();
    const ws1 = XLSX.utils.aoa_to_sheet([["Distrik", "Kampung", "Transport Kabupaten-Kampung (PP) 2026", "Keterangan"], ...kampungDB.map(k => [k.distrik, k.kampung, k.tarif, kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? [k.ket, "Lokal"].filter(Boolean).join(" · ") : !kamLokal(k) && /lokal/i.test(k.ket ?? "") ? String(k.ket).replace(/\s*·?\s*lokal/ig, "").trim() : k.ket])]);
    ws1["!cols"] = [{ wch: 24 }, { wch: 24 }, { wch: 22 }, { wch: 14 }];
    const ws2 = XLSX.utils.aoa_to_sheet([["Grup", "Uraian", "Nilai"], ...tarifDB.map(t => [t.grup, t.nama, t.nilai])]);
    ws2["!cols"] = [{ wch: 26 }, { wch: 36 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, ws1, "SK TRANS 2026");
    XLSX.utils.book_append_sheet(wb, ws2, "Tarif lain");
    XLSX.writeFile(wb, `Tarif Transport (${kampungDB.length} kampung).xlsx`);
    toast(`${kampungDB.length} kampung & ${tarifDB.length} tarif lain diekspor.`);
};
$("#fTarImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
        const aoa = (n) => XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: null, raw: true });
        const tsn = wb.SheetNames.filter(n => /^SK\s*TRANS/i.test(n)).sort().pop();
        let kam = [], tar = [];
        if (tsn) {
            const got = parseTransSheet(aoa(tsn));
            kam = got.kam.filter(k => k.kampung);
            tar = got.tar;
        }
        const lsn = wb.SheetNames.find(n => /tarif\s*lain/i.test(n));
        if (lsn) {
            const rows = aoa(lsn), H = (rows[0] || []).map(x => String(x ?? "").trim().toUpperCase());
            const cg = H.findIndex(h => /^GRUP/.test(h)), cu = H.findIndex(h => /^URAIAN|^NAMA/.test(h)), cn = H.findIndex(h => /^NILAI|^TARIF/.test(h));
            const list = rows.slice(1).filter(r => r[cu] != null && String(r[cu]).trim()).map(r => ({ grup: String(r[cg] ?? "").trim().toUpperCase() || "LAINNYA", nama: String(r[cu]).trim().toUpperCase(), nilai: num(r[cn]) }));
            if (list.length)
                tar = list;
        }
        if (!kam.length && !tar.length)
            return toast("Tidak ditemukan sheet 'SK TRANS …' atau 'Tarif lain' di file ini.");
        const msg = [kam.length ? `${kam.length} kampung (sekarang ${kampungDB.length})` : "", tar.length ? `${tar.length} tarif lain (sekarang ${tarifDB.length})` : ""].filter(Boolean).join(" dan ");
        if (!confirm(`Ganti data tarif dengan isi file?\n\n${msg}\n\nSurat yang sudah tersimpan tidak berubah sampai dibuka & disesuaikan lagi.`))
            return;
        if (kam.length)
            kampungDB = kam;
        if (tar.length) {
            tarifDB = tar;
            for (const [n, v] of RULE_DEFAULTS)
                if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n))
                    tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v });
        }
        persist();
        renderKam();
        renderTarif();
        buildLists();
        renderChips();
        $("#tarInfo").textContent = `Diimpor dari ${f.name}`;
        toast("Tarif diperbarui: " + msg.replace(/ \(sekarang \d+\)/g, ""));
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file tarif: " + err.message);
    }
});
$("#bTplReset").onclick = () => {
    if (template && !template.kind && !templateRB) {
        templateRB = { ...template, kind: "rb" };
        LS.set("st.templateRB", templateRB);
    }
    template = null;
    LS.del("st.template");
    tplInfo();
    toast("Template Surat Tugas kembali ke bawaan.");
};
$("#bTplResetRB").onclick = () => {
    templateRB = null;
    LS.del("st.templateRB");
    if (template && !template.kind) {
        template = { ...template, kind: "st" };
        LS.set("st.template", template);
    }
    tplInfo();
    toast("Template Rincian Biaya kembali ke bawaan.");
};
const tplInfo = () => {
    $("#tplInfo").textContent = "Aktif: " + (template ? template.name : "bawaan (SURAT_TUGAS_2026.docx)");
    $("#tplInfoRB").textContent = "Aktif: " + (templateRB ? templateRB.name : template && !template.kind ? template.name : "bawaan (rincian_biaya.docx)");
};
$("#bReset").onclick = () => {
    if (!confirm("Semua perubahan yang tersimpan di server akan hilang dan data kembali seperti bawaan. Lanjutkan?"))
        return;
    pegawai = clone(SEED.pegawai);
    records = clone(SEED.records);
    kampungDB = clone(SEED.kampung);
    tarifDB = clone(SEED.tarif);
    kodeDB = clone(SEED.kode);
    pokDB = clone(SEED.pok);
    for (const y of pokYears())
        pokDrop(y);
    for (const [y, v] of Object.entries(SEED.pokY || {}))
        pokSave(y, clone(v));
    pokYear = String(pokDB.meta?.tahun || new Date().getFullYear());
    pokSave(pokYear, pokDB);
    LS.set("st.pokYear", pokYear);
    for (const [n, v] of RULE_DEFAULTS)
        if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n))
            tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v });
    persist();
    renderAll();
    newForm();
    toast("Data dikembalikan.");
};
/* ================= PENULIS .XLSX BERGAYA (daftar bayar pelatihan & honor) ================= */
const XS = { n: 0, title: 1, b: 2, wrap: 3, th: 4, td: 5, tdl: 6, num: 7, numb: 8, tdb: 9, c: 10, nameU: 11, numP: 12, thn: 13, bl: 14, it: 15, tdlb: 16 };
function xlsxStylesXml() {
    const fonts = ['<font><sz val="10"/><name val="Arial"/></font>', '<font><b/><sz val="10"/><name val="Arial"/></font>', '<font><b/><sz val="12"/><name val="Arial"/></font>',
        '<font><b/><u/><sz val="10"/><name val="Arial"/></font>', '<font><i/><sz val="9"/><name val="Arial"/></font>', '<font><i/><sz val="10"/><name val="Arial"/></font>'];
    const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>', '<fill><patternFill patternType="solid"><fgColor rgb="FFEDEFF3"/><bgColor indexed="64"/></patternFill></fill>'];
    const bd = '<left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/>';
    const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>', `<border>${bd}</border>`];
    const al = (h, v = "center", w = 1) => `<alignment horizontal="${h}" vertical="${v}"${w ? ' wrapText="1"' : ""}/>`;
    const x = (font, fill, border, fmt, align) => `<xf numFmtId="${fmt}" fontId="${font}" fillId="${fill}" borderId="${border}" xfId="0"${font ? ' applyFont="1"' : ""}${fill ? ' applyFill="1"' : ""}${border ? ' applyBorder="1"' : ""}${fmt ? ' applyNumberFormat="1"' : ""}${align ? ' applyAlignment="1">' + align + "</xf>" : "/>"}`;
    const xfs = [x(0, 0, 0, 0, ""), x(2, 0, 0, 0, al("center")), x(1, 0, 0, 0, al("left", "top", 0)), x(0, 0, 0, 0, al("left", "top")),
        x(1, 2, 1, 0, al("center")), x(0, 0, 1, 0, al("center")), x(0, 0, 1, 0, al("left")), x(0, 0, 1, 164, al("right", "center", 0)), x(1, 0, 1, 164, al("right", "center", 0)),
        x(1, 0, 1, 0, al("center")), x(0, 0, 0, 0, al("center")), x(3, 0, 0, 0, al("center", "bottom", 0)), x(0, 0, 0, 164, al("right", "center", 0)), x(4, 2, 1, 0, al("center")),
        x(1, 0, 0, 0, al("center", "top")), x(5, 0, 0, 0, al("left", "top")), x(1, 0, 1, 0, al("left"))];
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0;-#,##0;&quot;-&quot;"/></numFmts><fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="${borders.length}">${borders.join("")}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
}
const xCol = (n) => { let s = ""; n++; while (n) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
} return s; };
const xEsc = (t) => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function xSheet(name, widths, opt = {}) {
    const rows = new Map(), merges = [], heights = {};
    const sh = {
        name, widths, opt, rows, merges, heights,
        set(r, c, v, st = 0, f = null) { let row = rows.get(r); if (!row) {
            row = new Map();
            rows.set(r, row);
        } row.set(c, { v, st, f }); return sh; },
        merge(r1, c1, r2, c2, st) { merges.push(`${xCol(c1 - 1)}${r1}:${xCol(c2 - 1)}${r2}`); if (st != null)
            for (let r = r1; r <= r2; r++)
                for (let c = c1; c <= c2; c++) {
                    const cur = rows.get(r)?.get(c);
                    if (!cur)
                        sh.set(r, c, "", st);
                    else if (cur.st === 0)
                        cur.st = st;
                } return sh; },
        h(r, ht) { heights[r] = ht; return sh; },
        xml() {
            const out = [...rows.keys()].sort((a, b) => a - b).map(r => {
                const cells = [...rows.get(r).entries()].sort((a, b) => a[0] - b[0]).map(([c, { v, st, f }]) => {
                    const ref = xCol(c - 1) + r;
                    if (f)
                        return `<c r="${ref}" s="${st}"><f>${xEsc(f)}</f>${typeof v === "number" ? `<v>${v}</v>` : ""}</c>`;
                    if (typeof v === "number" && isFinite(v))
                        return `<c r="${ref}" s="${st}"><v>${v}</v></c>`;
                    if (v === "" || v == null)
                        return `<c r="${ref}" s="${st}"/>`;
                    return `<c r="${ref}" s="${st}" t="inlineStr"><is><t xml:space="preserve">${xEsc(v)}</t></is></c>`;
                }).join("");
                return `<row r="${r}"${heights[r] ? ` ht="${heights[r]}" customHeight="1"` : ""}>${cells}</row>`;
            }).join("");
            const cols = widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("");
            return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>${cols}</cols><sheetData>${out}</sheetData>${merges.length ? `<mergeCells count="${merges.length}">${merges.map(m => `<mergeCell ref="${m}"/>`).join("")}</mergeCells>` : ""}<pageMargins left="0.4" right="0.3" top="0.5" bottom="0.5" header="0.3" footer="0.3"/><pageSetup paperSize="${opt.paper || 9}" orientation="${opt.portrait ? "portrait" : "landscape"}" fitToWidth="1" fitToHeight="0"/></worksheet>`;
        }
    };
    return sh;
}
async function xlsxSave(sheets, fname) {
    const z = new JSZip(), safe = (n) => String(n).replace(/[\\/?*[\]:]/g, " ").slice(0, 31) || "Sheet";
    const names = [];
    for (const sh of sheets) {
        let n = safe(sh.name), k = 2;
        while (names.includes(n))
            n = safe(sh.name).slice(0, 28) + " " + k++;
        names.push(n);
    }
    z.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`);
    z.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
    z.file("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${names.map((n, i) => `<sheet name="${xEsc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
    z.file("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    z.file("xl/styles.xml", xlsxStylesXml());
    sheets.forEach((sh, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, sh.xml()));
    download(await z.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", compression: "DEFLATE" }), fname);
}
/* baris "Program … Akun" dari POK */
const KRO_NAMA = { BMA: "Data dan Informasi Publik", BMB: "Data dan Informasi Publik", EBA: "Layanan Dukungan Manajemen Internal", EBB: "Layanan Sarana dan Prasarana Internal", EBC: "Layanan Manajemen SDM Internal", EBD: "Layanan Manajemen Kinerja Internal", BDB: "Fasilitasi dan Pembinaan Lembaga", QDB: "Fasilitasi dan Pembinaan Lembaga" };
function makLines(mak) {
    const k = normMak(mak), a = pokMap()[k], p = k.split(".");
    if (!a)
        return [["Akun", String(mak || "-")]];
    const kro = p[1] || "", prog = a.keg === "2886" ? "(054.01.WA) Program Dukungan Manajemen" : "(054.01.GG) Penyediaan dan Pelayanan Informasi Statistik";
    return [["Program", prog], ["Aktivitas", `(${a.keg}) ${a.kegNama}`], ["KRO", `(${a.keg}.${kro}) ${KRO_NAMA[kro] || ""}`.trim()], ["RO", `(${a.ro}) ${a.roNama}`],
        ["Komponen", `(${a.komp}) ${a.kompNama}`], ["Sub-Komponen", `(${a.sub}) ${a.sub === "A" ? "Tanpa Sub Komponen" : ""}`.trim()], ["Akun/Detil", `(${a.akun}) ${a.nama}`]];
}
const capFirst = (t) => String(t || "").trim().replace(/\s+/g, " ").replace(/^./, c => c.toUpperCase());
const tglLong = (a, b) => {
    const A = parseTgl(a), B = parseTgl(b);
    if (!A)
        return String(a || "");
    if (!B || +A === +B)
        return fmtDate(A);
    if (A.getFullYear() === B.getFullYear() && A.getMonth() === B.getMonth())
        return `${A.getDate()}-${fmtDate(B)}`;
    if (A.getFullYear() === B.getFullYear())
        return `${A.getDate()} ${BULAN[A.getMonth()]} - ${fmtDate(B)}`;
    return `${fmtDate(A)} - ${fmtDate(B)}`;
};
const nipText = (p) => p && p.nip && !/^-|terlampir/i.test(p.nip) && /\d{8}/.test(String(p.nip).replace(/\s/g, "")) ? "NIP. " + p.nip : "";
function pelatihanRows(r) {
    const P = pegMap(), tm = teamOf(r, P), L = num(r.LAMA_JALAN) || 1;
    const ex = new Set(r._pelExcl || []), U = r._pelUH || {};
    return [...tm.peg, ...tm.mit].filter(c => !ex.has(c)).map(c => {
        const p = P[c] || { kode: c, nama: "" }, x = personRec(r, c), n = compute(x)._num, mit = isMitra(p);
        return { c, nama: p.nama || c, gol: mit || !p.gol || p.gol === "-" ? "" : p.gol, nip: mit ? "-" : (p.nip || "-"), jab: mit ? "Mitra" : (p.jabatan || ""), lama: L, full: num(U[c]?.full), board: num(U[c]?.board), tr: n.totTr || 0 };
    });
}
function pelatihanHtml(r) {
    const F = compute(r), P = pegMap(), rows = pelatihanRows(r), bend = P[codeOf(r.No_Bend)], ppk = P[codeOf(r.No_PPK)];
    const info = [...makLines(r.MAK), ["Nomor Surat Tugas, Tanggal", `${F.NOMOR_ST} ${F.TGL_TERBIT_ST}`], ["Tanggal Pelaksanaan", tglLong(r.TGL_PERGI, r.TGL_PULANG)]];
    const sum = (k) => rows.reduce((a, x) => a + x[k], 0), tot = sum("full") + sum("board") + sum("tr"), asal = $("#pelAsal")?.value.trim() || "BPS Kab. Maybrat", d = (v) => v ? rupiah(v) : "-";
    return `<div class="hp-title">BIAYA PERJALANAN DINAS DALAM RANGKA<br>${esc(String(F.MAKSUD__TUJUAN || F.kegiatan || "").toUpperCase())}</div>
    <table class="hp-info">${info.map(([k, v]) => `<tr><td style="width:170px">${esc(k)}</td><td>: ${esc(v || "")}</td></tr>`).join("")}</table>
    <table class="hp-tbl"><thead><tr><th rowspan="3">No</th><th rowspan="3">Nama Pelaksana Perjalanan Dinas</th><th rowspan="3">Gol</th><th rowspan="3">NIP</th><th rowspan="3">Jabatan</th><th rowspan="3">Asal Penugasan</th><th colspan="2" rowspan="2">Lama Tugas (O-H)</th><th colspan="2">Biaya</th><th rowspan="3">Pengeluaran Riil Transport Lokal</th><th rowspan="3">Jumlah Biaya (Rp) ∑ = 9 s.d 11</th><th rowspan="3" colspan="2">Tanda Tangan Penerima</th></tr>
      <tr><th rowspan="2">Uang Harian Fullday</th><th rowspan="2">Uang Harian Fullboard</th></tr><tr><th>hari</th><th>huruf</th></tr>
      <tr class="n">${Array.from({ length: 12 }, (_, i) => `<td>(${i + 1})</td>`).join("")}<td colspan="2">(13)</td></tr></thead>
      <tbody>${rows.map((x, i) => `<tr><td class="c">${i + 1}</td><td>${esc(x.nama)}</td><td class="c">${esc(x.gol || "")}</td><td class="c">${esc(x.nip)}</td><td class="c">${esc(x.jab)}</td><td class="c">${esc(asal)}</td><td class="c">${x.lama}</td><td class="c">(${esc(capFirst(terbilang(x.lama)))})</td><td class="r">${d(x.full)}</td><td class="r">${d(x.board)}</td><td class="r">${d(x.tr)}</td><td class="r">${rupiah(x.full + x.board + x.tr)}</td><td>${i % 2 ? "" : (i + 1) + ". ……"}</td><td>${i % 2 ? (i + 1) + ". ……" : ""}</td></tr>`).join("")}
      <tr class="tot"><td colspan="8" class="c">Jumlah</td><td class="r">${d(sum("full"))}</td><td class="r">${d(sum("board"))}</td><td class="r">${d(sum("tr"))}</td><td class="r">${rupiah(tot)}</td><td colspan="2"></td></tr></tbody></table>
    <p class="hp-terb"><i>Terbilang : ${esc(capFirst(terbilang(tot)))} Rupiah</i></p>
    <div class="hp-sign" style="grid-template-columns:1fr 1fr"><div>Lunas Pada Tanggal : ${esc(pelLunas(r))}<br>Bendahara Pengeluaran<br>BPS Kabupaten Maybrat<br><br><br><br><b>${esc(bend?.nama || "")}</b><br>${esc(nipText(bend))}</div>
      <div>Setuju dibayar<br>Pejabat Pembuat Komitmen<br>BPS Kabupaten Maybrat<br><br><br><br><b>${esc(ppk?.nama || "")}</b><br>${esc(nipText(ppk))}</div></div>`;
}
async function downloadPelatihan(r) {
    const F = compute(r), P = pegMap(), rows = pelatihanRows(r);
    if (!rows.length)
        return toast("Belum ada pelaksana / anggota di surat ini.");
    const sh = xSheet("Daftar Transport", [5, 27, 8, 21, 15, 13, 6, 10, 12, 12, 13, 14, 12, 12]);
    sh.set(1, 1, "BIAYA PERJALANAN DINAS DALAM RANGKA\n" + String(F.MAKSUD__TUJUAN || F.kegiatan || "").toUpperCase(), XS.title).merge(1, 1, 1, 14).h(1, 36);
    let y = 3;
    const info = [...makLines(r.MAK), ["Nomor Surat Tugas, Tanggal", `${F.NOMOR_ST} ${F.TGL_TERBIT_ST}`], ["Tanggal Pelaksanaan", tglLong(r.TGL_PERGI, r.TGL_PULANG)]];
    for (const [k, v] of info) {
        sh.set(y, 2, k, XS.wrap).set(y, 3, ":", XS.wrap).set(y, 4, v, XS.wrap).merge(y, 4, y, 14);
        if (String(v).length > 95)
            sh.h(y, 27);
        y++;
    }
    y++;
    const h0 = y;
    sh.set(y, 1, "No", XS.th).merge(y, 1, y + 2, 1, XS.th);
    sh.set(y, 2, "Nama Pelaksana Perjalanan Dinas", XS.th).merge(y, 2, y + 2, 2, XS.th);
    sh.set(y, 3, "Gol", XS.th).merge(y, 3, y + 2, 3, XS.th);
    sh.set(y, 4, "NIP", XS.th).merge(y, 4, y + 2, 4, XS.th);
    sh.set(y, 5, "Jabatan", XS.th).merge(y, 5, y + 2, 5, XS.th);
    sh.set(y, 6, "Asal Penugasan", XS.th).merge(y, 6, y + 2, 6, XS.th);
    sh.set(y, 7, "Lama Tugas (O-H)", XS.th).merge(y, 7, y + 1, 8, XS.th);
    sh.set(y + 2, 7, "hari", XS.th).set(y + 2, 8, "huruf", XS.th);
    sh.set(y, 9, "Biaya", XS.th).merge(y, 9, y, 10, XS.th);
    sh.set(y + 1, 9, "Uang Harian Fullday", XS.th).merge(y + 1, 9, y + 2, 9, XS.th);
    sh.set(y + 1, 10, "Uang Harian Fullboard", XS.th).merge(y + 1, 10, y + 2, 10, XS.th);
    sh.set(y, 11, "Pengeluaran Riil Transport Lokal", XS.th).merge(y, 11, y + 2, 11, XS.th);
    sh.set(y, 12, "Jumlah Biaya (Rp)\n∑ = 9 s.d 11", XS.th).merge(y, 12, y + 2, 12, XS.th);
    sh.set(y, 13, "Tanda Tangan Penerima", XS.th).merge(y, 13, y + 2, 14, XS.th);
    sh.h(y, 18).h(y + 1, 24).h(y + 2, 24);
    y += 3;
    for (let c = 1; c <= 13; c++)
        sh.set(y, c, `(${c})`, XS.thn);
    sh.merge(y, 13, y, 14, XS.thn);
    y++;
    const d0 = y;
    rows.forEach((x, i) => {
        sh.set(y, 1, i + 1, XS.td).set(y, 2, x.nama, XS.tdl).set(y, 3, x.gol || "", XS.td).set(y, 4, x.nip, XS.td).set(y, 5, x.jab, XS.td).set(y, 6, ($("#pelAsal")?.value.trim() || "BPS Kab. Maybrat"), XS.td)
            .set(y, 7, x.lama, XS.td).set(y, 8, `(${capFirst(terbilang(x.lama))})`, XS.td).set(y, 9, x.full, XS.num).set(y, 10, x.board, XS.num).set(y, 11, x.tr, XS.num)
            .set(y, 12, x.full + x.board + x.tr, XS.num, `SUM(I${y}:K${y})`).set(y, 13, i % 2 ? "" : `${i + 1}. ………`, XS.tdl).set(y, 14, i % 2 ? `${i + 1}. ………` : "", XS.tdl);
        sh.h(y, 30);
        y++;
    });
    const sum = (k) => rows.reduce((a, x) => a + x[k], 0);
    sh.set(y, 2, "Jumlah", XS.tdb).merge(y, 1, y, 8, XS.tdb);
    sh.set(y, 1, "Jumlah", XS.tdb);
    sh.set(y, 9, sum("full"), XS.numb, `SUM(I${d0}:I${y - 1})`).set(y, 10, sum("board"), XS.numb, `SUM(J${d0}:J${y - 1})`).set(y, 11, sum("tr"), XS.numb, `SUM(K${d0}:K${y - 1})`)
        .set(y, 12, sum("full") + sum("board") + sum("tr"), XS.numb, `SUM(L${d0}:L${y - 1})`).merge(y, 13, y, 14, XS.td);
    sh.h(y, 20);
    y++;
    const tot = sum("full") + sum("board") + sum("tr");
    sh.set(y, 2, "Terbilang", XS.it).set(y, 3, ":", XS.it).set(y, 4, capFirst(terbilang(tot)) + " Rupiah", XS.it).merge(y, 4, y, 14);
    y += 2;
    const bend = P[codeOf(r.No_Bend)], ppk = P[codeOf(r.No_PPK)];
    sh.set(y, 4, "Lunas Pada Tanggal : " + pelLunas(r), XS.n).set(y, 11, "Setuju dibayar", XS.n);
    y++;
    sh.set(y, 4, "Bendahara Pengeluaran", XS.n).set(y, 11, "Pejabat Pembuat Komitmen", XS.n);
    y++;
    sh.set(y, 4, "BPS Kabupaten Maybrat", XS.n).set(y, 11, "BPS Kabupaten Maybrat", XS.n);
    y += 5;
    sh.set(y, 4, bend?.nama || F.BEND || "", XS.b).set(y, 11, ppk?.nama || F.PPK || "", XS.b);
    y++;
    sh.set(y, 4, nipText(bend) || (F.NIP_BEND ? "NIP. " + F.NIP_BEND : ""), XS.n).set(y, 11, nipText(ppk) || (F.NIP_PPK ? "NIP. " + F.NIP_PPK : ""), XS.n);
    await xlsxSave([sh], `Daftar Transport Pelatihan ${F.NOMOR_ST.replace(/\//g, "-")}.xlsx`);
    toast(`Daftar transport pelatihan ${rows.length} orang diunduh (total Rp ${rupiah(tot)}).` + (r._noBiaya ? " Rincian biaya surat ini belum dibuat — transport masih 0." : ""));
}

/* ---- 75_honor.ts ---- */
/** isi kolom isian bebas (data-h / data-hr) lewat nama kolom dinamis */
const hoField = dyn;
var honorDB = LS.get("st.honor", []).map(h => ({ ...h, rows: (h.rows || []).map(x => { const b = num(x.dok) * num(x.sat), v = num(x.pph); return v > 100 && b ? { ...x, pph: Math.round(v / b * 10000) / 100 } : x; }) })).map(h => (h.judul1 === "DAFTAR PEMBAYARAN HONOR " + "PETUGAS LAPANGAN" ? { ...h, judul1: "DAFTAR PEMBAYARAN HONOR" } : h)), rekMap = LS.get("st.rekening", {}), hoCur = null, hoSaved = null;
const persistHonor = () => { LS.set("st.honor", honorDB); LS.set("st.rekening", rekMap); _use = null; _dataVer++; };
/* PPh 21 diisi persen (%) dari bruto; bawaan dari golongan: IV → 15%, III → 5%, II/I & mitra → 0% */
const pphPctGol = (c) => { const g = String(pegMap()[c]?.gol || "").trim().toUpperCase(); return /^IV/.test(g) ? 15 : /^III/.test(g) ? 5 : 0; };
const hoBruto = (x) => num(x.dok) * num(x.sat);
const ptkpBatas = () => num(LS.get("st.ptkp", 4500000)) || 4500000; // batas honor PTKP (Pengaturan)
/* PPh otomatis: pegawai → golongan (IV 15%, III 5%, II 0%); mitra / nama di luar data → 5% bila bruto melebihi batas PTKP, selain itu 0% */
function pphAuto(x) { const c = x.c || "", p = c ? pegMap()[c] : undefined; if (p && !isMitra(p) && !isSystemPeg(p))
    return pphPctGol(c); return hoBruto(x) > ptkpBatas() ? 5 : 0; }
const HO_UNITS = ["Dokumen", "OB", "EA", "PLOT", "RUTA", "OJP"];
/* jabatan honor: mitra memilih dari daftar baku (semua mitra satu jabatan); pegawai otomatis jabatan di Database (boleh berbeda) */
const HO_JAB_MITRA = ["Petugas Pendata Lapangan", "Petugas Pemeriksa Lapangan"];
const hoKind = (x) => { const p = x.c ? pegMap()[x.c] : undefined; return !p || isSystemPeg(p) ? "" : isMitra(p) ? "mitra" : "pegawai"; };
const hoPegJab = (x) => String(pegMap()[x.c]?.jabatan || "").trim();
/** pilihan jabatan baris: mitra → daftar baku; pegawai → jabatan di Database; + Lainnya */
function hoJabOpts(x) { const k = hoKind(x); return k === "mitra" ? HO_JAB_MITRA : k === "pegawai" ? [hoPegJab(x)].filter(Boolean) : []; }
const hoJabOther = (x) => !!x.jabOther || (!!x.jab && !hoJabOpts(x).includes(x.jab));
/** jenis petugas yang sudah ada di daftar (selain baris i) */
const hoListKind = (h, skip = -1) => { for (let i = 0; i < h.rows.length; i++) {
    if (i === skip)
        continue;
    const k = hoKind(h.rows[i]);
    if (k)
        return k;
} return ""; };
/** jabatan bersama mitra (baris mitra pertama selain baris i) */
const hoMitraJab = (h, skip = -1) => h.rows.find((r, i) => i !== skip && hoKind(r) === "mitra" && r.jab)?.jab || "";
function hoRulesErr(h) {
    const ks = new Set(h.rows.filter(x => hoName(x)).map(hoKind).filter(Boolean));
    if (ks.size > 1)
        return "Anggota honor tidak boleh campuran mitra dan pegawai — buat daftar honor terpisah.";
    const mj = new Set(h.rows.filter(x => hoKind(x) === "mitra").map(x => x.jab.trim()));
    if (mj.size > 1)
        return `Semua mitra dalam satu daftar honor harus berjabatan sama (sekarang: ${[...mj].map(j => j || "kosong").join(", ")}).`;
    return null;
}
const hoUnitOther = (x) => !!x.unitOther || (!!x.unit && !HO_UNITS.includes(x.unit));
const pphAmt = (x) => Math.round(hoBruto(x) * num(x.pph) / 100);
const hoTot = (h) => (h.rows || []).reduce((a, x) => { const b = hoBruto(x), t = pphAmt(x); a.bruto += b; a.pph += t; a.net += b - t; return a; }, { bruto: 0, pph: 0, net: 0 });
const hoName = (x) => (x.c && pegMap()[x.c]?.nama) || x.nama || "";
function hoBlank() {
    const d = defaults();
    return { _id: newId(), judul1: "DAFTAR PEMBAYARAN HONOR", judul2: "", MAK: "", unit: "BPS Kabupaten Maybrat (690691)", sk: "", tglSk: "", tglDaftar: today(), tempat: "Maybrat",
        bend: codeOf(d.No_Bend) || "", ppk: codeOf(d.No_PPK) || "", pembuat: codeOf(d.No_PPK) || "", defJab: "Petugas Lapangan", defSat: "", rows: [] };
}
/* ---------- daftar ---------- */
function renderHonorList() {
    const q = acNorm($("#hoQ").value.trim()), toks = q.split(/\s+/).filter(Boolean);
    const list = [...honorDB].reverse().filter(h => !toks.length || toks.every(t => acNorm([h.judul2, h.judul1, h.sk, h.MAK, ...(h.rows || []).map(hoName)].join(" ")).includes(t)));
    let sum = 0;
    $("#hoTbl tbody").innerHTML = list.map((h, i) => {
        const t = hoTot(h);
        sum += t.net;
        const a = pokMap()[normMak(h.MAK)];
        return `<tr data-ho="${esc(h._id)}"><td class="no"><b>${honorDB.length - honorDB.indexOf(h)}</b></td>
      <td><span class="lt-title" data-hoa="edit">${esc(h.judul2 || "(tanpa nama kegiatan)")}</span><div class="lsub one">${esc(h.judul1 || "")}${h.tglDaftar ? " · " + esc(h.tglDaftar) : ""}</div></td>
      <td><div class="one" style="font-size:13px">${esc(skOf(h)[0] || "–")}</div><div class="lsub one" title="${esc(h.MAK || "")}">${esc(a ? a.kompNama + " · " + h.MAK : h.MAK || "MAK belum diisi")}</div></td>
      <td class="num">${(h.rows || []).length}</td><td class="num">Rp ${rupiah(t.net)}${t.pph ? `<div class="lsub">bruto ${rupiah(t.bruto)}</div>` : ""}</td>
      <td class="acts"><button class="btn sm pri" data-hoa="xls">Excel</button> <button class="ib" data-hoa="edit" title="Edit">${IC.edit}</button><button class="ib" data-hoa="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-hoa="del" title="Hapus">${IC.del}</button></td></tr>`;
    }).join("")
        || `<tr><td colspan="6" class="muted" style="text-align:center;padding:24px">${honorDB.length ? "Tidak ada yang cocok." : "Belum ada daftar honor. Klik <b>+ Daftar honor baru</b>."}</td></tr>`;
    $("#hoInfo").textContent = list.length ? `${list.length} daftar · total diterima Rp ${rupiah(sum)}` : "";
}
$("#hoQ").addEventListener("input", debounce(() => renderHonorList(), 150));
$("#hoTbl").addEventListener("click", e => {
    const tr = tg(e).closest("tr[data-ho]"), a = tg(e).closest("[data-hoa]")?.dataset.hoa;
    if (!tr || !a)
        return;
    const h = honorDB.find(x => x._id === tr.dataset.ho);
    if (!h)
        return;
    if (a === "edit")
        openHonor(h);
    if (a === "xls")
        honorXlsx(h);
    if (a === "dup") {
        const c = clone(h);
        c._id = newId();
        c.judul2 = (c.judul2 || "") + " (salinan)";
        c.sk = "";
        openHonor(c, true);
        toast("Salinan dibuat — ubah lalu simpan.");
    }
    if (a === "del" && confirm(`Hapus daftar honor "${h.judul2 || h.judul1}"?`)) {
        honorDB = honorDB.filter(x => x !== h);
        persistHonor();
        renderHonorList();
    }
});
$("#hoNew").onclick = () => openHonor(hoBlank(), true);
/* ---------- editor ---------- */
const hoIn = (k) => $(`#hoForm [data-h="${k}"]`);
function openHonor(h, isNew = false) {
    hoCur = clone(h);
    hoSaved = isNew ? null : h;
    for (const e of $$("#hoForm [data-h]")) {
        const k = e.dataset.h ?? "", v = String(hoField(hoCur)[k] ?? "");
        e.value = ["bend", "ppk", "pembuat"].includes(k) ? (v ? pegLabel(v) : "") : v;
    }
    if (!hoCur.obFrom) {
        const fr = hoCur.rows.map(x => parseTgl(x.obFrom)?.getTime()).filter((t) => t != null), to = hoCur.rows.map(x => parseTgl(x.obTo)?.getTime()).filter((t) => t != null); // data lama: rentang per petugas → satu rentang
        if (fr.length)
            hoCur.obFrom = fmtDate(new Date(Math.min(...fr)));
        if (to.length)
            hoCur.obTo = fmtDate(new Date(Math.max(...to)));
    }
    $("#hoObFrom").value = isoOf(hoCur.obFrom);
    $("#hoObTo").value = isoOf(hoCur.obTo);
    hoCur.judul1 = hoCur.judul1 || "DAFTAR PEMBAYARAN HONOR";
    hoSkOpts();
    hoIn("tglSk").value = skOf(hoCur)[1] || "";
    $("#hoAllJab").value = hoCur.defJab || "";
    $("#hoAllSat").value = String(hoCur.defSat || "");
    $("#hoFlag").textContent = isNew ? "Daftar honor baru" : "Mengubah daftar honor";
    $("#hoFlag").hidden = false;
    $("#hoListCard").hidden = true;
    $("#hoEdit").hidden = false;
    renderHoRows();
    window.scrollTo(0, 0);
}
function closeHonor() { hoCur = null; $("#hoEdit").hidden = true; $("#hoListCard").hidden = false; renderHonorList(); }
$("#hoBack").onclick = () => { if (hoCur && JSON.stringify(hoCur) !== JSON.stringify(hoSaved || {}) && hoCur.rows.length && !confirm("Tinggalkan tanpa menyimpan?"))
    return; closeHonor(); };
/* tanggal daftar honor tidak boleh sebelum tanggal SK (minimal sama) */
function hoTglErr(h) {
    const sk = parseTgl(skOf(h)[1]), d = parseTgl(h.tglDaftar);
    if (h.tglDaftar && !d)
        return "Tanggal daftar tidak terbaca — tulis mis. 8 November 2026.";
    if (sk && d && d < sk)
        return `Tanggal daftar (${fmtDate(d)}) tidak boleh sebelum tanggal SK (${fmtDate(sk)}) — minimal sama dengan tanggal SK.`;
    return null;
}
function skOf(h) { const x = h.skId ? suratDB.find(s0 => s0._id === h.skId) : undefined; return x ? [nsNomor(x), x.tgl, x] : [h.sk || "", h.tglSk || "", null]; }
function hoSkOpts() {
    if (!hoCur)
        return;
    const cur = hoCur;
    const sel = hoIn("skId"), list = suratDB.filter(x => /keputusan/i.test(String(x.jenis || ""))).sort((a, b) => (nsYearOf(b) || 0) - (nsYearOf(a) || 0) || b.no - a.no);
    const old = !cur.skId && cur.sk ? `<option value="__old" selected disabled>${esc(cur.sk)} (lama, bukan dari daftar SK — pilih ulang)</option>` : "";
    sel.innerHTML = `<option value="">${list.length ? "— pilih Surat Keputusan —" : "Belum ada Surat Keputusan — catat di tab Nomor Surat"}</option>` + old
        + list.map(x => `<option value="${esc(x._id)}" ${x._id === cur.skId ? "selected" : ""}>${esc(nsNomor(x))} — ${esc(String(x.perihal).slice(0, 55))}</option>`).join("");
    $("#ho-skInfo").textContent = skOf(cur)[2]?.perihal || "";
}
$("#hoForm").addEventListener("input", e => {
    const k = tg(e).dataset.h;
    if (!k || !hoCur)
        return;
    if (k === "skId")
        return;
    if (!["bend", "ppk", "pembuat"].includes(k))
        hoField(hoCur)[k] = tg(e).value.trim();
    hoSums();
});
$("#hoForm").addEventListener("change", e => {
    if (!hoCur)
        return;
    const hf = tg(e).dataset.hfor;
    if (hf && tg(e).value) {
        const t = hoIn(hf);
        t.value = fmtTgl(tg(e).value);
        hoField(hoCur)[hf] = t.value;
    }
    const k = tg(e).dataset.h ?? "";
    if (["bend", "ppk", "pembuat"].includes(k)) {
        const c = resolvePeg(tg(e).value);
        hoField(hoCur)[k] = c || "";
        if (c)
            tg(e).value = pegLabel(c);
    }
    if (k === "skId" && tg(e).value !== "__old") {
        const x = suratDB.find(s0 => s0._id === tg(e).value);
        hoCur.skId = x ? x._id : "";
        hoCur.sk = x ? nsNomor(x) : "";
        hoCur.tglSk = x ? x.tgl : "";
        hoIn("tglSk").value = hoCur.tglSk;
        $("#ho-skInfo").textContent = x ? x.perihal : "";
    }
    hoSums();
});
function hoRowHtml(x, i) {
    const b = num(x.dok) * num(x.sat);
    return `<tr data-r="${i}"><td class="muted">${i + 1}</td>
    <td><input data-hr="nama" data-ac="peg" autocomplete="off" value="${esc(hoName(x))}" placeholder="Cari nama…"></td>
    <td><input data-hr="rek" value="${esc(x.rek || "")}" placeholder="-"></td>
    <td><div class="volin"><input data-hr="dok" type="number" min="0" value="${esc(x.dok ?? "")}" style="text-align:right"><select data-hr="unit">${HO_UNITS.map(u => `<option ${!hoUnitOther(x) && (x.unit || "Dokumen") === u ? "selected" : ""}>${u}</option>`).join("")}<option value="__lain" ${hoUnitOther(x) ? "selected" : ""}>Lainnya…</option></select></div>${hoUnitOther(x) ? `<input data-hr="unitLain" value="${esc(x.unit)}" placeholder="tulis satuan" style="margin-top:4px;height:28px">` : ""}</td>
    <td>${hoKind(x) ? `<select data-hr="jabSel" title="${hoKind(x) === "mitra" ? "Mitra: pilih jabatan — semua mitra di daftar ini ikut sama" : "Pegawai: otomatis jabatan di Database"}">${hoJabOpts(x).map(j => `<option ${!hoJabOther(x) && x.jab === j ? "selected" : ""}>${esc(j)}</option>`).join("")}<option value="__lain" ${hoJabOther(x) ? "selected" : ""}>Lainnya…</option></select>${hoJabOther(x) ? `<input data-hr="jab" value="${esc(x.jab || "")}" placeholder="tulis jabatan" style="margin-top:4px;height:28px">` : ""}<div class="lsub">${hoKind(x)}</div>` : `<input data-hr="jab" value="${esc(x.jab || "")}" placeholder="pilih nama dulu">`}</td>
    <td><input data-hr="sat" type="number" min="0" step="1000" value="${esc(x.sat ?? "")}" style="text-align:right"></td>
    <td class="num" data-o="bruto">${rupiah(b)}</td>
    <td><div class="pctin"><input data-hr="pph" type="number" min="0" max="100" step="0.5" value="${esc(x.pph ?? "")}" placeholder="0" style="text-align:right" title="Persen dari bruto — otomatis: pegawai dari golongan (IV 15%, III 5%, II 0%); mitra 5% bila bruto melebihi batas PTKP"><span>%</span></div><div class="lsub" data-o="pphrp" style="text-align:right">${pphAmt(x) ? "Rp " + rupiah(pphAmt(x)) : ""}</div></td>
    <td class="num" data-o="net"><b>${rupiah(b - pphAmt(x))}</b></td>
    <td><button class="ib del" type="button" data-hdel="${i}" title="Hapus baris">${IC.del}</button></td></tr>`;
}
function renderHoRows() {
    if (!hoCur)
        return;
    $("#hoRows tbody").innerHTML = hoCur.rows.map(hoRowHtml).join("") || `<tr><td colspan="10" class="muted" style="text-align:center;padding:18px">Belum ada petugas. Klik <b>+ Tambah petugas</b> atau impor dari Excel.</td></tr>`;
    hoSums();
}
function hoObUI() {
    if (!hoCur)
        return;
    const ob = hoCur.rows.some(x => x.unit === "OB");
    $("#hoObWrap").hidden = !ob;
    if (!ob)
        return;
    const a = parseTgl(hoCur.obFrom), b = parseTgl(hoCur.obTo);
    $("#hoObInfo").innerHTML = a && b ? (b < a ? `<span class="bad">tanggal selesai sebelum tanggal mulai</span>` : `${dayDiff(a, b)} hari · ${fmtDate(a)} – ${fmtDate(b)}`) : `<span class="bad">isi tanggal mulai & selesai</span>`;
}
$("#hoObFrom").addEventListener("change", e => { if (!hoCur)
    return; hoCur.obFrom = tg(e).value ? fmtTgl(tg(e).value) : ""; hoObUI(); });
$("#hoObTo").addEventListener("change", e => { if (!hoCur)
    return; hoCur.obTo = tg(e).value ? fmtTgl(tg(e).value) : ""; hoObUI(); });
function hoSums() {
    if (!hoCur)
        return;
    hoObUI();
    const t = hoTot(hoCur), n = hoCur.rows.length;
    $("#hoCount").textContent = n + " petugas";
    $("#hoFoot").innerHTML = n ? `<tr><td></td><td colspan="5"><b>Jumlah</b></td><td class="num"><b>${rupiah(t.bruto)}</b></td><td class="num"><b>${rupiah(t.pph)}</b></td><td class="num"><b>${rupiah(t.net)}</b></td><td></td></tr>` : "";
    $("#hoSum").textContent = "Rp " + rupiah(t.net);
    {
        const e = hoTglErr(hoCur), el = $("#ho-tgl");
        if (el)
            el.innerHTML = e ? `<span class="bad">${esc(e)}</span>` : "";
    }
    $("#ho-judul").textContent = "Di dokumen: " + (hoCur.judul1 || "DAFTAR PEMBAYARAN HONOR") + " / " + String(hoCur.judul2 || "…").toUpperCase();
    $("#hoTerb").textContent = n ? "Terbilang: " + capFirst(terbilang(t.net)) + " Rupiah" : "";
    const saved = hoSaved && normMak(hoSaved.MAK) === normMak(hoCur.MAK) ? hoTot(hoSaved).bruto : 0;
    $("#ho-mak").innerHTML = budgetHtml(hoCur.MAK, t.bruto - saved, null, "daftar ini");
}
$("#hoRows").addEventListener("input", e => {
    const tr = tg(e).closest("tr[data-r]"), k = tg(e).dataset.hr;
    if (!tr || !k || !hoCur)
        return;
    const ri = +tr.dataset.r, x = hoCur.rows[ri];
    if (k === "nama") {
        x.nama = tg(e).value.trim();
        x.c = "";
    }
    else if (k === "jabSel") {
        if (tg(e).value === "__lain") {
            x.jabOther = true;
            x.jab = "";
        }
        else {
            x.jabOther = false;
            x.jab = tg(e).value;
        }
        if (hoKind(x) === "mitra" && x.jab) {
            let n = 0;
            for (const r of hoCur.rows)
                if (r !== x && hoKind(r) === "mitra" && r.jab !== x.jab) {
                    r.jab = x.jab;
                    r.jabOther = x.jabOther;
                    n++;
                }
            if (n)
                toast(`Jabatan ${n} mitra lain ikut diubah menjadi "${x.jab}" — mitra dalam satu daftar harus berjabatan sama.`);
        }
        renderHoRows();
        if (x.jabOther)
            $(`#hoRows tr[data-r="${ri}"] [data-hr="jab"]`)?.focus();
        return;
    }
    else if (k === "unit") {
        if (tg(e).value === "__lain") {
            x.unit = "";
            x.unitOther = true;
            tr.outerHTML = hoRowHtml(x, ri);
            $(`#hoRows tr[data-r="${tr.dataset.r}"] [data-hr="unitLain"]`)?.focus();
            hoSums();
            return;
        }
        const wasOB = x.unit === "OB";
        x.unit = tg(e).value;
        if (wasOB !== (x.unit === "OB")) {
            x.unitOther = false;
            renderHoRows();
            return;
        }
        if (x.unitOther) {
            x.unitOther = false;
            tr.outerHTML = hoRowHtml(x, ri);
            hoSums();
            return;
        }
    }
    else if (k === "unitLain")
        x.unit = tg(e).value.trim();
    else if (k === "obFrom" || k === "obTo") {
        x[k] = tg(e).value ? fmtTgl(tg(e).value) : "";
        const a = parseTgl(x.obFrom), b2 = parseTgl(x.obTo), inf = tr.querySelector('[data-o="obinfo"]');
        if (inf)
            inf.innerHTML = a && b2 ? (b2 < a ? `<span class="bad">tanggal selesai sebelum tanggal mulai</span>` : dayDiff(a, b2) + " hari · petugas tidak bisa diberi surat tugas lain di luar MAK kegiatan yang sama") : "isi tanggal mulai & selesai";
        hoSums();
        return;
    }
    else
        hoField(x)[k] = ["dok", "sat", "pph"].includes(k) ? (tg(e).value === "" ? "" : Number(tg(e).value)) : tg(e).value.trim();
    if (k === "pph" && e.isTrusted)
        x.pphManual = true; // diketik pengguna → tidak diubah otomatis lagi
    if ((k === "dok" || k === "sat") && !x.pphManual) {
        const a = pphAuto(x);
        if (num(x.pph) !== a) {
            x.pph = a;
            tr.querySelector('[data-hr="pph"]').value = String(a);
        }
    }
    const b = num(x.dok) * num(x.sat);
    tr.querySelector('[data-o="bruto"]').textContent = rupiah(b);
    tr.querySelector('[data-o="net"]').innerHTML = `<b>${rupiah(b - pphAmt(x))}</b>`;
    tr.querySelector('[data-o="pphrp"]').textContent = pphAmt(x) ? "Rp " + rupiah(pphAmt(x)) : "";
    hoSums();
});
$("#hoRows").addEventListener("change", e => {
    const tr = tg(e).closest("tr[data-r]");
    if (!tr || !hoCur)
        return;
    if (tg(e).dataset.hr === "jab") {
        const x = hoCur.rows[+tr.dataset.r]; // jabatan "Lainnya" mitra → semua mitra sama
        if (hoKind(x) === "mitra" && x.jab) {
            let n = 0;
            for (const r of hoCur.rows)
                if (r !== x && hoKind(r) === "mitra" && r.jab !== x.jab) {
                    r.jab = x.jab;
                    r.jabOther = true;
                    n++;
                }
            if (n) {
                toast(`Jabatan ${n} mitra lain ikut diubah menjadi "${x.jab}".`);
                renderHoRows();
            }
        }
        return;
    }
    if (tg(e).dataset.hr !== "nama")
        return;
    const ri = +tr.dataset.r, x = hoCur.rows[ri], c = resolvePeg(tg(e).value);
    if (c) {
        const nk = hoKind({ c }), lk = hoListKind(hoCur, ri);
        if (nk && lk && nk !== lk) {
            x.nama = "";
            x.c = "";
            tg(e).value = "";
            return toast(`${pegMap()[c].nama} adalah ${nk}, sedangkan daftar ini berisi ${lk} — anggota honor tidak boleh campuran mitra dan pegawai.`, "warn");
        }
        if (hoCur.rows.some((r, i) => i !== ri && r.c === c)) {
            x.nama = "";
            x.c = "";
            tg(e).value = "";
            return toast(`${pegMap()[c].nama} sudah ada di daftar honor ini.`, "warn");
        }
        x.c = c;
        x.jabOther = false;
        if (nk === "pegawai")
            x.jab = hoPegJab(x) || x.jab;
        else if (nk === "mitra") {
            const mj = hoMitraJab(hoCur, ri);
            x.jab = mj || (HO_JAB_MITRA.includes(x.jab) ? x.jab : HO_JAB_MITRA.includes($("#hoAllJab").value.trim()) ? $("#hoAllJab").value.trim() : HO_JAB_MITRA[0]);
            x.jabOther = !!mj && !HO_JAB_MITRA.includes(mj);
        }
        x.nama = pegMap()[c].nama;
        {
            const q = () => document.querySelector(`#hoRows tr[data-r="${ri}"]`), ae = document.activeElement;
            if (ae && q()?.contains(ae))
                ae.blur(); // blur dulu: "change" bawaan peramban dijalankan sebelum baris diganti
            const cur = q();
            if (cur?.isConnected)
                cur.outerHTML = hoRowHtml(x, ri);
        }
        hoSums();
        const tr2 = $(`#hoRows tr[data-r="${ri}"]`), pi = tr2.querySelector('[data-hr="pph"]');
        x.pphManual = false;
        x.pph = pphAuto(x);
        pi.value = String(x.pph);
        pi.dispatchEvent(new Event("input", { bubbles: true }));
        if (!x.rek && rekMap[c]) {
            x.rek = rekMap[c];
            tr2.querySelector('[data-hr="rek"]').value = x.rek;
        }
    }
});
$("#hoRows").addEventListener("click", e => { const d = tg(e).closest("[data-hdel]")?.dataset.hdel; if (d == null || !hoCur)
    return; hoCur.rows.splice(+d, 1); renderHoRows(); });
$("#hoAllUnit").innerHTML = HO_UNITS.map(u => `<option>${u}</option>`).join("");
$("#hoAdd").onclick = () => {
    if (!hoCur)
        return;
    const cur = hoCur;
    cur.rows.push({ nama: "", c: "", rek: "", dok: "", unit: $("#hoAllUnit").value || "Dokumen", jab: hoMitraJab(cur) || $("#hoAllJab").value.trim() || "Petugas Lapangan", sat: $("#hoAllSat").value === "" ? "" : Number($("#hoAllSat").value), pph: "" });
    renderHoRows();
    $(`#hoRows tr[data-r="${cur.rows.length - 1}"] [data-hr="nama"]`).focus();
};
$("#hoApply").onclick = () => {
    if (!hoCur)
        return;
    const j = $("#hoAllJab").value.trim(), s0 = $("#hoAllSat").value;
    hoCur.defJab = j;
    hoCur.defSat = s0;
    const u = $("#hoAllUnit").value;
    hoCur.defUnit = u;
    for (const x of hoCur.rows) {
        if (j && hoKind(x) !== "pegawai") {
            x.jab = j;
            x.jabOther = hoKind(x) === "mitra" && !HO_JAB_MITRA.includes(j);
        }
        if (s0 !== "")
            x.sat = Number(s0);
        if (u)
            x.unit = u;
        if (!x.pphManual)
            x.pph = pphAuto(x);
    }
    renderHoRows();
    toast(hoListKind(hoCur) === "pegawai" ? "Satuan diterapkan — jabatan pegawai tetap mengikuti Database." : "Jabatan & satuan diterapkan ke semua petugas.");
};
$("#hoSave").onclick = () => {
    if (!hoCur)
        return;
    if (!hoCur.judul2)
        return toast("Isi judul / nama kegiatan.");
    {
        const e = hoTglErr(hoCur);
        if (e)
            return toast(e);
    }
    if (hoCur.rows.some(x => x.unit === "OB" && hoName(x))) {
        const a = parseTgl(hoCur.obFrom), b = parseTgl(hoCur.obTo);
        if (!a || !b || b < a)
            return toast("Isi rentang tanggal OB / kontrak di bagian 1 · Data kegiatan.");
    }
    if (hoCur.MAK && !HO_AKUN.includes(akunOf(hoCur.MAK)))
        return toast("MAK honor harus akun 521213 (Belanja Honor Output Kegiatan).");
    if (hoCur.bend && !roleOk(hoCur.bend, ["BEND"]) && hoCur.bend !== hoSaved?.bend)
        return toast("Bendahara Pengeluaran harus pegawai berperan Bendahara — atur di Database → Pegawai.");
    if (hoCur.ppk && !roleOk(hoCur.ppk, ["PPK"]) && hoCur.ppk !== hoSaved?.ppk)
        return toast("PPK harus pegawai berperan PPK — atur di Database → Pegawai.");
    hoCur.rows = hoCur.rows.filter(x => hoName(x));
    if (!hoCur.rows.length)
        return toast("Belum ada petugas.");
    for (const x of hoCur.rows)
        if (!x.c) {
            const c = resolvePeg(x.nama);
            if (c)
                x.c = c;
        }
    {
        const e = hoRulesErr(hoCur);
        if (e) {
            renderHoRows();
            return toast(e, "warn");
        }
    }
    const bad = hoCur.rows.filter(x => !num(x.dok) || !num(x.sat));
    if (bad.length && !confirm(`${bad.length} petugas belum berisi banyak dokumen / satuan. Tetap simpan?`))
        return;
    for (const x of hoCur.rows) {
        if (!x.c) {
            const c = resolvePeg(x.nama);
            if (c)
                x.c = c;
        }
        if (x.c && x.rek && x.rek !== "-")
            rekMap[x.c] = x.rek;
    }
    const cur = hoCur, i = honorDB.findIndex(h => h._id === cur._id);
    if (i >= 0)
        honorDB[i] = clone(cur);
    else
        honorDB.push(clone(cur));
    hoSaved = honorDB.find(h => h._id === cur._id);
    persistHonor();
    renderHoRows();
    $("#hoFlag").textContent = "Tersimpan";
    $("#hsvMsg").textContent = `${hoCur.judul2} — ${hoCur.rows.length} petugas, jumlah diterima Rp ${rupiah(hoTot(hoCur).net)}.`;
    $("#dHoSaved").showModal();
};
$$("#dHoSaved [data-hsv]").forEach(b => b.onclick = () => {
    const a = b.dataset.hsv;
    $("#dHoSaved").close();
    if (a === "list")
        closeHonor();
    else if (a === "xls" && hoCur)
        honorXlsx(hoCur);
    else if (a === "prev" && hoCur)
        honorPreview(hoCur);
});
/* pratinjau dokumen honor (tampilan sama dengan hasil Excel) */
function honorHtml(h) {
    const P = pegMap(), t = hoTot(h), rows = (h.rows || []).filter(x => hoName(x)), [skNo, skTgl] = skOf(h);
    const lines = makLines(h.MAK).filter(([k]) => k !== "Sub-Komponen").map(([k, v]) => [k === "Akun/Detil" ? "Akun" : k, v]);
    const info = [...lines, ["Unit Kerja", h.unit || "BPS Kabupaten Maybrat (690691)"], ["Nomor SK", skNo], ["Tanggal SK", skTgl]];
    const bend = P[h.bend], ppk = P[h.ppk], pb = P[h.pembuat];
    return `<div class="hp-title">${esc(h.judul1 || "DAFTAR PEMBAYARAN HONOR")}<br>${esc(String(h.judul2 || "").toUpperCase())}</div>
    <table class="hp-info">${info.map(([k, v]) => `<tr><td>${esc(k)}</td><td>: ${esc(v || "")}</td></tr>`).join("")}</table>
    <table class="hp-tbl"><thead><tr><th>No</th><th>Nama</th><th>No Rekening</th><th>Volume</th><th>Satuan</th><th>Jabatan</th><th>Harga Satuan (Rp)</th><th>Jumlah Bruto (Rp)</th><th>PPh 21 (Rp)</th><th>Jumlah yang Diterima (Rp)</th><th colspan="2">Tanda Tangan</th></tr>
      <tr class="n">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(i => `<td>(${i})</td>`).join("")}<td colspan="2">(11)</td></tr></thead>
      <tbody>${rows.map((x, i) => { const b = num(x.dok) * num(x.sat); return `<tr><td class="c">${i + 1}</td><td>${esc(hoName(x))}</td><td class="c">${esc(x.rek || "-")}</td><td class="c">${num(x.dok)}</td><td class="c">${esc(x.unit || "Dokumen")}</td><td>${esc(x.jab || "")}</td><td class="r">${rupiah(num(x.sat))}</td><td class="r">${rupiah(b)}</td><td class="r">${pphAmt(x) ? rupiah(pphAmt(x)) : "-"}</td><td class="r">${rupiah(b - pphAmt(x))}</td><td>${i % 2 ? "" : (i + 1) + ". ……"}</td><td>${i % 2 ? (i + 1) + ". ……" : ""}</td></tr>`; }).join("")}
      <tr class="tot"><td colspan="7" class="c">Jumlah</td><td class="r">${rupiah(t.bruto)}</td><td class="r">${t.pph ? rupiah(t.pph) : "-"}</td><td class="r">${rupiah(t.net)}</td><td colspan="2"></td></tr></tbody></table>
    <p class="hp-terb"><i>Terbilang : ${esc(capFirst(terbilang(t.net)))} Rupiah</i></p>
    <p>Lunas pada tanggal</p>
    <div class="hp-sign"><div><br>Bendahara Pengeluaran<br><br><br><br><b>${esc(bend?.nama || "")}</b><br>${esc(nipText(bend))}</div>
      <div>Setuju dibayar,<br>Pejabat Pembuat Komitmen<br><br><br><br><b>${esc(ppk?.nama || "")}</b><br>${esc(nipText(ppk))}</div>
      <div>${esc(h.tempat || "Maybrat")}, ${esc(h.tglDaftar || "")}<br>Pembuat Daftar<br><br><br><br><b>${esc(pb?.nama || "")}</b><br>${esc(nipText(pb))}</div></div>`;
}
function honorPreview(h) {
    if (!(h.rows || []).some(x => hoName(x)))
        return toast("Belum ada petugas untuk dipratinjau.");
    $("#hpDoc").innerHTML = honorHtml(h);
    $("#dHoPrev").showModal();
}
$("#hoPrev").onclick = () => { if (hoCur)
    honorPreview(hoCur); };
$("#hpClose").onclick = () => $("#dHoPrev").close();
$("#hpXls").onclick = () => { if (hoCur)
    honorXlsx(hoCur); };
$("#hoDel").onclick = () => { if (!hoCur)
    return; if (!confirm("Hapus daftar honor ini?"))
    return; const id = hoCur._id; honorDB = honorDB.filter(h => h._id !== id); persistHonor(); closeHonor(); };
$("#hoXls").onclick = () => { if (hoCur)
    honorXlsx(hoCur); };
/* ---------- salin petugas dari surat tugas ---------- */
const hsSel = new Set();
function renderHs() {
    const toks = acNorm($("#hsQ").value.trim()).split(/\s+/).filter(Boolean), P = pegMap();
    const list = [...records].sort(byYearNo).reverse().filter(r => !toks.length || toks.every(t => acNorm(hayOf(r)).includes(t))).slice(0, 150);
    $("#hsTbl tbody").innerHTML = list.map(r => {
        const F = computeC(r);
        return `<tr data-hs="${esc(r._id)}" style="cursor:pointer" class="${hsSel.has(r._id ?? "") ? "on" : ""}"><td><input type="checkbox" ${hsSel.has(r._id ?? "") ? "checked" : ""}></td><td><b style="font-size:13px">${esc(F.MAKSUD__TUJUAN)}</b><div class="lsub">${esc(F.NOMOR_ST)}${F.kegiatan ? " · " + esc(F.kegiatan) : ""}</div></td><td style="font-size:13px">${esc(tglRange(r))}</td><td class="num">${personCodes(r, P).length}</td></tr>`;
    }).join("")
        || `<tr><td colspan="4" class="muted" style="text-align:center;padding:18px">Tidak ada surat tugas yang cocok.</td></tr>`;
    const nP = new Set([...hsSel].flatMap(id => { const r = records.find(x => x._id === id); return r ? personCodes(r, P) : []; })).size;
    $("#hsInfo").textContent = hsSel.size ? `${hsSel.size} surat dipilih · ${nP} petugas (nama ganda hanya dihitung sekali)` : "Centang satu atau beberapa surat tugas — semua pelaksana & anggota timnya ditambahkan.";
}
$("#hoFromSt").onclick = () => { hsSel.clear(); $("#hsQ").value = ""; renderHs(); $("#dHoSt").showModal(); $("#hsQ").focus(); };
$("#hsQ").addEventListener("input", debounce(() => renderHs(), 150));
$("#hsTbl").addEventListener("click", e => { const tr = tg(e).closest("tr[data-hs]"); if (!tr)
    return; const id = tr.dataset.hs ?? ""; hsSel.has(id) ? hsSel.delete(id) : hsSel.add(id); renderHs(); });
$("#hsCancel").onclick = () => $("#dHoSt").close();
$("#hsGo").onclick = () => {
    if (!hsSel.size)
        return toast("Centang surat tugas dulu.");
    if (!hoCur)
        return;
    const cur = hoCur;
    const P = pegMap(), have = new Set(cur.rows.map(x => x.c).filter(Boolean));
    let n = 0;
    for (const id of hsSel) {
        const r = records.find(x => x._id === id);
        if (!r)
            continue;
        for (const c of personCodes(r, P)) {
            if (have.has(c))
                continue;
            have.add(c);
            cur.rows.push({ nama: P[c].nama, c, rek: rekMap[c] || "", dok: "", jab: cur.defJab || "Petugas Lapangan", sat: cur.defSat === "" || cur.defSat == null ? "" : num(cur.defSat), unit: cur.defUnit || "Dokumen", pph: pphAuto({ c, dok: 0, sat: cur.defSat }) });
            n++;
        }
    }
    $("#dHoSt").close();
    renderHoRows();
    toast(n ? `${n} petugas ditambahkan dari ${hsSel.size} surat tugas — isi banyak dokumen & satuan.` : "Semua petugas itu sudah ada di daftar.");
};
/* ---------- template & impor petugas ---------- */
const HO_HDR = ["Nama", "No Rekening", "Volume", "Satuan Volume", "Jabatan", "Satuan (Rp)", "PPh 21 (%)"];
const hoTemplate = () => {
    const mit = pegawai.filter(isMitra).slice(0, 3);
    const ws = XLSX.utils.aoa_to_sheet([HO_HDR, ...mit.map((p, i) => [p.nama, rekMap[p.kode] || "-", 10 + i * 5, HO_UNITS[i % HO_UNITS.length], "Petugas Lapangan", 69000, pphAuto({ c: p.kode, dok: 10 + i * 5, sat: 69000 })])]);
    ws["!cols"] = [34, 20, 10, 14, 22, 14, 12].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Petugas");
    XLSX.writeFile(wb, "Template Honor Petugas.xlsx");
    toast("Template diunduh — satu baris per petugas, lalu Impor petugas.");
};
$("#hoTpl").onclick = hoTemplate;
$("#hoTpl2").onclick = hoTemplate;
$("#hoImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f || !hoCur)
        return;
    const cur = hoCur;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
        let rows = null, H = [];
        for (const sn of wb.SheetNames) {
            const a = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: true });
            const hi = a.findIndex(r => r.some(c => /^nama$/i.test(String(c).trim())));
            if (hi >= 0) {
                H = a[hi].map(c => String(c).trim().toLowerCase());
                rows = a.slice(hi + 1);
                break;
            }
        }
        if (!rows)
            return toast("Kolom 'Nama' tidak ditemukan. Pakai template.");
        const ix = (re) => H.findIndex(h => re.test(h)), cN = ix(/^nama$/), cR = ix(/rekening/), cD = ix(/dokumen|^volume|jumlah dok/), cJ = ix(/^jabatan/), cS = ix(/^satuan \(rp|^harga|^tarif|^satuan$/), cU = ix(/^satuan volume|^unit/), cP = ix(/pph/);
        let n = 0, unk = 0;
        for (const r of rows) {
            const nm = String(r[cN] ?? "").trim();
            if (!nm || /^jumlah$/i.test(nm))
                continue;
            const c = resolvePeg(nm);
            if (!c)
                unk++;
            cur.rows.push({ nama: c ? pegMap()[c].nama : nm, c: c || "", rek: String(cR < 0 ? "" : r[cR] ?? "").trim() || (c && rekMap[c]) || "", dok: cD < 0 ? "" : num(r[cD]), jab: String(cJ < 0 ? "" : r[cJ] ?? "").trim() || cur.defJab || "Petugas Lapangan",
                sat: cS < 0 ? (cur.defSat === "" ? "" : num(cur.defSat)) : num(r[cS]), unit: ((u) => u ? (HO_UNITS.find(x => x.toLowerCase() === u.toLowerCase()) || u) : (cur.defUnit || "Dokumen"))(String(cU < 0 ? "" : r[cU] ?? "").trim()),
                pph: cP < 0 ? pphAuto({ c, dok: cD < 0 ? 0 : num(r[cD]), sat: cS < 0 ? num(cur.defSat) : num(r[cS]) }) : ((v) => /%/.test(H[cP]) || v <= 100 ? v : (num(r[cD]) * num(r[cS]) ? Math.round(v / (num(r[cD]) * num(r[cS])) * 10000) / 100 : 0))(num(r[cP])) });
            n++;
        }
        renderHoRows();
        toast(`${n} petugas diimpor` + (unk ? ` — ${unk} nama belum ada di Pegawai & Mitra (tetap dipakai apa adanya).` : "."));
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
});
/* ---------- ekspor Excel seperti draf Honor ---------- */
async function honorXlsx(h) {
    const P = pegMap(), t = hoTot(h), rows = (h.rows || []).filter(x => hoName(x)), C = 12;
    if (!rows.length)
        return toast("Belum ada petugas di daftar ini.");
    const sh = xSheet(h.judul2 || "Honor", [5, 27, 17, 8, 10, 18, 12, 14, 12, 15, 12, 12], { portrait: false });
    sh.set(1, 1, h.judul1 || "DAFTAR PEMBAYARAN HONOR", XS.title).merge(1, 1, 1, C);
    sh.set(2, 1, String(h.judul2 || "").toUpperCase(), XS.title).merge(2, 1, 2, C);
    let y = 4;
    const lines = makLines(h.MAK).filter(([k]) => k !== "Sub-Komponen").map(([k, v]) => [k === "Akun/Detil" ? "Akun" : k, v]);
    for (const [k, v] of [...lines, ["Unit Kerja", h.unit || "BPS Kabupaten Maybrat (690691)"], ["Nomor SK", skOf(h)[0] || ""], ["Tanggal SK", skOf(h)[1] || ""]]) {
        sh.set(y, 1, k, XS.wrap).merge(y, 1, y, 2).set(y, 3, ": " + v, XS.wrap).merge(y, 3, y, C);
        if (String(v).length > 100)
            sh.h(y, 27);
        y++;
    }
    y++;
    const H = ["No", "Nama", "No Rekening", "Volume", "Satuan", "Jabatan", "Harga Satuan (Rp)", "Jumlah Bruto (Rp)", "PPh 21 (Rp)", "Jumlah yang Diterima (Rp)", "Tanda Tangan"];
    H.forEach((x, i) => sh.set(y, i + 1, x, XS.th));
    sh.merge(y, 11, y, 12, XS.th);
    sh.h(y, 32);
    y++;
    H.forEach((_, i) => sh.set(y, i + 1, `(${i + 1})`, XS.thn));
    sh.merge(y, 11, y, 12, XS.thn);
    y++;
    const d0 = y;
    rows.forEach((x, i) => {
        const b = hoBruto(x);
        sh.set(y, 1, i + 1, XS.td).set(y, 2, hoName(x), XS.tdl).set(y, 3, x.rek || "-", XS.td).set(y, 4, num(x.dok), XS.td).set(y, 5, x.unit || "Dokumen", XS.td).set(y, 6, x.jab || "", XS.tdl).set(y, 7, num(x.sat), XS.num)
            .set(y, 8, b, XS.num, `D${y}*G${y}`).set(y, 9, pphAmt(x), XS.num, `ROUND(H${y}*${num(x.pph)}/100,0)`).set(y, 10, b - pphAmt(x), XS.num, `H${y}-I${y}`)
            .set(y, 11, i % 2 ? "" : `${i + 1}  …………`, XS.tdl).set(y, 12, i % 2 ? `${i + 1}  …………` : "", XS.tdl);
        sh.h(y, 24);
        y++;
    });
    sh.set(y, 1, "Jumlah", XS.tdb).merge(y, 1, y, 7, XS.tdb);
    sh.set(y, 8, t.bruto, XS.numb, `SUM(H${d0}:H${y - 1})`).set(y, 9, t.pph, XS.numb, `SUM(I${d0}:I${y - 1})`).set(y, 10, t.net, XS.numb, `SUM(J${d0}:J${y - 1})`).merge(y, 11, y, 12, XS.td);
    sh.h(y, 20);
    y += 2;
    sh.set(y, 1, "Terbilang", XS.it).merge(y, 1, y, 2).set(y, 3, ": " + capFirst(terbilang(t.net)) + " Rupiah", XS.it).merge(y, 3, y, C);
    y += 2;
    sh.set(y, 1, "Lunas pada tanggal", XS.n).merge(y, 1, y, 3);
    y += 2;
    const bend = P[h.bend], ppk = P[h.ppk], pb = P[h.pembuat];
    sh.set(y, 6, "Setuju dibayar,", XS.n).set(y, 10, `${h.tempat || "Maybrat"}, ${h.tglDaftar || ""}`, XS.n);
    y++;
    sh.set(y, 1, "Bendahara Pengeluaran", XS.n).merge(y, 1, y, 3).set(y, 6, "Pejabat Pembuat Komitmen", XS.n).set(y, 10, "Pembuat Daftar", XS.n);
    y += 5;
    sh.set(y, 1, bend?.nama || "", XS.b).merge(y, 1, y, 3).set(y, 6, ppk?.nama || "", XS.b).set(y, 10, pb?.nama || "", XS.b);
    y++;
    sh.set(y, 1, nipText(bend), XS.n).merge(y, 1, y, 3).set(y, 6, nipText(ppk), XS.n).set(y, 10, nipText(pb), XS.n);
    await xlsxSave([sh], `Honor ${(h.judul2 || "Petugas").replace(/[\\/:*?"<>|]+/g, " ").slice(0, 80)}.xlsx`);
    toast(`Daftar honor ${rows.length} petugas diunduh (Rp ${rupiah(t.net)}).`);
}

/* ---- 78_nomor.ts ---- */
/* ================= NOMOR SURAT (register tersendiri, urut per jenis & tahun) ================= */
const NS_JENIS = ["Surat Keputusan", "Surat Keluar", "Kontrak", "Kuitansi", "Surat Penghargaan"];
const NS_FMT0 = Object.fromEntries(["Surat Keputusan", "Surat Keluar", "Kontrak", "Kuitansi", "Surat Penghargaan"].map(j => [j, "{SIFAT}-{NO}/9204/{KODE}/{TAHUN}"]));
var suratDB = LS.get("st.surat", []), nsFmt = { ...NS_FMT0, ...LS.get("st.suratFmt", {}) }, nsEdit = null, nsYear = "";
for (const x of suratDB)
    if (x.kode)
        x.kode = String(x.kode).toUpperCase();
for (const j in nsFmt)
    nsFmt[j] = String(nsFmt[j]).replace(/^B-\{NO\}/, "{SIFAT}-{NO}");
const persistSurat = () => { LS.set("st.surat", suratDB); LS.set("st.suratFmt", nsFmt); };
const nsYearOf = (x) => yrOf(x.tgl) || x.tahun || null;
{
    const sig = (x) => [nsYearOf(x), x.jenis, x.sifat, x.tgl, x.kode, x.perihal].join("|"), srt = suratDB.filter(x => !x.batch).sort((a, b) => sig(a).localeCompare(sig(b)) || a.no - b.no);
    for (let i = 0; i < srt.length;) {
        let j = i;
        while (j + 1 < srt.length && sig(srt[j + 1]) === sig(srt[i]) && srt[j + 1].no === srt[j].no + 1)
            j++;
        if (j - i >= 2) {
            const b = "m" + srt[i]._id;
            for (let k = i; k <= j; k++)
                srt[k].batch = b;
        }
        i = j + 1;
    }
}
const nsBULAN_ROM = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
function nsNomor(x) {
    const d = parseTgl(x.tgl), y = nsYearOf(x) || "", f = nsFmt[x.jenis] || NS_FMT0["Surat Keluar"];
    const sf = x.sifat == null ? "B" : String(x.sifat);
    return (sf ? f : f.replace(/\{SIFAT\}[-/.]?/g, "")).replace(/\{SIFAT\}/g, sf).replace(/\{NO\}/g, pad3(x.no || "")).replace(/\{KODE\}/g, String(x.kode || "…").toUpperCase()).replace(/\{TAHUN\}/g, String(y)).replace(/\{BULAN\}/g, d ? nsBULAN_ROM[d.getMonth()] : "").replace(/\{BLN\}/g, d ? String(d.getMonth() + 1).padStart(2, "0") : "");
}
const nsNext = (jenis, y, exceptId) => 1 + suratDB.filter(x => nsYearOf(x) === y && x._id !== exceptId).reduce((m, x) => Math.max(m, parseInt(String(x.no), 10) || 0), 0); // urutan bersama semua jenis surat
const nsIn = (k) => $(`#nsForm [data-ns="${k}"]`);
function nsRead() {
    const o = { jenis: "", sifat: "", tgl: "", kode: "", no: "", noEnd: "", perihal: "" };
    $$("#nsForm [data-ns]").forEach(e => { if (e.dataset.ns)
        o[e.dataset.ns] = e.value.trim(); });
    return o;
}
function nsReset(keep) {
    nsEdit = null;
    nsEditBatch = null;
    $("#nsEndWrap").hidden = false;
    nsIn("no").readOnly = nsIn("noEnd").readOnly = false;
    const j = keep?.jenis || nsIn("jenis").value || NS_JENIS[1];
    for (const e of $$("#nsForm [data-ns]"))
        e.value = "";
    nsIn("jenis").value = j;
    nsIn("sifat").value = keep?.sifat || "B";
    nsKodeMode(false);
    nsIn("tgl").value = keep?.tgl || today();
    if (keep?.kode)
        nsIn("kode").value = keep.kode;
    nsAutoNo(true);
    $("#nsSave").textContent = "Simpan nomor";
    $("#nsCancel").hidden = true;
    $("#nsFlag").hidden = true;
    nsPreview();
}
let _nsAutoNo = true;
function nsAutoNo(force) {
    const f = nsRead(), y = yrOf(f.tgl) || new Date().getFullYear(), nx = nsNext(f.jenis, y, nsEdit);
    if (force || _nsAutoNo)
        nsIn("no").value = String(nx);
    _nsAutoNo = true;
}
function nsCheck(f) {
    if (!f.perihal)
        return "Perihal surat wajib diisi.";
    const d = parseTgl(f.tgl);
    if (!d)
        return "Tanggal tidak terbaca — tulis mis. 7 November 2026.";
    if (!f.kode)
        return "Kode klasifikasi arsip wajib diisi.";
    if (!$("#nsKodeLain").checked && !kodeMap()[f.kode.toUpperCase()])
        return `Kode klasifikasi "${f.kode}" tidak ada di daftar — pilih dari daftar atau centang "Lainnya".`;
    const n = parseInt(String(f.no), 10), y = d.getFullYear();
    if (!n || n < 1)
        return "No. urut tidak valid.";
    {
        const dup = suratDB.find(x => x._id !== nsEdit && nsYearOf(x) === y && parseInt(String(x.no), 10) === n);
        if (dup)
            return `No. ${pad3(n)} tahun ${y} sudah dipakai oleh ${dup.jenis}: ${nsNomor(dup)}.`;
    }
    const old = nsEdit ? suratDB.find(x => x._id === nsEdit) : undefined, nx = nsNext(f.jenis, y, nsEdit);
    if ((!old || parseInt(String(old.no), 10) !== n || nsYearOf(old) !== y) && n > nx)
        return `Nomor harus berurutan: nomor surat tahun ${y} berikutnya No. ${pad3(nx)} (tidak boleh langsung ${pad3(n)}).`;
    const e = parseInt(f.noEnd, 10);
    if (!nsEdit && f.noEnd !== "" && f.noEnd != null) {
        if (!e || e < n)
            return `"Sampai No." harus sama atau lebih besar dari No. urut (${pad3(n)}).`;
        if (e - n + 1 > 1000)
            return "Maksimal 1.000 nomor sekali catat.";
        const used = suratDB.filter(x => nsYearOf(x) === y && parseInt(String(x.no), 10) >= n && parseInt(String(x.no), 10) <= e).map(x => pad3(x.no));
        if (used.length)
            return `No. ${used.slice(0, 5).join(", ")}${used.length > 5 ? "…" : ""} tahun ${y} sudah dipakai — rentang massal tidak boleh menimpa nomor lain.`;
    }
    return null;
}
const nsRange = (f) => { const n = parseInt(String(f.no), 10), e = parseInt(f.noEnd, 10); return !nsEdit && e && n && e > n ? [n, e] : null; };
function nsKodeMode(lain) {
    const inp = nsIn("kode");
    $("#nsKodeLain").checked = !!lain;
    if (lain) {
        delete inp.dataset.ac;
        inp.placeholder = "Tulis kode sendiri, mis. KU.010 atau 001";
    }
    else {
        inp.dataset.ac = "kode";
        inp.placeholder = "Cari kode / kata, mis. KP.200 atau keputusan";
    }
}
$("#nsKodeLain").addEventListener("change", e => { nsKodeMode(tg(e).checked); if (!tg(e).checked) {
    const c = kodeMap()[nsIn("kode").value.trim().toUpperCase()];
    if (!c)
        nsIn("kode").value = "";
} nsIn("kode").focus(); nsPreview(); });
function nsPreview() {
    const f = nsRead(), y = yrOf(f.tgl) || new Date().getFullYear(), x = { ...f, no: f.no };
    const kc = kodeMap()[f.kode.toUpperCase()];
    $("#nsKodeInfo").innerHTML = $("#nsKodeLain").checked ? `<span class="muted">Kode lainnya — diisi manual${kc ? ` (ada di daftar: ${esc(kc.d)})` : ""}</span>` : f.kode ? (kc ? `${esc(kc.d)} · ${esc(kodeGroup(kc.k))}` : `<span class="bad">Kode tidak dikenal — pilih dari daftar atau centang "Lainnya"</span>`) : "";
    {
        const rg = nsRange(f) || (nsEditBatch ? [parseInt(String(f.no), 10), parseInt(f.noEnd, 10)] : null);
        $("#nsNo").textContent = rg ? `${nsNomor({ ...x, no: rg[0] })}  s.d.  ${nsNomor({ ...x, no: rg[1] })}` : nsNomor(x);
        $("#nsSave").textContent = nsEdit ? (nsEditBatch && rg ? `Simpan perubahan (${rg[1] - rg[0] + 1} nomor)` : "Simpan perubahan") : rg ? `Simpan ${rg[1] - rg[0] + 1} nomor` : "Simpan nomor";
    }
    $("#nsYearInfo").textContent = `Tahun ${y} · nomor surat berikutnya (semua jenis): ${pad3(nsNext(f.jenis, y, nsEdit))}`;
    const err = nsCheck(f);
    $("#nsErr").innerHTML = err && (f.perihal || f.kode) ? `<span class="bad">${esc(err)}</span>` : "";
}
$("#nsForm").addEventListener("input", e => {
    const k = tg(e).dataset.ns, t0 = tg(e);
    if (k === "no")
        _nsAutoNo = false;
    if (k === "sifat") {
        const v = tg(e).value.toUpperCase().replace(/[^A-Z]/g, "");
        if (v !== tg(e).value)
            tg(e).value = v;
    }
    if (k === "jenis" || k === "tgl") {
        if (!nsEdit)
            nsAutoNo(true);
    }
    if (k === "kode") {
        const t = tg(e), up = t.value.toUpperCase();
        if (up !== t.value) {
            const c = t.selectionStart;
            t.value = up;
            t.setSelectionRange(c, c);
        }
    }
    if (k === "kode" && !$("#nsKodeLain").checked) {
        const c = kodeMap()[tg(e).value.trim().toUpperCase()];
        if (c)
            tg(e).value = c.k;
    }
    nsPreview();
});
$("#nsForm").addEventListener("change", e => {
    if (tg(e).dataset.nsfor && tg(e).value) {
        nsIn("tgl").value = fmtTgl(tg(e).value);
        if (!nsEdit)
            nsAutoNo(true);
    }
    if (tg(e).dataset.ns === "kode" && !$("#nsKodeLain").checked) {
        const { c, n } = lookupKode(tg(e).value);
        if (c)
            tg(e).value = c.k;
        else if (n > 1)
            toast(`${n} kode cocok — pilih dari daftar.`);
    }
    nsPreview();
});
$("#nsSave").onclick = async () => {
    const f = nsRead();
    f.kode = f.kode.toUpperCase();
    const err = nsCheck(f);
    if (err)
        return toast(err);
    if (nsEdit && nsEditBatch) {
        const g = suratDB.filter(x => x.batch === nsEditBatch && nsYearOf(x) === nsYearOf(suratDB.find(y => y._id === nsEdit) || { tgl: "" })), d = parseTgl(f.tgl);
        if (d.getFullYear() !== nsYearOf(g[0]))
            return toast("Tahun nomor massal tidak bisa diubah — hapus lalu catat ulang di tahun yang baru.");
        for (const x of g)
            Object.assign(x, { jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), tgl: fmtDate(d), kode: f.kode, perihal: f.perihal, kodeLain: $("#nsKodeLain").checked || undefined });
        persistSurat();
        toast(`${g.length} nomor diperbarui: ${nsNomor(g[0])} s.d. ${nsNomor(g[g.length - 1])}`);
        nsReset({ jenis: f.jenis, tgl: fmtDate(d) });
        renderSurat();
        return;
    }
    const rg = nsRange(f);
    if (rg) {
        const d = parseTgl(f.tgl), base = { jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), tgl: fmtDate(d), tahun: d.getFullYear(), kode: f.kode, ...($("#nsKodeLain").checked ? { kodeLain: true } : {}), perihal: f.perihal };
        const cnt = rg[1] - rg[0] + 1;
        if (cnt > 20 && !confirm(`Catat ${cnt} nomor sekaligus (${pad3(rg[0])} s.d. ${pad3(rg[1])}) dengan perihal "${f.perihal}"?`))
            return;
        const batch = newId();
        for (let n = rg[0]; n <= rg[1]; n++)
            suratDB.push({ _id: newId(), ...base, batch, no: n });
        persistSurat();
        nsYear = String(base.tahun);
        const t = `${nsNomor({ ...base, no: rg[0] })} s.d. ${nsNomor({ ...base, no: rg[1] })}`;
        try {
            await navigator.clipboard.writeText(t);
        }
        catch (e) { }
        toast(`Tersimpan ${cnt} nomor: ${t}`);
        nsReset({ jenis: base.jenis, tgl: base.tgl });
        renderSurat();
        return;
    }
    const d = parseTgl(f.tgl), x = { _id: nsEdit || newId(), jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), no: parseInt(String(f.no), 10), tgl: fmtDate(d), tahun: d.getFullYear(), kode: f.kode, ...($("#nsKodeLain").checked ? { kodeLain: true } : {}), perihal: f.perihal, tujuan: suratDB.find(s0 => s0._id === nsEdit)?.tujuan || "", ket: suratDB.find(s0 => s0._id === nsEdit)?.ket || "" };
    const i = suratDB.findIndex(s0 => s0._id === x._id);
    if (i >= 0)
        suratDB[i] = x;
    else
        suratDB.push(x);
    persistSurat();
    nsYear = String(x.tahun);
    const nomor = nsNomor(x);
    try {
        await navigator.clipboard.writeText(nomor);
    }
    catch (e) { }
    toast(`${i >= 0 ? "Diperbarui" : "Tersimpan"}: ${nomor} (nomor disalin)`);
    nsReset({ jenis: x.jenis, tgl: x.tgl });
    renderSurat();
};
$("#nsCancel").onclick = () => nsReset();
/* ---------- daftar ---------- */
function renderSurat() {
    const years = [...new Set(suratDB.map(nsYearOf).filter((y) => !!y))].sort((a, b) => b - a), cy = new Date().getFullYear();
    const opts = [...new Set([String(cy), ...years.map(String)])].sort((a, b) => +b - +a).concat("semua");
    if (!opts.includes(nsYear))
        nsYear = String(cy);
    $("#nsYear").innerHTML = opts.map(y => `<option value="${y}" ${y === nsYear ? "selected" : ""}>${y === "semua" ? "Semua tahun" : "Tahun " + y}</option>`).join("");
    const J = $("#nsJenisF").value, toks = acNorm($("#nsQ").value.trim()).split(/\s+/).filter(Boolean);
    const inY = suratDB.filter(x => nsYear === "semua" || String(nsYearOf(x)) === nsYear);
    const cnt = Object.fromEntries(NS_JENIS.map(j => [j, inY.filter(x => x.jenis === j).length]));
    $("#nsStats").innerHTML = `<div class="nsst nsnext"><small>Nomor berikutnya ${nsYear === "semua" ? cy : nsYear}</small><b>${pad3(nsNext(null, nsYear === "semua" ? cy : +nsYear))}</b><span>${inY.length} surat · semua jenis</span></div>` + NS_JENIS.map(j => `<button type="button" class="nsst ${J === j ? "on" : ""}" data-nsj="${esc(j)}"><small>${esc(j)}</small><b>${cnt[j]}</b><span>${cnt[j] ? "terakhir " + pad3(Math.max(...inY.filter(x => x.jenis === j).map(x => parseInt(String(x.no), 10) || 0))) : "belum ada"}</span></button>`).join("");
    const list = inY.filter(x => (!J || x.jenis === J) && (!toks.length || toks.every(t => acNorm([nsNomor(x), x.perihal, x.tujuan, x.ket, x.kode, x.jenis, x.tgl].join(" ")).includes(t))));
    // nomor yang dicatat massal → satu baris
    nsGroups = new Map();
    for (const x of list) {
        const k = x.batch ? "b:" + nsYearOf(x) + ":" + x.batch : "s:" + x._id;
        const g0 = nsGroups.get(k);
        if (g0)
            g0.push(x);
        else
            nsGroups.set(k, [x]);
    }
    for (const g of nsGroups.values())
        g.sort((a, b) => a.no - b.no);
    const groups = [...nsGroups.entries()].sort((a, b) => (nsYearOf(b[1][0]) || 0) - (nsYearOf(a[1][0]) || 0) || b[1][b[1].length - 1].no - a[1][a[1].length - 1].no);
    const KM = kodeMap();
    $("#nsTbl tbody").innerHTML = groups.map(([k, g]) => {
        const x = g[0], z = g[g.length - 1], many = g.length > 1, on = g.every(y => nsSel.has(y._id));
        return `<tr data-nsg="${esc(k)}" class="${on ? "on" : ""}"><td><input type="checkbox" class="nsck" ${on ? "checked" : ""}></td>
    <td class="no"><b>${many ? `${pad3(x.no)}–${pad3(z.no)}` : pad3(x.no)}</b><div class="lsub">${nsYearOf(x) || ""}${many ? ` · <b>${g.length} nomor</b>` : ""}</div></td>
    <td><span class="nsnum">${esc(nsNomor(x))}</span>${many ? `<div class="nsnum" style="font-weight:400"><span class="muted">s.d.</span> ${esc(nsNomor(z))}</div>` : ""}<div class="lsub">${esc(x.tgl)}</div></td>
    <td><span class="tag nsj-${NS_JENIS.indexOf(x.jenis)}">${esc(x.jenis)}</span>${many ? `<div class="lsub">dicatat massal</div>` : ""}</td>
    <td><div class="lt-title" data-nsa="edit">${esc(x.perihal)}</div></td>
    <td><b style="font-size:13px">${esc(x.kode)}</b><div class="lsub one" title="${esc(KM[x.kode]?.d || "")}">${esc(KM[x.kode]?.d || "")}</div></td>
    <td class="acts"><button class="btn sm" data-nsa="copy" title="Salin nomor">Salin</button> <button class="ib" data-nsa="edit" title="Edit">${IC.edit}</button><button class="ib" data-nsa="dup" title="Duplikat — pakai data ini untuk nomor baru">${IC.dup}</button><button class="ib del" data-nsa="del" title="Hapus">${IC.del}</button></td></tr>`;
    }).join("")
        || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">${suratDB.length ? "Tidak ada nomor surat yang cocok." : "Belum ada nomor surat. Isi formulir di atas lalu Simpan nomor."}</td></tr>`;
    const seen = {}, dups = new Set();
    for (const x of inY) {
        const k = nsYearOf(x) + "|" + parseInt(String(x.no), 10);
        if (seen[k])
            dups.add(k);
        seen[k] = 1;
    }
    $("#nsInfo").innerHTML = (list.length ? `${groups.length} baris · ${list.length} nomor surat ditampilkan` : "") + (dups.size ? ` · <span class="bad">${dups.size} nomor urut dipakai lebih dari satu surat — ubah salah satunya</span>` : "");
    nsSelUI();
}
var nsGroups = new Map(), nsSel = new Set(), nsEditBatch = null;
function nsSelUI() {
    for (const id of [...nsSel])
        if (!suratDB.some(x => x._id === id))
            nsSel.delete(id);
    const b = $("#nsDelSel");
    b.hidden = !nsSel.size;
    b.textContent = `Hapus terpilih (${nsSel.size} nomor)`;
    const all = [...nsGroups.values()].flat();
    $("#nsAll").checked = all.length > 0 && all.every(x => nsSel.has(x._id));
}
$("#nsAll").addEventListener("change", e => { for (const x of [...nsGroups.values()].flat())
    tg(e).checked ? nsSel.add(x._id) : nsSel.delete(x._id); renderSurat(); });
$("#nsDelSel").onclick = () => {
    const xs = suratDB.filter(x => nsSel.has(x._id));
    if (!xs.length)
        return;
    if (!confirm(`Hapus ${xs.length} nomor surat terpilih?\n\n${xs.slice(0, 6).map(nsNomor).join("\n")}${xs.length > 6 ? "\n…" : ""}\n\nNomor yang dihapus akan kosong di urutan bila bukan nomor terakhir.`))
        return;
    suratDB = suratDB.filter(x => !nsSel.has(x._id));
    if (nsEdit && nsSel.has(nsEdit))
        nsReset();
    nsSel.clear();
    persistSurat();
    renderSurat();
    nsAutoNo(true);
    nsPreview();
    toast(`${xs.length} nomor surat dihapus.`);
};
$("#nsQ").addEventListener("input", debounce(() => renderSurat(), 150));
$("#nsYear").addEventListener("change", e => { nsYear = tg(e).value; renderSurat(); });
$("#nsJenisF").addEventListener("change", () => renderSurat());
$("#nsStats").addEventListener("click", e => { const b = tg(e).closest("[data-nsj]"); if (!b)
    return; $("#nsJenisF").value = $("#nsJenisF").value === b.dataset.nsj ? "" : b.dataset.nsj ?? ""; renderSurat(); });
$("#nsTbl").addEventListener("click", async (e) => {
    const tr = tg(e).closest("tr[data-nsg]");
    if (!tr)
        return;
    const g = nsGroups.get(tr.dataset.nsg ?? "");
    if (!g)
        return;
    const x = g[0], z = g[g.length - 1], many = g.length > 1, rangeTxt = many ? `${nsNomor(x)} s.d. ${nsNomor(z)}` : nsNomor(x);
    if (tg(e).classList.contains("nsck")) {
        g.forEach(y => tg(e).checked ? nsSel.add(y._id) : nsSel.delete(y._id));
        tr.classList.toggle("on", tg(e).checked);
        nsSelUI();
        return;
    }
    const a = tg(e).closest("[data-nsa]")?.dataset.nsa;
    if (!a)
        return;
    if (a === "copy") {
        try {
            await navigator.clipboard.writeText(rangeTxt);
            toast("Disalin: " + rangeTxt);
        }
        catch (err) {
            toast(rangeTxt);
        }
    }
    if (a === "edit") {
        nsEdit = x._id;
        nsEditBatch = many ? x.batch ?? null : null;
        nsIn("jenis").value = x.jenis;
        nsIn("sifat").value = x.sifat == null ? "B" : x.sifat;
        nsIn("tgl").value = x.tgl;
        nsIn("kode").value = x.kode;
        nsKodeMode(x.kodeLain || !kodeMap()[x.kode]);
        nsIn("no").value = String(x.no);
        nsIn("perihal").value = x.perihal;
        $("#nsEndWrap").hidden = !many;
        nsIn("noEnd").value = many ? String(z.no) : "";
        nsIn("no").readOnly = nsIn("noEnd").readOnly = many;
        _nsAutoNo = false;
        $("#nsSave").textContent = many ? `Simpan perubahan (${g.length} nomor)` : "Simpan perubahan";
        $("#nsCancel").hidden = false;
        $("#nsFlag").hidden = false;
        $("#nsFlag").textContent = "Mengubah " + rangeTxt;
        nsPreview();
        window.scrollTo({ top: 0, behavior: "smooth" });
    }
    if (a === "dup") {
        nsReset();
        nsIn("jenis").value = x.jenis;
        nsIn("sifat").value = x.sifat == null ? "B" : x.sifat;
        nsIn("kode").value = x.kode;
        nsKodeMode(x.kodeLain || !kodeMap()[x.kode]);
        nsIn("perihal").value = x.perihal;
        nsAutoNo(true);
        if (many)
            nsIn("noEnd").value = String(parseInt(nsIn("no").value, 10) + g.length - 1);
        $("#nsCancel").hidden = false;
        $("#nsFlag").hidden = false;
        $("#nsFlag").textContent = "Salinan dari " + rangeTxt;
        nsPreview();
        window.scrollTo({ top: 0, behavior: "smooth" });
        nsIn("perihal").focus();
        nsIn("perihal").select();
        toast(`Salinan dibuat dengan nomor baru${many ? ` (${g.length} nomor)` : ""} — ubah perihal lalu simpan.`);
    }
    if (a === "del") {
        const last = nsNext(null, nsYearOf(z)) - 1 === parseInt(String(z.no), 10);
        if (!confirm(`Hapus ${many ? `${g.length} nomor (${rangeTxt})` : "nomor " + rangeTxt}?` + (last ? "" : "\n\nBukan nomor terakhir — akan ada nomor kosong di urutan.")))
            return;
        const del = new Set(g.map(y => y._id));
        suratDB = suratDB.filter(s0 => !del.has(s0._id));
        g.forEach(y => nsSel.delete(y._id));
        persistSurat();
        if (nsEdit && del.has(nsEdit))
            nsReset();
        renderSurat();
        nsAutoNo(true);
        nsPreview();
    }
});
/* ---------- format nomor ---------- */
function renderNsFmt() {
    $("#nsFmtRows").innerHTML = NS_JENIS.map(j => `<div class="c6"><label>${esc(j)}</label><input data-nsf="${esc(j)}" value="${esc(nsFmt[j])}"></div>`).join("");
}
$("#nsFmtRows").addEventListener("input", e => { const j = tg(e).dataset.nsf; if (!j)
    return; nsFmt[j] = tg(e).value.trim() || NS_FMT0[j]; persistSurat(); nsPreview(); renderSurat(); });
$("#nsFmtReset").onclick = () => { nsFmt = { ...NS_FMT0 }; persistSurat(); renderNsFmt(); nsPreview(); renderSurat(); toast("Format nomor kembali ke bawaan."); };
/* ---------- ekspor & impor Excel ---------- */
const NS_HDR = ["Jenis Surat", "Sifat", "No Urut", "Nomor Surat", "Tanggal", "Tahun", "Kode Klasifikasi", "Uraian Kode", "Perihal"];
$("#nsExp").onclick = () => {
    const list = suratDB.filter(x => nsYear === "semua" || String(nsYearOf(x)) === nsYear).sort((a, b) => (nsYearOf(a) || 0) - (nsYearOf(b) || 0) || a.no - b.no);
    if (!list.length)
        return toast("Belum ada nomor surat untuk diekspor.");
    const KM = kodeMap(), ws = XLSX.utils.aoa_to_sheet([NS_HDR, ...list.map(x => [x.jenis, x.sifat == null ? "B" : x.sifat, x.no, nsNomor(x), x.tgl, nsYearOf(x), x.kode, KM[x.kode]?.d || "", x.perihal])]);
    ws["!cols"] = [18, 6, 8, 30, 18, 7, 12, 34, 60].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Nomor Surat");
    XLSX.writeFile(wb, `Nomor Surat ${nsYear === "semua" ? "semua tahun" : nsYear} (${list.length}).xlsx`);
    toast(`${list.length} nomor surat diekspor.`);
};
$("#nsImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
        let rows = null, H = [];
        for (const sn of wb.SheetNames) {
            const a = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: "", raw: true });
            const hi = a.findIndex(r => r.some(c => /^perihal/i.test(String(c).trim())));
            if (hi >= 0) {
                H = a[hi].map(c => String(c).trim().toLowerCase());
                rows = a.slice(hi + 1);
                break;
            }
        }
        if (!rows)
            return toast("Kolom 'Perihal' tidak ditemukan. Pakai file hasil Ekspor.");
        const ix = (re) => H.findIndex(h => re.test(h)), cJ = ix(/^jenis/), cN = ix(/^no urut/), cNs = ix(/^nomor surat/), cT = ix(/^tanggal/), cK = ix(/^kode/), cP = ix(/^perihal/), cU = ix(/^tujuan|penerima/), cX = ix(/^keterangan/), cS = ix(/^sifat/);
        const cell = (r, i) => { const v = i < 0 ? "" : r[i]; return v instanceof Date ? fmtDate(new Date(v.getTime() + 12 * 36e5)) : String(v ?? "").trim(); };
        let add = 0, upd = 0, bad = 0;
        for (const r of rows) {
            const per = cell(r, cP);
            if (!per)
                continue;
            const jr = cell(r, cJ), jenis = NS_JENIS.find(j => acNorm(j) === acNorm(jr)) || NS_JENIS.find(j => acNorm(jr) && acNorm(j).includes(acNorm(jr))) || "Surat Keluar";
            let no = parseInt(cell(r, cN), 10);
            if (!no) {
                const m = cell(r, cNs).match(/\d+/);
                no = m ? +m[0] : 0;
            }
            const d = parseTgl(cell(r, cT));
            if (!no || !d) {
                bad++;
                continue;
            }
            const sf = (cS >= 0 ? cell(r, cS) : (cell(r, cNs).match(/^([A-Z]{1,4})-/) || [])[1] || (cell(r, cNs) && /^\d/.test(cell(r, cNs)) ? "" : "B")).toUpperCase();
            const x = { _id: newId(), jenis, sifat: sf.replace(/[^A-Z]/g, "").slice(0, 4), no, tgl: fmtDate(d), tahun: d.getFullYear(), kode: cell(r, cK).toUpperCase(), perihal: per, tujuan: cell(r, cU), ket: cell(r, cX) };
            const i = suratDB.findIndex(s0 => nsYearOf(s0) === x.tahun && parseInt(String(s0.no), 10) === x.no);
            if (i >= 0) {
                x._id = suratDB[i]._id;
                suratDB[i] = x;
                upd++;
            }
            else {
                suratDB.push(x);
                add++;
            }
        }
        persistSurat();
        renderSurat();
        nsAutoNo(true);
        nsPreview();
        toast(`Impor selesai: ${add} ditambahkan, ${upd} diperbarui` + (bad ? `, ${bad} baris dilewati (nomor/tanggal kosong)` : "") + ".");
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca file: " + err.message);
    }
});

/* ---- 80_anggaran.ts ---- */
/* ================= ANGGARAN: RPD · CATAT TUP · PERMINTAAN REVISI (dari detil POK) ================= */
/* RPD, TUP & Revisi disimpan per tahun anggaran (st.<nama>.<tahun>); tahun dipilih sendiri, terpisah dari POK aktif */
var rpdDB = {}, tupDB = {}, upDB = {}, revDB = [], rpdKet = {}, rabDB = [], rpdFinDB = {}, rpdSup = {};
const ANG_N = ["rpd", "rpdKet", "tup", "revisi", "rab", "rpdFin", "up", "rpdSup"];
const angK = (n, y) => `st.${n}.${y}`;
{
    const y0 = String(pokDB.meta?.tahun || pokYear); // migrasi data lama (tanpa tahun)
    for (const n of ANG_N) {
        const old = LS.get("st." + n, null);
        if (old != null) {
            if (LS.get(angK(n, y0), null) == null)
                LS.set(angK(n, y0), old);
            LS.del("st." + n);
        }
    }
}
let angYear = String(LS.get("st.angYear", "") || pokYear);
function angLoad(y) { rpdDB = LS.get(angK("rpd", y), {}); rpdKet = LS.get(angK("rpdKet", y), {}); tupDB = LS.get(angK("tup", y), {}); upDB = LS.get(angK("up", y), {}); rpdSup = LS.get(angK("rpdSup", y), {}); if (rpdSupMigrate())
    LS.set(angK("rpdSup", y), rpdSup); revDB = LS.get(angK("revisi", y), []); rabDB = LS.get(angK("rab", y), []); rpdFinDB = LS.get(angK("rpdFin", y), {}); }
angLoad(angYear);
const persistAng = () => { LS.set(angK("rpd", angYear), rpdDB); LS.set(angK("rpdKet", angYear), rpdKet); LS.set(angK("tup", angYear), tupDB); LS.set(angK("up", angYear), upDB); LS.set(angK("rpdSup", angYear), rpdSup); LS.set(angK("revisi", angYear), revDB); LS.set(angK("rab", angYear), rabDB); LS.set(angK("rpdFin", angYear), rpdFinDB); };
const angPok = () => pokGet(angYear) || { meta: { tahun: angYear }, akun: [] };
const angYearsOpt = () => { const cy = new Date().getFullYear(); return [...new Set([...pokYears(), angYear, String(cy), String(cy + 1)])].sort(); };
function angRefresh() { angYearUI(); const v = document.querySelector(".view.on")?.id; if (v === "v-rpd")
    renderRpd(); if (v === "v-tup")
    renderTup(); if (v === "v-revisi")
    renderRev(); if (v === "v-rab")
    renderRab(); if (v === "v-rablist")
    renderRabList(); }
function angSetYear(y0, quiet) { const y = String(y0); if (y === angYear)
    return; angYear = y; LS.set("st.angYear", y); angLoad(y); _detC = null; rpdOpen.clear(); angRefresh(); if (!quiet)
    toast(`Tahun anggaran RPD/TUP/Revisi: ${y}`); }
function angYearUI() {
    const opts = angYearsOpt().map(y => `<option value="${y}" ${y === angYear ? "selected" : ""}>T.A. ${y}${pokGet(y) ? (pokGet(y)?.meta?.draft ? " (POK rancangan)" : "") : " (POK belum ada)"}${y === pokYear ? " · POK aktif" : ""}</option>`).join("");
    $$(".angYear").forEach(el => el.innerHTML = opts);
    const no = !pokGet(angYear), base = pokYears().filter(y => y !== angYear).at(-1);
    $$(".angNoPok").forEach(el => { el.hidden = !no; el.innerHTML = no ? `⚠ <b>POK T.A. ${angYear} belum ada.</b> Unggah POK ${angYear} di menu Database › POK (POK aktif tidak berubah)${base ? `, atau mulai dulu dengan salinan POK ${base} sebagai rancangan. <button class="btn sm" type="button" data-angcopy="${base}">Pakai POK ${base} sebagai rancangan ${angYear}</button>` : "."} <button class="btn sm" type="button" data-anggo="1">Buka Database POK</button>` : ""; });
}
document.addEventListener("change", e => { if (tg(e).classList?.contains("angYear"))
    angSetYear(tg(e).value); });
document.addEventListener("click", e => {
    const c = tg(e).closest("[data-angcopy]")?.dataset.angcopy;
    if (c) {
        const src = pokGet(c);
        if (!src)
            return;
        const d = clone(src);
        d.meta = { ...(d.meta || {}), tahun: angYear, tanggal: "", draft: true, dasar: c };
        pokSave(angYear, d);
        _dataVer++;
        angRefresh();
        toast(`POK ${c} disalin sebagai rancangan T.A. ${angYear}. Ganti dengan POK ${angYear} asli saat sudah terbit.`);
        return;
    }
    if (tg(e).closest("[data-anggo]"))
        show("pok");
});
const BLN_S = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"], TWN = ["TW I", "TW II", "TW III", "TW IV"];
/* semua detil POK: kunci = MAK + nama detil (tetap walau POK diimpor ulang) */
let _detC = null, _detV = -1, _detY = null;
function detKeysOf(pok) {
    const out = [], seen = {};
    for (const a of (pok && pok.akun) || [])
        a.items.forEach((it, i) => { const u = String(it.u || "").trim() || a.kompNama; let key = a.mak + "#" + acNorm(u); seen[key] = (seen[key] || 0) + 1; if (seen[key] > 1)
            key += "#" + seen[key]; out.push({ mak: a.mak, i, j: num(it.j), key }); });
    return out;
}
/* POK tahun y diganti (impor ulang): pindahkan isian RPD/TUP/Revisi dari kunci lama ke kunci baru
   (detil dipasangkan per MAK menurut urutan bila jumlahnya sama, selain itu menurut nilai) */
function angRemap(y, oldP, newP) {
    if (!oldP || !newP)
        return 0;
    const O = detKeysOf(oldP), N = detKeysOf(newP), byMak = (m) => N.filter(x => x.mak === m), map = {};
    for (const mk of [...new Set(O.map(x => x.mak))]) {
        const os = O.filter(x => x.mak === mk), ns = byMak(mk);
        if (!ns.length)
            continue;
        if (os.length === ns.length)
            os.forEach((o, i) => { if (o.key !== ns[i].key)
                map[o.key] = ns[i].key; });
        else {
            const used = new Set();
            for (const o of os) {
                if (ns.some(n => n.key === o.key)) {
                    used.add(o.key);
                    continue;
                }
                const n = ns.find(n => !used.has(n.key) && n.j === o.j && !os.some(x => x.key === n.key));
                if (n) {
                    used.add(n.key);
                    map[o.key] = n.key;
                }
            }
        }
    }
    const ks = Object.keys(map);
    if (!ks.length)
        return 0;
    const mv = (obj) => { if (!obj)
        return obj; const o = obj; for (const k of ks)
        if (k in o && !(map[k] in o)) {
            o[map[k]] = o[k];
            delete o[k];
        } return obj; };
    const rpd = mv(LS.get(angK("rpd", y), null)), ket = mv(LS.get(angK("rpdKet", y), null)), tup = LS.get(angK("tup", y), null), rev = LS.get(angK("revisi", y), null);
    if (tup)
        for (const t of Object.values(tup)) {
            mv(t.val);
            mv(t.nama);
            mv(t.kt);
            if (t.add)
                t.add = t.add.map((k) => map[k] || k);
            if (t.excl)
                t.excl = t.excl.map((k) => map[k] || k);
        }
    if (Array.isArray(rev))
        rev.forEach(x => { if (map[x.key])
            x.key = map[x.key]; });
    const rab = LS.get(angK("rab", y), null);
    if (Array.isArray(rab)) {
        for (const d of rab) {
            for (const l of d.items || [])
                if (map[l.key])
                    l.key = map[l.key];
            for (const t of d.trips || [])
                if (map[t.key])
                    t.key = map[t.key];
            for (const r of d.rpdIn || [])
                if (map[r.key])
                    r.key = map[r.key];
        }
        LS.set(angK("rab", y), rab);
    }
    if (rpd)
        LS.set(angK("rpd", y), rpd);
    if (ket)
        LS.set(angK("rpdKet", y), ket);
    if (tup)
        LS.set(angK("tup", y), tup);
    if (rev)
        LS.set(angK("revisi", y), rev);
    if (y === angYear)
        angLoad(y);
    return ks.length;
}
function pokDetil() {
    if (_detC && _detV === _dataVer && _detY === angYear)
        return _detC;
    const out = [], seen = {};
    for (const a of angPok().akun)
        a.items.forEach(it => {
            const u = String(it.u || "").trim() || a.kompNama;
            let key = a.mak + "#" + acNorm(u);
            seen[key] = (seen[key] || 0) + 1;
            if (seen[key] > 1)
                key += "#" + seen[key];
            out.push({ key, a, u, j: num(it.j), blokir: !!it.b, v: it.v, s: it.s, h: it.h });
        });
    _detC = out;
    _detV = _dataVer;
    _detY = angYear;
    return out;
}
const detMap = () => Object.fromEntries(pokDetil().map(d => [d.key, d]));
const detLabel = (d) => `${d.u} — ${d.a.mak}`;
const rpdOf = (k) => rpdDB[k] || (rpdDB[k] = Array(12).fill(0));
const rpdSum = (k, from = 0, to = 12) => (rpdDB[k] || []).slice(from, to).reduce((s, v) => s + num(v), 0);
const tw = (k, t) => rpdSum(k, t * 3, t * 3 + 3);
function detilAc(q) {
    const toks = acNorm(q).split(/\s+/).filter(Boolean), res = [];
    const noAk51 = !!AC.el?.closest("#tupTbl");
    for (const d of pokDetil()) {
        if (noAk51 && /^51/.test(String(d.a.akun)))
            continue;
        const h = acNorm(d.u + " " + d.a.mak + " " + d.a.roNama + " " + d.a.kompNama + " " + d.a.nama);
        if (toks.length && !toks.every(t => h.includes(t)))
            continue;
        res.push({ v: detLabel(d), key: d.key, html: `<span class="d"><b>${acHi(d.u, toks)}</b><small>${esc(d.a.mak)} · ${esc(d.a.nama)} · pagu Rp ${rupiah(d.j)}</small></span>`, score: 0 });
        if (res.length > 150)
            break;
    }
    return res;
}
const keyFromInput = (el) => { const k0 = el.dataset.key; if (k0 && detMap()[k0] && detLabel(detMap()[k0]) === el.value)
    return k0; const d = pokDetil().find(x => detLabel(x) === el.value.trim()); return d ? d.key : null; };
/* ================= RPD ================= */
let rpdOpen = new Set(), rpdBlk = new Set(), rpdTw = LS.get("st.rpdTw", Math.floor(new Date().getMonth() / 3)), rpdRoSel = LS.get("st.rpdRo", "");
// rpdKet: keterangan per detil per triwulan { key: ["", "", "", ""] } — dimuat per tahun oleh angLoad()
const rpdKetOf = (k) => rpdKet[k] || (rpdKet[k] = ["", "", "", ""]);
/* supplier RPD: per detil per BULAN; dipilih lewat pop-up — boleh beberapa supplier, RAB dan Surat Tugas sekaligus.
   Surat tugas tertaut dicatat sebagai nama petugasnya, tiap nama satu kali. Data lama (per triwulan) disalin ke tiga bulan triwulannya. */
const rpdSupRefs = (x) => !x ? [] : x.refs ? x.refs : x.ref ? [x.ref] : [];
function rpdSupMigrate() {
    let ch = false;
    for (const k of Object.keys(rpdSup)) {
        const a = rpdSup[k];
        if (!Array.isArray(a) || a.length > 4)
            continue;
        // (dipanggil dari angLoad saat modul dimuat → tidak boleh memakai const yang dideklarasikan di bawahnya)
        const n = [];
        for (let m = 0; m < 12; m++) {
            const o = a[Math.floor(m / 3)], refs = o ? (o.refs || (o.ref ? [o.ref] : [])) : [];
            n.push(o && o.t ? (refs.length ? { t: o.t, refs: refs.slice() } : { t: o.t, s: [o.t] }) : { t: "" });
        }
        rpdSup[k] = n;
        ch = true;
    }
    return ch;
}
const rpdSupOf = (k) => { const a = rpdSup[k] || (rpdSup[k] = []); for (let i = 0; i < 12; i++)
    a[i] ||= { t: "" }; return a; };
const rpdSupGet = (k, m) => { const x = (rpdSup[k] || [])[m]; return x && x.t ? x : undefined; };
const uniqNames = (xs) => { const seen = new Set(), out = []; for (const x of xs) {
    const t = String(x || "").trim(), key = acNorm(t);
    if (!t || seen.has(key))
        continue;
    seen.add(key);
    out.push(t);
} return out; };
/** supplier satu triwulan (gabungan tiga bulannya, tanpa duplikat) */
const rpdSupTw = (k, t) => uniqNames([0, 1, 2].flatMap(j => (rpdSupGet(k, t * 3 + j)?.t || "").split(/\s*,\s*/))).join(", ");
/** nama petugas surat tugas (pelaksana + anggota), tanpa gelar */
const stNames = (r) => { const P = pegMap(); return personCodes(r, P).map(c => String(P[c]?.nama || "").split(",")[0].trim()).filter(Boolean); };
function rpdSupText(sup, refs) {
    const rab = refs.filter(x => x.startsWith("rab:")).map(x => rabDB.find(d => d._id === x.slice(4))?.nama || "");
    const st = refs.filter(x => x.startsWith("st:")).flatMap(x => { const r = records.find(y => y._id === x.slice(3)); return r ? stNames(r) : []; });
    return uniqNames([...sup, ...rab, ...st]).join(", ");
}
function rpdSupGo(ref) {
    if (!ref)
        return;
    const [ty, id] = ref.split(":");
    if (ty === "rab") {
        if (!rabDB.some(x => x._id === id))
            return toast("RAB yang ditautkan sudah tidak ada.", "warn");
        rabCur = id;
        LS.set("st.rabCur", id);
        $("#rabHead").dataset.new = "";
        show("rab");
        return;
    }
    if (ty === "st") {
        const r = records.find(x => x._id === id);
        if (!r)
            return toast("Surat tugas yang ditautkan sudah tidak ada.", "warn");
        openPreview([r], `Surat tugas ${compute(r).NOMOR_ST} (tautan supplier RPD) — hanya lihat`);
    }
}
/* supplier hanya berisi NAMA: tautan surat tugas dicatat sebagai nama petugasnya, bukan nomor surat.
   Isian lama ("ST B-…/2026 — Nama") dirapikan saat RPD dibuka. */
const rpdSupNoSt = (t) => uniqNames(String(t || "").split(/\s*,\s*/).map(x => x.replace(/^ST\s+\S+\s*[—–-]\s*/i, "").replace(/^ST\s+B-\S+$/i, ""))).join(", ");
function rpdSupNamesOnly() {
    let ch = false;
    for (const a of Object.values(rpdSup))
        for (const x of a || []) {
            if (!x || !x.t)
                continue;
            const refs = rpdSupRefs(x), want = refs.some(r => r.startsWith("st:")) ? (rpdSupText(x.s || [], refs) || rpdSupNoSt(x.t)) : rpdSupNoSt(x.t);
            if (want !== x.t) {
                x.t = want;
                if (x.ref) {
                    x.refs = refs;
                    delete x.ref;
                }
                ch = true;
            }
        }
    if (ch)
        persistAng();
}
/** buka semua surat tugas yang tertaut ke supplier bulan ini */
function rpdSupGoSt(x) {
    const rs = rpdSupRefs(x).filter(r => r.startsWith("st:")).map(r => records.find(y => y._id === r.slice(3))).filter((r) => !!r);
    if (!rs.length)
        return toast("Surat tugas yang ditautkan sudah tidak ada.", "warn");
    openPreview(rs, `${rs.length} surat tugas (tautan supplier RPD) — hanya lihat`);
}
/** supplier yang pernah dicatat (RPD, Catat TUP, Catat UP) — pilihan di pop-up */
function rpdSupKnown() {
    const xs = [];
    for (const a of Object.values(rpdSup))
        for (const x of a || [])
            if (x)
                xs.push(...(x.s || (rpdSupRefs(x).length ? [] : [x.t])));
    for (const db of [tupDB, upDB])
        for (const mo of Object.values(db))
            for (const f of Object.values(mo?.f || {}))
                if (f && typeof f.sup === "string")
                    xs.push(f.sup);
    return uniqNames(xs).sort((a, b) => a.localeCompare(b));
}
/* ---- pop-up pilih supplier & tautan (multi-pilih) ---- */
let rsu = null;
function rpdSupOpen(k, m) {
    const x = (rpdSup[k] || [])[m], refs = rpdSupRefs(x), d = detMap()[k];
    rsu = { k, m, st: new Set(refs.filter(r => r.startsWith("st:")).map(r => r.slice(3))), rab: new Set(refs.filter(r => r.startsWith("rab:")).map(r => r.slice(4))), sup: (x?.s || (x?.t && !refs.length ? [x.t] : [])).slice(), extra: [] };
    $("#rsuH").innerHTML = `Supplier &amp; tautan · ${esc(BULAN[m])} ${esc(angYear)} <span class="muted" style="font-weight:400;font-size:13px">— ${esc(String(d?.u || "").slice(0, 70))}</span>`;
    $("#rsuQ").value = "";
    $("#rsuNew").value = "";
    rpdSupRender();
    $("#dRpdSup").showModal();
    $("#rsuQ").focus();
}
function rpdSupRender() {
    if (!rsu)
        return;
    const R = rsu, toks = acNorm($("#rsuQ").value.trim()).split(/\s+/).filter(Boolean), hit = (h) => !toks.length || toks.every(t => acNorm(h).includes(t));
    const mak = normMak(detMap()[R.k]?.a.mak || ""), same = (r) => !!mak && normMak(r.MAK) === mak;
    const rs = [...records].sort(byYearNo).reverse().filter(r => R.st.has(r._id ?? "") || (toks.length ? toks.every(t => hayOf(r).includes(t)) : true))
        .sort((a, b) => +R.st.has(b._id ?? "") - +R.st.has(a._id ?? "") || +same(b) - +same(a));
    $("#rsuSt").innerHTML = rs.slice(0, 150).map(r => {
        const F = computeC(r), on = R.st.has(r._id ?? "");
        return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="st" value="${esc(r._id)}" ${on ? "checked" : ""}><span><b>${esc(stNames(r).join(", ") || "(tanpa petugas)")}</b>${same(r) ? ` <span class="tag ok">MAK sama</span>` : ""}<small>${esc(String(F.MAKSUD__TUJUAN || "").slice(0, 70))} · ${esc(F.TGL_PERGI || "")} · ${esc(F.NOMOR_ST)}</small></span></label>`;
    }).join("")
        + (rs.length > 150 ? `<div class="muted" style="font-size:12px;padding:6px">${rs.length - 150} surat lain — persempit dengan kolom cari.</div>` : "") || `<div class="muted" style="padding:10px;font-size:12.5px">Tidak ada surat tugas yang cocok.</div>`;
    const sups = uniqNames([...R.sup, ...R.extra, ...rpdSupKnown()]), selSup = new Set(R.sup.map(acNorm));
    $("#rsuSup").innerHTML = [...rabDB].reverse().filter(d => R.rab.has(d._id) || hit(d.nama + " " + d.ro + " rab")).map(d => {
        const on = R.rab.has(d._id);
        return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="rab" value="${esc(d._id)}" ${on ? "checked" : ""}><span><b><span class="tag">RAB</span> ${esc(d.nama)}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></span></label>`;
    }).join("")
        + sups.filter(n => selSup.has(acNorm(n)) || hit(n)).map(n => { const on = selSup.has(acNorm(n)); return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="sup" value="${esc(n)}" ${on ? "checked" : ""}><span><b>${esc(n)}</b></span></label>`; }).join("")
        || `<div class="muted" style="padding:10px;font-size:12.5px">Belum ada supplier — ketik nama di bawah lalu Tambah.</div>`;
    $("#rsuNSt").textContent = R.st.size + " dipilih";
    $("#rsuNSup").textContent = (R.sup.length + R.rab.size) + " dipilih";
    const refs = [...[...R.rab].map(i => "rab:" + i), ...[...R.st].map(i => "st:" + i)], t = rpdSupText(R.sup, refs);
    $("#rsuOut").innerHTML = t ? `Tercatat sebagai: <b>${esc(t)}</b>${R.st.size ? ` <span class="muted">— nama petugas dari ${R.st.size} surat tugas, tiap nama satu kali</span>` : ""}` : `<span class="muted">Belum ada yang dipilih.</span>`;
}
$("#dRpdSup").addEventListener("change", e => {
    const t = tg(e), ty = t.dataset.rsu;
    if (!rsu || !ty)
        return;
    if (ty === "st")
        t.checked ? rsu.st.add(t.value) : rsu.st.delete(t.value);
    else if (ty === "rab")
        t.checked ? rsu.rab.add(t.value) : rsu.rab.delete(t.value);
    else {
        rsu.sup = rsu.sup.filter(n => acNorm(n) !== acNorm(t.value));
        if (t.checked)
            rsu.sup.push(t.value);
    }
    rpdSupRender();
});
$("#rsuQ").addEventListener("input", debounce(() => rpdSupRender(), 120));
const rsuAddNew = () => { const v = $("#rsuNew").value.trim(); if (!rsu || !v)
    return; if (!rsu.sup.some(n => acNorm(n) === acNorm(v)))
    rsu.sup.push(v); rsu.extra.push(v); $("#rsuNew").value = ""; rpdSupRender(); $("#rsuNew").focus(); };
$("#rsuAdd").onclick = rsuAddNew;
$("#rsuNew").addEventListener("keydown", (e) => { if (e.key === "Enter") {
    e.preventDefault();
    rsuAddNew();
} });
$("#rsuCancel").onclick = () => { rsu = null; $("#dRpdSup").close(); };
$("#rsuClr").onclick = () => { if (!rsu)
    return; rsu.st.clear(); rsu.rab.clear(); rsu.sup = []; rpdSupRender(); };
$("#rsuOk").onclick = () => {
    if (!rsu)
        return;
    const R = rsu, x = rpdSupOf(R.k)[R.m], refs = [...[...R.rab].map(i => "rab:" + i), ...[...R.st].map(i => "st:" + i)];
    x.t = rpdSupText(R.sup, refs);
    delete x.ref;
    if (refs.length)
        x.refs = refs;
    else
        delete x.refs;
    if (R.sup.length)
        x.s = R.sup.slice();
    else
        delete x.s;
    persistAng();
    rsu = null;
    $("#dRpdSup").close();
    renderRpd();
    toast(x.t ? `Supplier ${BULAN[R.m]} dicatat: ${x.t.slice(0, 80)}${x.t.length > 80 ? "…" : ""}` : `Supplier ${BULAN[R.m]} dikosongkan.`, "ok");
};
/* triwulan yang sudah lewat (menurut tanggal komputer) tidak bisa diisi lagi */
const rpdYear = () => +angYear || new Date().getFullYear();
function rpdLockTw(t) { const now = new Date(), y = rpdYear(); return y < now.getFullYear() || (y === now.getFullYear() && t < Math.floor(now.getMonth() / 3)); }
const rpdFinM = (m) => !!tupDB[m]?.fin || !!upDB[m]?.fin;
/** detil dasar TUP (tanpa akun 51) */
const rpdTupDet = () => pokDetil().filter(d => !/^51/.test(String(d.a.akun)));
/** Total Permintaan RPD Awal bulan m: nilai yang dikunci di RPD; bila belum dikunci → RPD sebelum finalisasi TUP (atau RPD saat ini) */
function rpdAwal(m) {
    const L = rpdFinDB[m];
    if (L)
        return { total: L.total, locked: true, tgl: L.tgl };
    const prev = tupDB[m]?.fin?.prev || {};
    let s = 0;
    for (const d of rpdTupDet())
        s += d.key in prev ? num(prev[d.key]) : num((rpdDB[d.key] || [])[m]);
    return { total: s, locked: false, tgl: "" };
}
/* ---------- Finalisasi RPD: kunci / buka kunci Total Permintaan RPD Awal, per bulan ---------- */
const rpdCurTot = (m) => rpdTupDet().reduce((s0, d) => s0 + num((rpdDB[d.key] || [])[m]), 0);
let rfSel = new Set();
function rpdFinOpen(m0) {
    rfSel = new Set(m0 != null ? [m0] : [Math.min(11, Math.max(0, rpdTw * 3 + (new Date().getFullYear() === rpdYear() ? new Date().getMonth() % 3 : 0)))]);
    rpdFinRender();
    $("#dRpdFin").showModal();
}
function rpdFinRender() {
    $("#rfMonths").innerHTML = BULAN.map((b, m) => {
        const L = rpdFinDB[m], cur = rpdCurTot(m), on = rfSel.has(m);
        return `<button type="button" class="rfm ${L ? "lk" : ""} ${on ? "sel" : ""}" data-rfm="${m}" aria-pressed="${on}" title="Klik untuk memilih / batal memilih ${b}"><small>${on ? "☑" : "☐"} ${BLN_S[m]}</small><b>${rpShort(L ? L.total : cur).replace("Rp ", "")}</b><span>${L ? `🔒 dikunci ${esc(L.tgl)}` : "🔓 belum dikunci"}</span>${L && L.total !== cur ? `<span class="muted">RPD sekarang ${rpShort(cur).replace("Rp ", "")}</span>` : ""}</button>`;
    }).join("");
    const sel = [...rfSel].sort((a, b) => a - b), nL = sel.filter(m => rpdFinDB[m]).length, nU = sel.length - nL;
    $("#rfInfo").textContent = sel.length ? `Dipilih: ${sel.map(m => BLN_S[m]).join(", ")} — ${nU} belum dikunci, ${nL} sudah dikunci` : "Pilih bulan dulu (klik kotak bulan).";
    $("#rfLock").disabled = !nU;
    $("#rfUnlock").disabled = !nL;
    $("#rfLock").textContent = `🔒 Kunci ${nU || ""} bulan terpilih`.replace("  ", " ");
    $("#rfUnlock").textContent = `🔓 Buka kunci ${nL || ""} bulan terpilih`.replace("  ", " ");
}
/** kunci (lock=true) atau buka kunci bulan-bulan ms; satu konfirmasi */
function rpdFinSet(ms, lock) {
    const list = ms.filter(m => lock ? !rpdFinDB[m] : !!rpdFinDB[m]).sort((a, b) => a - b);
    if (!list.length)
        return false;
    const txt = list.map(m => `• ${BULAN[m]}: Rp ${rupiah(lock ? rpdCurTot(m) : rpdFinDB[m].total)}`).join("\n");
    if (!confirm(lock ? `Finalisasi RPD ${angYear} — kunci Total Permintaan RPD Awal (tanpa akun 51):\n\n${txt}\n\nIsian RPD tetap bisa diubah; yang dikunci hanya nilai total awal sebagai pembanding Catat TUP.` : `Buka kunci RPD awal ${angYear}:\n\n${txt}`))
        return false;
    for (const m of list) {
        if (!lock) {
            delete rpdFinDB[m];
            continue;
        }
        const val = {};
        let tot = 0;
        for (const d of rpdTupDet()) {
            const v = num((rpdDB[d.key] || [])[m]);
            if (v) {
                val[d.key] = v;
                tot += v;
            }
        }
        rpdFinDB[m] = { tgl: today(), total: tot, val };
    }
    persistAng();
    toast(`${lock ? "RPD awal dikunci" : "Kunci RPD awal dibuka"}: ${list.map(m => BULAN[m]).join(", ")}.`, lock ? "ok" : "info");
    return true;
}
$("#rpdFinBtn").onclick = () => rpdFinOpen();
$("#rfClose").onclick = () => { $("#dRpdFin").close(); renderRpd(); };
$("#rfMonths").addEventListener("click", e => { const m = Number(tg(e).closest("[data-rfm]")?.dataset.rfm ?? -1); if (m < 0)
    return; rfSel.has(m) ? rfSel.delete(m) : rfSel.add(m); rpdFinRender(); });
$("#rfAll").onclick = () => { rfSel = rfSel.size === 12 ? new Set() : new Set([...Array(12).keys()]); rpdFinRender(); };
$("#rfLock").onclick = () => { if (rpdFinSet([...rfSel], true))
    rpdFinRender(); };
$("#rfUnlock").onclick = () => { if (rpdFinSet([...rfSel], false))
    rpdFinRender(); };
/* gembok di judul kolom bulan RPD: kunci / buka kunci bulan itu langsung */
$("#rpdTbl").addEventListener("click", e => { const b = tg(e).closest("[data-rfh]"); if (!b)
    return; e.stopPropagation(); const m = Number(b.dataset.rfh); if (rpdFinSet([m], !rpdFinDB[m]))
    renderRpd(); });
const rpdLockM = (m) => rpdLockTw(Math.floor(m / 3)) || rpdFinM(m);
const rpdOpenM = () => [...Array(12).keys()].filter(m => !rpdLockM(m));
const roOf = (d) => d.a.ro;
const roTitle = (n) => cleanRoNama(n);
const fmtVol = (v) => v == null ? "" : Number.isInteger(+v) ? (+v).toFixed(1) : String(v);
const volTxt = (d) => d.h != null && d.v != null ? `(${fmtVol(d.v)} ${esc(d.s || "")} @ ${rupiah(d.h)})` : "";
let rpdAkOpen = new Set(), rpdAkAll = false, rpdHide0 = !!LS.get("st.rpdHide0", false);
function rpdScope() {
    const D = pokDetil();
    return rpdRoSel === "*" || !rpdRoSel ? D : D.filter(d => roOf(d) === rpdRoSel);
}
function rpdKpi() {
    const S = rpdScope(), A = S.filter(d => !d.blokir), B = S.filter(d => d.blokir), t = rpdTw, m0 = t * 3;
    const pagu = A.reduce((s, d) => s + d.j, 0), tot = A.reduce((s, d) => s + rpdSum(d.key), 0), twv = A.reduce((s, d) => s + tw(d.key, t), 0);
    const scope = rpdRoSel && rpdRoSel !== "*" ? rpdRoSel : "semua RO";
    $("#rpdSum").innerHTML = [
        ["Pagu (tanpa blokir)", rpShort(pagu), `${A.length} detil · ${scope}`],
        [`RPD ${TWN[t]}${rpdLockTw(t) ? " 🔒" : ""}`, rpShort(twv), [0, 1, 2].map(j => `${BLN_S[m0 + j]} ${rpShort(A.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0))}`).join(" · ")],
        ["Total RPD setahun", rpShort(tot), pagu ? Math.round(tot / pagu * 100) + "% dari pagu" : ""],
        ["Belum direncanakan", rpShort(pagu - tot), `${A.filter(d => !rpdSum(d.key)).length} detil kosong`, pagu - tot < 0],
        ["Detil blokir", B.length, B.length ? `Rp ${rupiah(B.reduce((s, d) => s + d.j, 0))} · disembunyikan` : "tidak ada"]
    ]
        .map(([k, v, sub, bad]) => `<div class="kpi ${bad ? "bad" : ""}"><small>${k}</small><b>${v}</b><span class="sub">${sub}</span></div>`).join("");
    const OV = A.filter(d => rpdSum(d.key) > d.j);
    $("#rpdWarn").hidden = !OV.length;
    $("#rpdWarn").innerHTML = OV.length ? `⚠ <b>${OV.length} detil RPD melebihi pagu</b> (lebih Rp ${rupiah(OV.reduce((s, d) => s + rpdSum(d.key) - d.j, 0))})${rpdRoSel && rpdRoSel !== "*" ? "" : " di semua RO"}. Detil tersebut <b>tidak dimunculkan di Catat TUP</b> sampai RPD-nya diperbaiki. <button class="btn sm" type="button" id="rpdWarnGo">Tampilkan detilnya</button>` : "";
    $("#rpdTwChips").innerHTML = TWN.map((n, i) => {
        const v = A.reduce((s, d) => s + tw(d.key, i), 0), lk = rpdLockTw(i);
        return `<button type="button" class="twchip ${i === t ? "on" : ""} ${lk ? "lock" : ""}" data-twc="${i}" title="${lk ? "Triwulan sudah lewat — hanya bisa dilihat" : ""}"><b>${n}${lk ? " 🔒" : ""}</b><span>${BLN_S[i * 3]} – ${BLN_S[i * 3 + 2]}${lk ? " · sudah lewat" : ""}</span><small>${v ? "Rp " + rupiah(v) : "belum diisi"}</small></button>`;
    }).join("");
}
function renderRpd() {
    rpdSupNamesOnly();
    angYearUI();
    const D = pokDetil(), q = acNorm($("#rpdQ").value.trim()).split(/\s+/).filter(Boolean), st = $("#rpdSt").value, t = rpdTw, m0 = t * 3, lock = rpdLockTw(t);
    const ros = [...new Map(angPok().akun.map((a) => [a.ro, a.roNama])).entries()].sort((a, b) => a[0].localeCompare(b[0]));
    if (rpdRoSel && rpdRoSel !== "*" && !ros.some(r => r[0] === rpdRoSel))
        rpdRoSel = "";
    $("#rpdRo").innerHTML = `<option value="">— Pilih MAK / RO —</option><option value="*">Semua RO</option>` + ros.map(([k, n]) => `<option value="${esc(k)}">${esc(k)} ${esc(roTitle(n).slice(0, 70))}</option>`).join("");
    $("#rpdRo").value = rpdRoSel;
    $("#rpdBack").hidden = !rpdRoSel;
    $("#rpdAkAll").hidden = !rpdRoSel && !q.length;
    $("#rpdAkAll").textContent = rpdAkAll || rpdAkOpen.size ? "Tutup semua akun" : "Buka semua akun";
    const now = new Date();
    const finM = [0, 1, 2].map(j => m0 + j).filter(rpdFinM);
    $("#rpdLock").hidden = !lock && !finM.length;
    $("#rpdLock").innerHTML = lock ? `🔒 <b>${TWN[t]} ${rpdYear()} sudah lewat</b> (tanggal komputer ${now.getDate()} ${BULAN[now.getMonth()]} ${now.getFullYear()}). Isian dan keterangan hanya bisa dilihat, tidak bisa diubah.`
        : finM.length ? `🔒 <b>${finM.map(m => BULAN[m]).join(", ")} terkunci</b> — TUP bulan itu sudah difinalisasi, nilai RPD mengikuti Catat TUP. Untuk mengubah, batalkan finalisasi di Catat TUP.` : "";
    $("#rpdTbl thead").innerHTML = `<tr><th style="width:26px"></th><th>${rpdRoSel || q.length ? "Detil POK" : "MAK / RO"}</th><th class="num" style="width:108px">Pagu</th>${[0, 1, 2].map(j => `<th class="num c-m" style="width:88px">${BULAN[m0 + j]} <button type="button" class="rfh ${rpdFinDB[m0 + j] ? "on" : ""}" data-rfh="${m0 + j}" title="${rpdFinDB[m0 + j] ? `RPD awal ${BULAN[m0 + j]} dikunci ${esc(rpdFinDB[m0 + j].tgl)} (Rp ${rupiah(rpdFinDB[m0 + j].total)}) — klik untuk membuka kunci` : `Klik untuk mengunci RPD awal ${BULAN[m0 + j]}`}">${rpdFinDB[m0 + j] ? "🔒" : "🔓"}</button>${tupDB[m0 + j]?.fin ? ` <span class="tag ok" title="TUP ${BULAN[m0 + j]} sudah difinalisasi — RPD bulan ini = realisasi TUP">final TUP</span>` : ""}${upDB[m0 + j]?.fin ? ` <span class="tag ok" title="UP ${BULAN[m0 + j]} sudah difinalisasi — RPD detil UP = realisasi UP">final UP</span>` : ""}</th>`).join("")}<th class="c-k" style="width:210px">Keterangan</th><th class="num" style="width:112px">Sisa pagu</th></tr>`;
    rpdKpi();
    // langkah 1: belum pilih RO → daftar RO untuk dipilih
    if (!rpdRoSel && !q.length) {
        const html = ros.map(([r, n]) => {
            const ds = D.filter(d => roOf(d) === r && !d.blokir), nb = D.filter(d => roOf(d) === r && d.blokir).length, pg = ds.reduce((s, d) => s + d.j, 0), tt = ds.reduce((s, d) => s + rpdSum(d.key), 0), nk = ds.filter(d => (rpdKet[d.key] || [])[t]).length;
            if (rpdHide0 && pg - tt === 0)
                return "";
            return `<tr class="rpd-pick" data-ro="${esc(r)}"><td class="chev">▸</td><td><div class="lt-title"><span class="rocode">${esc(r)}</span> ${esc(roTitle(n))}</div><div class="lsub one">${ds.length} detil${nb ? ` · ${nb} blokir` : ""}${ds.some(d => rpdSum(d.key) > d.j) ? ` · <span class="bad">⚠ ${ds.filter(d => rpdSum(d.key) > d.j).length} melebihi pagu</span>` : ""}</div></td><td class="num">${rupiah(pg)}</td>${[0, 1, 2].map(j => { const v = ds.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0); return `<td class="num">${v ? rupiah(v) : `<span class="muted">–</span>`}</td>`; }).join("")}<td class="muted" style="font-size:12px">${nk ? nk + " keterangan" : ""}</td><td class="num ${pg - tt < 0 ? "bad" : ""}">${rupiah(pg - tt)}</td></tr>`;
        }).join("");
        $("#rpdTbl tbody").innerHTML = html || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">POK T.A. ${angYear} belum ada.</td></tr>`;
        $("#rpdInfo").textContent = `${ros.length} MAK/RO · pilih salah satu untuk ${lock ? "melihat" : "mengisi"} RPD ${TWN[t]}`;
        return;
    }
    const fit = (d) => (!q.length || q.every(x => acNorm(d.u + " " + d.a.mak + " " + d.a.nama + " " + d.a.roNama + " " + (rpdKet[d.key] || []).join(" ")).includes(x)))
        && (!st || (st === "isi" ? rpdSum(d.key) > 0 : st === "kosong" ? rpdSum(d.key) === 0 : st === "twkosong" ? tw(d.key, t) === 0 : rpdSum(d.key) > d.j))
        && (!rpdHide0 || d.j - rpdSum(d.key) !== 0);
    const list = (rpdRoSel && rpdRoSel !== "*" ? D.filter(d => roOf(d) === rpdRoSel) : D).filter(fit);
    const byRo = new Map();
    for (const d of list) {
        const r = roOf(d);
        byRo.set(r, [...(byRo.get(r) || []), d]);
    }
    const dis = lock ? "disabled" : "", nLock = 12 - rpdOpenM().length;
    const row = (d) => {
        const k = d.key, tt = rpdSum(k), op = rpdOpen.has(k), sisa = d.j - tt, r = rpdDB[k] || [];
        let h = `<tr class="rpd-row ${op ? "open" : ""} ${d.blokir ? "blk" : ""} ${lock ? "lock" : ""}" data-k="${esc(k)}"><td class="chev">${op ? "▾" : "▸"}</td><td class="rpd-det"><div class="lt-title">• ${esc(d.u)}</div><div class="lsub">${(() => { const s0 = rpdSupTw(k, t); return s0 ? `<span class="supchip" title="Supplier ${TWN[t]}: ${esc(s0)}">🏷 ${esc(s0.slice(0, 40))}${s0.length > 40 ? "…" : ""}</span> ` : ""; })()}${volTxt(d)}${d.blokir ? ` <span class="bad">· blokir</span>` : ""}${rpdRoSel === "*" || q.length ? ` <span class="muted">· ${esc(d.a.mak)}</span>` : ""}</div><div class="rpd-over" data-over ${sisa < 0 ? "" : "hidden"}>⚠ RPD melebihi pagu Rp <span>${rupiah(-sisa)}</span> — tidak muncul di Catat TUP</div></td><td class="num">${rupiah(d.j)}</td>
      ${[0, 1, 2].map(j => `<td class="c-m"><input type="number" min="0" step="1000" data-m="${m0 + j}" value="${num(r[m0 + j]) || ""}" placeholder="0" aria-label="${BULAN[m0 + j]}" ${dis || (rpdFinM(m0 + j) ? `disabled title="Terkunci: TUP / UP ${BULAN[m0 + j]} sudah difinalisasi — nilai mengikuti Catat TUP / Catat UP"` : "")}></td>`).join("")}
      <td class="c-k"><input type="text" data-ket="${t}" value="${esc((rpdKet[k] || [])[t] || "")}" placeholder="${lock ? "" : "Keterangan…"}" aria-label="Keterangan ${TWN[t]}" title="${esc((rpdKet[k] || [])[t] || "")}" ${dis}></td>
      <td class="num ${sisa < 0 ? "bad" : ""}" data-sisa>${rupiah(sisa)}</td></tr>`;
        if (op)
            h += `<tr class="rpd-edit" data-k="${esc(k)}"><td></td><td colspan="7"><div class="rpd-mini">${TWN.map((n, i) => `<span class="${i === t ? "on" : ""}" data-twm="${i}">${n}${rpdLockTw(i) ? " 🔒" : ""}: <b>Rp ${rupiah(tw(k, i))}</b>${(rpdKet[k] || [])[i] ? ` <i>(${esc(rpdKet[k][i])})</i>` : ""}</span>`).join("")}<span>Setahun: <b data-tot>Rp ${rupiah(tt)}</b></span></div>
      <div class="rpd-sup">${[0, 1, 2].map(j => {
                const m = m0 + j, s0 = (rpdSup[k] || [])[m], refs = rpdSupRefs(s0), nSt = refs.filter(x => x.startsWith("st:")).length, rabs = refs.filter(x => x.startsWith("rab:"));
                return `<div class="rs-m"><span>Supplier ${BULAN[m]}${nSt ? ` <button type="button" class="lnk" data-supgo="${m}:st" title="Lihat surat tugas yang ditautkan">↗ ${nSt} surat tugas</button>` : ""}${rabs.map(x => `<button type="button" class="lnk" data-supgo="${m}:${esc(x)}" title="Buka RAB">↗ RAB</button>`).join("")}</span>
          <button type="button" class="rs-pick${s0?.t ? "" : " empty"}" data-suppick="${m}" title="${esc(s0?.t || "")}" ${rpdLockTw(t) ? "disabled" : ""}>${esc(s0?.t || "Pilih supplier / surat tugas…")}</button></div>`;
            }).join("")}</div>
      <div class="actions" style="margin-top:8px">${lock ? "" : `<button class="btn sm" type="button" data-rpda="sisa">Isi sisa pagu ke ${BULAN[m0 + 2]}</button>`}${nLock < 12 ? `<button class="btn sm" type="button" data-rpda="rata">${nLock ? `Bagi rata sisa ke ${12 - nLock} bulan terbuka` : "Bagi rata 12 bulan"}</button><button class="btn sm" type="button" data-rpda="tw">Bagi rata per triwulan${nLock ? " terbuka" : ""} (akhir TW)</button><button class="btn sm del" type="button" data-rpda="clr" title="${nLock ? "Hapus isian bulan yang masih terbuka (triwulan yang sudah lewat tidak berubah)" : "Hapus semua isian RPD detil ini"}">Bersihkan</button>` : `<span class="muted" style="font-size:12px">Semua triwulan tahun ${rpdYear()} sudah lewat.</span>`}<span class="muted" style="font-size:12px" data-info></span></div></td></tr>`;
        return h;
    };
    let html = "";
    for (const [r, ds] of byRo) {
        const A = ds.filter(d => !d.blokir), B = ds.filter(d => d.blokir), pg = A.reduce((s, d) => s + d.j, 0), tt = A.reduce((s, d) => s + rpdSum(d.key), 0);
        html += `<tr class="rpd-ro" data-ro="${esc(r)}"><td colspan="2"><b><span class="rocode">${esc(r)}</span> ${esc(roTitle(ds[0].a.roNama))}</b></td><td class="num">${rupiah(pg)}</td>${[0, 1, 2].map(j => `<td class="num" data-rom="${j}">${rupiah(A.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0))}</td>`).join("")}<td></td><td class="num ${pg - tt < 0 ? "bad" : ""}" data-rosisa>${rupiah(pg - tt)}</td></tr>`;
        const showB = rpdBlk.has(r), byAk = new Map();
        for (const d of ds) {
            if (d.blokir && !showB)
                continue;
            byAk.set(d.a.mak, [...(byAk.get(d.a.mak) || []), d]);
        }
        for (const [mk, xs] of byAk) {
            const a0 = xs[0].a, XA = xs.filter(d => !d.blokir), apg = XA.reduce((s0, d) => s0 + d.j, 0), att = XA.reduce((s0, d) => s0 + rpdSum(d.key), 0), aop = rpdAkAll || q.length > 0 || !!st || rpdAkOpen.has(mk);
            const nOv = XA.filter(d => rpdSum(d.key) > d.j).length;
            html += `<tr class="rpd-ak ${aop ? "open" : ""}" data-mak="${esc(mk)}"><td class="chev">${aop ? "▾" : "▸"}</td><td><div class="ak-t"><b>${esc(a0.akun)}</b> ${esc(a0.nama)}</div><div class="lsub one">${esc(a0.komp)} ${esc(a0.kompNama || "")} · ${xs.length} detil${nOv ? ` · <span class="bad">⚠ ${nOv} melebihi pagu</span>` : ""}</div></td><td class="num">${rupiah(apg)}</td>${[0, 1, 2].map(j => `<td class="num" data-akm="${j}">${rupiah(XA.reduce((s0, d) => s0 + num((rpdDB[d.key] || [])[m0 + j]), 0)) || "0"}</td>`).join("")}<td></td><td class="num ${apg - att < 0 ? "bad" : ""}" data-aksisa>${rupiah(apg - att)}</td></tr>`;
            if (aop)
                html += xs.map(row).join("");
        }
        if (B.length) {
            const on = showB;
            html += `<tr class="rpd-blk" data-blk="${esc(r)}"><td class="chev">${on ? "▾" : "▸"}</td><td colspan="7">${on ? "Sembunyikan" : "Tampilkan"} <b>${B.length} detil blokir</b> <span class="muted">· pagu Rp ${rupiah(B.reduce((s, d) => s + d.j, 0))} (tidak dihitung dalam total)</span></td></tr>`;
        }
    }
    $("#rpdTbl tbody").innerHTML = html || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">Tidak ada detil yang cocok.</td></tr>`;
    const nA = list.filter(d => !d.blokir).length;
    $("#rpdInfo").textContent = `${nA} detil ditampilkan${list.length > nA ? ` · ${list.length - nA} blokir disembunyikan` : ""} · ${lock ? `${TWN[t]} terkunci (sudah lewat)` : `isi langsung kolom ${BLN_S.slice(m0, m0 + 3).join(", ")} dan keterangannya`} · klik ▸ untuk rincian`;
}
/** cari elemen di dalam baris (markup buatan sendiri → selalu ada) */
const q1 = (root, sel) => root.querySelector(sel);
function rpdRowRefresh(k) {
    const d = detMap()[k], tr = document.querySelector(`#rpdTbl tr.rpd-row[data-k="${CSS.escape(k)}"]`), ed = document.querySelector(`#rpdTbl tr.rpd-edit[data-k="${CSS.escape(k)}"]`);
    if (!d || !tr)
        return;
    const t = rpdTw, tt = rpdSum(k), sc = q1(tr, "[data-sisa]");
    sc.textContent = rupiah(d.j - tt);
    sc.classList.toggle("bad", d.j - tt < 0);
    const ov = q1(tr, "[data-over]");
    ov.hidden = !(tt > d.j);
    q1(ov, "span").textContent = rupiah(tt - d.j);
    if (ed) {
        for (let i = 0; i < 4; i++)
            q1(ed, `[data-twm="${i}"] b`).textContent = "Rp " + rupiah(tw(k, i));
        q1(ed, "[data-tot]").textContent = "Rp " + rupiah(tt);
        q1(ed, "[data-info]").innerHTML = tt > d.j ? `<span class="bad">RPD melebihi pagu Rp ${rupiah(tt - d.j)}</span>` : tt === d.j ? "RPD sama dengan pagu ✓" : `Belum direncanakan Rp ${rupiah(d.j - tt)}`;
    }
    // subtotal RO + ringkasan
    const r = roOf(d), gr = document.querySelector(`#rpdTbl tr.rpd-ro[data-ro="${CSS.escape(r)}"]`);
    if (gr) {
        const A = pokDetil().filter(x => roOf(x) === r && !x.blokir), pg = A.reduce((s, x) => s + x.j, 0), T = A.reduce((s, x) => s + rpdSum(x.key), 0);
        for (let j = 0; j < 3; j++)
            q1(gr, `[data-rom="${j}"]`).textContent = rupiah(A.reduce((s, x) => s + num((rpdDB[x.key] || [])[t * 3 + j]), 0));
        const rs = q1(gr, "[data-rosisa]");
        rs.textContent = rupiah(pg - T);
        rs.classList.toggle("bad", pg - T < 0);
    }
    const ar = document.querySelector(`#rpdTbl tr.rpd-ak[data-mak="${CSS.escape(d.a.mak)}"]`);
    if (ar) {
        const XA = pokDetil().filter(x => x.a.mak === d.a.mak && !x.blokir), apg = XA.reduce((s0, x) => s0 + x.j, 0), att = XA.reduce((s0, x) => s0 + rpdSum(x.key), 0);
        for (let j = 0; j < 3; j++)
            q1(ar, `[data-akm="${j}"]`).textContent = rupiah(XA.reduce((s0, x) => s0 + num((rpdDB[x.key] || [])[t * 3 + j]), 0)) || "0";
        const as = q1(ar, "[data-aksisa]");
        as.textContent = rupiah(apg - att);
        as.classList.toggle("bad", apg - att < 0);
    }
    rpdKpi();
}
const rpdSetRo = (v) => { rpdRoSel = v; LS.set("st.rpdRo", v); rpdOpen.clear(); rpdAkOpen.clear(); rpdAkAll = false; renderRpd(); const wr = $("#rpdTbl").closest(".tblwrap"); if (wr)
    wr.scrollTop = 0; };
$("#rpdTwChips").addEventListener("click", e => { const b = tg(e).closest("[data-twc]"); if (!b)
    return; rpdTw = Number(b.dataset.twc); LS.set("st.rpdTw", rpdTw); renderRpd(); });
$("#rpdRo").addEventListener("change", e => rpdSetRo(tg(e).value));
$("#rpdBack").onclick = () => { $("#rpdQ").value = ""; rpdSetRo(""); };
$("#rpdTbl").addEventListener("click", e => {
    const pk = tg(e).closest("tr.rpd-pick");
    if (pk)
        return rpdSetRo(pk.dataset.ro ?? "");
    const ak = tg(e).closest("tr.rpd-ak");
    if (ak) {
        const mk = ak.dataset.mak ?? "";
        if (rpdAkAll) {
            rpdAkAll = false;
            pokDetil().forEach(x => rpdAkOpen.add(x.a.mak));
        }
        rpdAkOpen.has(mk) ? rpdAkOpen.delete(mk) : rpdAkOpen.add(mk);
        return renderRpd();
    }
    const bk = tg(e).closest("tr.rpd-blk");
    if (bk) {
        const r = bk.dataset.blk ?? "";
        rpdBlk.has(r) ? rpdBlk.delete(r) : rpdBlk.add(r);
        return renderRpd();
    }
    if (tg(e).closest("input"))
        return;
    const a = tg(e).closest("[data-rpda]")?.dataset.rpda, row = tg(e).closest("tr[data-k]");
    if (!row)
        return;
    const k = row.dataset.k ?? "", d = detMap()[k];
    if (a) {
        const r = rpdOf(k), open = rpdOpenM();
        if (!open.length)
            return toast("Semua triwulan sudah lewat.");
        const base = d.j - [...Array(12).keys()].filter(rpdLockM).reduce((s, m) => s + num(r[m]), 0); // pagu dikurangi bulan terkunci
        if (a === "rata") {
            const v = Math.max(0, Math.floor(base / open.length / 1000) * 1000);
            open.forEach(m => r[m] = v);
            r[open[open.length - 1]] += Math.max(0, base) - v * open.length;
        }
        if (a === "tw") {
            const ends = [2, 5, 8, 11].filter(m => !rpdLockM(m)), v = Math.max(0, Math.floor(base / ends.length / 1000) * 1000);
            open.forEach(m => r[m] = 0);
            ends.forEach(m => r[m] = v);
            r[ends[ends.length - 1]] += Math.max(0, base) - v * ends.length;
        }
        if (a === "sisa") {
            if (rpdLockM(rpdTw * 3 + 2))
                return toast(`${BULAN[rpdTw * 3 + 2]} terkunci (TUP sudah difinalisasi / triwulan lewat).`, "warn");
            const s0 = d.j - rpdSum(k);
            if (s0 <= 0)
                return toast("Tidak ada sisa pagu.");
            r[rpdTw * 3 + 2] = num(r[rpdTw * 3 + 2]) + s0;
        }
        if (a === "clr") {
            if (!open.some(m => num(r[m])))
                return toast("Tidak ada isian untuk dibersihkan.");
            if (!confirm(`Bersihkan isian RPD "${d.u}"${rpdOpenM().length < 12 ? " pada bulan yang masih terbuka" : ""}?`))
                return;
            open.forEach(m => r[m] = 0);
            toast("Isian RPD dibersihkan.");
        }
        persistAng();
        renderRpd();
        return;
    }
    if (row.classList.contains("rpd-row")) {
        rpdOpen.has(k) ? rpdOpen.delete(k) : rpdOpen.add(k);
        renderRpd();
    }
});
$("#rpdTbl").addEventListener("input", e => {
    const row = tg(e).closest("tr[data-k]");
    if (!row)
        return;
    const m = tg(e).dataset.m, kt = tg(e).dataset.ket, k = row.dataset.k ?? "";
    if (kt != null) {
        if (rpdLockTw(+kt))
            return;
        rpdKetOf(k)[+kt] = tg(e).value;
        tg(e).title = tg(e).value;
        persistAng();
        return;
    }
    if (m == null || rpdLockM(+m))
        return;
    rpdOf(k)[+m] = num(tg(e).value);
    persistAng();
    rpdRowRefresh(k);
});
$("#rpdQ").addEventListener("input", debounce(() => renderRpd(), 150));
$("#rpdSt").addEventListener("change", renderRpd);
$("#rpdHide0").checked = rpdHide0;
$("#rpdHide0").addEventListener("change", e => { rpdHide0 = tg(e).checked; LS.set("st.rpdHide0", rpdHide0); renderRpd(); });
$("#rpdAkAll").onclick = () => { const open = rpdAkAll || rpdAkOpen.size > 0; rpdAkAll = !open; rpdAkOpen.clear(); renderRpd(); };
$("#rpdWarn").addEventListener("click", e => { if (!tg(e).closest("#rpdWarnGo"))
    return; $("#rpdSt").value = "lebih"; if (!rpdRoSel)
    rpdRoSel = "*"; renderRpd(); });
$("#rpdExp").onclick = () => {
    $("#reTw").innerHTML = [...TWN.map((n, i) => `<label class="twchip ${i === rpdTw ? "on" : ""}"><input type="radio" name="reTw" value="${i}" ${i === rpdTw ? "checked" : ""} hidden><b>${n}</b><span>${BLN_S[i * 3]} – ${BLN_S[i * 3 + 2]}</span></label>`),
        `<label class="twchip"><input type="radio" name="reTw" value="all" hidden><b>Setahun</b><span>Jan – Des</span></label>`].join("");
    $("#reRoWrap").hidden = !rpdRoSel || rpdRoSel === "*";
    $("#reRoTxt").textContent = rpdRoSel && rpdRoSel !== "*" ? rpdRoSel : "";
    $("#dRpdExp").showModal();
};
$("#reTw").addEventListener("change", () => $$("#reTw .twchip").forEach(l => l.classList.toggle("on", !!l.querySelector("input")?.checked)));
$("#reCancel").onclick = () => $("#dRpdExp").close();
$("#reGo").onclick = () => {
    const v = document.querySelector('#reTw input:checked')?.value ?? "all", hide0 = $("#reHide0").checked, onlyRo = !$("#reRoWrap").hidden && $("#reRo").checked;
    const D0 = pokDetil().filter(d => !onlyRo || d.a.ro === rpdRoSel);
    if (v !== "all") {
        const t = +v, D = D0.filter(d => !hide0 || tw(d.key, t) > 0);
        if (!D.length)
            return toast(`Tidak ada detil ber-RPD di ${TWN[t]} ${angYear}.`, "warn");
        const H = ["RO", "MAK", "Akun", "Detil", "Pagu", ...BULAN.slice(t * 3, t * 3 + 3), "Jumlah " + TWN[t], "Keterangan " + TWN[t], "Total RPD setahun", "Sisa pagu", "Status", "Supplier " + TWN[t]];
        const rows = D.map(d => { const r = rpdDB[d.key] || Array(12).fill(0); return [d.a.ro, d.a.mak, d.a.nama, d.u, d.j, ...r.slice(t * 3, t * 3 + 3).map(num), tw(d.key, t), (rpdKet[d.key] || [])[t] || "", rpdSum(d.key), d.j - rpdSum(d.key), d.blokir ? "Blokir" : "", rpdSupTw(d.key, t)]; });
        const tot = ["", "", "", "Jumlah", D.reduce((s, d) => s + d.j, 0), ...[0, 1, 2].map(j => D.reduce((s, d) => s + num((rpdDB[d.key] || [])[t * 3 + j]), 0)), D.reduce((s, d) => s + tw(d.key, t), 0), "", D.reduce((s, d) => s + rpdSum(d.key), 0), D.reduce((s, d) => s + d.j - rpdSum(d.key), 0), ""];
        const ws = XLSX.utils.aoa_to_sheet([H, ...rows, tot]);
        ws["!cols"] = [14, 28, 28, 46, 14, 13, 13, 13, 15, 34, 15, 14, 9, 30].map(w => ({ wch: w }));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, `RPD ${TWN[t]} ${angYear}`);
        XLSX.writeFile(wb, `RPD ${TWN[t]} ${angYear}${onlyRo ? " " + rpdRoSel : ""} (${D.length} detil).xlsx`);
        $("#dRpdExp").close();
        return toast(`RPD ${TWN[t]} diekspor (${D.length} detil).`, "ok");
    }
    const D = D0.filter(d => !hide0 || rpdSum(d.key) > 0);
    if (!D.length)
        return toast(`Belum ada detil ber-RPD di ${angYear}.`, "warn");
    $("#dRpdExp").close();
    const rows = D.map(d => { const r = rpdDB[d.key] || Array(12).fill(0); return [d.a.ro, d.a.mak, d.a.nama, d.u, d.j, ...[0, 1, 2, 3].flatMap(t => [...r.slice(t * 3, t * 3 + 3).map(num), tw(d.key, t), (rpdKet[d.key] || [])[t] || ""]), rpdSum(d.key), d.j - rpdSum(d.key), d.blokir ? "Blokir" : ""]; });
    const H = ["RO", "MAK", "Akun", "Detil", "Pagu", ...[0, 1, 2, 3].flatMap(t => [...BULAN.slice(t * 3, t * 3 + 3), TWN[t], "Keterangan " + TWN[t]]), "Total RPD", "Sisa", "Status"];
    const ws = XLSX.utils.aoa_to_sheet([H, ...rows]);
    ws["!cols"] = [14, 28, 28, 46, 14, ...[0, 1, 2, 3].flatMap(() => [12, 12, 12, 13, 30]), 14, 14, 9].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "RPD " + angYear);
    XLSX.writeFile(wb, `RPD setahun ${angYear}${onlyRo ? " " + rpdRoSel : ""} (${D.length} detil).xlsx`);
    toast(`RPD setahun diekspor (${D.length} detil).`, "ok");
};
$("#rpdImp").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    tg(e).value = "";
    if (!f)
        return;
    try {
        const wb = XLSX.read(await f.arrayBuffer(), { type: "array" }), a = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: "" }), H = a[0].map(x => String(x).trim());
        const iM = H.indexOf("MAK"), iD = H.indexOf("Detil"), mi = BULAN.map(b => H.indexOf(b));
        if (iM < 0 || iD < 0 || mi.every(i => i < 0))
            return toast("Pakai file hasil Ekspor RPD.");
        const ki = TWN.map(t0 => H.indexOf("Keterangan " + t0));
        let n = 0, nl = 0;
        for (const r of a.slice(1)) {
            const d = pokDetil().find(x => x.a.mak === String(r[iM]).trim() && acNorm(x.u) === acNorm(r[iD]));
            if (!d)
                continue;
            const old = rpdDB[d.key] || Array(12).fill(0);
            rpdDB[d.key] = mi.map((i, m) => { if (i < 0)
                return num(old[m]); if (rpdLockM(m)) {
                if (num(r[i]) !== num(old[m]))
                    nl++;
                return num(old[m]);
            } return num(r[i]); });
            ki.forEach((i, t0) => { if (i >= 0 && !rpdLockTw(t0))
                rpdKetOf(d.key)[t0] = String(r[i] ?? "").trim(); });
            n++;
        }
        persistAng();
        renderRpd();
        toast(`RPD ${n} detil diimpor.` + (nl ? ` ${nl} isian di triwulan yang sudah lewat diabaikan.` : ""));
    }
    catch (err) {
        toast("Gagal membaca file: " + err.message);
    }
});
$("#rpdTbl").addEventListener("click", e => {
    const b = tg(e).closest("[data-supgo],[data-suppick]");
    if (!b)
        return;
    e.stopPropagation();
    const k = b.closest("tr[data-k]")?.dataset.k || "";
    if (b.dataset.suppick != null)
        return rpdSupOpen(k, +b.dataset.suppick);
    const [m, ...rest] = (b.dataset.supgo || "").split(":"), ref = rest.join(":"), x = (rpdSup[k] || [])[+m];
    if (ref === "st")
        rpdSupGoSt(x);
    else
        rpdSupGo(ref);
}, true);

/* ---- 82_tup.ts ---- */
/* ================= CATAT TUP & CATAT UP (satu modul, dua mode) ================= */
let tupM = new Date().getMonth();
/** "tup" = Catat TUP (baris dari RPD, batas = Total Permintaan RPD Awal); "up" = Catat UP (baris ditambah sendiri, batas = Total UP baku setahun dari Pengaturan) */
let tupMode = "tup";
const TD = () => tupMode === "up" ? upDB : tupDB;
/** bulan sudah difinalisasi → seluruh rincian terkunci; harus "Batalkan finalisasi" dulu untuk mengubah */
const tupFinOn = (m = tupM) => !!TD()[m]?.fin;
const tupFinMsg = () => `${tupMode === "up" ? "UP" : "TUP"} ${BULAN[tupM]} sudah difinalisasi — rincian terkunci. Klik "Batalkan finalisasi" dulu untuk mengubah.`;
const TL = () => tupMode === "up" ? "UP" : "TUP";
/** Total UP setahun per tahun anggaran (Pengaturan) */
const upTotalAll = () => LS.get("st.upTotal", {});
const upTotal = (y = angYear) => num(upTotalAll()[y]);
function withMode(md, fn) { const o = tupMode; tupMode = md; try {
    return fn();
}
finally {
    tupMode = o;
} }
const otherMode = () => tupMode === "up" ? "tup" : "up";
/** batas pembanding bulan ini: TUP → Total Permintaan RPD Awal; UP → Total UP */
const capLbl = () => tupMode === "up" ? `Total UP ${angYear}` : "Total Permintaan RPD Awal";
/** TUP bulan m — data lama dilengkapi bagian yang belum ada */
const tupOf = (m) => { const t = TD()[m] || (TD()[m] = { val: {}, add: [], excl: [], tgl: "", ket: "" }); t.val ||= {}; t.add ||= []; t.excl ||= []; t.tgl ??= ""; t.ket ??= ""; t.nama ||= {}; t.kt ||= {}; t.f ||= {}; t.dup ||= []; return t; };
const tupAkMap = () => Object.fromEntries(angPok().akun.map(a => [a.mak, a]));
const isoTgl = (v) => isoToDmy(v) || v || "";
const tupAkun51 = (d) => /^51/.test(String(d.a.akun || "").trim()); // belanja pegawai: tidak lewat TUP
const tupOver = (d) => rpdSum(d.key) > d.j; // RPD melebihi pagu
const rpdKetM = (k, m) => (rpdKet[k] || [])[Math.floor(m / 3)] || "";
/** detil POK yang menerima realisasi baris: detil asal, atau — bila MAK diganti — detil di MAK baru (pilihan, nama sama, atau detil pertama tanpa blokir) */
function tupKey(x) { return x.d.key; } // MAK di Catat TUP terkunci: realisasi selalu ke detil asal
function tupRows(m) {
    const t = TD()[m] || {}, M = detMap();
    const keys = [...new Set([...(tupMode === "up" ? [] : t.fin ? Object.entries(t.fin.prev).filter(([, v]) => num(v) > 0).map(([k]) => k) : pokDetil().filter(d => num((rpdDB[d.key] || [])[m]) > 0).map(d => d.key)), ...(t.add || [])])].filter(k => M[k] && !(t.excl || []).includes(k) && !tupAkun51(M[k]) && (t.fin ? true : !tupOver(M[k])));
    const AK = tupAkMap();
    /* k = kunci baris (detil, atau "dup:…" untuk baris duplikat); a = akun/MAK yang dipakai (bisa dipilih lain) */
    const mkRow = (k, d, dup) => {
        const rk = rpdKetM(d.key, m), f = (t.f || {})[k] || {}, rpd = dup ? 0 : num((rpdDB[d.key] || [])[m]);
        void AK;
        return { k, d, a: d.a, dup, rpd, tup: t.val && t.val[k] != null ? num(t.val[k]) : rpd, edited: !!(t.val && t.val[k] != null), added: !dup && (t.add || []).includes(k),
            nama: t.nama && t.nama[k] != null ? t.nama[k] : d.u, namaEd: !!(t.nama && t.nama[k] != null), ket: t.kt && t.kt[k] != null ? t.kt[k] : rk, ketEd: !!(t.kt && t.kt[k] != null), rpdKet: rk, f };
    };
    const out = [];
    for (const k of keys) {
        out.push(mkRow(k, M[k], false));
        for (const dp of (t.dup || []).filter(x => x.src === k))
            out.push(mkRow(dp.id, M[k], true));
    }
    return out;
}
function tupHidden(m) {
    const D = pokDetil().filter(d => num((rpdDB[d.key] || [])[m]) > 0);
    return { a51: D.filter(tupAkun51), over: D.filter(d => !tupAkun51(d) && tupOver(d)) };
}
/* ---------- tampilan Catat TUP: daftar ringkas, klik baris untuk mengisi; pajak lewat pop-up ---------- */
let tupOpen = new Set(), tupFlt = "", tupPjKey = "";
const IC_CP = `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>`;
const tglSalin = (v) => { if (!v)
    return ""; const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}` : v; }; // format isian SAKTI: dd/mm/yyyy
async function salin(txt0, lbl) {
    const txt = String(txt0 ?? "").trim();
    if (!txt)
        return toast(`${lbl || "Isian"} masih kosong.`);
    let ok = false;
    try {
        await navigator.clipboard.writeText(txt);
        ok = true;
    }
    catch (e) { }
    if (!ok) {
        const ta = document.createElement("textarea");
        ta.value = txt;
        ta.style.cssText = "position:fixed;opacity:0;left:-9999px";
        document.body.appendChild(ta);
        ta.select();
        try {
            ok = document.execCommand("copy");
        }
        catch (e) { }
        ta.remove();
    }
    toast(ok ? `Disalin${lbl ? " " + (lbl === "MAK" ? "MAK" : lbl.replace(/SAKTI/, "\x00").toLowerCase().replace("\x00", "SAKTI").replace("spby", "SPBY")) : ""}: ${txt.length > 70 ? txt.slice(0, 70) + "…" : txt}` : "Gagal menyalin — pilih teks lalu tekan Ctrl+C.");
}
const cpBtn = (val, lbl) => `<button type="button" class="cpb" data-cp="${esc(val)}" data-cpl="${esc(lbl)}" data-stop title="Salin ${esc(lbl.toLowerCase())}" aria-label="Salin ${esc(lbl.toLowerCase())}">${IC_CP}</button>`;
const PPH_J = [["PPh 22", 1.5], ["PPh 23", 2], ["PPh 21", 5], ["PPh 4 ayat 2", 10], ["Lainnya", 0]];
const tglS = (v) => isoToDmy(v) || v || "";
const tupPj = (f) => f.pajak && f.pj ? { ppn: num(f.pj.ppn), pph: num(f.pj.pph) } : { ppn: 0, pph: 0 };
const tupVis = (rows) => rows.filter(x => !tupFlt || (tupFlt === "belum" ? !x.f.catat : tupFlt === "sudah" ? x.f.catat : tupFlt === "pajak" ? x.f.pajak : !x.f.pajak));
const tupSel = (x) => x.dup ? "baris duplikat · tidak dihitung dari RPD" : x.rpd || x.tup ? (x.tup - x.rpd ? `RPD ${rupiah(x.rpd)} · <span class="${x.tup > x.rpd ? "bad" : "ok"}">${x.tup > x.rpd ? "+" : "−"}${rupiah(Math.abs(x.tup - x.rpd))}</span>` : `sesuai RPD`) : (x.added ? "ditambahkan" : "");
/* ---------- syarat "Selesai": isian lengkap & pagu detil cukup ---------- */
/** sisa pagu detil per kunci untuk bulan m: pagu − realisasi (baris selesai) bulan lain − semua baris detil itu di bulan m */
let tupSisa = {};
function tupCalcSisa(m) {
    const used = {};
    for (let mm = 0; mm < 12; mm++)
        for (const x of tupRows(mm))
            if (mm === m || x.f.catat) {
                const kk = tupKey(x);
                used[kk] = (used[kk] || 0) + x.tup;
            }
    for (let mm = 0; mm < 12; mm++)
        for (const x of withMode(otherMode(), () => tupRows(mm)))
            if (x.f.catat) {
                const kk = tupKey(x);
                used[kk] = (used[kk] || 0) + x.tup;
            } // Catat TUP + Catat UP memakai pagu yang sama
    const o = {};
    for (const d of pokDetil())
        if (used[d.key] != null)
            o[d.key] = (d.blokir ? 0 : d.j) - used[d.key];
    return (tupSisa = o);
}
/** isian yang belum diisi (nama kolom untuk pesan) */
function tupMissing(x) {
    const f = x.f, out = [];
    if (!f.nota)
        out.push("tanggal nota");
    if (!f.spby)
        out.push("tanggal SPBY");
    if (!f.kui)
        out.push("tanggal kuitansi SAKTI");
    if (!String(x.nama || "").trim())
        out.push("uraian");
    if (!String(f.sup || "").trim())
        out.push("supplier");
    if (!(x.tup > 0))
        out.push("jumlah");
    if (f.pajak && !(f.pj && num(f.pj.dpp) > 0))
        out.push("rincian pajak (DPP)");
    return out;
}
const tupMinus = (x) => Math.min(0, tupSisa[tupKey(x)] ?? 0);
const tupOk = (x) => !tupMissing(x).length && tupMinus(x) >= 0;
function tupMain(x, i) {
    const f = x.f, a = x.a, op = tupOpen.has(x.k), pj = tupPj(f);
    const dates = [["Nota", f.nota, "Tanggal nota"], ["SPBY", f.spby, "Tanggal SPBY"], ["Kuitansi", f.kui, "Tanggal kuitansi SAKTI"]].map(([l, v, n]) => v
        ? `<span class="tchip on" title="${esc(n)}">${l} ${tglS(v)}</span>`
        : `<span class="tchip">${l} —</span>`).join("");
    return `<label class="tck" title="Tandai selesai (sudah dicatat)" data-stop><input type="checkbox" data-tc="catat" ${f.catat ? "checked" : ""} ${tupFinOn() ? "disabled" : ""} aria-label="Selesai dicatat"><span class="no">${i + 1}</span></label>
    <div class="tr-t"><div class="tr-u">${x.dup ? `<span class="tdup">duplikat</span> ` : ""}${esc(x.nama)} ${cpBtn(x.nama, "Uraian")}</div>
      <div class="tr-mak"><span class="mk">MAK</span><code>${esc(a.mak)}</code>${cpBtn(a.mak, "MAK")}<span class="tr-s">${esc(a.nama)} · ${esc(roTitle(a.roNama))}</span><span class="tr-s tr-det" title="Detil POK: ${esc(x.d.u)}">detil: ${esc(x.d.u.slice(0, 70))}</span></div>
      <div class="tr-c">${dates}${f.sup ? `<span class="tchip sup" title="Supplier">${esc(f.sup)}</span>` : ""}${x.ket ? `<span class="tchip ket" title="${esc(x.ket)}">${esc(x.ket)}</span>` : ""}</div></div>
    <div class="tr-j"><b>Rp ${rupiah(x.tup)}</b><small>${tupSel(x)}</small>${(() => {
        const s = tupSisa[tupKey(x)] ?? 0, ms = tupMissing(x);
        return `<small class="tr-pg ${s < 0 ? "bad" : ""}" title="Pagu detil dikurangi realisasi ${TL()} bulan lain & semua baris detil ini bulan ini">${s < 0 ? `⚠ pagu kurang Rp ${rupiah(-s)}` : `sisa pagu Rp ${rupiah(s)}`}</small>${f.catat && (ms.length || s < 0) ? `<small class="bad">⚠ ${ms.length ? "belum lengkap" : "melebihi pagu"} — tidak bisa difinalisasi</small>` : !f.catat && ms.length ? `<small class="muted tr-ms" title="Wajib diisi sebelum Selesai: ${esc(ms.join(", "))}">belum diisi: ${esc(ms.slice(0, 2).join(", "))}${ms.length > 2 ? ` +${ms.length - 2}` : ""}</small>` : ""}`;
    })()}</div>
    <button type="button" class="tpj ${f.pajak ? "on" : ""}" data-tpj data-stop ${f.catat || tupFinOn() ? "disabled" : ""} title="${f.catat ? "Baris selesai — terkunci. " : ""}${f.pajak ? "Ubah rincian pajak" : "Tandai ada pajak & isi DPP, PPN, PPh"}">${f.pajak ? `<b>Pajak</b><small>${f.pj ? `PPN ${rupiah(pj.ppn)} · ${esc(f.pj.pphJ || "PPh")} ${rupiah(pj.pph)}` : "isi rincian"}</small>` : `<span>+ Pajak</span>`}</button>
    <span class="tr-tools"><button type="button" class="cpb tdupb" data-tdup data-stop ${f.catat || tupFinOn() ? "disabled" : ""} title="Duplikat baris (mis. satu detil dibayar beberapa nota)" aria-label="Duplikat baris">${IC.dup}</button><span class="tr-chev" aria-hidden="true">${op ? "▾" : "▸"}</span></span>`;
}
/** pilihan MAK berisi judul detil: dikelompokkan per MAK (optgroup), nilai = kunci detil */
function tupDetOpts(cur) {
    const byMak = new Map();
    for (const d of pokDetil())
        if (!tupAkun51(d)) {
            const g = byMak.get(d.a.mak);
            if (g)
                g.push(d);
            else
                byMak.set(d.a.mak, [d]);
        }
    return [...byMak.entries()].map(([mak, ds]) => `<optgroup label="${esc(mak)} — ${esc(ds[0].a.nama)}">${ds.map(d => `<option value="${esc(d.key)}" ${d.key === cur ? "selected" : ""}>${esc(d.u.slice(0, 80))} · pagu ${rupiah(d.blokir ? 0 : d.j)}${d.blokir ? " (blokir)" : ""}</option>`).join("")}</optgroup>`).join("");
}
function tupEditor(x) {
    const f = x.f, L = f.catat || tupFinOn() ? "disabled" : "";
    return `<div class="tr-ed ${f.catat || tupFinOn() ? "locked" : ""}">${tupFinOn() ? `<div class="w4 tr-lock">🔒 ${tupMode === "up" ? "UP" : "TUP"} ${BULAN[tupM]} sudah <b>difinalisasi</b> — rincian terkunci. Klik <b>Batalkan finalisasi</b> untuk mengubah.</div>` : f.catat ? `<div class="w4 tr-lock">🔒 Baris sudah <b>Selesai</b> — semua isian terkunci. Hapus centang ✓ Selesai untuk mengubah lagi.</div>` : ""}
    <div class="w4 trmk"><span class="lh"><span><span class="mk">MAK</span> &amp; detil POK <span class="muted">(terkunci — sesuai POK / RPD)</span></span><button type="button" class="cpb" data-cp="${esc(x.a.mak)}" data-cpl="MAK" title="Salin MAK">${IC_CP}</button></span>
      <div class="trmk-v" title="MAK tidak bisa diubah di Catat ${TL()}"><span class="lk" aria-hidden="true">🔒</span><code>${esc(x.a.mak)}</code><b>${esc(x.d.u)}</b></div>
      <span class="muted" style="font-size:11.5px">${esc(x.a.nama)} · ${esc(x.a.ro)} ${esc(roTitle(x.a.roNama))} · pagu detil Rp ${rupiah(x.d.blokir ? 0 : x.d.j)}</span></div>
    <label><span class="lh">Tanggal nota</span><input type="date" data-tf="nota" value="${esc(f.nota || "")}" ${L}></label>
    <label><span class="lh">Tanggal SPBY</span><input type="date" data-tf="spby" value="${esc(f.spby || "")}" ${L}></label>
    <label><span class="lh">Tanggal kuitansi SAKTI</span><input type="date" data-tf="kui" value="${esc(f.kui || "")}" ${L}></label>
    <label><span class="lh">Jumlah (Rp)</span><input type="number" min="0" step="1000" data-tv value="${x.tup || ""}" ${L} class="${x.edited ? "edited" : ""}"></label>
    <label class="w2"><span class="lh">Uraian<button type="button" class="cpb" data-cpf="tn" data-cpl="Uraian" title="Salin uraian">${IC_CP}</button></span><input type="text" data-tn value="${esc(x.nama)}" ${L} class="${x.namaEd ? "edited" : ""}" title="${x.namaEd ? "Nama di POK: " + esc(x.d.u) : "Bisa diubah — POK tidak berubah"}"></label>
    <label class="w2"><span class="lh">Supplier</span><input type="text" data-tf="sup" value="${esc(f.sup || "")}" ${L} placeholder="${esc(rpdSupGet(x.d.key, tupM)?.t ? "Supplier di RPD: " + rpdSupGet(x.d.key, tupM).t : "Nama toko / penyedia")}">${!f.sup && rpdSupGet(x.d.key, tupM) && !f.catat ? `<button type="button" class="lnk" data-supuse title="Isi supplier dari RPD">Pakai supplier RPD</button>` : ""}</label>
    <label class="w4">Keterangan<input type="text" data-tk value="${esc(x.ket)}" ${L} placeholder="Keterangan…" class="${x.ketEd ? "edited" : ""}" title="${x.rpdKet ? "Keterangan RPD: " + esc(x.rpdKet) : ""}"></label>
    <div class="w4 tr-act"><span class="muted">${x.dup ? "Baris duplikat — ubah uraian supaya berbeda sebelum ditandai selesai." : x.namaEd ? `Nama di POK: ${esc(x.d.u)}` : ""}</span><span style="display:flex;gap:6px"><button class="btn sm" type="button" data-tdup ${L}>Duplikat baris</button><button class="btn sm del" type="button" data-tx ${L}>${x.dup ? "Hapus duplikat" : "Keluarkan dari bulan ini"}</button></span></div></div>`;
}
function tupSummary(rows) {
    const tot = rows.reduce((s0, x) => s0 + x.tup, 0), nC = rows.filter(x => x.f.catat).length, nP = rows.filter(x => x.f.pajak).length;
    const ppn = rows.reduce((s0, x) => s0 + tupPj(x.f).ppn, 0), pph = rows.reduce((s0, x) => s0 + tupPj(x.f).pph, 0);
    $("#tupSum").innerHTML = `<div class="ts"><small>Total ${TL()}</small><b>Rp ${rupiah(tot)}</b><span>${rows.length} baris</span></div>
    <div class="ts"><small>Selesai dicatat</small><b>${nC} / ${rows.length}</b><span class="tbar"><i style="width:${rows.length ? Math.round(nC / rows.length * 100) : 0}%"></i></span></div>
    <div class="ts"><small>Ada pajak</small><b>${nP} baris</b><span>PPN Rp ${rupiah(ppn)} · PPh Rp ${rupiah(pph)}</span></div>`;
    tupFinUI(rows);
    $$("#tupSeg [data-flt]").forEach(b => { b.classList.toggle("on", b.dataset.flt === tupFlt); const c = b.dataset.flt === "" ? rows.length : b.dataset.flt === "belum" ? rows.length - nC : b.dataset.flt === "sudah" ? nC : nP; b.querySelector("i").textContent = String(c); });
}
/* ---------- finalisasi TUP: semua baris selesai → RPD bulan itu diganti realisasi TUP (bisa dibatalkan) ---------- */
/** realisasi TUP per detil (baris duplikat ikut dijumlahkan ke detilnya) */
const tupReal = (rows) => { const o = {}; for (const x of rows) {
    const kk = tupKey(x);
    o[kk] = (o[kk] || 0) + x.tup;
} return o; };
/** selisih RPD awal − total Catat TUP (minus = TUP melebihi RPD awal) */
function tupCmp(rows) {
    const tot = rows.reduce((s0, x) => s0 + x.tup, 0);
    if (tupMode === "up") {
        const u = upTotal();
        return { awal: u, tot, sel: u - tot, locked: u > 0, tgl: "" };
    }
    const a = rpdAwal(tupM);
    return { awal: a.total, tot, sel: a.total - tot, locked: a.locked, tgl: a.tgl };
}
function tupCmpUI(rows) {
    const c = tupCmp(rows), el = $("#tupCmp");
    if (tupMode === "up") {
        el.innerHTML = `<span>${capLbl()} (baku setahun): <b>Rp ${rupiah(c.awal)}</b> ${c.awal ? "" : `<span class="bad">— belum diisi di Pengaturan</span>`}</span>
    <span>Total Catat UP ${BULAN[tupM]}: <b>Rp ${rupiah(c.tot)}</b></span>
    <span>Selisih: <b class="sel ${c.sel < 0 ? "bad" : c.sel > 0 ? "" : "ok"}">${c.sel < 0 ? "−" : c.sel > 0 ? "+" : ""}Rp ${rupiah(Math.abs(c.sel))}</b></span>
    <span class="msg ${c.sel < 0 ? "bad" : ""}">${!c.awal ? `Isi <b>Total UP</b> di Pengaturan → Tarif bawaan.` : c.sel < 0 ? `⚠ Total Catat UP melebihi Total UP Rp ${rupiah(-c.sel)} — <b>UP tidak bisa difinalisasi</b>. Kurangi nominal UP.` : c.tot ? `Sisa UP Rp ${rupiah(c.sel)}.` : ""}</span>`;
        return;
    }
    el.innerHTML = `<span>Total Permintaan RPD Awal ${BLN_S[tupM]}: <b>Rp ${rupiah(c.awal)}</b> ${c.locked ? `<span class="tag" title="Dikunci di RPD ${esc(c.tgl)}">🔒 dikunci</span>` : `<span class="muted" title="Kunci lewat tombol Finalisasi RPD di halaman RPD">(belum dikunci)</span>`}</span>
    <span>Total Catat ${TL()}: <b>Rp ${rupiah(c.tot)}</b></span>
    <span>Selisih: <b class="sel ${c.sel < 0 ? "bad" : c.sel > 0 ? "" : "ok"}">${c.sel < 0 ? "−" : c.sel > 0 ? "+" : ""}Rp ${rupiah(Math.abs(c.sel))}</b></span>
    <span class="msg ${c.sel < 0 ? "bad" : ""}">${c.sel < 0 ? `⚠ Total Catat ${TL()} melebihi RPD awal Rp ${rupiah(-c.sel)} — <b>${TL()} tidak bisa difinalisasi</b>. Kurangi nominal ${TL()}.` : c.sel > 0 && c.tot ? `↩ Sisa Rp ${rupiah(c.sel)} dari RPD awal tidak terpakai — <b>harus dilakukan pengembalian</b>.` : c.tot ? "✓ Total Catat ${TL()} sama dengan RPD awal." : ""}</span>`;
}
function tupFinUI(rows) {
    tupCmpUI(rows);
    const cmp = tupCmp(rows);
    const el = $("#tupFin"), t = TD()[tupM] || {}, fin = t.fin, nOk = rows.filter(x => x.f.catat && tupOk(x)).length, done = rows.length > 0 && nOk === rows.length, tot = rows.reduce((s0, x) => s0 + x.tup, 0);
    const diff = fin ? Object.entries(tupReal(rows)).some(([k, v]) => num((rpdDB[k] || [])[tupM]) !== v) : false;
    el.hidden = !fin && !rows.length;
    el.className = "tup-fin" + (fin ? (done && !diff ? " ok" : " warn") : done ? "" : " wait");
    if (!fin && done && cmp.sel < 0) {
        el.className = "tup-fin warn";
        el.innerHTML = `<div><b>⚠ ${TL()} ${BULAN[tupM]} tidak bisa difinalisasi</b><br><small>Total Catat ${TL()} (Rp ${rupiah(cmp.tot)}) melebihi ${capLbl()} (Rp ${rupiah(cmp.awal)}) sebesar Rp ${rupiah(-cmp.sel)}. Kurangi nominal ${TL()} terlebih dahulu.</small></div>
       <div class="tf-act"><button type="button" class="btn sm" disabled>Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`;
        return;
    }
    if (!fin && !done) {
        el.innerHTML = `<div><b>Finalisasi ${TL()} ${BULAN[tupM]}</b> <span class="muted">— ${nOk} dari ${rows.length} baris selesai</span><br><small>Tersedia setelah semua baris dicentang <b>Selesai</b> (isian lengkap & pagu cukup). Finalisasi mengganti RPD ${BULAN[tupM]} dengan realisasi ${TL()}.</small><span class="tbar"><i style="width:${Math.round(nOk / rows.length * 100)}%"></i></span></div>
       <div class="tf-act"><button type="button" class="btn sm" disabled title="Selesaikan semua baris dulu">Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`;
        return;
    }
    el.innerHTML = fin
        ? `<div><b>✓ ${TL()} ${BULAN[tupM]} sudah difinalisasi</b> <span class="muted">(${esc(fin.tgl)})</span><br><small>RPD ${BULAN[tupM]} ${esc(angYear)} otomatis = hasil Catat ${TL()}: <b>Rp ${rupiah(fin.total)}</b>${diff ? "" : " ✓ sesuai"}. 🔒 Rincian Catat ${TL()} dan kolom RPD ${BULAN[tupM]} terkunci — klik <b>Batalkan finalisasi</b> untuk mengubah.${!done ? " ⚠ Ada baris yang belum selesai / melebihi pagu." : ""}</small></div>
       <div class="tf-act"><button type="button" class="btn sm" data-tgo-rpd>Lihat RPD</button><button type="button" class="btn sm" data-tfin="undo">Batalkan finalisasi</button></div>`
        : `<div><b>Semua ${rows.length} baris sudah selesai dicatat.</b><br><small>Finalisasi mengganti nilai RPD ${BULAN[tupM]} ${esc(angYear)} dengan realisasi ${TL()} (Rp ${rupiah(tot)}). Nilai RPD lama disimpan dan bisa dikembalikan.</small></div>
       <div class="tf-act"><button type="button" class="btn sm pri" data-tfin="go">Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`;
}
/** detil yang ikut TUP (bukan akun 51) dan punya RPD di bulan m */
const tupRpdKeys = (m) => (TD()[m]?.excl || []).filter(k => num((rpdDB[k] || [])[m]) > 0);
/* RPD bulan m := hasil Catat TUP. Detil ber-RPD yang tidak dicatat di TUP (dikeluarkan / tidak ada baris) menjadi 0.
   Akun 51 tidak disentuh (tidak lewat TUP). Nilai RPD sebelum finalisasi disimpan di prev (sekali) agar bisa dibatalkan. */
/* RPD bulan m = gabungan: TUP terfinalisasi → realisasi TUP (+ realisasi UP terfinalisasi), detil lain 0;
   hanya UP terfinalisasi → detil UP = realisasi UP, detil lain tetap. Nilai asli disimpan di prev (TUP / UP) agar bisa dibatalkan. */
function finRecalc(m, prev) {
    const tf = tupDB[m]?.fin, uf = upDB[m]?.fin, tP = tf?.prev || {}, uP = uf?.prev || {};
    const tr = tf ? withMode("tup", () => tupReal(tupRows(m))) : {}, ur = uf ? withMode("up", () => tupReal(tupRows(m))) : {};
    const orig = (k) => k in uP ? num(uP[k]) : k in tP ? num(tP[k]) : num((rpdDB[k] || [])[m]);
    const keys = new Set([...Object.keys(tP), ...Object.keys(uP), ...Object.keys(prev), ...Object.keys(tr), ...Object.keys(ur), ...(tf ? withMode("tup", () => tupRpdKeys(m)) : [])]);
    let chg = 0;
    for (const k of keys) {
        const v = tf ? num(tr[k]) + num(ur[k]) : uf && k in ur ? num(ur[k]) : orig(k), cur = num((rpdDB[k] || [])[m]);
        if (cur === v)
            continue;
        if (!(k in tP) && !(k in uP) && !(k in prev))
            prev[k] = cur;
        rpdOf(k)[m] = v;
        chg++;
    }
    return chg;
}
function tupApplyFin(m, prev) {
    const rows = tupRows(m);
    return { chg: finRecalc(m, prev), tot: rows.reduce((s0, x) => s0 + x.tup, 0) };
}
/** bulan yang sudah difinalisasi: RPD selalu mengikuti perubahan Catat TUP */
function tupFinSync(m) {
    const t = TD()[m];
    if (!t?.fin)
        return 0;
    const r = tupApplyFin(m, t.fin.prev);
    t.fin.total = r.tot;
    if (r.chg)
        persistAng();
    return r.chg;
}
function tupFinalize(m) {
    const rows = tupRows(m), t = tupOf(m);
    if (!rows.length)
        return;
    tupCalcSisa(m);
    if (!rows.every(x => x.f.catat && tupOk(x)))
        return toast("Semua baris harus selesai, lengkap, dan tidak melebihi pagu sebelum finalisasi.", "warn");
    const cmp = (() => { const tt = rows.reduce((s0, x) => s0 + x.tup, 0), aw = tupMode === "up" ? upTotal() : rpdAwal(m).total; return { awal: aw, tot: tt, sel: aw - tt }; })();
    if (cmp.sel < 0)
        return toast(`${TL()} tidak bisa difinalisasi: Total Catat ${TL()} melebihi ${tupMode === "up" ? "Total UP" : "RPD awal"} Rp ${rupiah(-cmp.sel)}.`, "err");
    if (tupMode === "up" && !upTotal())
        return toast("Isi Total UP tahun ini di Pengaturan sebelum finalisasi Catat UP.", "warn");
    const real = tupReal(rows), M = detMap(), prev = { ...(t.fin?.prev || {}) };
    const zero = tupRpdKeys(m).filter(k => !(k in real)), chg = [...Object.entries(real).filter(([k, v]) => num((rpdDB[k] || [])[m]) !== v).map(([k]) => k), ...zero], tot = rows.reduce((s0, x) => s0 + x.tup, 0);
    const over = Object.entries(real).filter(([k, v]) => M[k] && rpdSum(k) - num((rpdDB[k] || [])[m]) + v > M[k].j).length;
    if (!confirm(`Finalisasi ${TL()} ${BULAN[m]} ${angYear}?

• ${rows.length} baris, realisasi Rp ${rupiah(tot)}
• RPD ${BULAN[m]} otomatis diisi sesuai hasil Catat ${TL()} (${chg.length} detil berubah${zero.length ? `, ${zero.length} detil yang dikeluarkan dari ${TL()} menjadi 0` : ""})
• Kolom RPD ${BULAN[m]} dikunci (tidak bisa diisi manual) selama terfinalisasi
• Rincian Catat ${TL()} bulan ini terkunci — untuk mengubah, batalkan finalisasi dulu
• ${capLbl()} Rp ${rupiah(cmp.awal)} · selisih ${cmp.sel ? `Rp ${rupiah(cmp.sel)}${tupMode === "up" ? " (sisa UP)" : " → HARUS DILAKUKAN PENGEMBALIAN"}` : "Rp 0"}
• Nilai RPD lama disimpan — bisa dibatalkan kapan saja${over ? `

⚠ ${over} detil akan melebihi pagu setahun di RPD.` : ""}`))
        return;
    for (const x of rows)
        if (!x.dup) {
            if (!(t.val && x.k in t.val))
                t.val[x.k] = x.tup;
            if (!t.add.includes(x.k))
                t.add.push(x.k);
        } // jumlah & baris tetap walau RPD berubah
    if (tupMode === "tup" && !rpdFinDB[m]) {
        const val = {};
        let s0 = 0;
        for (const d of rpdTupDet()) {
            const v = num((rpdDB[d.key] || [])[m]);
            if (v) {
                val[d.key] = v;
                s0 += v;
            }
        }
        rpdFinDB[m] = { tgl: today(), total: s0, val };
    }
    void real;
    t.fin = { tgl: today(), prev, total: tot };
    tupApplyFin(m, prev);
    persistAng();
    renderTup();
    toast(`${TL()} ${BULAN[m]} difinalisasi — RPD ${BULAN[m]} sekarang sama dengan hasil Catat ${TL()} (Rp ${rupiah(tot)}).${cmp.sel > 0 ? (tupMode === "up" ? ` Sisa UP Rp ${rupiah(cmp.sel)}.` : ` Sisa Rp ${rupiah(cmp.sel)} harus dikembalikan.`) : ""}`, cmp.sel > 0 && tupMode === "tup" ? "warn" : "ok");
}
function tupUnfinal(m) {
    const t = tupOf(m), fin = t.fin;
    if (!fin)
        return;
    if (!confirm(`Batalkan finalisasi ${TL()} ${BULAN[m]}? Nilai RPD ${BULAN[m]} dikembalikan seperti sebelum finalisasi.`))
        return;
    const of = withMode(otherMode(), () => TD()[m]?.fin);
    delete t.fin;
    if (of) {
        for (const [k, v] of Object.entries(fin.prev))
            if (!(k in of.prev))
                of.prev[k] = v;
        finRecalc(m, of.prev);
    }
    else
        for (const [k, v] of Object.entries(fin.prev))
            rpdOf(k)[m] = v;
    persistAng();
    renderTup();
    toast(`Finalisasi ${TL()} ${BULAN[m]} dibatalkan — RPD dikembalikan.`);
}
$("#tupFin").addEventListener("click", e => { if (tg(e).closest("[data-tgo-rpd]")) {
    rpdTw = Math.floor(tupM / 3);
    show("rpd");
    return;
} const a = tg(e).closest("[data-tfin]")?.dataset.tfin; if (a === "go")
    tupFinalize(tupM);
else if (a === "undo")
    tupUnfinal(tupM); });
function renderTup() {
    rpdSupNamesOnly();
    $("#tupMonths").innerHTML = BULAN.map((b, m) => {
        const tot = tupRows(m).reduce((s0, x) => s0 + x.tup, 0);
        return `<button type="button" class="tupm ${m === tupM ? "on" : ""}" data-tm="${m}"><small>${BLN3[m]}</small><b>${tot ? rpShort(tot).replace("Rp ", "") : "–"}</b></button>`;
    }).join("");
    tupFinSync(tupM);
    const rows = tupRows(tupM), t = tupOf(tupM);
    tupCalcSisa(tupM);
    {
        const fin = tupFinOn();
        for (const id of ["#tupAdd", "#tupAddBtn", "#tupReset", "#tupTgl", "#tupKet"]) {
            const el = $(id);
            el.disabled = fin;
            if (el._dmy)
                el._dmy.disabled = fin;
        }
        $("#tupTbl").classList.toggle("finlock", fin);
    }
    angYearUI();
    $("#tupTitle").textContent = `${TL()} ${BULAN[tupM]} ${angYear}`;
    $("#tupSubT").innerHTML = tupMode === "up" ? `Detil ditambahkan sendiri (tanpa akun 51) · batas: <b>Total UP ${esc(angYear)} Rp ${rupiah(upTotal())}</b> (baku setahun, ubah di Pengaturan) · finalisasi mengubah RPD` : "Otomatis dari RPD (tanpa akun 51) · jumlah, uraian &amp; keterangan bisa diubah tanpa mengubah RPD/POK";
    $("#tupReset").hidden = tupMode === "up";
    $("#tupKet").placeholder = tupMode === "up" ? "mis. Belanja UP kegiatan survei" : "mis. Pengajuan TUP kegiatan survei";
    $("#tupAdd").placeholder = tupMode === "up" ? "+ Tambah detil POK yang dibayar dengan UP…" : "+ Tambah detil POK lain ke bulan ini…";
    $("#tupTgl").value = t.tgl || "";
    $("#tupKet").value = t.ket || "";
    tupSummary(rows);
    const vis = tupVis(rows);
    $("#tupTbl").innerHTML = (vis.length ? `<div class="tlist-h" aria-hidden="true"><span title="Centang bila sudah selesai dicatat">✓ Selesai</span><span>Uraian · MAK · tanggal</span><span>Jumlah</span><span>Pajak</span><span></span></div>` : "") + vis.map(x => `<div class="trow ${x.f.catat ? "tcat" : ""} ${tupOpen.has(x.k) ? "open" : ""}" data-k="${esc(x.k)}"><div class="tr-main" data-ttog tabindex="0" role="button" aria-label="Buka / tutup isian baris">${tupMain(x, rows.indexOf(x))}</div>${tupOpen.has(x.k) ? tupEditor(x) : ""}</div>`).join("")
        || `<div class="tempty">${rows.length ? "Tidak ada baris yang cocok dengan saringan." : (tupMode === "up" ? `Belum ada detil UP di bulan ${BULAN[tupM]}. Tambahkan detil POK yang dibayar dengan UP di bawah.` : `Belum ada detil dengan RPD di bulan ${BULAN[tupM]}. Isi RPD dulu, atau tambahkan detil di bawah.`)}</div>`;
    const hd = tupHidden(tupM);
    $("#tupHid").hidden = tupMode === "up" || !(hd.a51.length || hd.over.length);
    $("#tupHid").innerHTML = [hd.over.length ? `⚠ <b>${hd.over.length} detil tidak dimunculkan karena RPD melebihi pagu</b> (sisa minus): ${hd.over.slice(0, 4).map(d => esc(d.u.slice(0, 40))).join(", ")}${hd.over.length > 4 ? ", …" : ""}. Perbaiki di tab RPD.` : "",
        hd.a51.length ? `ℹ️ ${hd.a51.length} detil akun 51 (belanja pegawai) tidak dicatat di ${TL()}.` : ""].filter(Boolean).join("<br>");
    const ex = (t.excl || []).map(k => detMap()[k]).filter((d) => !!d);
    $("#tupExcl").innerHTML = ex.length ? `Dikeluarkan dari ${TL()} ${BULAN[tupM]}: ${ex.map(d => `<span class="chip">${esc(d.u.slice(0, 50))}<button type="button" class="x" data-tback="${esc(d.key)}" title="Masukkan lagi">↺</button></span>`).join(" ")}` : "";
}
/* perbarui satu baris (bagian ringkas) & ringkasan tanpa menyentuh kolom yang sedang diisi */
function tupRefreshRow(k) {
    if (tupFinSync(tupM)) {
        const mb = document.querySelector(`#tupMonths [data-tm="${tupM}"]`);
        if (mb)
            mb.title = "RPD ikut diperbarui (bulan terfinalisasi)";
    }
    const rows = tupRows(tupM), x = rows.find(y => y.k === k), el = document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(k)}"]`);
    if (!x || !el)
        return;
    tupCalcSisa(tupM);
    for (const y of rows)
        if (y.k !== k && (y.d.key === x.d.key || tupKey(y) === tupKey(x))) {
            const o = document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(y.k)}"] .tr-main`);
            if (o)
                o.innerHTML = tupMain(y, rows.indexOf(y));
        } // detil sama → sisa pagu ikut berubah
    el.querySelector(".tr-main").innerHTML = tupMain(x, rows.indexOf(x));
    el.classList.toggle("tcat", !!x.f.catat);
    tupSummary(rows);
    const mb = document.querySelector(`#tupMonths [data-tm="${tupM}"] b`);
    if (mb) {
        const tot = rows.reduce((s0, y) => s0 + y.tup, 0);
        mb.textContent = tot ? rpShort(tot).replace("Rp ", "") : "–";
    }
}
$("#tupMonths").addEventListener("click", e => { const b = tg(e).closest("[data-tm]"); if (!b)
    return; tupM = Number(b.dataset.tm); tupOpen.clear(); renderTup(); });
$("#tupSeg").addEventListener("click", e => { const b = tg(e).closest("[data-flt]"); if (!b)
    return; tupFlt = b.dataset.flt ?? ""; renderTup(); });
$("#tupTbl").addEventListener("input", e => {
    const row = tg(e).closest("[data-k]");
    if (!row)
        return;
    if (tupFinOn()) {
        toast(tupFinMsg(), "warn");
        renderTup();
        return;
    }
    const k0 = row.dataset.k ?? "", d0 = tupRows(tupM).find(y => y.k === k0)?.d, t0 = tupOf(tupM), el = tg(e);
    if (el.hasAttribute("data-tn")) {
        const v = el.value;
        if (!v.trim() || v.trim() === d0?.u)
            delete t0.nama[k0];
        else
            t0.nama[k0] = v;
        el.classList.toggle("edited", k0 in t0.nama);
    }
    else if (el.hasAttribute("data-tk")) {
        const v = el.value;
        if (v === rpdKetM(k0, tupM))
            delete t0.kt[k0];
        else
            t0.kt[k0] = v;
        el.classList.toggle("edited", k0 in t0.kt);
    }
    else if (el.dataset.tf === "mak") {
        const o = t0.f[k0] ||= {};
        if (el.value === d0?.a.mak)
            delete o.mak;
        else
            o.mak = el.value;
        delete o.det;
        persistAng();
        renderTup();
        const xx = tupRows(tupM).find(y => y.k === k0), dk = xx ? detMap()[tupKey(xx)] : undefined;
        toast(`MAK baris diubah ke ${el.value}${dk && xx && dk.key !== xx.d.key ? ` — realisasi dibebankan ke detil "${dk.u.slice(0, 50)}"` : ""}.`);
        return;
    }
    else if (el.dataset.tf === "det") {
        const o = t0.f[k0] ||= {}, nk = keyFromInput(el), nd = nk ? detMap()[nk] : undefined;
        if (!nd || !d0)
            return;
        if (tupAkun51(nd)) {
            toast(`Akun 51 (belanja pegawai) tidak dicatat di ${TL()} — pilih detil lain.`, "warn");
            return;
        }
        if (nd.a.mak === d0.a.mak)
            delete o.mak;
        else
            o.mak = nd.a.mak;
        if (nd.key === d0.key)
            delete o.det;
        else
            o.det = nd.key;
        persistAng();
        renderTup();
        toast(nd.key === d0.key ? "Kembali ke detil & MAK asal." : `Dibebankan ke ${nd.a.mak} — "${nd.u.slice(0, 50)}".`);
        return;
    }
    else if (el.dataset.tf) {
        const o = t0.f[k0] ||= {}, fk = el.dataset.tf;
        o[fk] = el.value.trim();
        if (!o[fk])
            delete o[fk];
    }
    else if (el.hasAttribute("data-tv")) {
        t0.val[k0] = num(el.value);
        el.classList.add("edited");
    }
    else
        return;
    persistAng();
    tupRefreshRow(k0);
});
$("#tupTbl").addEventListener("input", e => { const el = tg(e); if (el.classList.contains("need") && el.value) {
    el.classList.remove("need");
    el._dmy?.classList.remove("need");
} }, true);
$("#tupTbl").addEventListener("change", e => {
    const el0 = tg(e);
    if (el0.classList.contains("need") && el0.value) {
        el0.classList.remove("need");
        el0._dmy?.classList.remove("need");
    }
    if (tg(e).dataset.tc !== "catat")
        return;
    const row = tg(e).closest("[data-k]");
    if (!row)
        return;
    if (tupFinOn()) {
        tg(e).checked = !tg(e).checked;
        return toast(tupFinMsg(), "warn");
    }
    const k = row.dataset.k ?? "", o = tupOf(tupM).f[k] ||= {};
    if (tg(e).checked) {
        const rs = tupRows(tupM), me0 = rs.find(y => y.k === k);
        if (me0) {
            tupCalcSisa(tupM);
            const ms = tupMissing(me0), mn = tupMinus(me0);
            if (ms.length || mn < 0) {
                tg(e).checked = false;
                tupOpen.add(k);
                renderTup();
                if (ms.length) {
                    const map = { "tanggal nota": '[data-tf="nota"]', "tanggal SPBY": '[data-tf="spby"]', "tanggal kuitansi SAKTI": '[data-tf="kui"]', uraian: "[data-tn]", supplier: '[data-tf="sup"]', jumlah: "[data-tv]" };
                    setTimeout(() => { for (const m0 of ms) {
                        const sel = map[m0];
                        const inp = sel && document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(k)}"] ${sel}`);
                        if (inp) {
                            inp.classList.add("need");
                            inp._dmy?.classList.add("need");
                        }
                    } }, 0);
                    if (ms.includes("rincian pajak (DPP)") && ms.length === 1)
                        openPajak(k);
                    return toast(`Belum bisa ditandai selesai — lengkapi dulu: ${ms.join(", ")}.`, "warn");
                }
                return toast(`Belum bisa ditandai selesai — dana pagu detil tidak cukup (kurang Rp ${rupiah(-mn)}). Kurangi jumlah atau ajukan revisi.`, "err");
            }
        }
        const me = me0, nrm = (v) => String(v || "").trim().toLowerCase().replace(/\s+/g, " ");
        const same = rs.filter(y => y.k !== k && nrm(y.nama) === nrm(me?.nama));
        if (same.length) {
            tg(e).checked = false;
            tupOpen.add(k);
            renderTup();
            const el = document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(k)}"] [data-tn]`);
            el?.focus();
            el?.select();
            return toast(`Uraian sama dengan baris ${same.map(y => rs.indexOf(y) + 1).join(", ")}. Ubah uraian dulu sebelum menandai selesai.`, "warn");
        }
    }
    if (tg(e).checked)
        o.catat = true;
    else
        delete o.catat;
    persistAng();
    toast(tg(e).checked ? "Ditandai selesai dicatat — semua isian baris ini terkunci." : "Tanda selesai dihapus — isian bisa diubah lagi.");
    if (tupFlt || tupOpen.has(k))
        renderTup();
    else
        tupRefreshRow(k);
});
$("#tupTbl").addEventListener("click", e => {
    const row = tg(e).closest("[data-k]");
    if (!row)
        return;
    const k = row.dataset.k ?? "";
    const cp = tg(e).closest("[data-cp]");
    if (cp) {
        e.preventDefault();
        return salin(cp.dataset.cp, cp.dataset.cpl);
    }
    const cpf = tg(e).closest("[data-cpf]");
    if (cpf) {
        e.preventDefault();
        const f0 = cpf.dataset.cpf ?? "", inp = row.querySelector(f0 === "tn" ? "[data-tn]" : f0 === "tv" ? "[data-tv]" : `[data-tf="${f0}"]`);
        return salin(/^(nota|spby|kui)$/.test(f0) ? tglSalin(inp?.value) : inp?.value, cpf.dataset.cpl);
    }
    const locked = !!TD()[tupM]?.f?.[k]?.catat || tupFinOn();
    if (tupFinOn() && tg(e).closest("[data-tpj],[data-tdup],[data-tx],[data-supuse]"))
        return toast(tupFinMsg(), "warn");
    if (tg(e).closest("[data-supuse]")) {
        const x = tupRows(tupM).find(y => y.k === k), s0 = x ? rpdSupGet(x.d.key, tupM) : undefined;
        if (!s0 || locked)
            return;
        const o = TD()[tupM].f[k] ||= {};
        o.sup = s0.t;
        persistAng();
        renderTup();
        return toast(`Supplier diisi dari RPD: ${s0.t}`);
    }
    if (locked && tg(e).closest("[data-tpj],[data-tdup],[data-tx]"))
        return toast("Baris sudah Selesai — terkunci. Hapus centang ✓ Selesai untuk mengubah.", "warn");
    if (tg(e).closest("[data-tpj]"))
        return openPajak(k);
    if (tg(e).closest("[data-tdup]")) {
        const t = tupOf(tupM), x = tupRows(tupM).find(y => y.k === k);
        if (!x)
            return;
        const id = "dup:" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        t.dup.push({ id, src: x.d.key });
        t.val[id] = x.tup;
        t.nama[id] = x.nama;
        if (x.ket)
            t.kt[id] = x.ket;
        const f = { ...x.f };
        delete f.catat;
        delete f.pajak;
        delete f.pj;
        if (Object.keys(f).length)
            t.f[id] = f;
        tupOpen.add(id);
        persistAng();
        renderTup();
        const el = document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(id)}"] [data-tn]`);
        el?.focus();
        el?.select();
        return toast("Baris diduplikat. Ubah uraian & jumlahnya; uraian harus berbeda sebelum ditandai selesai.");
    }
    if (tg(e).closest("[data-tx]")) {
        const t = tupOf(tupM);
        if (Object.keys(t.f[k] || {}).length && !confirm(`Baris ini sudah berisi tanggal / supplier / pajak / tanda. Tetap keluarkan dari ${TL()} bulan ini?`))
            return;
        if (k.startsWith("dup:")) {
            t.dup = t.dup.filter(x => x.id !== k);
            delete t.val[k];
            delete t.nama[k];
            delete t.kt[k];
            delete t.f[k];
            tupOpen.delete(k);
            persistAng();
            renderTup();
            return toast("Baris duplikat dihapus.");
        }
        if (t.dup.some(x => x.src === k) && !confirm("Detil ini punya baris duplikat. Keluarkan juga semua duplikatnya?"))
            return;
        for (const dp of t.dup.filter(x => x.src === k)) {
            delete t.val[dp.id];
            delete t.nama[dp.id];
            delete t.kt[dp.id];
            delete t.f[dp.id];
        }
        t.dup = t.dup.filter(x => x.src !== k);
        t.add = t.add.filter(x => x !== k);
        if (tupMode === "tup" && num((rpdDB[k] || [])[tupM]) > 0 && !t.excl.includes(k))
            t.excl.push(k);
        delete t.val[k];
        delete t.nama[k];
        delete t.kt[k];
        delete t.f[k];
        tupOpen.delete(k);
        persistAng();
        renderTup();
        toast(`Detil dikeluarkan dari ${TL()} bulan ini.`);
        return;
    }
    if (tg(e).closest("[data-stop]") || !tg(e).closest("[data-ttog]"))
        return;
    tupOpen.has(k) ? tupOpen.delete(k) : tupOpen.add(k);
    renderTup();
    if (tupOpen.has(k))
        document.querySelector(`#tupTbl .trow[data-k="${CSS.escape(k)}"] [data-tf="nota"]`)?.focus();
});
$("#tupTbl").addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && tg(e).matches(".tr-main")) {
    e.preventDefault();
    tg(e).click();
} });
$("#tupExcl").addEventListener("click", e => { const k = tg(e).closest("[data-tback]")?.dataset.tback; if (!k)
    return; if (tupFinOn())
    return toast(tupFinMsg(), "warn"); const t = tupOf(tupM); t.excl = t.excl.filter(x => x !== k); persistAng(); renderTup(); });
$("#tupAddBtn").onclick = () => {
    if (tupFinOn())
        return toast(tupFinMsg(), "warn");
    const el = $("#tupAdd"), k = keyFromInput(el);
    if (!k)
        return toast("Pilih detil dari daftar.");
    const t = tupOf(tupM), dd = detMap()[k];
    if (tupAkun51(dd))
        return toast(`Akun 51 (belanja pegawai) tidak dicatat di ${TL()}.`);
    if (tupOver(dd))
        return toast("RPD detil ini melebihi pagu. Perbaiki dulu di tab RPD.");
    t.excl = t.excl.filter(x => x !== k);
    if (!t.add.includes(k) && (tupMode === "up" || !num((rpdDB[k] || [])[tupM])))
        t.add.push(k);
    el.value = "";
    tupOpen.add(k);
    persistAng();
    renderTup();
    toast(`Detil ditambahkan ke ${TL()} ` + BULAN[tupM] + ".");
};
$("#tupAdd").addEventListener("keydown", e => { if (e.key === "Enter" && $("#acBox").hidden) {
    e.preventDefault();
    $("#tupAddBtn").click();
} });
$("#tupTgl").addEventListener("input", e => { if (tupFinOn())
    return; tupOf(tupM).tgl = tg(e).value.trim(); persistAng(); });
$("#tupKet").addEventListener("input", e => { if (tupFinOn())
    return; tupOf(tupM).ket = tg(e).value.trim(); persistAng(); });
$("#tupReset").onclick = () => { if (tupFinOn())
    return toast(tupFinMsg(), "warn"); if (!confirm(`Kembalikan nilai ${TL()} ${BULAN[tupM]} sesuai RPD? Perubahan jumlah, uraian, keterangan, detil tambahan & yang dikeluarkan dihapus (tanggal, supplier, pajak & tanda tetap).`))
    return; const t = tupOf(tupM); t.val = {}; t.add = []; t.excl = []; t.nama = {}; t.kt = {}; persistAng(); renderTup(); toast("${TL()} dikembalikan sesuai RPD."); };
$("#tupExp").onclick = () => {
    const wb = XLSX.utils.book_new(), one = $("#tupScope").value === "bulan";
    for (const m of one ? [tupM] : [...Array(12).keys()]) {
        const rows = tupRows(m);
        if (!rows.length && !one)
            continue;
        const t = TD()[m] || {}, P = (x) => tupPj(x.f);
        const ws = XLSX.utils.aoa_to_sheet([[`CATATAN ${TL()} ${BULAN[m].toUpperCase()} ${angYear}`], [t.tgl ? "Tanggal pengajuan: " + t.tgl : "", t.ket || ""], [],
            ["No", "Tanggal Nota", "Tanggal SPBY", "Tanggal Kuitansi SAKTI", "Uraian", "Supplier", "Jumlah", "Kegiatan", "Akun", "Keterangan", "Sudah Catat", "Ada Pajak", "DPP", "PPN", "Jenis PPh", "PPh", "MAK"],
            ...rows.map((x, i) => [i + 1, isoTgl(x.f.nota), isoTgl(x.f.spby), isoTgl(x.f.kui), x.nama, x.f.sup || "", x.tup, `${x.a.ro} ${roTitle(x.a.roNama)}`, `${x.a.akun} ${x.a.nama}`, x.ket, x.f.catat ? "Ya" : "Belum", x.f.pajak ? "Ya" : "Tidak",
                x.f.pajak && x.f.pj ? num(x.f.pj.dpp) : "", x.f.pajak && x.f.pj ? P(x).ppn : "", x.f.pajak && x.f.pj ? x.f.pj.pphJ || "" : "", x.f.pajak && x.f.pj ? P(x).pph : "", x.a.mak]),
            ["", "", "", "", "Jumlah", "", rows.reduce((s0, x) => s0 + x.tup, 0), "", "", "", `${rows.filter(x => x.f.catat).length} dari ${rows.length}`, `${rows.filter(x => x.f.pajak).length}`, "", rows.reduce((s0, x) => s0 + P(x).ppn, 0), "", rows.reduce((s0, x) => s0 + P(x).pph, 0), ""]]);
        ws["!cols"] = [5, 16, 16, 20, 46, 24, 14, 40, 34, 36, 11, 10, 14, 12, 12, 12, 28].map(w => ({ wch: w }));
        XLSX.utils.book_append_sheet(wb, ws, BULAN[m]);
    }
    if (!wb.SheetNames.length)
        return toast(`Belum ada ${TL()} untuk diekspor.`);
    XLSX.writeFile(wb, one ? `${TL()} ${BULAN[tupM]} ${angYear}.xlsx` : `${TL()} ${angYear} (${wb.SheetNames.length} bulan).xlsx`);
    toast(`${TL()} diekspor.`);
};
/* ---------- pop-up pajak: DPP, PPN, PPh ---------- */
function openPajak(k) {
    const x = tupRows(tupM).find(y => y.k === k);
    if (!x)
        return;
    tupPjKey = k;
    const f = x.f, pj = f.pj || {}, dppDef = Math.round(x.tup * 100 / 111);
    $("#pjU").textContent = x.nama;
    $("#pjJml").textContent = "Rp " + rupiah(x.tup);
    $("#pjDel").hidden = !f.pajak;
    $("#pjPphJ").innerHTML = PPH_J.map(([n, r]) => `<option value="${n}" data-r="${r}">${n}${r ? ` (${String(r).replace(".", ",")}%)` : ""}</option>`).join("");
    $("#pjPpnOn").checked = pj.ppnOn ?? true;
    $("#pjDpp").value = String(pj.dpp ?? (($("#pjPpnOn").checked) ? dppDef : x.tup));
    $("#pjPpnT").value = String(pj.ppnT ?? 11);
    $("#pjPphJ").value = pj.pphJ || "PPh 22";
    $("#pjPphT").value = String(pj.pphT ?? 1.5);
    $("#pjPpn").value = String(pj.ppn ?? "");
    $("#pjPph").value = String(pj.pph ?? "");
    if (pj.ppn == null)
        pjCalc("ppn");
    if (pj.pph == null)
        pjCalc("pph");
    pjCalc();
    $("#dPajak").showModal();
    $("#pjDpp").focus();
    $("#pjDpp").select();
}
function pjCalc(what) {
    const dpp = num($("#pjDpp").value), on = $("#pjPpnOn").checked;
    $("#pjPpnBox").classList.toggle("off", !on);
    if (what === "ppn" || what === "all")
        $("#pjPpn").value = String(on ? Math.round(dpp * num($("#pjPpnT").value) / 100) : 0);
    if (what === "pph" || what === "all")
        $("#pjPph").value = String(Math.round(dpp * num($("#pjPphT").value) / 100));
    const x = tupRows(tupM).find(y => y.k === tupPjKey), ppn = on ? num($("#pjPpn").value) : 0, pph = num($("#pjPph").value);
    $("#pjTot").textContent = "Rp " + rupiah(ppn + pph);
    $("#pjNet").textContent = "Rp " + rupiah((x ? x.tup : 0) - ppn - pph);
}
$("#pjDpp").addEventListener("input", () => pjCalc("all"));
$("#pjPpnT").addEventListener("input", () => pjCalc("ppn"));
$("#pjPphT").addEventListener("input", () => pjCalc("pph"));
$("#pjPpnOn").addEventListener("change", () => pjCalc("ppn"));
$("#pjPphJ").addEventListener("change", e => { const r = e.target.selectedOptions[0]?.dataset.r; if (r && +r)
    $("#pjPphT").value = r; pjCalc("pph"); });
$("#pjPpn").addEventListener("input", () => pjCalc());
$("#pjPph").addEventListener("input", () => pjCalc());
$("#pjFromJml").onclick = () => { const x = tupRows(tupM).find(y => y.k === tupPjKey); if (!x)
    return; $("#pjDpp").value = String($("#pjPpnOn").checked ? Math.round(x.tup * 100 / 111) : x.tup); pjCalc("all"); };
$("#pjCancel").onclick = () => $("#dPajak").close();
$("#pjSave").onclick = () => {
    if (tupFinOn())
        return toast(tupFinMsg(), "warn");
    const o = tupOf(tupM).f[tupPjKey] ||= {};
    o.pajak = true;
    o.pj = { dpp: num($("#pjDpp").value), ppnOn: $("#pjPpnOn").checked, ppnT: num($("#pjPpnT").value), ppn: $("#pjPpnOn").checked ? num($("#pjPpn").value) : 0, pphJ: $("#pjPphJ").value, pphT: num($("#pjPphT").value), pph: num($("#pjPph").value) };
    persistAng();
    $("#dPajak").close();
    if (tupFlt)
        renderTup();
    else
        tupRefreshRow(tupPjKey);
    toast("Rincian pajak disimpan.");
};
$("#pjDel").onclick = () => { if (!confirm("Hapus tanda & rincian pajak baris ini?"))
    return; const o = tupOf(tupM).f[tupPjKey] || {}; delete o.pajak; delete o.pj; persistAng(); $("#dPajak").close(); if (tupFlt)
    renderTup();
else
    tupRefreshRow(tupPjKey); toast("Pajak dihapus dari baris ini."); };

/* ---- 84_tupreq.ts ---- */
const trKey = () => "st.tupReq." + angYear;
let trDB = { hdr: {}, m: {} }, trM = new Date().getMonth();
const trLoad = () => { trDB = LS.get(trKey(), null) || { hdr: {}, m: {} }; trDB.hdr ||= {}; trDB.m ||= {}; return trDB; };
const trSave = () => LS.set(trKey(), trDB);
const isoToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const isoD = (v) => { const m = String(v || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
/* rentang tanggal → "2 – 20 November 2026" · "28 Oktober – 3 November 2026" · "30 Desember 2026 – 2 Januari 2027" */
function fmtRange(a, b) {
    const A = isoD(a);
    if (!A)
        return "";
    const B = isoD(b) || A;
    if (+B === +A)
        return fmtDate(A);
    const [x, y] = B < A ? [B, A] : [A, B];
    if (x.getFullYear() !== y.getFullYear())
        return `${fmtDate(x)} – ${fmtDate(y)}`;
    if (x.getMonth() !== y.getMonth())
        return `${x.getDate()} ${BULAN[x.getMonth()]} – ${fmtDate(y)}`;
    return `${x.getDate()} – ${fmtDate(y)}`;
}
const joinDan = (xs0) => { const xs = [...new Set(xs0.map(s => String(s).trim()).filter(Boolean))]; return xs.length < 2 ? (xs[0] || "") : xs.slice(0, -1).join(", ") + " dan " + xs[xs.length - 1]; };
const kpaList = () => roleHolders(["KEPALA"]);
const trHdr = () => {
    const h = trDB.hdr, k = kpaList();
    const kpa = h.kpa && k.some((p) => String(p.kode) === String(h.kpa)) ? String(h.kpa) : (k[0] ? String(k[0].kode) : "");
    return { sd: h.sd ?? "RM", dipa: h.dipa ?? `DIPA-054.01.2.690691/${angYear}`, up: h.up ?? "", tempat: h.tempat ?? "Maybrat", tglIso: h.tglIso || trDefTgl(), kpa };
};
const trDefTgl = () => { const t = isoToday(), mo = `${angYear}-${String(trM + 1).padStart(2, "0")}`; return t.startsWith(mo) ? t : `${mo}-01`; };
const isoDt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
/* rentang sah tanggal kegiatan: tanggal surat permintaan TUP s.d. 30 hari sesudahnya */
const TR_MAXD = 30;
function trWin() { const d0 = isoD(trHdr().tglIso) || new Date(), d1 = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + TR_MAXD); return { a: isoDt(d0), b: isoDt(d1), A: d0, B: d1, txt: `${fmtDate(d0)} – ${fmtDate(d1)}` }; }
function trSuratErr() { const d = isoD(trHdr().tglIso); if (!d)
    return "Pilih tanggal surat."; if (String(d.getFullYear()) !== String(angYear))
    return `Tanggal surat harus di tahun anggaran ${angYear} (terpilih tahun ${d.getFullYear()}).`; return ""; }
function trTglErr(a, b) {
    if (!a)
        return "";
    const w = trWin(), A = isoD(a);
    if (!A)
        return "Tanggal tidak valid.";
    const B = isoD(b) || A;
    if (String(A.getFullYear()) !== String(angYear) || String(B.getFullYear()) !== String(angYear))
        return `Tahun salah: TUP ${angYear}, terpilih tahun ${(String(A.getFullYear()) !== String(angYear) ? A : B).getFullYear()}.`;
    if (a < w.a)
        return `Tidak boleh sebelum tanggal surat (${fmtDate(w.A)}).`;
    if ((b || a) > w.b)
        return `Maksimal ${TR_MAXD} hari dari tanggal surat (s.d. ${fmtDate(w.B)}).`;
    return "";
}
/* baris = kegiatan + output (KRO.RO) + akun; nilai dari RPD bulan m */
function trGroups(m) {
    const G = new Map();
    for (const d of pokDetil()) {
        if (d.blokir || tupAkun51(d))
            continue;
        const a = d.a, g = `${a.keg}|${a.ro}|${a.akun}`, r = rpdDB[d.key] || [];
        const o = G.get(g) || { g, keg: a.keg, out: a.ro.split(".").slice(1).join("."), ro: a.ro, akun: a.akun, akunNm: a.nama, pagu: 0, before: 0, val: 0, detil: [] };
        o.pagu += d.j;
        for (let i = 0; i < m; i++)
            o.before += num(r[i]);
        const v = num(r[m]);
        if (v > 0 && !tupOver(d)) {
            o.val += v;
            o.detil.push(d.u);
        }
        G.set(g, o);
    }
    const ov = (trDB.m[m] || {});
    return [...G.values()].filter(o => o.val > 0).map((o) => {
        const s = ov[o.g] || {}, sis = o.pagu - o.before, val = o.val; // sesuai RPD — tidak bisa diubah di sini
        return { ...o, sisa: sis, val, sesudah: sis - val, tglA: s.tglA || "", tglB: s.tglB || "", tgl: fmtRange(s.tglA, s.tglB), namaDef: joinDan(o.detil), namaK: s.nama ?? joinDan(o.detil), off: !!s.off };
    })
        .sort((x, y) => x.keg.localeCompare(y.keg) || x.ro.localeCompare(y.ro) || x.akun.localeCompare(y.akun));
}
function trRender() {
    const h = trHdr(), rows = trGroups(trM), on = rows.filter(x => !x.off);
    $("#trMonth").innerHTML = BULAN.map((b, i) => `<option value="${i}" ${i === trM ? "selected" : ""}>${b} ${angYear}</option>`).join("");
    for (const [id, k] of [["#trSd", "sd"], ["#trDipa", "dipa"], ["#trUp", "up"], ["#trTempat", "tempat"], ["#trTgl", "tglIso"]])
        if (document.activeElement !== $(id))
            $(id).value = String(h[k]);
    $("#trTglTxt").textContent = fmtDate(isoD(h.tglIso) || new Date());
    const k = kpaList();
    $("#trKpa").innerHTML = k.length ? k.map((p) => `<option value="${esc(p.kode)}" ${String(p.kode) === h.kpa ? "selected" : ""}>${esc(p.nama)}</option>`).join("") : `<option value="">— belum ada pegawai berperan Kepala Kantor —</option>`;
    $("#trKpaHint").hidden = !!k.length;
    const W0 = trWin();
    $("#trWin").textContent = `Rentang sah: ${W0.txt} (maks. ${TR_MAXD} hari dari tanggal surat)`;
    {
        const se = trSuratErr();
        $("#trTglErr").textContent = se;
        $("#trTglErr").hidden = !se;
        $("#trTgl").classList.toggle("err", !!se);
    }
    $("#trRows").innerHTML = on.length ? on.map((x, i) => `<tr data-g="${esc(x.g)}" class="${x.tglA ? "" : "need"} ${x.sesudah < 0 ? "neg" : ""} ${trTglErr(x.tglA, x.tglB) ? "tglerr" : ""}"><td class="muted">${i + 1}</td>
      <td><div class="trk"><b>${esc(x.keg)}</b> · ${esc(x.out)} · <b>${esc(x.akun)}</b></div><div class="lsub one">${esc(x.akunNm)} · ${x.detil.length} detil</div></td>
      <td class="num" title="Pagu ${rupiah(x.pagu)} − RPD bulan sebelumnya ${rupiah(x.before)}"><b>${rupiah(x.sisa)}</b><div class="lsub">pagu − RPD s.d. ${BLN3[Math.max(0, trM - 1)]}</div></td>
      <td class="num"><b>${rupiah(x.val)}</b><div class="lsub">RPD ${BLN3[trM]}</div></td>
      <td class="num ${x.sesudah < 0 ? "bad" : ""}" data-sesudah>${rupiah(x.sesudah)}${x.sesudah < 0 ? `<div class="lsub bad">tidak boleh minus</div>` : ""}</td>
      <td><div class="trdr"><input type="date" data-trf="tglA" value="${esc(x.tglA)}" min="${W0.a}" max="${W0.b}" aria-label="Tanggal mulai" title="Tanggal mulai (${W0.txt})"><span>s.d.</span><input type="date" data-trf="tglB" value="${esc(x.tglB)}" min="${esc(x.tglA || W0.a)}" max="${W0.b}" aria-label="Tanggal selesai" title="Tanggal selesai (kosong = 1 hari)"></div>${trTglTxt(x.tglA, x.tglB)}</td>
      <td><textarea rows="2" data-trf="nama" title="Bawaan: gabungan nama detil">${esc(x.namaK)}</textarea>${x.namaK !== x.namaDef ? `<button type="button" class="linkbtn" data-trdef>kembalikan ke nama detil</button>` : ""}</td>
      <td><button class="ib del" type="button" data-troff title="Jangan masukkan baris ini">${IC.del}</button></td></tr>`).join("")
        : `<tr><td colspan="8" class="muted" style="text-align:center;padding:20px">Tidak ada RPD di bulan ${BULAN[trM]} ${angYear} (akun 51 &amp; detil yang RPD-nya melebihi pagu tidak dihitung). Isi RPD bulan ini dulu.</td></tr>`;
    $("#trAllA").min = $("#trAllB").min = W0.a;
    $("#trAllA").max = $("#trAllB").max = W0.b;
    trSumOnly();
}
function trSumOnly() {
    const h = trHdr(), rows = trGroups(trM), on = rows.filter(x => !x.off), off = rows.length - on.length;
    const tot = on.reduce((s0, x) => s0 + x.val, 0), up = num(h.up), need = on.filter(x => !x.tglA).length, neg = on.filter(x => x.sesudah < 0).length, bad = on.filter(x => trTglErr(x.tglA, x.tglB)).length, se = trSuratErr();
    $("#trSum").innerHTML = `<span>Rencana TUP <b>Rp ${rupiah(tot)}</b></span><span>UP Satker <b>Rp ${rupiah(up)}</b></span><span class="${tot - up < 0 ? "bad" : ""}">Total TUP <b>Rp ${rupiah(tot - up)}</b></span>${tot - up < 0 ? `<span class="bad">⚠ Total TUP tidak boleh minus — UP Satker melebihi rencana TUP</span>` : ""}${neg ? `<span class="bad">⚠ ${neg} baris sisa pagu setelah TUP minus</span>` : ""}${se ? `<span class="bad">⚠ ${esc(se)}</span>` : ""}${bad ? `<span class="bad">⚠ ${bad} baris tanggal kegiatan di luar rentang</span>` : ""}${need ? `<span class="bad">⚠ ${need} baris belum diisi tanggal kegiatan</span>` : on.length && !bad && !se ? `<span class="ok">✓ Tanggal kegiatan lengkap</span>` : ""}${off ? `<button type="button" class="linkbtn" id="trOn">Tampilkan lagi ${off} baris yang dikeluarkan</button>` : ""}`;
}
const trTglTxt = (a, b) => { const e = trTglErr(a, b); return `<div class="lsub ${e ? "bad" : ""}" data-tgltxt>${e ? "⚠ " + esc(e) : esc(fmtRange(a, b)) || "pilih tanggal mulai &amp; selesai"}</div>`; };
function trSet(g, k, v) { const o = (trDB.m[trM] ||= {})[g] ||= {}; if (v === "" || v == null)
    delete o[k];
else
    o[k] = v; trSave(); }
function openTupReq() {
    trLoad();
    trM = Math.max(0, Math.min(11, LS.get("st.trM", new Date().getMonth())));
    $("#trPrev").hidden = true;
    $("#trPrevDoc").innerHTML = "";
    trRender();
    $("#dTupReq").showModal();
}
/* ---------- isi template .docx ---------- */
const TR_FONT = "Arial", TR_SZ = 18, TR_SZ_TITLE = 24; // 9 pt isi, 12 pt judul (half-point)
async function buildTupReq() {
    const h = trHdr(), rows = trGroups(trM).filter(x => !x.off), kpa = pegawai.find(p => String(p.kode) === String(h.kpa)) || {};
    const zip = await JSZip.loadAsync(TUPREQ_TPL, { base64: true }), xml = await zip.file("word/document.xml").async("string");
    const doc = new DOMParser().parseFromString(xml, "application/xml"), W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    /* elemen anak WordprocessingML dengan nama lokal tertentu */
    const ch = (el, tag) => [...el.children].filter(n => n.localName === tag);
    const ts = (el) => [...el.getElementsByTagNameNS(W, "t")];
    const txt = (el) => ts(el).map(t => t.textContent).join("");
    const rTxt = (r) => ch(r, "t").map(t => t.textContent).join("");
    const isTab = (r) => !!ch(r, "tab").length && !ch(r, "t").length;
    const mk = (tag, val) => { const e = doc.createElementNS(W, "w:" + tag); if (val != null)
        e.setAttributeNS(W, "w:val", String(val)); return e; };
    const setT = (r, v) => { const t = ch(r, "t"); if (t.length) {
        t[0].textContent = v;
        t[0].setAttribute("xml:space", "preserve");
        t.slice(1).forEach(x => x.remove());
    }
    else {
        const n = doc.createElementNS(W, "w:t");
        n.setAttribute("xml:space", "preserve");
        n.textContent = v;
        r.appendChild(n);
    } };
    const body = doc.getElementsByTagNameNS(W, "body")[0], kids = [...body.children];
    const para = (s) => kids.find(k => k.localName === "p" && txt(k).includes(s));
    const pNip = para("(21)"), pT1 = para("FORMAT RENCANA"), pT2 = para("DAFTAR RENCANA PENGGUNAAN");
    /* "Label : ....(N)" → "Label : nilai" — semua tab (bertitik) setelah titik dua dibuang */
    const fillColon = (p, v, bold) => {
        if (!p)
            return;
        const rs = ch(p, "r"), ic = rs.findIndex(r => rTxt(r).trim() === ":");
        if (ic < 0)
            return;
        setT(rs[ic], ": ");
        let set = false;
        for (const r of rs.slice(ic + 1)) {
            if (ch(r, "tab").length && !ch(r, "t").length) {
                r.remove();
                continue;
            }
            if (!rTxt(r))
                continue;
            if (!set) {
                setT(r, v);
                set = true;
                if (bold) {
                    const pr = ch(r, "rPr")[0] || r.insertBefore(mk("rPr"), r.firstChild);
                    pr.appendChild(mk("b"));
                }
            }
            else
                r.remove();
        }
    };
    fillColon(para("Kode Satker"), "690691");
    fillColon(para("Nama Satker"), "BPS Kabupaten Maybrat");
    fillColon(para("Nomor DIPA"), h.dipa);
    fillColon(para("Sumber Dana"), h.sd);
    const tot = rows.reduce((s0, x) => s0 + x.val, 0), up = num(h.up);
    fillColon(para("Rencana TUP"), "Rp " + rupiah(tot));
    fillColon(para("UP Satker"), "Rp " + rupiah(up));
    fillColon(para("Total TUP"), "Rp " + rupiah(tot - up), true);
    {
        const p = para("(17)");
        if (p) {
            const rs = ch(p, "r").filter(r => rTxt(r));
            if (rs[0]) {
                setT(rs[0], `${h.tempat}, ${fmtDate(isoD(h.tglIso) || new Date())}`);
                rs.slice(1).forEach(r => r.remove());
            }
        }
    }
    {
        const p = para("(19)");
        if (p) {
            const rs = ch(p, "r");
            rs.filter(r => rTxt(r).includes("(19)")).forEach(r => r.remove());
            rs.filter(isTab).slice(1).forEach(r => r.remove());
        }
    }
    {
        const p = para("(20)");
        if (p) {
            const rs = ch(p, "r");
            rs.filter(isTab).slice(1).forEach(r => r.remove());
            const r = rs.find(r => rTxt(r).includes("(20)"));
            if (r) {
                setT(r, kpa.nama || "");
                const pr = ch(r, "rPr")[0] || r.insertBefore(mk("rPr"), r.firstChild);
                pr.appendChild(mk("b"));
                pr.appendChild(mk("u", "single"));
            }
        }
    }
    {
        const p = pNip;
        if (p) {
            const rs = ch(p, "r"), i = rs.findIndex(r => rTxt(r).trim() === "NIP");
            if (i >= 0) {
                setT(rs[i], "NIP. " + (kpa.nip || ""));
                rs.slice(i + 1).forEach(r => r.remove());
            }
        }
    }
    // buang "Petunjuk pengisian" (halaman 3–4 template)
    {
        const all = [...body.children], i = pNip ? all.indexOf(pNip) : -1;
        if (i >= 0)
            all.slice(i + 1).filter(n => n.localName !== "sectPr").forEach(n => n.remove());
    }
    // tabel
    const tbl = body.getElementsByTagNameNS(W, "tbl")[0], trs = ch(tbl, "tr"), tplRow = trs[3], totRow = trs[trs.length - 1];
    const cellSet = (tc, v) => {
        const ps = ch(tc, "p"), p = ps[0];
        ps.slice(1).forEach(x => x.remove());
        const rs = [...p.getElementsByTagNameNS(W, "r")].filter(r => ch(r, "t").length);
        if (rs.length) {
            setT(rs[0], v);
            rs.slice(1).forEach(r => r.remove());
            return;
        }
        const r = doc.createElementNS(W, "w:r"), mark = ch(p, "pPr")[0] && ch(ch(p, "pPr")[0], "rPr")[0];
        if (mark) {
            const pr = doc.createElementNS(W, "w:rPr");
            [...mark.childNodes].forEach(n => pr.appendChild(n.cloneNode(true)));
            r.appendChild(pr);
        }
        setT(r, v);
        p.appendChild(r);
    };
    const jc = (tc, v) => { const p = ch(tc, "p")[0]; let pp = ch(p, "pPr")[0]; if (!pp) {
        pp = mk("pPr");
        p.insertBefore(pp, p.firstChild);
    } ch(pp, "jc").forEach(x => x.remove()); const r = ch(pp, "rPr")[0]; pp.insertBefore(mk("jc", v), r || null); };
    // baris nomor kolom: (5) … (13)
    ch(trs[2], "tc").forEach((tc, j) => { cellSet(tc, `(${j + 5})`); jc(tc, "center"); });
    const list = rows.length ? rows : [null];
    list.forEach((x, i) => {
        const tr = tplRow.cloneNode(true), tcs = ch(tr, "tc");
        const vals = x ? [String(i + 1), x.keg, x.out, x.akun, rupiah(x.sisa), rupiah(x.val), rupiah(x.sisa - x.val), x.tgl, x.namaK] : ["", "", "", "", "", "", "", "", ""];
        tcs.forEach((tc, j) => {
            cellSet(tc, vals[j] ?? "");
            jc(tc, j <= 3 ? "center" : j <= 6 ? "right" : "left");
            let pr = ch(tc, "tcPr")[0];
            if (!pr) {
                pr = mk("tcPr");
                tc.insertBefore(pr, tc.firstChild);
            }
            ch(pr, "vAlign").forEach(x => x.remove());
            pr.appendChild(mk("vAlign", "center"));
        });
        let trPr = ch(tr, "trPr")[0];
        if (!trPr) {
            trPr = mk("trPr");
            const ex = ch(tr, "tblPrEx")[0];
            tr.insertBefore(trPr, ex ? ex.nextSibling : tr.firstChild);
        }
        if (!ch(trPr, "cantSplit").length)
            trPr.insertBefore(mk("cantSplit"), trPr.firstChild);
        tbl.insertBefore(tr, totRow);
    });
    trs.slice(3, trs.length - 1).forEach(r => r.remove());
    {
        const tcs = ch(totRow, "tc"), sis = rows.reduce((s0, x) => s0 + x.sisa, 0);
        if (tcs.length >= 4) {
            cellSet(tcs[1], rupiah(sis));
            cellSet(tcs[2], rupiah(tot));
            cellSet(tcs[3], rupiah(sis - tot));
            [1, 2, 3].forEach(j => jc(tcs[j], "right"));
            tcs.forEach(tc => { let pr = ch(tc, "tcPr")[0]; if (!pr) {
                pr = mk("tcPr");
                tc.insertBefore(pr, tc.firstChild);
            } ch(pr, "vAlign").forEach(x => x.remove()); pr.appendChild(mk("vAlign", "center")); });
        }
    }
    /* seragamkan huruf: satu jenis & satu ukuran; judul sedikit lebih besar & tebal */
    const fmtRun = (pr, sz, bold) => {
        ch(pr, "rFonts").forEach(x => x.remove());
        const f = mk("rFonts");
        for (const a of ["ascii", "hAnsi", "cs", "eastAsia"])
            f.setAttributeNS(W, "w:" + a, TR_FONT);
        pr.insertBefore(f, pr.firstChild);
        for (const t of ["sz", "szCs", "color"])
            ch(pr, t).forEach(x => x.remove());
        pr.appendChild(mk("color", "000000"));
        pr.appendChild(mk("sz", sz));
        pr.appendChild(mk("szCs", sz));
        if (bold && !ch(pr, "b").length)
            pr.insertBefore(mk("b"), f.nextSibling);
    };
    const titles = new Set([pT1, pT2].filter((t) => !!t));
    for (const r of [...body.getElementsByTagNameNS(W, "r")]) {
        const title = [...titles].some(t => t.contains(r));
        let pr = ch(r, "rPr")[0];
        if (!pr) {
            pr = mk("rPr");
            r.insertBefore(pr, r.firstChild);
        }
        fmtRun(pr, title ? TR_SZ_TITLE : TR_SZ, title);
    }
    for (const pp of [...body.getElementsByTagNameNS(W, "pPr")]) {
        const mr = ch(pp, "rPr")[0];
        if (mr)
            fmtRun(mr, [...titles].some(t => t.contains(pp)) ? TR_SZ_TITLE : TR_SZ, false);
    }
    for (const t of titles) {
        const pp = ch(t, "pPr")[0] || t.insertBefore(mk("pPr"), t.firstChild);
        ch(pp, "jc").forEach(x => x.remove());
        const r = ch(pp, "rPr")[0];
        pp.insertBefore(mk("jc", "center"), r || null);
    }
    zip.file("word/document.xml", new XMLSerializer().serializeToString(doc));
    return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
}
const trFile = () => `Rencana Penggunaan TUP ${BULAN[trM]} ${angYear}.docx`;
$("#rpdTupReq").onclick = openTupReq;
$("#trClose").onclick = () => $("#dTupReq").close();
$("#trMonth").addEventListener("change", e => { trM = +tg(e).value; LS.set("st.trM", trM); $("#trPrev").hidden = true; trRender(); });
for (const [id, k] of [["#trSd", "sd"], ["#trDipa", "dipa"], ["#trUp", "up"], ["#trTempat", "tempat"], ["#trTgl", "tglIso"], ["#trKpa", "kpa"]])
    $(id).addEventListener(id === "#trKpa" || id === "#trTgl" ? "change" : "input", e => {
        const v = tg(e).value;
        if (k === "up")
            trDB.hdr.up = num(v);
        else
            trDB.hdr[k] = v.trim();
        trSave();
        if (k === "up")
            trSumOnly();
        if (k === "tglIso") {
            const d = isoD(v);
            $("#trTglTxt").textContent = d ? fmtDate(d) : "";
            trRender();
            const se = trSuratErr();
            if (se)
                toast(se, "err");
        }
    });
$("#trRows").addEventListener("input", e => {
    const f = tg(e).dataset.trf, tr = tg(e).closest("tr[data-g]");
    if (!f || !tr || /^tgl/.test(f))
        return;
    trSet(tr.dataset.g ?? "", f, f === "sisa" || f === "val" ? (tg(e).value === "" ? null : num(tg(e).value)) : tg(e).value);
    const x = trGroups(trM).find(y => y.g === tr.dataset.g);
    if (x) {
        const c = tr.querySelector("[data-sesudah]");
        c.innerHTML = rupiah(x.sesudah) + (x.sesudah < 0 ? `<div class="lsub bad">tidak boleh minus</div>` : "");
        c.classList.toggle("bad", x.sesudah < 0);
        tr.classList.toggle("neg", x.sesudah < 0);
    }
    trSumOnly();
});
$("#trRows").addEventListener("change", e => {
    const f = tg(e).dataset.trf, tr = tg(e).closest("tr[data-g]");
    if (!f || !tr || !/^tgl/.test(f))
        return;
    const g = tr.dataset.g ?? "";
    trSet(g, f, tg(e).value);
    const a = tr.querySelector("[data-trf=tglA]"), b = tr.querySelector("[data-trf=tglB]");
    if (f === "tglA") {
        b.min = a.value;
        if (b.value && a.value && b.value < a.value) {
            b.value = a.value;
            trSet(g, "tglB", a.value);
        }
    }
    if (f === "tglB" && a.value && b.value && b.value < a.value) {
        b.value = a.value;
        trSet(g, "tglB", a.value);
        toast("Tanggal selesai tidak boleh sebelum tanggal mulai.");
    }
    tr.classList.toggle("need", !a.value);
    const er = trTglErr(a.value, b.value);
    tr.classList.toggle("tglerr", !!er);
    tr.querySelector("[data-tgltxt]").outerHTML = trTglTxt(a.value, b.value);
    if (er)
        toast("Tanggal kegiatan: " + er, "err");
    trSumOnly();
});
$("#trRows").addEventListener("click", e => {
    const d = tg(e).closest("[data-trdef]");
    if (d) {
        trSet(d.closest("tr")?.dataset.g ?? "", "nama", null);
        trRender();
        return;
    }
    const b = tg(e).closest("[data-troff]");
    if (!b)
        return;
    trSet(b.closest("tr")?.dataset.g ?? "", "off", true);
    trRender();
    toast("Baris dikeluarkan dari surat permintaan TUP.");
});
$("#trSum").addEventListener("click", e => { if (tg(e).id !== "trOn")
    return; for (const o of Object.values(trDB.m[trM] || {}))
    delete o.off; trSave(); trRender(); });
$("#trAllBtn").onclick = () => {
    const a = $("#trAllA").value, b = $("#trAllB").value;
    if (!a)
        return toast("Pilih dulu tanggal mulai kegiatan.");
    if (b && b < a)
        return toast("Tanggal selesai tidak boleh sebelum tanggal mulai.");
    {
        const er = trTglErr(a, b);
        if (er)
            return toast("Tanggal kegiatan: " + er, "err");
    }
    for (const x of trGroups(trM))
        if (!x.off) {
            trSet(x.g, "tglA", a);
            trSet(x.g, "tglB", b || "");
        }
    trRender();
    toast(`Tanggal kegiatan ${fmtRange(a, b)} diterapkan ke semua baris.`);
};
$("#trPrevBtn").onclick = async () => {
    const host = $("#trPrevDoc");
    $("#trPrev").hidden = false;
    host.innerHTML = `<p class="muted" style="padding:16px">Menyiapkan pratinjau…</p>`;
    try {
        const blob = await buildTupReq();
        host.innerHTML = "";
        await docx.renderAsync(blob, host, host, { inWrapper: true, breakPages: true, ignoreLastRenderedPageBreak: true, experimental: true, className: "docx" });
        $("#trPrev").scrollIntoView({ behavior: "smooth", block: "start" });
    }
    catch (err) {
        console.error(err);
        host.innerHTML = `<p class="bad" style="padding:16px">Gagal membuat pratinjau: ${esc(err.message)}</p>`;
    }
};
$("#trDl").onclick = async () => {
    const rows = trGroups(trM).filter(x => !x.off);
    if (!rows.length)
        return toast("Tidak ada RPD di bulan ini untuk dimintakan TUP.");
    if (!trHdr().kpa)
        return toast("Belum ada pegawai berperan Kepala Kantor. Atur peran di Database › Pegawai & Mitra.");
    const negR = rows.filter(x => x.sesudah < 0);
    if (negR.length) {
        $$("#trRows tr.neg")[0]?.scrollIntoView({ block: "center" });
        return toast(`Sisa pagu setelah TUP tidak boleh minus (${negR.length} baris). Perbaiki isian RPD-nya di tab RPD.`, "warn");
    }
    {
        const tt = rows.reduce((s0, x) => s0 + x.val, 0) - num(trHdr().up);
        if (tt < 0) {
            $("#trUp").focus();
            return toast("Total TUP tidak boleh minus: UP Satker melebihi rencana TUP.", "warn");
        }
    }
    {
        const se = trSuratErr();
        if (se) {
            $("#trTgl").focus();
            return toast(se, "err");
        }
    }
    {
        const bad = rows.filter(x => trTglErr(x.tglA, x.tglB));
        if (bad.length) {
            $$("#trRows tr.tglerr [data-trf=tglA]")[0]?.focus();
            return toast(`${bad.length} baris tanggal kegiatan di luar rentang ${trWin().txt}. Perbaiki dulu.`, "err");
        }
    }
    const need = rows.filter(x => !x.tglA).length;
    if (need) {
        $$("#trRows tr.need [data-trf=tglA]")[0]?.focus();
        return toast(`Pilih dulu tanggal kegiatan (${need} baris belum diisi).`);
    }
    try {
        download(await buildTupReq(), trFile());
        toast("Surat permintaan TUP diunduh.");
    }
    catch (err) {
        console.error(err);
        toast("Gagal membuat dokumen: " + err.message);
    }
};

/* ---- 86_revisi.ts ---- */
/* ================= PERMINTAAN REVISI ================= */
let revEdit = null;
function revForm() {
    const o = {};
    $$("#revForm [data-rv]").forEach(e => { if (e.dataset.rv)
        o[e.dataset.rv] = e.value.trim(); });
    return { ...o, key: keyFromInput($("#revDet")) };
}
const revDetil = (f) => f.key ? detMap()[f.key] : undefined;
const revBaruMode = () => document.querySelector('#revForm input[name="revMode"]:checked')?.value === "baru";
const revMakAkun = () => { const v = normMak($("#revMak").value); return angPok().akun.find(a => normMak(a.mak) === v); };
function revModeUI() { const b = revBaruMode(); $("#revDetWrap").hidden = b; $("#revMakWrap").hidden = !b; $("#revNama").placeholder = b ? "Nama detil baru (wajib)" : "(kosong = sama dengan nama lama)"; }
/** nilai sebelum revisi: tersimpan di permintaan, atau (data lama) diambil dari POK */
function revPrevOf(x) {
    if (x.baru)
        return { vol: 0, sat: "", harga: 0, jml: 0 };
    const d = detMap()[x.key];
    return { vol: x.volLama ?? num(d?.v), sat: x.satLama ?? (d?.s || ""), harga: x.hargaLama ?? num(d?.h), jml: x.jmlLama };
}
const revPrevTxt = (v) => v.vol ? `${v.vol.toLocaleString("id-ID")} ${esc(v.sat)} × Rp ${rupiah(v.harga)} = Rp ${rupiah(v.jml)}` : "Rp " + rupiah(v.jml);
function revPrevUI(d, baru) {
    $("#revVol0").textContent = baru ? "0" : d ? (num(d.v) ? num(d.v).toLocaleString("id-ID") : "–") : "";
    $("#revSat0").textContent = baru ? "– (detil baru)" : d ? d.s || "–" : "";
    $("#revHarga0").textContent = baru ? "Rp 0" : d ? (num(d.h) ? "Rp " + rupiah(num(d.h)) : "–") : "";
    $("#revJml0").textContent = baru ? "Rp 0" : d ? "Rp " + rupiah(d.j) : "";
}
/** selisih usulan − pagu detil POK: lebih (merah) / kurang (hijau) */
const revLK = (s) => s > 0 ? `<span class="rv-lebih" title="Usulan lebih dari pagu detil POK">Lebih Rp ${rupiah(s)}</span>` : s < 0 ? `<span class="rv-kurang" title="Usulan kurang dari pagu detil POK">Kurang Rp ${rupiah(-s)}</span>` : `<span class="muted">sama</span>`;
const revSys = () => (document.querySelector('#revForm input[name="revSys"]:checked')?.value || "SAKTI");
const revSysSet = (v) => { const el = document.querySelector(`#revForm input[name="revSys"][value="${v || "SAKTI"}"]`); if (el)
    el.checked = true; };
const revSysTag = (x) => (x.sistem || "SAKTI").split("+").map(s0 => `<span class="tag">${s0}</span>`).join(" ");
function revPreview() {
    const f = revForm(), jb = num(f.vol) * num(f.harga);
    revPrevUI(revBaruMode() ? undefined : revDetil(f), revBaruMode());
    if (revBaruMode()) {
        const a = revMakAkun(), mk = $("#revMak").value.trim();
        $("#revMakInfo").innerHTML = a ? `${esc(a.nama)} · ${esc(a.ro)} ${esc(roTitle(a.roNama))} · pagu MAK <b>Rp ${rupiah(a.pagu)}</b> · ${a.items.length} detil saat ini` : mk ? `<span class="bad">MAK tidak ada di POK ${esc(angYear)} — pilih dari daftar</span>` : `<span class="muted">Pilih MAK tempat detil baru ditambahkan.</span>`;
        $("#revJml").value = jb ? "Rp " + rupiah(jb) : "";
        $("#revSel").innerHTML = jb ? `Keterangan: ${revLK(jb)}` : "";
        return;
    }
    const d = revDetil(f);
    $("#revCur").innerHTML = d ? `Saat ini: <b>${esc(d.u)}</b> ${volTxt(d)} · ${esc(d.a.mak)} · ${esc(d.a.nama)} · <b>Rp ${rupiah(d.j)}</b>${d.blokir ? ` · <span class="bad">blokir</span>` : ""}` : `<span class="muted">Pilih detil POK yang ingin direvisi.</span>`;
    $("#revJml").value = jb ? "Rp " + rupiah(jb) : "";
    $("#revSel").innerHTML = d && jb ? `Keterangan: ${revLK(jb - d.j)}` : "";
}
$("#revForm").addEventListener("input", e => { if (tg(e).id === "revDet")
    tg(e).dataset.key = ""; revPreview(); });
$("#revForm").addEventListener("change", e => { if (tg(e).name === "revMode") {
    revModeUI();
    revPreview();
} });
$("#revForm").addEventListener("change", e => {
    if (tg(e).id === "revDet") {
        const k = keyFromInput(tg(e)), d = k ? detMap()[k] : undefined;
        if (d) {
            if (!$("#revNama").value)
                $("#revNama").value = d.u;
            if (!$("#revVol").value && !$("#revHarga").value) {
                if (num(d.v))
                    $("#revVol").value = String(num(d.v));
                if (num(d.h))
                    $("#revHarga").value = String(num(d.h));
                if (!$("#revSat").value)
                    $("#revSat").value = d.s || "";
            }
        }
    }
    revPreview();
});
function revReset() { revEdit = null; $$("#revForm [data-rv]").forEach(e => e.value = ""); $("#revDet").value = ""; $("#revDet").dataset.key = ""; $("#revMak").value = ""; document.querySelector('#revForm input[name="revMode"][value="ubah"]').checked = true; revModeUI(); revSysSet(); $("#revTgl").value = today(); $("#revSave").textContent = "Tambah permintaan revisi"; $("#revCancel").hidden = true; revPreview(); }
$("#revSave").onclick = () => {
    const f = revForm();
    if (revBaruMode()) {
        const a = revMakAkun();
        if (!a)
            return toast("Pilih MAK tujuan dari daftar.", "warn");
        if (!f.nama)
            return toast("Isi nama detil baru.", "warn");
        if (!(num(f.vol) > 0 && num(f.harga) > 0))
            return toast("Isi volume dan harga satuan detil baru.", "warn");
        if (!f.ket)
            return toast("Isi keterangan / alasan revisi.", "warn");
        const old = revDB.find(y => y._id === revEdit), x = { _id: revEdit || newId(), tgl: f.tgl || today(), key: old?.baru ? old.key : `baru:${a.mak}#${newId()}`, mak: a.mak, akun: a.nama, namaLama: "(detil baru)", jmlLama: 0, namaBaru: f.nama, vol: num(f.vol), sat: f.sat || "", harga: num(f.harga), jmlBaru: num(f.vol) * num(f.harga), ket: f.ket, status: old?.status || "Diajukan", baru: true, sistem: revSys() };
        if (old?.baru && old.mak !== a.mak)
            x.key = `baru:${a.mak}#${newId()}`;
        const i = revDB.findIndex(y => y._id === x._id);
        if (i >= 0)
            revDB[i] = x;
        else
            revDB.push(x);
        persistAng();
        toast(i >= 0 ? "Usulan detil baru diperbarui." : `Usulan detil baru ditambahkan di ${a.mak}.`, "ok");
        revReset();
        renderRev();
        return;
    }
    const d = revDetil(f);
    if (!d)
        return toast("Pilih detil POK dari daftar.");
    if (!f.ket)
        return toast("Isi keterangan / alasan revisi.");
    const x = { _id: revEdit || newId(), tgl: f.tgl || today(), key: d.key, mak: d.a.mak, akun: d.a.nama, namaLama: d.u, jmlLama: d.j, volLama: num(d.v), satLama: d.s || "", hargaLama: num(d.h), namaBaru: f.nama || d.u, vol: num(f.vol), sat: f.sat || "", harga: num(f.harga), jmlBaru: num(f.vol) * num(f.harga), ket: f.ket, status: revDB.find(y => y._id === revEdit)?.status || "Diajukan", sistem: revSys() };
    const i = revDB.findIndex(y => y._id === x._id);
    if (i >= 0)
        revDB[i] = x;
    else
        revDB.push(x);
    persistAng();
    toast(i >= 0 ? "Permintaan revisi diperbarui." : "Permintaan revisi ditambahkan.");
    revReset();
    renderRev();
};
$("#revCancel").onclick = revReset;
function renderRev() {
    angYearUI();
    if (!$("#revTgl").value)
        $("#revTgl").value = today();
    const q = acNorm($("#revQ").value.trim()).split(/\s+/).filter(Boolean), stf = $("#revStF").value, syf = $("#revSysF").value;
    const list = [...revDB].reverse().filter(x => (!stf || x.status === stf) && (!syf || (x.sistem || "SAKTI").includes(syf)) && (!q.length || q.every(t => acNorm([x.namaLama, x.namaBaru, x.mak, x.ket, x.akun].join(" ")).includes(t))));
    $("#revTbl tbody").innerHTML = list.map((x, i) => {
        const sel = x.jmlBaru - x.jmlLama;
        return `<tr data-rid="${esc(x._id)}"><td class="muted">${revDB.length - revDB.indexOf(x)}</td><td style="font-size:13px;white-space:nowrap">${esc(x.tgl)}</td>
      <td><div class="lt-title" data-ra="edit">${x.baru ? `<span class="tag ok">detil baru</span> ${esc(x.namaBaru)}` : esc(x.namaLama)}${x.auto === "rab" ? ` <span class="tag warn" title="Dibuat otomatis karena kebutuhan RAB melebihi pagu detil — diperbarui mengikuti RAB selama berstatus Diajukan">otomatis RAB</span>` : ""}</div><div class="lsub one">${esc(x.mak)}</div><div class="lsub">Sebelumnya: ${x.baru ? "belum ada di POK (Rp 0)" : revPrevTxt(revPrevOf(x))}</div></td>
      <td><div style="font-weight:500">${esc(x.namaBaru)}</div><div class="lsub">${x.vol} ${esc(x.sat || "")} × Rp ${rupiah(x.harga)} = <b>Rp ${rupiah(x.jmlBaru)}</b></div></td>
      <td class="num">${revLK(sel)}<div class="lsub">${revSysTag(x)}</div></td>
      <td style="font-size:13px">${esc(x.ket)}</td>
      <td><div class="rvst"><button type="button" class="rvb ok ${x.status === "Disetujui" ? "on" : ""}" data-rs="Disetujui" title="${x.status === "Disetujui" ? "Disetujui — klik untuk kembali ke Diajukan" : "Setujui"}" aria-label="Setujui">✓</button><button type="button" class="rvb no ${x.status === "Ditolak" ? "on" : ""}" data-rs="Ditolak" title="${x.status === "Ditolak" ? "Ditolak — klik untuk kembali ke Diajukan" : "Tolak"}" aria-label="Tolak">✕</button><span class="rvs ${x.status === "Disetujui" ? "ok" : x.status === "Ditolak" ? "bad" : "muted"}">${x.status}</span></div></td>
      <td class="acts"><button class="ib" data-ra="edit" title="Edit">${IC.edit}</button><button class="ib del" data-ra="del" title="Hapus">${IC.del}</button></td></tr>`;
    }).join("")
        || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">${revDB.length ? "Tidak ada yang cocok." : "Belum ada permintaan revisi."}</td></tr>`;
    const sl = list.reduce((s, x) => s + x.jmlBaru - x.jmlLama, 0);
    renderRevPok();
    {
        const ok = revDB.filter(x => x.status === "Disetujui"), el = $("#revRemind");
        el.hidden = !ok.length;
        el.innerHTML = ok.length ? `🔔 <b>Pengingat:</b> ${ok.length} permintaan revisi sudah <b>disetujui</b> (${["SAKTI", "BOS"].map(s0 => `${s0}: ${ok.filter(x => (x.sistem || "SAKTI").includes(s0)).length}`).join(" · ")}). Pagu POK &amp; RPD di aplikasi <b>tidak berubah otomatis</b> — perbarui di aplikasi SAKTI / BOS, lalu impor POK hasil revisi.` : "";
    }
    $("#revInfo").textContent = list.length ? `${list.length} permintaan · total selisih ${sl >= 0 ? "+" : "−"}Rp ${rupiah(Math.abs(sl))}` : "";
}
$("#revQ").addEventListener("input", debounce(() => renderRev(), 150));
$("#revStF").addEventListener("change", renderRev);
$("#revSysF").addEventListener("change", renderRev);
$("#revTbl").addEventListener("change", e => { if (!tg(e).hasAttribute("data-rst"))
    return; const x = revDB.find(y => y._id === tg(e).closest("tr")?.dataset.rid); if (x) {
    x.status = tg(e).value;
    persistAng();
    renderRevPok();
} });
$("#revTbl").addEventListener("click", e => {
    const b = tg(e).closest("[data-rs]");
    if (!b)
        return;
    const x = revDB.find(y => y._id === b.closest("tr")?.dataset.rid);
    if (!x)
        return;
    const ns = b.dataset.rs;
    x.status = x.status === ns ? "Diajukan" : ns;
    persistAng();
    renderRev();
    toast(x.status === "Disetujui" ? "Revisi disetujui — sebagai pengingat saja, pagu POK & RPD tidak berubah." : x.status === "Ditolak" ? "Revisi ditolak." : "Status dikembalikan ke Diajukan.", x.status === "Ditolak" ? "warn" : "ok");
});
$("#revTbl").addEventListener("click", e => {
    const a = tg(e).closest("[data-ra]")?.dataset.ra;
    if (!a)
        return;
    const x = revDB.find(y => y._id === tg(e).closest("tr")?.dataset.rid);
    if (!x)
        return;
    if (a === "del" && confirm(`Hapus permintaan revisi "${x.namaLama}"?`)) {
        revDB = revDB.filter(y => y !== x);
        persistAng();
        renderRev();
        if (revEdit === x._id)
            revReset();
    }
    if (a === "edit" && x.baru) {
        revReset();
        revEdit = x._id;
        document.querySelector('#revForm input[name="revMode"][value="baru"]').checked = true;
        revModeUI();
        revSysSet(x.sistem);
        $("#revMak").value = x.mak;
        $("#revNama").value = x.namaBaru;
        $("#revVol").value = String(x.vol || "");
        $("#revSat").value = x.sat || "";
        $("#revHarga").value = String(x.harga || "");
        $("#revKet").value = x.ket;
        $("#revTgl").value = x.tgl;
        $("#revSave").textContent = "Simpan perubahan";
        $("#revCancel").hidden = false;
        revPreview();
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
    }
    if (a === "edit") {
        revEdit = x._id;
        const d = detMap()[x.key];
        $("#revDet").value = d ? detLabel(d) : `${x.namaLama} — ${x.mak}`;
        $("#revDet").dataset.key = x.key;
        revSysSet(x.sistem);
        $("#revNama").value = x.namaBaru;
        $("#revVol").value = x.vol ? String(x.vol) : "";
        $("#revSat").value = x.sat || "";
        $("#revHarga").value = x.harga ? String(x.harga) : "";
        $("#revKet").value = x.ket;
        $("#revTgl").value = x.tgl;
        $("#revSave").textContent = "Simpan perubahan";
        $("#revCancel").hidden = false;
        revPreview();
        window.scrollTo({ top: 0, behavior: "smooth" });
    }
});
function revPokData() {
    const st = $("#revPokSt").value, all = $("#revPokAll").checked, M = detMap();
    const use = revDB.filter(x => st === "aktif" ? x.status !== "Ditolak" : !st || x.status === st), last = {};
    for (const x of use)
        last[x.key] = x; // revisi terakhir per detil (detil baru: kunci sendiri)
    const maks = [...new Set(Object.keys(last).map(k => M[k]?.a.mak || last[k].mak))].sort();
    return maks.map(mak => {
        const ds = pokDetil().filter(d => d.a.mak === mak), a = ds[0]?.a;
        const rows = ds.map((d) => { const r = last[d.key]; return r ? { d, r, nm: r.namaBaru || d.u, vol: num(r.vol), sat: r.sat, harga: num(r.harga), jml: num(r.jmlBaru) } : { d, nm: d.u, vol: num(d.v), sat: d.s || "", harga: num(d.h), jml: d.j }; });
        if (a)
            for (const r of Object.values(last))
                if (r.baru && r.mak === mak)
                    rows.push({ d: { key: r.key, a, u: "(detil baru)", j: 0, blokir: false }, r, nm: r.namaBaru, vol: num(r.vol), sat: r.sat, harga: num(r.harga), jml: num(r.jmlBaru) });
        return { mak, a: a, rows: all ? rows : rows.filter(x => x.r), sb: ds.reduce((s0, d) => s0 + d.j, 0), ss: rows.reduce((s0, x) => s0 + x.jml, 0) };
    }).filter(g => g.a);
}
function renderRevPok() {
    const G = revPokData(), vt = (v, s) => v ? `${v.toLocaleString("id-ID")} ${esc(s)}` : "–";
    $("#revPok").innerHTML = G.length ? G.map(g => `<div class="rvp tblwrap"><table class="ltbl tight"><thead>
      <tr><th rowspan="2" style="width:30%">Detil</th><th colspan="3" class="grp">POK sebelum</th><th colspan="4" class="grp">POK sesudah revisi</th><th rowspan="2" class="num">Selisih</th></tr>
      <tr><th class="num">Volume</th><th class="num">Harga</th><th class="num">Jumlah</th><th>Uraian</th><th class="num">Volume</th><th class="num">Harga</th><th class="num">Jumlah</th></tr></thead><tbody>
      <tr class="rvh"><td colspan="3">${esc(g.mak)} · ${esc(g.a.nama)}<div class="lsub">${esc(g.a.ro)} ${esc(roTitle(g.a.roNama))}</div></td><td class="num">${rupiah(g.sb)}</td><td colspan="3"></td><td class="num">${rupiah(g.ss)}</td><td class="num"><b>${revLK(g.ss - g.sb)}</b></td></tr>
      ${g.rows.map(x => {
        const s = x.jml - x.d.j;
        return `<tr class="${x.r ? "chg" : ""}"><td>${esc(x.d.u)}${x.r ? `<div class="lsub"><span class="tag">${esc(x.r.status)}</span> ${esc(x.r.ket).slice(0, 80)}</div>` : ""}</td><td class="num">${vt(num(x.d.v), x.d.s || "")}</td><td class="num">${x.d.h ? rupiah(num(x.d.h)) : "–"}</td><td class="num">${rupiah(x.d.j)}</td>
          <td>${x.r?.baru ? `<span class="tag ok">baru</span> ${esc(x.nm)}` : x.r && x.nm !== x.d.u ? esc(x.nm) : `<span class="muted">${x.r ? "(nama tetap)" : "tidak berubah"}</span>`}</td><td class="num">${vt(x.vol, x.sat)}</td><td class="num">${x.harga ? rupiah(x.harga) : "–"}</td><td class="num"><b>${rupiah(x.jml)}</b></td>
          <td class="num">${s ? revLK(s) : "–"}</td></tr>`;
    }).join("")}
    </tbody></table></div>`).join("") : `<p class="muted">Belum ada permintaan revisi${$("#revPokSt").value ? " dengan status ini" : ""}.</p>`;
}
$("#revPokSt").addEventListener("change", () => renderRevPok());
$("#revPokAll").addEventListener("change", () => renderRevPok());
$("#revPokExp").onclick = () => {
    const G = revPokData();
    if (!G.length)
        return toast("Belum ada permintaan revisi untuk diekspor.", "warn");
    const H = ["MAK", "Akun", "Detil", "Vol sebelum", "Satuan sebelum", "Harga sebelum", "Jumlah sebelum", "Uraian sesudah", "Vol sesudah", "Satuan sesudah", "Harga sesudah", "Jumlah sesudah", "Selisih", "Status", "Keterangan"];
    const aoa = [H];
    for (const g of G) {
        for (const x of g.rows)
            aoa.push([g.mak, g.a.nama, x.d.u, num(x.d.v), x.d.s || "", num(x.d.h), x.d.j, x.nm, x.vol, x.sat, x.harga, x.jml, x.jml - x.d.j, x.r?.status || "", x.r?.ket || ""]);
        aoa.push([g.mak, "Jumlah MAK", "", "", "", "", g.sb, "", "", "", "", g.ss, g.ss - g.sb, "", ""], []);
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [28, 26, 40, 9, 9, 13, 14, 40, 9, 9, 13, 14, 13, 11, 40].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "POK sebelum-sesudah");
    XLSX.writeFile(wb, `POK sebelum-sesudah revisi ${angYear}.xlsx`);
    toast("POK sebelum & sesudah revisi diekspor.", "ok");
};
$("#revExp").onclick = () => {
    if (!revDB.length)
        return toast("Belum ada permintaan revisi.");
    const H = ["No", "Tanggal", "MAK", "Akun", "Detil lama", "Volume lama", "Satuan lama", "Harga satuan lama (Rp)", "Jumlah lama (Rp)", "Detil usulan", "Volume", "Satuan", "Harga satuan (Rp)", "Jumlah usulan (Rp)", "Selisih (Rp)", "Keterangan / alasan", "Status", "Revisi untuk"];
    const ws = XLSX.utils.aoa_to_sheet([H, ...revDB.map((x, i) => [i + 1, x.tgl, x.mak, x.akun, x.namaLama, ...((v) => [v.vol, v.sat, v.harga])(revPrevOf(x)), x.jmlLama, x.namaBaru, x.vol, x.sat, x.harga, x.jmlBaru, x.jmlBaru - x.jmlLama, x.ket, x.status, (x.sistem || "SAKTI").replace("+", " & ")])]);
    ws["!cols"] = [5, 16, 28, 26, 40, 8, 10, 14, 14, 40, 8, 10, 14, 14, 13, 40, 11].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Permintaan Revisi");
    XLSX.writeFile(wb, `Permintaan Revisi POK (${revDB.length}).xlsx`);
    toast("Permintaan revisi diekspor.");
};

/* ---- 88_rab.ts ---- */
/* ================= RENCANA PPIS · RAB (Rencana Anggaran Biaya) =================
   RAB disimpan per tahun anggaran bersama RPD/TUP/Revisi (st.rab.<tahun>).
   Setiap RAB terikat pada satu MAK/RO; setiap baris dibebankan ke satu detil POK di RO itu, dibatasi menurut akun.
   Biaya perjalanan dihitung dengan aturan yang sama dengan Surat Tugas (SK transport kampung, uang harian, inap).
   Kebutuhan melebihi pagu detil → otomatis tercatat di Permintaan Revisi. Perjadin bisa langsung dijadikan Surat Tugas Kolektif. */
const RAB_BAHAN = ["521211", "522191", "521219", "521811"];
const RAB_SECS = [
    { id: "honor", n: "Belanja Honor", trip: false, ok: a => a === "521213", akTxt: "521213", peran: [] },
    { id: "bahan", n: "Belanja Bahan", trip: false, ok: a => RAB_BAHAN.includes(a), akTxt: RAB_BAHAN.join(", "), peran: [] },
    { id: "pel", n: "Pelatihan Petugas", trip: false, ok: a => RAB_BAHAN.includes(a) || /^524/.test(a), akTxt: `${RAB_BAHAN.join(", ")} & 524…`, peran: [] },
    { id: "pemut", n: "Perjadin Pemutakhiran", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Lokal", peran: ["Pengawas", "Pendata"] },
    { id: "lokal", n: "Perjadin Lokal", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Lokal", fix: "Lokal", peran: ["Pengawas", "Pendata"] },
    { id: "remote", n: "Perjadin Remote", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Remote", fix: "Remote", peran: ["Pengawas", "Pendata"] },
    { id: "sup", n: "Perjadin Supervisi", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Remote", peran: ["Pelaksana", "Pengawas"] },
    { id: "luar", n: "Perjadin Luar Kota", trip: true, ok: a => a === "524111", akTxt: "524111", jenis: "Remote", peran: ["Pelaksana"] },
];
const RAB_DEF = Object.fromEntries(RAB_SECS.map(s => [s.id, s]));
/** tambah cepat: [uraian, satuan, peran untuk hitung orang otomatis] */
const RAB_PRESET = {
    honor: [["Honor pengawas (PML)", "OK", "Pengawas"], ["Honor pendata (PCL)", "OK", "Pendata"], ["Honor pengolahan", "OK"], ["Honor instruktur", "OJ"]],
    bahan: [["Uang pulsa / internet petugas", "OB"], ["ATK & penggandaan", "Paket"], ["Konsumsi rapat", "OK"], ["Spanduk", "Lembar"]],
    pel: [["Konsumsi pelatihan", "OK"], ["Uang harian peserta", "OH"], ["Transport peserta", "OK"], ["Perlengkapan peserta", "Paket"], ["Spanduk", "Lembar"], ["Sewa gedung", "Hari"]],
};
const RAB_VIEWS = [...RAB_SECS.map((s) => [s.id, s.n]), ["rekap", "Rekap RAB"], ["timeline", "Timeline Kegiatan"]];
let rabCur = LS.get("st.rabCur", null), rabView = LS.get("st.rabView", "honor");
const rabDoc = () => rabDB.find(d => d._id === rabCur) || null;
/** bulan pelaksanaan RAB: opsional (bln = -1 → belum ditentukan), satu bulan, beberapa bulan, sampai setahun */
const rabNoBln = (d) => !(d.bln >= 0);
const rabBlnTo = (d) => rabNoBln(d) ? -1 : Math.max(d.bln, d.blnTo ?? d.bln);
const rabMonths = (d) => { const o = []; if (rabNoBln(d))
    return o; for (let m = d.bln; m <= rabBlnTo(d); m++)
    o.push(m); return o; };
const rabBlnTxt = (d) => rabNoBln(d) ? "—" : rabBlnTo(d) === d.bln ? BULAN[d.bln] || "" : rabBlnTo(d) - d.bln === 11 ? "Setahun (Januari – Desember)" : `${BULAN[d.bln]} – ${BULAN[rabBlnTo(d)]} (${rabBlnTo(d) - d.bln + 1} bulan)`;
/** nilai dibagi rata ke beberapa bulan (kelipatan 1.000; sisa ke bulan terakhir) */
const rabSplit = (v, n) => { if (n <= 1)
    return [v]; const per = Math.floor(v / n / 1000) * 1000, a = Array(n).fill(per); a[n - 1] = v - per * (n - 1); return a; };
/** bagian yang dipakai RAB ini (data lama tanpa pilihan = semua) */
const rabSecsOf = (doc) => doc.secs?.length ? RAB_SECS.map(s => s.id).filter(id => doc.secs.includes(id)) : RAB_SECS.map(s => s.id);
const rabSecHas = (doc, sec) => (RAB_DEF[sec].trip ? doc.trips : doc.items).some(x => x.sec === sec);
let rabSecSel = new Set(), rabSecOpen = false;
/** tampilkan juga bagian yang pagunya tidak ada di POK RO ini (bawaan: disembunyikan, tidak dihapus) */
let rabSecAll = false;
function rabSecPickUI(doc, neu) {
    const ro = $("#rabRo").value, show = neu ? !!ro : rabSecOpen && !!doc;
    $("#rabSecPick").hidden = !show;
    if (!show)
        return;
    const cur = neu ? rabSecSel : new Set(rabSecsOf(doc)), dets = (id) => pokDetil().filter(d => d.a.ro === (neu ? ro : doc.ro) && RAB_DEF[id].ok(String(d.a.akun).trim()));
    /* bagian tanpa pagu di POK (tidak ada detil, atau pagunya 0 / diblokir) disembunyikan otomatis — kecuali sudah dipilih / sudah berisi; bisa ditampilkan lagi */
    const info = RAB_SECS.map(s => { const ds = dets(s.id), pg = ds.reduce((t, d) => t + rabPagu(d), 0); return { s, n: ds.length, pg, keep: pg > 0 || cur.has(s.id) || (!neu && !!doc && rabSecHas(doc, s.id)) }; });
    const hid = info.filter(x => !x.keep);
    $("#rabSecList").innerHTML = info.filter(x => x.keep || rabSecAll).map(({ s, n, pg, keep }) => `<label class="${cur.has(s.id) ? "on" : ""}${keep && pg > 0 ? "" : " nopagu"}" title="Akun ${esc(s.akTxt)}"><input type="checkbox" data-rsec="${s.id}" ${cur.has(s.id) ? "checked" : ""}> ${esc(s.n)} <small>${pg > 0 ? `${n} detil · pagu ${rpShort(pg)}` : n ? `${n} detil · pagu 0` : "tidak ada pagu di POK RO ini"}</small></label>`).join("")
        + (hid.length ? `<button type="button" class="rsp-more" data-rsecall title="${esc(hid.map(x => x.s.n).join(", "))}">${rabSecAll ? "Sembunyikan lagi bagian tanpa pagu" : `+ Tampilkan ${hid.length} bagian tanpa pagu`}</button>` : "")
        + (!info.some(x => x.keep) && !rabSecAll ? `<span class="muted" style="font-size:12.5px;align-self:center">RO ini tidak punya pagu untuk bagian RAB mana pun.</span>` : "");
}
const rabRos = () => [...new Map(angPok().akun.map((a) => [a.ro, a.roNama])).entries()].sort((a, b) => a[0].localeCompare(b[0]));
const rabRoNama = (ro) => String(angPok().akun.find(a => a.ro === ro)?.roNama || "").trim();
const rabPagu = (d) => d.blokir ? 0 : d.j;
/** detil POK yang boleh dipakai bagian ini: di RO RAB dan akunnya sesuai */
const rabDetils = (doc, sec) => pokDetil().filter(d => d.a.ro === doc.ro && RAB_DEF[sec].ok(String(d.a.akun).trim()));
const rabLineTot = (l) => Math.max(0, num(l.org || 1)) * num(l.vol) * num(l.harga);
const isoDate = (iso) => { const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
const isoStr = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const rabTripEnd = (t) => { const a = isoDate(t.pergi); return a ? new Date(a.getFullYear(), a.getMonth(), a.getDate() + Math.max(1, num(t.hari) || 1) - 1) : null; };
const rabPegNama = (t) => (t.c && pegMap()[t.c]?.nama) || t.nama || "";
const rabKamTxt = (t) => { const M = kamByKey(); return [...t.kam.map(k => M[k] ? title(M[k].kampung) : k.split("|").pop() || k), ...t.kamBad].join(", "); };
const rabKamNm = (k) => { const M = kamByKey(); return M[k] ? title(M[k].kampung) : k.split("|").pop() || k; };
/* ---------- jadwal per kampung per hari; pengawas mengikuti petugas yang dibawahinya ---------- */
/** kampung yang dikunjungi tiap hari tugas: jadwal pengawas tersimpan, atau kampung dibagi rata menurut urutan rute */
function rabDays(t) {
    const H = Math.max(1, num(t.hari) || 1), n = t.kam.length;
    if (t.plan && t.plan.length === H && t.plan.every(k => t.kam.includes(k)))
        return t.plan.map(k => [k]);
    return Array.from({ length: H }, (_, i) => !n ? [] : n >= H ? t.kam.slice(Math.floor(i * n / H), Math.floor((i + 1) * n / H)) : [t.kam[Math.floor(i * n / H)]]);
}
/** tanggal (ISO) → kampung hari itu */
function rabDayMap(t) {
    const a = isoDate(t.pergi), m = new Map();
    if (!a)
        return m;
    rabDays(t).forEach((ks, i) => m.set(isoStr(new Date(a.getFullYear(), a.getMonth(), a.getDate() + i)), ks));
    return m;
}
const rabOverlap = (a, b) => { const A = rabDayMap(a); let n = 0; for (const d of rabDayMap(b).keys())
    if (A.has(d))
        n++; return n; };
/** petugas (Pendata, bagian yang sama) yang dibawahi perjalanan pengawas ini; bila pengawas punya >1 perjalanan, petugas ikut yang tanggalnya paling beririsan */
function rabSubs(doc, p) {
    if (p.peran !== "Pengawas" || !p.c)
        return [];
    const sibs = doc.trips.filter(t => t.sec === p.sec && t.peran === "Pengawas" && t.c === p.c);
    return doc.trips.filter(t => t.sec === p.sec && t.peran === "Pendata" && t.pml === p.c && t !== p).filter(t => { if (sibs.length < 2)
        return true; let best = sibs[0], bo = 0; for (const s0 of sibs) {
        const o = rabOverlap(s0, t);
        if (o > bo) {
            bo = o;
            best = s0;
        }
    } return best === p; });
}
/** jadwal pengawas yang mengikuti petugasnya: tiap hari berada di kampung salah satu petugas, mendahulukan petugas yang belum didampingi */
function rabPlanFor(doc, p) {
    const subs = rabSubs(doc, p).filter(t => t.pergi && t.kam.length).map(t => rabDayMap(t));
    if (!subs.length)
        return null;
    const dates = [...new Set(subs.flatMap(m => [...m.keys()]))].sort(), a = isoDate(dates[0]), b = isoDate(dates[dates.length - 1]), H = Math.round((b.getTime() - a.getTime()) / 864e5) + 1;
    const plan = [], seen = new Set();
    let prev = "";
    for (let i = 0; i < H; i++) {
        const d = isoStr(new Date(a.getFullYear(), a.getMonth(), a.getDate() + i)), cand = new Map();
        subs.forEach((m, si) => (m.get(d) || []).forEach(k => { const l = cand.get(k) || []; l.push(si); cand.set(k, l); }));
        let best = prev, bs = -1;
        for (const [k, l] of cand) {
            const sc = l.filter(x => !seen.has(x)).length * 100 + l.length * 10 + (k === prev ? 1 : 0);
            if (sc > bs) {
                bs = sc;
                best = k;
            }
        }
        (cand.get(best) || []).forEach(x => seen.add(x));
        plan.push(best);
        prev = best;
    }
    return { pergi: dates[0], hari: H, kam: [...new Set(plan)], plan };
}
/** periksa aturan "pada tanggal yang sama pengawas & petugasnya di kampung yang sama": tanggal yang melanggar + petugas yang belum didampingi */
function rabPlanCheck(doc, p) {
    const subs = rabSubs(doc, p).filter(t => t.pergi && t.kam.length);
    if (!subs.length)
        return null;
    const P = rabDayMap(p), S = subs.map(t => rabDayMap(t)), bad = [], hit = new Set();
    for (const [d, ks] of P) {
        const on = S.map((m, i) => ({ i, ks: m.get(d) })).filter(x => x.ks);
        if (!on.length)
            continue;
        const ok = on.filter(x => x.ks.some(k => ks.includes(k)));
        ok.forEach(x => hit.add(x.i));
        if (!ok.length)
            bad.push(d);
    }
    const au = rabPlanFor(doc, p), auto = !!au && au.pergi === p.pergi && au.hari === Math.max(1, num(p.hari) || 1) && JSON.stringify(rabDays(p)) === JSON.stringify(au.plan.map(k => [k]));
    return { bad, miss: subs.filter((_, i) => !hit.has(i)), auto };
}
function rabPlanWarn(doc, p) {
    const c = rabPlanCheck(doc, p);
    if (!c || (!c.bad.length && !c.miss.length))
        return "";
    const nm = c.miss.map(t => rabPegNama(t).split(",")[0]).join(", ");
    if (c.auto)
        return c.miss.length ? `tidak sempat mendampingi ${nm} — petugas bertugas bersamaan di kampung berbeda; geser tanggal petugas atau tambah pengawas` : "";
    return [!p.pergi ? "jadwal pengawas belum bertanggal" : "", c.bad.length ? `tidak sekampung dengan petugas pada ${c.bad.map(d => { const x = isoDate(d); return `${x.getDate()} ${BLN_S[x.getMonth()]}`; }).join(", ")}` : "", c.miss.length ? `belum mendampingi ${nm}` : ""].filter(Boolean).join("; ") + " — klik “Sesuaikan jadwal pengawas”";
}
/** terapkan jadwal otomatis ke semua pengawas (satu bagian, atau seluruh RAB); hasil: jumlah perjalanan pengawas yang berubah */
function rabPlanApply(doc, sec) {
    let n = 0;
    for (const p of doc.trips.filter(t => t.peran === "Pengawas" && (!sec || t.sec === sec))) {
        const au = rabPlanFor(doc, p);
        if (!au)
            continue;
        const same = p.pergi === au.pergi && num(p.hari) === au.hari && JSON.stringify(p.kam) === JSON.stringify(au.kam) && JSON.stringify(p.plan || []) === JSON.stringify(au.plan);
        if (same)
            continue;
        if (JSON.stringify(p.kam) !== JSON.stringify(au.kam) || num(p.hari) !== au.hari)
            delete p.rute;
        p.pergi = au.pergi;
        p.hari = au.hari;
        p.kam = au.kam;
        p.kamBad = [];
        p.plan = au.plan;
        n++;
    }
    return n;
}
/** perjalanan → rekaman Surat Tugas semu, supaya biaya memakai aturan yang sama (SK transport, uang harian, inap, hotel) */
function rabTripRec(doc, t, auto = false) {
    const a = isoDate(t.pergi), b = rabTripEnd(t), H = Math.max(1, num(t.hari) || 1), lok = t.jenis === "Lokal", noI = lok || t.jenis === JEN_TU;
    const hotel = noI ? 0 : Math.min(Math.max(0, num(t.hotel)), Math.max(0, H - 1));
    const r = { JENIS: t.jenis, KD_NAMA_SPD: t.c, TEMPAT_BERANGKAT: "Kampung Semu", LAMA_JALAN: H, _kampung: t.kam.map(k => ({ k, pp: true })),
        TGL_PERGI: a ? fmtDate(a) : "", TGL_PULANG: b ? fmtDate(b) : "", NILAI_UH: doc.uh ?? defUH(), TDK_INAP_HOTEL: doc.inap ?? defInap(),
        LAMA_UH: lok ? 0 : H, LAMA_INAP: noI ? 0 : Math.max(0, H - 1 - hotel), LAMA_HOTEL: hotel, TARIF_HOTEL: hotel ? num(t.hotelTarif) : 0, MAK: detMap()[t.key]?.a.mak || "" };
    applyKampungToRec(r);
    if (t.rute && !auto) { // lintasan disunting sendiri → menggantikan baris transport otomatis
        for (let i = 1; i <= MAXTR; i++) {
            delete r["KetTransport_" + i];
            delete r["Nilai" + i];
        }
        delete r._riilLok;
        t.rute.filter(([k, v]) => String(k).trim() !== "" || num(v)).slice(0, MAXTR - 1).forEach(([k, v], i) => { r["KetTransport_" + (i + 1)] = String(k).trim() || "Transport"; r["Nilai" + (i + 1)] = num(v); });
    }
    if (auto)
        return r;
    if (num(t.tr))
        for (let i = 1; i <= MAXTR; i++)
            if (!r["KetTransport_" + i] && !r["Nilai" + i]) {
                r["KetTransport_" + i] = t.sec === "luar" ? "Tiket / transport luar kota (PP)" : "Transport lain";
                r["Nilai" + i] = num(t.tr);
                break;
            }
    return r;
}
/** lintasan & transport otomatis (aturan SK Transport) untuk rute kampung perjalanan ini, berurutan */
function rabAutoLegs(doc, t) {
    const r = rabTripRec(doc, t, true), out = riilFilled(riilRows(r._riilLok)).map(([k, v]) => [k, num(v)]);
    for (let i = 1; i <= MAXTR; i++)
        if (r["KetTransport_" + i] || r["Nilai" + i])
            out.push([String(r["KetTransport_" + i] || ""), num(r["Nilai" + i])]);
    return out;
}
const rabLegs = (doc, t) => t.rute || rabAutoLegs(doc, t);
/** perjalanan yang panel lintasannya sedang dibuka */
const rabRuteOpen = new Set();
function rabRuteHtml(doc, t) {
    const M = kamByKey(), legs = rabLegs(doc, t), sum = legs.reduce((s, x) => s + num(x[1]), 0), open = rabRuteOpen.has(t.id), n = t.kam.length;
    const stops = t.kam.map((k, i) => `<span class="rt-k"><small>${i + 1}</small>${esc(M[k] ? title(M[k].kampung) : k.split("|").pop() || k)}${n > 1 ? `<button type="button" data-kmv="-1" data-ki="${i}" title="Majukan urutan" ${i ? "" : "disabled"}>‹</button><button type="button" data-kmv="1" data-ki="${i}" title="Mundurkan urutan" ${i < n - 1 ? "" : "disabled"}>›</button>` : ""}</span>`);
    const path = n ? [`<b>Semu</b>`, ...stops, `<b>Semu</b>`].join(`<i>→</i>`) : `<span class="muted">isi kampung tujuan untuk melihat rute</span>`;
    return `<div class="rt-rute"><div class="rt-path"><span class="muted">Rute</span>${path}${t.kamBad.length ? `<span class="bad">+ di luar SK: ${esc(t.kamBad.join(", "))}</span>` : ""}
      <button type="button" class="lnk" data-rtog>${open ? "▾" : "▸"} Lintasan &amp; biaya transport (${legs.length} · Rp ${rupiah(sum)})</button>${t.rute ? `<span class="tag warn">disunting</span><button type="button" class="lnk" data-rauto title="Buang suntingan, hitung lagi dari SK Transport">↺ otomatis dari SK</button>` : `<span class="tag">otomatis dari SK</span>`}</div>
    ${open ? `<div class="rt-legs">${legs.map(([k, v], i) => `<div class="rt-leg"><span class="muted">${i + 1}</span><input data-lg="k" data-li="${i}" value="${esc(k)}" placeholder="Keterangan lintasan / transport"><input type="number" min="0" step="1000" data-lg="v" data-li="${i}" value="${num(v) || ""}" placeholder="0"><button type="button" class="ib del" data-lgx="${i}" title="Hapus lintasan">×</button></div>`).join("")
        || `<div class="muted" style="font-size:12.5px">Belum ada lintasan.</div>`}<div><button type="button" class="btn sm" data-lgadd>+ Tambah lintasan / transport</button></div></div>` : ""}</div>`;
}
function rabTripCost(doc, t) { const n = compute(rabTripRec(doc, t))._num; return { tr: n.totTr, uh: n.totUH, inap: n.totInap, hotel: n.totHotel, jml: n.jml }; }
/** kebutuhan per detil POK untuk satu RAB */
function rabNeed(doc) {
    const o = {};
    for (const l of doc.items)
        if (l.key)
            o[l.key] = (o[l.key] || 0) + rabLineTot(l);
    for (const t of doc.trips)
        if (t.key)
            o[t.key] = (o[t.key] || 0) + rabTripCost(doc, t).jml;
    return o;
}
const rabSecTot = (doc, sec) => RAB_DEF[sec].trip ? doc.trips.filter(t => t.sec === sec).reduce((s, t) => s + rabTripCost(doc, t).jml, 0) : doc.items.filter(l => l.sec === sec).reduce((s, l) => s + rabLineTot(l), 0);
const rabTotal = (doc) => RAB_SECS.reduce((s, x) => s + rabSecTot(doc, x.id), 0);
/** kebutuhan semua RAB tahun ini per detil (+ nama RAB yang memakainya) */
function rabNeedAll() {
    const o = {};
    for (const d of rabDB)
        for (const [k, v] of Object.entries(rabNeed(d))) {
            const x = o[k] ||= { v: 0, docs: [] };
            x.v += v;
            if (!x.docs.includes(d.nama))
                x.docs.push(d.nama);
        }
    return o;
}
/* kebutuhan > pagu detil → Permintaan Revisi otomatis (status Diajukan, ditandai auto); diperbarui / dihapus mengikuti RAB.
   Yang sudah Disetujui/Ditolak tidak diubah lagi. */
function rabSyncRev() {
    const need = rabNeedAll(), M = detMap();
    for (const [k, x] of Object.entries(need)) {
        const d = M[k];
        if (!d)
            continue;
        const pg = rabPagu(d), r = revDB.find(y => y.auto === "rab" && y.key === k);
        if (x.v > pg) {
            const ket = `Otomatis dari RAB (${x.docs.join("; ")}): kebutuhan Rp ${rupiah(x.v)} melebihi pagu${d.blokir ? " (diblokir)" : ""} Rp ${rupiah(pg)} — kurang Rp ${rupiah(x.v - pg)}.`;
            if (!r)
                revDB.push({ _id: newId(), tgl: today(), key: k, mak: d.a.mak, akun: d.a.nama, namaLama: d.u, jmlLama: d.j, namaBaru: d.u, vol: 1, sat: "Paket", harga: x.v, jmlBaru: x.v, ket, status: "Diajukan", auto: "rab" });
            else if (r.status === "Diajukan") {
                r.vol = 1;
                r.harga = x.v;
                r.jmlBaru = x.v;
                r.ket = ket;
            }
        }
        else if (r && r.status === "Diajukan")
            revDB = revDB.filter(y => y !== r);
    }
    revDB = revDB.filter(y => !(y.auto === "rab" && y.status === "Diajukan" && !need[y.key]));
}
const rabSave = () => { rabSyncRev(); persistAng(); };
/** tebak detil dari uraian (kata yang sama), selain itu detil pertama yang boleh */
function rabGuessKey(dets, text) {
    const toks = acNorm(text).split(/[^a-z0-9]+/).filter(w => w.length > 2 && !["honor", "biaya", "belanja", "untuk", "dan"].includes(w));
    let best, sc = 0;
    for (const d of dets) {
        const h = acNorm(d.u), s = toks.filter(w => h.includes(w)).length;
        if (s > sc) {
            sc = s;
            best = d;
        }
    }
    return (best || dets[0])?.key || "";
}
/* ---------- tampilan ---------- */
/** pilihan jenis per bagian: judul Lokal / Remote → terkunci; Pemutakhiran / Supervisi → Lokal atau Remote; lainnya bebas */
const rabJenisOpts = (sec, cur) => { const d = RAB_DEF[sec]; if (d.fix)
    return [d.fix]; const o = sec === "pemut" || sec === "sup" ? ["Lokal", "Remote"] : ["Lokal", "Remote", JEN_TU]; return o.includes(cur) ? o : [...o, cur]; };
/** samakan jenis perjalanan dengan judul bagian yang mengunci (data lama / duplikat) */
function rabFixJenis() {
    let ch = false;
    rabDB.forEach(d => d.trips.forEach(t => { const f = RAB_DEF[t.sec]?.fix; if (!f || t.jenis === f)
        return; t.jenis = f; if (f !== "Remote") {
        t.hotel = 0;
        t.hotelTarif = 0;
    } delete t.rute; ch = true; }));
    return ch;
}
function renderRab() {
    if (rabFixJenis())
        rabSave();
    angYearUI();
    if (rabCur && !rabDoc())
        rabCur = null;
    if (!rabCur && rabDB.length)
        rabCur = rabDB[rabDB.length - 1]._id;
    const doc = rabDoc(), ros = rabRos();
    $("#rabDocs").innerHTML = rabDB.map(d => `<button type="button" class="rabdoc ${d._id === rabCur ? "on" : ""}" data-rd="${esc(d._id)}"><b>${esc(d.nama || "(tanpa nama)")}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></button>`).join("")
        + `<button type="button" class="rabdoc new" data-rnew><b>+ RAB baru</b><small>pilih MAK / RO dulu</small></button>`;
    const roCur = $("#rabRo").value, blnCur = $("#rabBln").value, toCur = $("#rabBlnTo").value;
    $("#rabRo").innerHTML = `<option value="">— Pilih MAK / RO —</option>` + ros.map(([k, n]) => `<option value="${esc(k)}">${esc(k)} ${esc(roTitle(n).slice(0, 70))}</option>`).join("");
    $("#rabBln").innerHTML = `<option value="-1">— tidak ditentukan —</option>` + BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join("");
    $("#rabBlnTo").innerHTML = BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join("");
    const neu = $("#rabHead").dataset.new === "1" || !doc;
    $("#rabHead").classList.toggle("isnew", neu);
    if (doc && !neu) {
        $("#rabRo").value = doc.ro;
        $("#rabNama").value = doc.nama;
        $("#rabBln").value = String(doc.bln);
        $("#rabBlnTo").value = String(rabBlnTo(doc));
    }
    else {
        $("#rabRo").value = roCur;
        $("#rabBln").value = blnCur || "-1";
        $("#rabBlnTo").value = toCur && +toCur >= +$("#rabBln").value ? toCur : $("#rabBln").value;
    }
    {
        const a = +$("#rabBln").value, b = +$("#rabBlnTo").value;
        $("#rabBlnTo").disabled = a < 0;
        if (a < 0)
            $("#rabBlnTo").value = "";
        $("#rabBlnInfo").textContent = a < 0 ? "Tanpa bulan — boleh diisi nanti" : b > a ? `${b - a + 1} bulan` : "1 bulan";
        [...$("#rabBlnTo").options].forEach(o => o.disabled = +o.value < a);
    }
    $("#rabMake").hidden = !neu;
    $("#rabNewCancel").hidden = !neu || !doc;
    $("#rabDocAct").hidden = neu;
    rabSecPickUI(doc, neu);
    $("#rabTabs").hidden = $("#rabBody").hidden = neu;
    $("#rabHint").innerHTML = neu ? `Langkah 1: pilih <b>MAK / RO</b> (mis. 2902.BMA.006) — pagu setiap baris RAB diambil dari detil POK RO ini (T.A. ${esc(angYear)}). Kebutuhan boleh melebihi pagu; kekurangannya otomatis dicatat di <b>Permintaan Revisi</b>.` : "";
    if (neu || !doc) {
        $("#rabPagu").innerHTML = "";
        return;
    }
    const need = rabNeed(doc), roDet = pokDetil().filter(d => d.a.ro === doc.ro), pg = roDet.reduce((s, d) => s + rabPagu(d), 0), tot = rabTotal(doc);
    const nRev = revDB.filter(r => r.auto === "rab" && Object.keys(need).includes(r.key)).length;
    $("#rabPagu").innerHTML = `<div class="ts"><small>Pagu RO ${esc(doc.ro)}</small><b>Rp ${rupiah(pg)}</b><span>${roDet.length} detil POK</span></div>
    <div class="ts"><small>Total RAB</small><b>Rp ${rupiah(tot)}</b><span>${doc.trips.length} perjalanan · ${doc.items.length} baris biaya</span></div>
    <div class="ts ${pg - tot < 0 ? "bad" : ""}"><small>Sisa pagu RO</small><b>${pg - tot < 0 ? "−" : ""}Rp ${rupiah(Math.abs(pg - tot))}</b><span>${nRev ? `${nRev} detil kurang → <a href="#" data-rgo="revisi">permintaan revisi</a>` : "semua detil cukup"}</span></div>`;
    {
        const ss = rabSecsOf(doc);
        if (RAB_DEF[rabView] && !ss.includes(rabView))
            rabView = ss[0] || "rekap";
        $("#rabTabs").innerHTML = RAB_VIEWS.filter(([id]) => !RAB_DEF[id] || ss.includes(id)).map(([id, n]) => {
            const s = RAB_DEF[id], c = s ? rabSecTot(doc, s.id) : 0;
            return `<button type="button" data-rv="${id}" class="${rabView === id ? "on" : ""}">${esc(n)}${s ? `<i>${c ? rpShort(c).replace("Rp ", "") : "–"}</i>` : ""}</button>`;
        }).join("")
            + `<button type="button" class="add ${rabSecOpen ? "on" : ""}" data-rsecadd title="Tambah / kurangi bagian RAB">+ Bagian</button>`;
    }
    renderRabBody(doc);
}
function rabDetOpts(dets, cur, need) {
    const M = detMap(), has = !cur || dets.some(d => d.key === cur);
    return `<option value="">— pilih pagu —</option>` + (has ? "" : `<option value="${esc(cur)}" selected>⚠ ${esc(M[cur]?.u || "detil tidak ada di RO/akun ini")}</option>`)
        + dets.map(d => {
            const s = rabPagu(d) - (need[d.key]?.v || 0);
            return `<option value="${esc(d.key)}" ${d.key === cur ? "selected" : ""}>${esc(d.u.slice(0, 58))} · ${esc(d.a.akun)} · pagu ${rupiah(rabPagu(d))}${s < 0 ? " · kurang " + rupiah(-s) : ""}</option>`;
        }).join("");
}
/** tabel cek pagu untuk detil yang dipakai bagian ini */
function rabPaguHtml(doc, keys) {
    const M = detMap(), all = rabNeedAll(), mine = rabNeed(doc), ks = [...new Set(keys.filter(Boolean))];
    if (!ks.length)
        return "";
    return `<div class="rab-cek"><b>Cek pagu</b><table class="ltbl tight"><thead><tr><th>Detil POK</th><th class="num">Pagu</th><th class="num">RAB ini</th><th class="num">RAB lain</th><th class="num">Sisa</th></tr></thead><tbody>${ks.map(k => {
        const d = M[k];
        if (!d)
            return `<tr><td colspan="5" class="bad">Detil tidak ditemukan di POK ${esc(angYear)}</td></tr>`;
        const v = mine[k] || 0, o = (all[k]?.v || 0) - v, s = rabPagu(d) - v - o, rv = revDB.find(r => r.auto === "rab" && r.key === k);
        return `<tr><td>${esc(d.u)}<div class="lsub">${esc(d.a.mak)} · ${esc(d.a.nama)}${d.blokir ? ` · <span class="bad">blokir</span>` : ""}</div></td><td class="num">${rupiah(rabPagu(d))}</td><td class="num">${rupiah(v)}</td><td class="num">${o ? rupiah(o) : "–"}</td>
      <td class="num"><b class="${s < 0 ? "bad" : ""}">${s < 0 ? "−" : ""}${rupiah(Math.abs(s))}</b>${s < 0 ? `<div class="lsub">${rv ? `revisi ${esc(rv.status.toLowerCase())}` : "revisi"}</div>` : ""}</td></tr>`;
    }).join("")}</tbody></table></div>`;
}
function renderRabBody(doc) {
    const el = $("#rabBody"), def = RAB_DEF[rabView];
    if (rabView === "rekap") {
        el.innerHTML = rabRekapHtml(doc);
        return;
    }
    if (rabView === "timeline") {
        el.innerHTML = rabTimelineHtml(doc);
        return;
    }
    if (!def) {
        rabView = "honor";
        renderRabBody(doc);
        return;
    }
    const dets = rabDetils(doc, def.id), need = rabNeedAll();
    const head = `<div class="rab-sh"><h3>${esc(def.n)}</h3><span class="muted">Pagu yang bisa dipilih: akun <b>${esc(def.akTxt)}</b> di RO ${esc(doc.ro)}</span></div>`
        + (dets.length ? "" : `<div class="rpd-warn">⚠ RO ${esc(doc.ro)} tidak punya detil POK akun ${esc(def.akTxt)} di T.A. ${esc(angYear)}. Baris tetap bisa diisi, tetapi belum dibebankan ke pagu.</div>`);
    if (!def.trip) {
        const L = doc.items.filter(l => l.sec === def.id), tot = L.reduce((s, l) => s + rabLineTot(l), 0);
        el.innerHTML = head + `<div class="rab-pre"><span class="muted">Tambah cepat:</span> ${(RAB_PRESET[def.id] || []).map(([u], i) => `<button type="button" class="btn sm" data-rpre="${i}">+ ${esc(u)}</button>`).join(" ")}</div>
      <div class="tblwrap"><table class="ltbl rabt"><thead><tr><th style="width:30px">No</th><th>Uraian</th><th style="width:74px">Orang</th><th style="width:84px">Volume</th><th style="width:84px">Satuan</th><th style="width:130px">Harga satuan</th><th class="num" style="width:120px">Jumlah</th><th style="width:30%">Dibebankan ke (detil POK)</th><th style="width:34px"></th></tr></thead>
      <tbody>${L.map((l, i) => `<tr data-rl="${esc(l.id)}"><td class="muted">${i + 1}</td><td><input data-lf="uraian" value="${esc(l.uraian)}"></td><td><input type="number" min="0" step="1" data-lf="org" value="${esc(l.org)}"></td><td><input type="number" min="0" step="any" data-lf="vol" value="${esc(l.vol)}"></td><td><input data-lf="sat" list="dl-revsat" value="${esc(l.sat)}"></td><td><input type="number" min="0" step="1000" data-lf="harga" value="${esc(l.harga)}"></td><td class="num" data-o="jml"><b>${rupiah(rabLineTot(l))}</b></td><td><select data-lf="key">${rabDetOpts(dets, l.key, need)}</select></td><td><button type="button" class="ib del" data-rdel title="Hapus baris">${IC.del}</button></td></tr>`).join("")
            || `<tr><td colspan="9" class="muted" style="text-align:center;padding:18px">Belum ada baris. Pakai <b>Tambah cepat</b> atau <b>+ Tambah baris</b>.</td></tr>`}</tbody>
      <tfoot><tr><td></td><td colspan="5"><b>Jumlah ${esc(def.n)}</b></td><td class="num" data-o="tot"><b>${rupiah(tot)}</b></td><td colspan="2"></td></tr></tfoot></table></div>
      <div class="actions" style="justify-content:flex-start;margin-top:8px"><button type="button" class="btn sm" data-radd>+ Tambah baris</button></div>` + rabPaguHtml(doc, L.map(l => l.key));
        return;
    }
    const T = doc.trips.filter(t => t.sec === def.id), costs = T.map(t => rabTripCost(doc, t)), tot = costs.reduce((s, c) => s + c.jml, 0);
    const pmls = T.filter((t, i) => t.peran === "Pengawas" && t.c && T.findIndex(x => x.peran === "Pengawas" && x.c === t.c) === i);
    const conflicts = T.map(t => [rabTripWarn(doc, t), rabPlanWarn(doc, t)].filter(Boolean).join(" · "));
    el.innerHTML = head + `<div class="rab-pre">${def.peran.map(p => `<button type="button" class="btn sm ${p === "Pendata" ? "" : "pri"}" data-radd="${p}">+ ${p}</button>`).join(" ")}
      <span class="spacer"></span><label class="rab-inl">Uang harian/hari<input type="number" min="0" step="1000" id="rabUh" value="${esc(doc.uh ?? "")}" placeholder="${rupiah(defUH())}"></label>
      <label class="rab-inl">Inap tanpa hotel/malam<input type="number" min="0" step="1000" id="rabInap" value="${esc(doc.inap ?? "")}" placeholder="${rupiah(defInap())}"></label></div>
    <div class="hint" style="margin:-2px 0 8px">Transport kampung otomatis dari SK Transport mengikuti <b>urutan rute</b> (Lokal / Translok+Uhar: tarif × hari; Remote: ½ tarif pergi &amp; pulang + lintasan antar kampung). Urutan kampung bisa digeser dengan ‹ ›; tiap lintasan dan biayanya bisa diubah, ditambah atau dihapus lewat <b>Lintasan &amp; biaya transport</b>. Kosongkan uang harian / inap untuk memakai tarif di Pengaturan. Satu pengawas boleh membawahi beberapa petugas: pilih pengawas yang sama pada tiap petugas, lalu klik <b>Sesuaikan jadwal pengawas</b> agar pengawas berada di kampung yang sama dengan petugasnya pada tanggal yang sama.</div>
    <div class="tblwrap"><table class="ltbl rabt rabtrip"><thead><tr><th style="width:30px">No</th><th style="width:132px">Peran</th><th style="width:22%">Petugas</th><th style="width:14%">Pengawas</th><th style="width:20%">Kampung tujuan (urut rute)</th><th style="width:150px">Jenis</th><th style="width:142px">Berangkat</th><th style="width:64px">Hari</th><th class="num" style="width:132px">Biaya</th><th style="width:36px"></th></tr></thead>
    <tbody>${T.map((t, i) => {
        const c = costs[i], w = conflicts[i], hot = !(def.id === "lokal" || def.id === "pemut");
        return `<tr data-rt="${esc(t.id)}" class="rt1 ${w ? "warn" : ""}"><td class="muted" rowspan="2">${i + 1}</td>
      <td><select data-tf="peran">${def.peran.map(p => `<option ${t.peran === p ? "selected" : ""}>${p}</option>`).join("")}</select></td>
      <td><input data-tf="nama" data-ac="peg" autocomplete="off" value="${esc(rabPegNama(t))}" placeholder="Cari nama…" class="${t.nama && !t.c ? "bad" : ""}"></td>
      <td>${t.peran === "Pendata" ? `<select data-tf="pml"><option value="">—</option>${pmls.map(p => `<option value="${esc(p.c)}" ${p.c === t.pml ? "selected" : ""}>${esc(rabPegNama(p).split(",")[0])}</option>`).join("")}</select>` : (() => { const n = t.peran === "Pengawas" && t.c ? T.filter(x => x.peran === "Pendata" && x.pml === t.c).length : 0; return n ? `<span class="tag" title="Jadwal pengawas mengikuti kampung petugasnya per tanggal">membawahi ${n} petugas</span>` : `<span class="muted">–</span>`; })()}</td>
      <td><input data-tf="kam" list="dl-kampung-nama" value="${esc(rabKamTxt(t))}" placeholder="mis. Isir, Sira" title="Pisahkan dengan koma, urut rute">${t.kamBad.length ? `<div class="lsub bad">di luar SK: ${esc(t.kamBad.join(", "))}</div>` : ""}</td>
      <td><select data-tf="jenis" ${def.fix ? `disabled title="Otomatis ${def.fix} mengikuti judul bagian ${esc(def.n)}"` : ""}>${rabJenisOpts(def.id, t.jenis).map(j => `<option ${t.jenis === j ? "selected" : ""}>${j}</option>`).join("")}</select></td>
      <td><input type="date" data-tf="pergi" value="${esc(t.pergi)}"></td>
      <td><input type="number" min="1" step="1" data-tf="hari" value="${esc(t.hari)}"></td>
      <td class="num" data-o="biaya" rowspan="2">${rabCostHtml(c)}${w ? `<div class="lsub bad" style="white-space:normal">${esc(w)}</div>` : ""}</td>
      <td rowspan="2"><button type="button" class="ib del" data-rdel title="Hapus">${IC.del}</button></td></tr>
      <tr data-rt="${esc(t.id)}" class="rt2 ${w ? "warn" : ""}"><td colspan="7">${rabRuteHtml(doc, t)}<div class="rt2-in">
        ${hot && t.jenis === "Remote" ? `<label>Hotel <input type="number" min="0" step="1" data-tf="hotel" value="${esc(t.hotel || "")}" placeholder="0" style="width:56px"> malam ×<input type="number" min="0" step="1000" data-tf="hotelTarif" value="${esc(t.hotelTarif || "")}" placeholder="tarif" style="width:110px"></label>` : ""}
        <label>${def.id === "luar" ? "Tiket / transport" : "Transport lain"} <input type="number" min="0" step="1000" data-tf="tr" value="${esc(t.tr || "")}" placeholder="0" style="width:110px"></label>
        <label class="rt2-key">Dibebankan ke <select data-tf="key">${rabDetOpts(dets, t.key, need)}</select></label></div></td></tr>`;
    }).join("")
        || `<tr><td colspan="10" class="muted" style="text-align:center;padding:18px">Belum ada perjalanan. Tambahkan ${def.peran.map(p => `<b>${p}</b>`).join(" / ")} di atas.</td></tr>`}</tbody>
    <tfoot><tr><td></td><td colspan="7"><b>Jumlah ${esc(def.n)}</b> <span class="muted">(${T.length} perjalanan · ${new Set(T.map(t => t.c || t.nama)).size} orang)</span></td><td class="num" data-o="tot"><b>${rupiah(tot)}</b></td><td></td></tr></tfoot></table></div>
    <div class="actions" style="justify-content:flex-start;margin-top:8px"><button type="button" class="btn sm" data-rkey>Samakan pagu semua baris…</button>${def.peran.includes("Pendata") ? ` <button type="button" class="btn sm" data-rpml title="Tanggal &amp; kampung pengawas disusun mengikuti semua petugas yang dibawahinya: pada tanggal yang sama pengawas berada di kampung yang sama dengan petugasnya">Sesuaikan jadwal pengawas</button>` : ""}<span class="spacer"></span><button type="button" class="btn sm pri" data-rst ${T.length ? "" : "disabled"}>Jadikan Surat Tugas…</button></div>` + rabPaguHtml(doc, T.map(t => t.key));
}
const rabCostHtml = (c) => `<b>${rupiah(c.jml)}</b><div class="lsub">${[c.tr ? "transport " + rupiah(c.tr) : "", c.uh ? "UH " + rupiah(c.uh) : "", c.inap ? "inap " + rupiah(c.inap) : "", c.hotel ? "hotel " + rupiah(c.hotel) : ""].filter(Boolean).join("<br>") || "–"}</div>`;
/** bentrok jadwal: dengan surat tugas tersimpan, atau dengan perjalanan lain orang yang sama di RAB ini */
function rabTripWarn(doc, t) {
    if (t.jenis === "Lokal") {
        const M = kamByKey(), bad = t.kam.map(k => M[k]).filter((k) => !!k && !kamLokal(k));
        if (bad.length)
            return `${RAB_DEF[t.sec].fix ? "Bagian ini khusus Lokal" : "Lokal tidak bisa dipilih"}: ${bad.map(k => title(k.kampung)).join(", ")} bukan kampung Lokal`;
    }
    if (!t.c || !t.pergi)
        return "";
    const a = isoDate(t.pergi), b = rabTripEnd(t);
    if (!a || !b)
        return "";
    const same = doc.trips.find(x => x !== t && x.c === t.c && x.pergi && (() => { const xa = isoDate(x.pergi), xb = rabTripEnd(x); return !!xa && !!xb && xa <= b && a <= xb; })());
    if (same)
        return `bentrok dengan ${RAB_DEF[same.sec].n} (${fmtDate(isoDate(same.pergi))})`;
    const cf = findConflicts(rabTripRec(doc, t), records, null);
    return cf.length ? `sudah ada ST ${cf[0].nomor} (${cf[0].tgl})` : "";
}
function rabRekapHtml(doc) {
    const M = detMap(), mine = rabNeed(doc), all = rabNeedAll(), tot = rabTotal(doc);
    const secRows = RAB_SECS.map(s => {
        const n = s.trip ? doc.trips.filter(t => t.sec === s.id).length : doc.items.filter(l => l.sec === s.id).length, v = rabSecTot(doc, s.id);
        return `<tr><td><a href="#" data-rv="${s.id}">${esc(s.n)}</a></td><td class="num">${n || "–"}</td><td class="num">${v ? rupiah(v) : "–"}</td><td class="num muted">${tot && v ? Math.round(v / tot * 100) + "%" : ""}</td></tr>`;
    }).join("");
    const ks = Object.keys(mine).sort((a, b) => (M[a]?.a.mak || a).localeCompare(M[b]?.a.mak || b));
    const noKey = doc.items.filter(l => !l.key).length + doc.trips.filter(t => !t.key).length;
    const detRows = ks.map(k => {
        const d = M[k], v = mine[k], o = (all[k]?.v || 0) - v;
        if (!d)
            return `<tr><td colspan="6" class="bad">Detil ${esc(k)} tidak ada di POK ${esc(angYear)}</td></tr>`;
        const s = rabPagu(d) - v - o, rv = revDB.find(r => r.auto === "rab" && r.key === k);
        return `<tr><td>${esc(d.u)}<div class="lsub">${esc(d.a.mak)}</div></td><td>${esc(d.a.akun)} <span class="muted">${esc(d.a.nama)}</span></td><td class="num">${rupiah(rabPagu(d))}</td><td class="num">${rupiah(v)}${o ? `<div class="lsub">+ RAB lain ${rupiah(o)}</div>` : ""}</td>
      <td class="num"><b class="${s < 0 ? "bad" : ""}">${s < 0 ? "−" : ""}${rupiah(Math.abs(s))}</b></td><td>${s < 0 ? `<span class="tag warn">revisi ${esc((rv?.status || "Diajukan").toLowerCase())}</span>` : `<span class="tag ok">cukup</span>`}</td></tr>`;
    }).join("");
    const inRpd = (doc.rpdIn || []).reduce((s, r) => s + r.v, 0);
    return `<div class="rab-sh"><h3>Rekap RAB — ${esc(doc.nama)}</h3><span class="muted">${esc(doc.ro)} ${esc(roTitle(rabRoNama(doc.ro)))} · T.A. ${esc(angYear)}</span></div>
    <div class="rab-rk"><table class="ltbl"><thead><tr><th>Komponen</th><th class="num">Baris</th><th class="num">Jumlah (Rp)</th><th class="num">%</th></tr></thead><tbody>${secRows}</tbody>
      <tfoot><tr><td><b>Total RAB</b></td><td></td><td class="num"><b>${rupiah(tot)}</b></td><td></td></tr></tfoot></table></div>
    ${noKey ? `<div class="rpd-warn">⚠ ${noKey} baris belum dibebankan ke detil POK — tidak ikut cek pagu & RPD.</div>` : ""}
    <h3 style="margin:16px 0 6px;font-size:15px">Kebutuhan per detil POK</h3>
    <div class="tblwrap"><table class="ltbl"><thead><tr><th>Detil POK</th><th>Akun</th><th class="num">Pagu</th><th class="num">Kebutuhan RAB</th><th class="num">Sisa</th><th>Status</th></tr></thead><tbody>${detRows || `<tr><td colspan="6" class="muted">Belum ada baris yang dibebankan ke pagu.</td></tr>`}</tbody></table></div>
    <div class="actions" style="margin-top:12px;justify-content:flex-start;flex-wrap:wrap">
      <button type="button" class="btn pri" data-rxls>Ekspor Excel RAB</button>
      <button type="button" class="btn" data-rrpd title="Kebutuhan baris biaya masuk ke bulan pelaksanaan (bila diisi); perjalanan masuk ke bulan berangkat">${doc.rpdIn?.length ? "Perbarui isian RPD" : "Masukkan ke RPD"}</button>
      <button type="button" class="btn" data-rst ${doc.trips.length ? "" : "disabled"}>Jadikan Surat Tugas…</button>
      <button type="button" class="btn" data-rgo="revisi">Lihat Permintaan Revisi</button>
      ${inRpd ? `<span class="muted" style="font-size:12.5px">Sudah di RPD: Rp ${rupiah(inRpd)}</span>` : ""}</div>`;
}
/** baris timeline: pengawas lalu pendata di bawahnya, lalu pelaksana lain */
function rabTimelineRows(doc) {
    const T = doc.trips.filter(t => t.pergi && (t.c || t.nama)), who = (t) => t.c || "n:" + t.nama, out = [], done = new Set();
    const add = (k, peran) => { if (done.has(k))
        return; done.add(k); const ts = T.filter(t => who(t) === k).sort((a, b) => a.pergi.localeCompare(b.pergi)); if (ts.length)
        out.push({ nama: rabPegNama(ts[0]), peran, trips: ts }); };
    for (const p of T.filter(t => t.peran === "Pengawas")) {
        add(who(p), "Pengawas");
        for (const d of T.filter(t => t.peran === "Pendata" && t.pml === p.c))
            add(who(d), "Pendata");
    }
    for (const t of T)
        add(who(t), t.peran);
    return out;
}
function rabTimelineHtml(doc) {
    const rows = rabTimelineRows(doc);
    if (!rows.length)
        return `<div class="rab-sh"><h3>Timeline Kegiatan</h3></div><p class="muted">Belum ada perjalanan bertanggal. Isi tanggal berangkat di tab Perjadin.</p>`;
    const all = rows.flatMap(r => r.trips), a0 = all.map(t => isoDate(t.pergi).getTime()), b0 = all.map(t => rabTripEnd(t).getTime());
    const start = new Date(Math.min(...a0)), nDay = Math.min(92, Math.round((Math.max(...b0) - start.getTime()) / 864e5) + 1);
    const days = Array.from({ length: nDay }, (_, i) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + i)), HR = ["Mg", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
    const di = (d) => Math.round((d.getTime() - start.getTime()) / 864e5);
    const body = rows.map(r => {
        let html = "", col = 0;
        const ts = r.trips.filter(t => di(isoDate(t.pergi)) < nDay);
        for (const t of ts) {
            const s = di(isoDate(t.pergi)), e = Math.min(nDay - 1, di(rabTripEnd(t)));
            if (s < col)
                continue;
            if (s > col)
                html += `<td colspan="${s - col}"></td>`;
            const bad = new Set((rabPlanCheck(doc, t)?.bad || []).map(d => di(isoDate(d)))), D = rabDays(t).slice(0, e - s + 1).map((ks, i) => ({ l: ks.map(rabKamNm).join(", ") || (i ? "" : rabKamTxt(t)) || RAB_DEF[t.sec].n, b: bad.has(s + i) }));
            for (let i = 0; i < D.length;) {
                let j = i + 1;
                while (j < D.length && D[j].l === D[i].l && D[j].b === D[i].b)
                    j++;
                html += `<td colspan="${j - i}" class="tl-ev tl-${t.sec}${D[i].b ? " tl-bad" : ""}" title="${esc(RAB_DEF[t.sec].n + " · " + D[i].l + (D[i].b ? " · tidak sekampung dengan petugas" : ""))}">${esc(D[i].l)}</td>`;
                i = j;
            }
            col = e + 1;
        }
        if (col < nDay)
            html += `<td colspan="${nDay - col}"></td>`;
        return `<tr><th class="tl-nm ${r.peran === "Pendata" ? "tl-sub" : ""}">${esc(r.nama.split(",")[0])}<small>${esc(r.peran)}</small></th>${html}</tr>`;
    }).join("");
    const nBad = doc.trips.filter(t => rabPlanWarn(doc, t)).length, hasPml = doc.trips.some(t => t.peran === "Pendata" && t.pml);
    const mon = [];
    days.forEach((d, i) => { if (i === 0 || d.getDate() === 1)
        mon.push(`<th colspan="${Math.min(nDay - i, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate() - d.getDate() + 1)}">${BULAN[d.getMonth()]} ${d.getFullYear()}</th>`); });
    return `<div class="rab-sh"><h3>Timeline Kegiatan</h3><span class="muted">${fmtDate(days[0])} – ${fmtDate(days[nDay - 1])} · ${rows.length} petugas · per kampung per hari</span>${hasPml ? `<span class="spacer"></span><button type="button" class="btn sm ${nBad ? "pri" : ""}" data-rpml="all">Sesuaikan jadwal pengawas</button>` : ""}</div>
    ${nBad ? `<div class="rpd-warn">⚠ ${nBad} jadwal pengawas belum sejalan dengan petugasnya (kotak bergaris merah = pengawas tidak sekampung dengan petugas pada tanggal itu).</div>` : ""}
    <div class="tl-leg">${RAB_SECS.filter(s => s.trip && doc.trips.some(t => t.sec === s.id)).map(s => `<span class="tl-ev tl-${s.id}">${esc(s.n.replace("Perjadin ", ""))}</span>`).join("")}</div>
    <div class="tblwrap"><table class="rab-tl"><thead><tr><th class="tl-nm"></th>${mon.join("")}</tr><tr><th class="tl-nm">Petugas</th>${days.map(d => `<th class="${d.getDay() === 0 ? "sun" : ""}">${HR[d.getDay()]}<br>${d.getDate()}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></div>`;
}
/* ---------- event ---------- */
let _rabT;
/** gambar ulang setelah event selesai, lalu kembalikan fokus ke kolom yang sama (baris & nama kolom) */
function rabLater() {
    clearTimeout(_rabT);
    _rabT = setTimeout(() => {
        const a = document.activeElement, row = a?.closest("[data-rl],[data-rt]"), f = a?.dataset.lf || a?.dataset.tf || (a?.classList.contains("dmy-t") ? "pergi" : "");
        const rk = row ? (row.dataset.rl ? `[data-rl="${row.dataset.rl}"]` : `[data-rt="${row.dataset.rt}"]`) : "";
        renderRab();
        if (rk && f) {
            const el = document.querySelector(`#rabBody ${rk} [data-lf="${f}"], #rabBody ${rk} [data-tf="${f}"]`);
            const t = el?._dmy || el;
            if (t) {
                t.focus();
                if (t instanceof HTMLInputElement && t.type === "text")
                    try {
                        t.setSelectionRange(t.value.length, t.value.length);
                    }
                    catch (e) { }
            }
        }
    }, 0);
}
function rabNew() {
    const ro = $("#rabRo").value;
    if (!ro)
        return toast("Pilih MAK / RO dulu sebelum membuat RAB.", "warn");
    const nama = $("#rabNama").value.trim() || roTitle(rabRoNama(ro));
    const secs = RAB_SECS.map(s => s.id).filter(id => rabSecSel.has(id));
    if (!secs.length)
        return toast("Pilih minimal satu bagian RAB (mis. Belanja Bahan, Perjadin Pemutakhiran).", "warn");
    const bv = $("#rabBln").value, b0 = bv === "" || !(+bv >= 0) ? -1 : +bv, b1 = b0 < 0 ? -1 : Math.max(b0, +$("#rabBlnTo").value || 0);
    const d = { _id: newId(), nama, ro, bln: b0, blnTo: b1, uh: null, inap: null, dibuat: today(), items: [], trips: [], secs };
    rabDB.push(d);
    rabCur = d._id;
    LS.set("st.rabCur", rabCur);
    rabView = secs[0];
    rabSecSel = new Set();
    $("#rabHead").dataset.new = "";
    rabSave();
    renderRab();
    toast(`RAB "${nama}" dibuat untuk ${ro}: ${secs.map(s0 => RAB_DEF[s0].n).join(", ")}.`, "ok");
}
$("#rabMake").onclick = rabNew;
$("#rabNewCancel").onclick = () => { $("#rabHead").dataset.new = ""; renderRab(); };
$("#rabDocs").addEventListener("click", e => {
    if (tg(e).closest("[data-rnew]")) {
        $("#rabHead").dataset.new = "1";
        rabSecSel = new Set();
        $("#rabNama").value = "";
        $("#rabRo").value = "";
        renderRab();
        $("#rabRo").focus();
        return;
    }
    const id = tg(e).closest("[data-rd]")?.dataset.rd;
    if (!id)
        return;
    rabCur = id;
    LS.set("st.rabCur", id);
    $("#rabHead").dataset.new = "";
    renderRab();
});
$("#rabHead").addEventListener("change", e => { if ($("#rabHead").dataset.new === "1" && (tg(e).id === "rabBln" || tg(e).id === "rabBlnTo"))
    renderRab(); });
$("#rabHead").addEventListener("change", e => {
    const doc = rabDoc();
    if (!doc || $("#rabHead").dataset.new === "1")
        return;
    const id = tg(e).id;
    if (id === "rabNama") {
        doc.nama = tg(e).value.trim() || doc.nama;
    }
    if (id === "rabBln") {
        doc.bln = +tg(e).value >= 0 ? +tg(e).value : -1;
        if (doc.bln < 0 || (doc.blnTo ?? -1) < doc.bln)
            doc.blnTo = doc.bln;
    }
    if (id === "rabBlnTo" && doc.bln >= 0) {
        doc.blnTo = Math.max(doc.bln, +tg(e).value || 0);
    }
    if (id === "rabRo") {
        const ro = tg(e).value;
        if (!ro) {
            tg(e).value = doc.ro;
            return;
        }
        const used = [...doc.items, ...doc.trips].filter(x => x.key).length;
        if (used && !confirm(`Ganti MAK/RO RAB ini ke ${ro}? ${used} baris yang sudah dibebankan ke detil POK ${doc.ro} akan dikosongkan bebannya (bisa dipilih ulang).`)) {
            tg(e).value = doc.ro;
            return;
        }
        doc.ro = ro;
        for (const x of [...doc.items, ...doc.trips])
            x.key = "";
    }
    rabSave();
    renderRab();
});
$("#rabDel").onclick = () => {
    const doc = rabDoc();
    if (!doc || !confirm(`Hapus RAB "${doc.nama}"?`))
        return;
    if (doc.rpdIn?.length && confirm("Kurangi juga isian RPD yang dulu dimasukkan dari RAB ini?"))
        for (const r of doc.rpdIn) {
            const a = rpdOf(r.key);
            a[r.m] = Math.max(0, num(a[r.m]) - r.v);
        }
    rabDB = rabDB.filter(d => d !== doc);
    rabCur = null;
    rabSave();
    renderRab();
    toast("RAB dihapus. Permintaan revisi otomatis ikut diperbarui.");
};
$("#rabDup").onclick = () => {
    const doc = rabDoc();
    if (!doc)
        return;
    const c = { ...clone(doc), _id: newId(), nama: doc.nama + " (salinan)", dibuat: today() };
    delete c.rpdIn;
    c.items.forEach(l => l.id = newId());
    c.trips.forEach(t => t.id = newId());
    rabDB.push(c);
    rabCur = c._id;
    LS.set("st.rabCur", rabCur);
    rabSave();
    renderRab();
    toast("Salinan RAB dibuat.");
};
$("#rabSecPick").addEventListener("click", e => { if (!tg(e).closest("[data-rsecall]"))
    return; rabSecAll = !rabSecAll; const neu = $("#rabHead").dataset.new === "1" || !rabDoc(); rabSecPickUI(rabDoc(), neu); });
$("#rabSecPick").addEventListener("change", e => {
    const id = tg(e).dataset.rsec;
    if (!id)
        return;
    const on = tg(e).checked, doc = rabDoc();
    if ($("#rabHead").dataset.new === "1" || !doc) {
        on ? rabSecSel.add(id) : rabSecSel.delete(id);
        tg(e).closest("label")?.classList.toggle("on", on);
        return;
    }
    const cur = rabSecsOf(doc);
    if (!on) {
        if (rabSecHas(doc, id)) {
            tg(e).checked = true;
            return toast(`Bagian ${RAB_DEF[id].n} sudah berisi data — hapus barisnya dulu sebelum menghilangkan bagian ini.`, "warn");
        }
        if (cur.length <= 1) {
            tg(e).checked = true;
            return toast("RAB minimal punya satu bagian.", "warn");
        }
        doc.secs = cur.filter(x => x !== id);
    }
    else {
        doc.secs = [...cur, id];
        rabView = id;
    }
    rabSave();
    renderRab();
    toast(on ? `Bagian ${RAB_DEF[id].n} ditambahkan.` : `Bagian ${RAB_DEF[id].n} dihilangkan.`);
});
$("#rabRo").addEventListener("change", () => { if ($("#rabHead").dataset.new === "1" || !rabDoc()) {
    rabSecAll = false;
    rabSecSel = new Set();
    rabSecPickUI(rabDoc(), true);
} });
$("#rabTabs").addEventListener("click", e => { if (tg(e).closest("[data-rsecadd]")) {
    rabSecOpen = !rabSecOpen;
    renderRab();
    return;
} });
$("#rabTabs").addEventListener("click", e => { const v = tg(e).closest("[data-rv]")?.dataset.rv; if (!v)
    return; rabView = v; LS.set("st.rabView", v); renderRab(); });
$("#rabPagu").addEventListener("click", e => { if (tg(e).closest("[data-rgo]")) {
    e.preventDefault();
    show("revisi");
} });
/** baris yang sedang diubah */
const rabLineOf = (doc, el) => { const id = el.closest("[data-rl]")?.dataset.rl; return doc.items.find(l => l.id === id); };
const rabTripOf = (doc, el) => { const id = el.closest("[data-rt]")?.dataset.rt; return doc.trips.find(t => t.id === id); };
function rabAddTrip(doc, sec, peran) {
    const def = RAB_DEF[sec], same = doc.trips.filter(t => t.sec === sec), last = same[same.length - 1], dets = rabDetils(doc, sec);
    const pml = peran === "Pendata" ? ([...same].reverse().find(t => t.peran === "Pengawas")?.c || "") : "";
    doc.trips.push({ id: newId(), sec, peran, c: "", nama: "", pml, kam: [], kamBad: [], jenis: def.fix || last?.jenis || def.jenis || "Lokal", pergi: last?.pergi || "", hari: last?.hari || (def.jenis === "Lokal" ? 1 : 3), hotel: 0, hotelTarif: 0, tr: 0,
        key: last?.key || rabGuessKey(dets, def.n + " " + (def.jenis === "Lokal" ? "transport lokal" : "perjalanan")), ket: "" });
}
/* rute perjalanan: geser urutan kampung, buka panel lintasan, tambah / hapus lintasan, kembali ke otomatis */
$("#rabBody").addEventListener("click", e => {
    const doc = rabDoc(), b = tg(e).closest("[data-kmv],[data-rtog],[data-rauto],[data-lgadd],[data-lgx]");
    if (!doc || !b)
        return;
    const t = rabTripOf(doc, b);
    if (!t)
        return;
    e.stopPropagation();
    const d = b.dataset;
    if (d.rtog != null) {
        rabRuteOpen.has(t.id) ? rabRuteOpen.delete(t.id) : rabRuteOpen.add(t.id);
        renderRabBody(doc);
        return;
    }
    if (d.kmv != null) {
        const i = Number(d.ki), j = i + Number(d.kmv);
        if (j < 0 || j >= t.kam.length)
            return;
        [t.kam[i], t.kam[j]] = [t.kam[j], t.kam[i]];
        if (t.rute) {
            delete t.rute;
            toast("Urutan rute berubah — lintasan dihitung ulang dari SK Transport.", "info");
        }
    }
    else if (d.rauto != null)
        delete t.rute;
    else if (d.lgadd != null) {
        t.rute ||= rabAutoLegs(doc, t);
        t.rute.push(["", 0]);
        rabRuteOpen.add(t.id);
    }
    else if (d.lgx != null) {
        t.rute ||= rabAutoLegs(doc, t);
        t.rute.splice(Number(d.lgx), 1);
    }
    rabSave();
    renderRab();
    if (d.lgadd != null)
        document.querySelector(`#rabBody tr.rt2[data-rt="${t.id}"] .rt-leg:last-of-type [data-lg="k"]`)?.focus();
}, true);
$("#rabBody").addEventListener("click", e => {
    const doc = rabDoc();
    if (!doc)
        return;
    const t0 = tg(e), sec = rabView, def = RAB_DEF[sec];
    const rv = t0.closest("[data-rv]")?.dataset.rv;
    if (rv) {
        e.preventDefault();
        rabView = rv;
        renderRab();
        return;
    }
    if (t0.closest("[data-rgo]")) {
        show("revisi");
        return;
    }
    if (t0.closest("[data-rxls]"))
        return rabXlsx(doc);
    if (t0.closest("[data-rrpd]"))
        return rabToRpd(doc);
    if (t0.closest("[data-rst]"))
        return rabStOpen(doc);
    const pm = t0.closest("[data-rpml]");
    if (pm) {
        const all = pm.dataset.rpml === "all", n = rabPlanApply(doc, all ? undefined : sec), left = doc.trips.filter(t => (all || t.sec === sec) && rabPlanWarn(doc, t)).length;
        if (n) {
            rabSave();
            renderRab();
        }
        toast(n ? `${n} jadwal pengawas disesuaikan dengan petugasnya${left ? ` — ${left} pengawas tetap tidak sempat mendampingi semua petugas` : ""}.` : doc.trips.some(t => (all || t.sec === sec) && t.peran === "Pendata" && t.pml && t.pergi && t.kam.length) ? "Jadwal pengawas sudah sesuai dengan petugasnya." : "Belum ada petugas bertanggal & berkampung yang dibawahi pengawas.", n ? "ok" : "info");
        return;
    }
    const pre = t0.closest("[data-rpre]")?.dataset.rpre;
    if (pre != null && def) {
        const [u, s, peran] = (RAB_PRESET[sec] || [])[+pre];
        const nOrg = peran ? new Set(doc.trips.filter(t => t.peran === peran && (t.c || t.nama)).map(t => t.c || t.nama)).size : 0;
        doc.items.push({ id: newId(), sec, uraian: u, org: nOrg || 1, vol: 1, sat: s, harga: 0, key: rabGuessKey(rabDetils(doc, sec), u) });
        rabSave();
        renderRab();
        if (nOrg)
            toast(`${nOrg} ${peran.toLowerCase()} diambil dari Perjadin RAB ini — isi volume & harga.`);
        return;
    }
    const add = t0.closest("[data-radd]");
    if (add && def) {
        if (def.trip)
            rabAddTrip(doc, sec, (add.dataset.radd || def.peran[0]));
        else
            doc.items.push({ id: newId(), sec, uraian: "", org: 1, vol: 1, sat: "", harga: 0, key: rabGuessKey(rabDetils(doc, sec), "") });
        rabSave();
        renderRab();
        const rows = $$(`#rabBody tbody tr${def.trip ? ".rt1" : ""}`);
        rows[rows.length - 1]?.querySelector(def.trip ? '[data-tf="nama"]' : '[data-lf="uraian"]')?.focus();
        return;
    }
    if (t0.closest("[data-rdel]")) {
        const l = rabLineOf(doc, t0), t = rabTripOf(doc, t0);
        if (l)
            doc.items = doc.items.filter(x => x !== l);
        if (t) {
            doc.trips = doc.trips.filter(x => x !== t);
            if (t.peran === "Pengawas")
                for (const x of doc.trips)
                    if (x.pml === t.c)
                        x.pml = "";
        }
        rabSave();
        renderRab();
        return;
    }
    if (t0.closest("[data-rkey]") && def) {
        const dets = rabDetils(doc, sec);
        if (!dets.length)
            return toast("Tidak ada detil POK yang bisa dipilih untuk bagian ini.", "warn");
        const cur = doc.trips.find(t => t.sec === sec && t.key)?.key || dets[0].key, list = dets.map((d, i) => `${i + 1}. ${d.u} (${d.a.akun})`).join("\n");
        const v = prompt(`Bebankan semua perjalanan ${def.n} ke detil nomor:\n\n${list}`, String(dets.findIndex(d => d.key === cur) + 1));
        const d = dets[(parseInt(v || "", 10) || 0) - 1];
        if (!d)
            return;
        for (const t of doc.trips)
            if (t.sec === sec)
                t.key = d.key;
        rabSave();
        renderRab();
        toast(`Semua perjalanan dibebankan ke ${d.u}.`);
    }
});
$("#rabBody").addEventListener("input", e => {
    const doc = rabDoc();
    if (!doc)
        return;
    const el = tg(e);
    if (el.id === "rabUh" || el.id === "rabInap") {
        const v = el.value === "" ? null : num(el.value);
        if (el.id === "rabUh")
            doc.uh = v;
        else
            doc.inap = v;
        rabSave();
        rabPatch(doc);
        return;
    }
    const l = rabLineOf(doc, el), lf = el.dataset.lf;
    if (l && lf && lf !== "key") {
        if (lf === "uraian" || lf === "sat")
            l[lf] = el.value;
        else if (lf === "org" || lf === "vol" || lf === "harga")
            l[lf] = num(el.value);
        rabSave();
        rabPatch(doc);
        return;
    }
    const t = rabTripOf(doc, el), tf = el.dataset.tf;
    if (t && el.dataset.lg) { // lintasan / biaya transport disunting → rute perjalanan ini jadi versi sendiri
        const first = !t.rute;
        t.rute ||= rabAutoLegs(doc, t);
        const row = t.rute[Number(el.dataset.li)];
        if (!row)
            return;
        if (el.dataset.lg === "k")
            row[0] = el.value;
        else
            row[1] = num(el.value);
        rabSave();
        rabPatch(doc);
        if (first)
            toast("Lintasan disunting — tidak lagi dihitung otomatis dari SK untuk perjalanan ini (klik ↺ untuk kembali).", "info");
        return;
    }
    if (t && (tf === "hari" || tf === "hotel" || tf === "hotelTarif" || tf === "tr")) {
        t[tf] = num(el.value);
        if (tf === "hari" && t.rute) {
            delete t.rute;
            toast("Lama hari berubah — lintasan dihitung ulang dari SK Transport.", "info");
            rabSave();
            rabLater();
            return;
        }
        rabSave();
        rabPatch(doc);
    }
});
$("#rabBody").addEventListener("change", e => {
    const doc = rabDoc();
    if (!doc)
        return;
    const el = tg(e);
    const l = rabLineOf(doc, el);
    if (l && el.dataset.lf === "key") {
        l.key = el.value;
        rabSave();
        rabLater();
        return;
    }
    const t = rabTripOf(doc, el), tf = el.dataset.tf;
    if (!t || !tf)
        return;
    if (tf === "peran") {
        t.peran = el.value;
        if (t.peran !== "Pendata")
            t.pml = "";
    }
    else if (tf === "nama") {
        const c = resolvePeg(el.value);
        t.c = c || "";
        t.nama = c ? "" : el.value.trim();
        if (el.value.trim() && !c)
            toast(`"${el.value.trim()}" tidak ada di Pegawai & Mitra — tetap dihitung, tetapi tidak bisa dijadikan surat tugas.`, "warn");
    }
    else if (tf === "pml")
        t.pml = el.value;
    else if (tf === "kam") {
        const p = parseKampungList(el.value);
        t.kam = p.found.map(kKey);
        t.kamBad = p.unknown;
        delete t.plan;
        if (t.rute) {
            delete t.rute;
            toast("Kampung berubah — lintasan dihitung ulang dari SK Transport.", "info");
        }
    }
    else if (tf === "jenis") {
        if (RAB_DEF[t.sec].fix)
            return;
        t.jenis = el.value === "Remote" ? "Remote" : el.value === JEN_TU ? JEN_TU : "Lokal";
        if (t.jenis !== "Remote") {
            t.hotel = 0;
            t.hotelTarif = 0;
        }
        if (t.rute) {
            delete t.rute;
            toast("Jenis berubah — lintasan dihitung ulang dari SK Transport.", "info");
        }
    }
    else if (tf === "pergi")
        t.pergi = el.value;
    else if (tf === "key")
        t.key = el.value;
    else
        return;
    rabSave();
    rabLater();
});
/** perbarui angka (biaya, total, ringkasan) tanpa menggambar ulang kolom isian */
function rabPatch(doc) {
    for (const l of doc.items) {
        const c = document.querySelector(`#rabBody tr[data-rl="${l.id}"] [data-o="jml"]`);
        if (c)
            c.innerHTML = `<b>${rupiah(rabLineTot(l))}</b>`;
    }
    for (const t of doc.trips) {
        const c = document.querySelector(`#rabBody tr[data-rt="${t.id}"] [data-o="biaya"]`);
        if (c)
            c.innerHTML = rabCostHtml(rabTripCost(doc, t));
    }
    const s = RAB_DEF[rabView], ft = document.querySelector('#rabBody tfoot [data-o="tot"]');
    if (s && ft)
        ft.innerHTML = `<b>${rupiah(rabSecTot(doc, s.id))}</b>`;
    clearTimeout(_rabPT);
    _rabPT = setTimeout(() => { if (!document.activeElement?.closest("#rabBody"))
        rabLater();
    else {
        const cek = document.querySelector("#rabBody .rab-cek");
        if (cek && s) {
            const keys = s.trip ? doc.trips.filter(t => t.sec === s.id).map(t => t.key) : doc.items.filter(l => l.sec === s.id).map(l => l.key);
            cek.outerHTML = rabPaguHtml(doc, keys) || "<div class=\"rab-cek\"></div>";
        }
    } }, 400);
}
let _rabPT;
$("#rabBody").addEventListener("focusout", () => setTimeout(() => { if (!document.activeElement?.closest("#rabBody") && document.querySelector("#v-rab.on"))
    renderRab(); }, 150));
/* ---------- RAB → RPD ---------- */
function rabToRpd(doc) {
    const add = {}, skip = [];
    let noBln = 0; // isian yang belum punya bulan (RAB tanpa bulan pelaksanaan & perjalanan tanpa tanggal berangkat)
    if (rabNoBln(doc))
        noBln += doc.items.filter(l => l.key && rabLineTot(l)).length;
    const put = (key, m, v) => { if (!key || !v)
        return; if (!(m >= 0)) {
        noBln++;
        return;
    } if (rpdLockM(m)) {
        if (!skip.includes(BULAN[m]))
            skip.push(BULAN[m]);
        return;
    } const x = add[key + "|" + m] ||= { key, m, v: 0 }; x.v += v; };
    {
        const ms = rabMonths(doc);
        for (const l of doc.items) {
            const parts = rabSplit(rabLineTot(l), ms.length);
            ms.forEach((m, i) => put(l.key, m, parts[i]));
        }
    }
    for (const t of doc.trips) {
        const a = isoDate(t.pergi);
        put(t.key, a && String(a.getFullYear()) === angYear ? a.getMonth() : doc.bln, rabTripCost(doc, t).jml);
    }
    const noBlnTxt = noBln ? `${noBln} isian belum punya bulan (RAB tanpa bulan pelaksanaan) — pilih Bulan mulai, atau isi tanggal berangkat perjalanan` : "";
    const list = Object.values(add);
    if (!list.length)
        return toast(noBln ? noBlnTxt + "." : skip.length ? `RPD ${skip.join(", ")} terkunci (triwulan lewat / TUP sudah difinalisasi).` : "Belum ada kebutuhan yang dibebankan ke detil POK.", "warn");
    const tot = list.reduce((s, x) => s + x.v, 0), months = [...new Set(list.map(x => BULAN[x.m]))].join(", ");
    if (!confirm(`Masukkan kebutuhan RAB "${doc.nama}" ke RPD ${angYear}?\n\n${list.length} isian · Rp ${rupiah(tot)} · bulan ${months}${doc.rpdIn?.length ? "\n\nIsian RPD dari RAB ini sebelumnya akan diganti (tidak dobel)." : ""}${skip.length ? `\n\nDilewati (RPD terkunci): ${skip.join(", ")}` : ""}${noBln ? `\n\nDilewati: ${noBlnTxt}.` : ""}`))
        return;
    for (const r of doc.rpdIn || []) {
        const a = rpdOf(r.key);
        a[r.m] = Math.max(0, num(a[r.m]) - r.v);
    }
    for (const r of list) {
        const a = rpdOf(r.key);
        a[r.m] = num(a[r.m]) + r.v;
    }
    doc.rpdIn = list;
    rabSave();
    renderRab();
    toast(`RAB masuk ke RPD: Rp ${rupiah(tot)} (${months}).`, "ok");
}
/* ---------- RAB → Surat Tugas Kolektif ---------- */
let rabStDoc = null;
function rabStOpen(doc) {
    const secs = RAB_SECS.filter(s => s.trip && doc.trips.some(t => t.sec === s.id));
    if (!secs.length)
        return toast("Belum ada perjalanan di RAB ini.", "warn");
    rabStDoc = doc;
    $("#rsSecs").innerHTML = secs.map(s => `<label class="chk0"><input type="checkbox" data-rss="${s.id}" ${s.id === rabView || !RAB_DEF[rabView]?.trip ? "checked" : ""}> ${esc(s.n)} <span class="muted">(${doc.trips.filter(t => t.sec === s.id).length})</span></label>`).join("");
    if (!$$("#rsSecs input:checked").length)
        $$("#rsSecs input")[0].checked = true;
    rabStInfo();
    $("#dRabSt").showModal();
}
const rabStSel = () => { const ss = $$("#rsSecs input:checked").map(i => i.dataset.rss); return (rabStDoc?.trips || []).filter(t => ss.includes(t.sec)); };
function rabStInfo() {
    const T = rabStSel(), M = detMap(), maks = [...new Set(T.map(t => M[t.key]?.a.mak).filter((m) => !!m))], cur = $("#rsMak").value;
    $("#rsMak").innerHTML = maks.map(m => `<option value="${esc(m)}" ${m === cur ? "selected" : ""}>${esc(m)} (${T.filter(t => M[t.key]?.a.mak === m).length})</option>`).join("") || `<option value="">— baris belum dibebankan ke pagu —</option>`;
    const mak = $("#rsMak").value, use = T.filter(t => !mak || M[t.key]?.a.mak === mak), noPeg = use.filter(t => !t.c).length, noTgl = use.filter(t => !t.pergi).length;
    const tim = $("#rsTim").checked, nSurat = tim ? rabStRows(use).length : use.filter(t => t.c).length;
    $("#rsInfo").innerHTML = `${use.length} perjalanan → <b>${nSurat} surat tugas</b> di Surat Tugas Kolektif (MAK ${esc(mak || "–")}).` + (maks.length > 1 ? `<br>⚠ Ada ${maks.length} MAK berbeda — satu kali ekspor untuk satu MAK; ulangi untuk MAK lain.` : "")
        + (noPeg ? `<br><span class="bad">${noPeg} baris tanpa petugas terdaftar dilewati.</span>` : "") + (noTgl ? `<br><span class="bad">${noTgl} baris belum bertanggal — lengkapi di Surat Tugas Kolektif.</span>` : "");
}
/** baris Surat Tugas Kolektif: per orang, atau per tim (pengawas + pendata di bawahnya, Terlampir) */
function rabStRows(use) {
    const doc = rabStDoc, fmt = (iso) => { const d = isoDate(iso); return d ? fmtDate(d) : ""; }, end = (t) => { const d = rabTripEnd(t); return d ? fmtDate(d) : ""; };
    const one = (t) => ({ peg: pegMap()[t.c]?.nama || "", ang: [], angBad: [], kam: t.kam.slice(), kamBad: t.kamBad.slice(), pp: true, pergi: fmt(t.pergi), pulang: end(t), jenis: t.jenis, maksud: `${RAB_DEF[t.sec].n.replace("Perjadin ", "")} — ${doc.nama}` });
    const T = use.filter(t => t.c);
    if (!$("#rsTim").checked)
        return T.map(one);
    const out = [], done = new Set();
    for (const p of T.filter(t => t.peran === "Pengawas")) {
        const mem = T.filter(t => t.peran === "Pendata" && t.pml === p.c && t.sec === p.sec);
        if (!mem.length)
            continue;
        const g = [p, ...mem];
        g.forEach(x => done.add(x));
        const st = g.map(x => x.pergi).filter(Boolean).sort(), en = g.map(x => rabTripEnd(x)).filter((d) => !!d).sort((a, b) => +a - +b);
        out.push({ peg: pegMap()[p.c]?.nama || "", ang: mem.map(x => x.c), angBad: [], kam: [...new Set(g.flatMap(x => x.kam))], kamBad: [...new Set(g.flatMap(x => x.kamBad))], pp: true,
            pergi: st[0] ? fmt(st[0]) : "", pulang: en.length ? fmtDate(en[en.length - 1]) : "", jenis: g.some(x => x.jenis === "Remote") ? "Remote" : "Lokal", maksud: `${RAB_DEF[p.sec].n.replace("Perjadin ", "")} — ${doc.nama}` });
    }
    for (const t of T)
        if (!done.has(t))
            out.push(one(t));
    return out;
}
$("#rsSecs").addEventListener("change", rabStInfo);
$("#rsMak").addEventListener("change", rabStInfo);
$("#rsTim").addEventListener("change", rabStInfo);
$("#rsOrang").addEventListener("change", rabStInfo);
$("#rsCancel").onclick = () => $("#dRabSt").close();
$("#rsGo").onclick = () => {
    const doc = rabStDoc;
    if (!doc)
        return;
    const M = detMap(), mak = $("#rsMak").value, use = rabStSel().filter(t => !mak || M[t.key]?.a.mak === mak), rows = rabStRows(use);
    if (!rows.length)
        return toast("Tidak ada perjalanan dengan petugas terdaftar untuk dijadikan surat tugas.", "warn");
    if (massRows.length && !confirm(`Surat Tugas Kolektif sudah berisi ${massRows.length} baris. Tambahkan ${rows.length} surat dari RAB di bawahnya?`))
        return;
    const base = Object.keys(massCommon).length ? massCommon : commonFrom(defaults()), keg = rabRoNama(doc.ro);
    massCommon = { ...base, kegiatan: keg, MAK: mak || base.MAK || "", MAKSUD__TUJUAN: doc.nama, kegLain: !pokJudul(ST_AKUN(false)).has(keg) };
    massRows.push(...rows);
    fillCommon(massCommon);
    persistMass();
    $("#dRabSt").close();
    show("mass");
    renderMass();
    toast(`${rows.length} surat tugas dari RAB masuk ke Surat Tugas Kolektif — periksa nomor & tanggal terbit, lalu Simpan.`, "ok");
};
/* ---------- ekspor Excel ---------- */
function rabXlsx(doc) {
    const M = detMap(), wb = XLSX.utils.book_new(), dn = (k) => M[k] ? `${M[k].u} (${M[k].a.mak})` : "";
    const add = (name, aoa, w) => { const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = w.map(x => ({ wch: x })); XLSX.utils.book_append_sheet(wb, ws, name.slice(0, 31)); };
    const mine = rabNeed(doc), all = rabNeedAll();
    add("Rekap", [[`RAB ${doc.nama}`], [`${doc.ro} ${roTitle(rabRoNama(doc.ro))} · T.A. ${angYear}`], [], ["Komponen", "Jumlah (Rp)"], ...RAB_SECS.map(s => [s.n, rabSecTot(doc, s.id)]), ["TOTAL", rabTotal(doc)], [],
        ["Detil POK", "MAK", "Pagu", "Kebutuhan RAB ini", "RAB lain", "Sisa"], ...Object.keys(mine).map(k => { const d = M[k], v = mine[k], o = (all[k]?.v || 0) - v; return [d?.u || k, d?.a.mak || "", d ? rabPagu(d) : 0, v, o, (d ? rabPagu(d) : 0) - v - o]; })], [40, 30, 14, 16, 14, 14]);
    for (const s of RAB_SECS) {
        if (!s.trip) {
            const L = doc.items.filter(l => l.sec === s.id);
            if (!L.length)
                continue;
            add(s.n, [["No", "Uraian", "Orang", "Volume", "Satuan", "Harga satuan", "Jumlah", "Dibebankan ke"], ...L.map((l, i) => [i + 1, l.uraian, l.org, l.vol, l.sat, l.harga, rabLineTot(l), dn(l.key)]), ["", "Jumlah", "", "", "", "", rabSecTot(doc, s.id), ""]], [5, 34, 8, 8, 10, 14, 14, 50]);
            continue;
        }
        const T = doc.trips.filter(t => t.sec === s.id);
        if (!T.length)
            continue;
        add(s.n.replace("Perjadin ", "Perjadin "), [["No", "Peran", "Petugas", "Pengawas", "Kampung tujuan (urut rute)", "Lintasan & transport", "Jenis", "Berangkat", "Kembali", "Hari", "Transport", "Uang harian", "Inap", "Hotel", "Jumlah", "Dibebankan ke"],
            ...T.map((t, i) => { const c = rabTripCost(doc, t), a = isoDate(t.pergi), b = rabTripEnd(t); return [i + 1, t.peran, rabPegNama(t), t.pml ? pegMap()[t.pml]?.nama || "" : "", rabKamTxt(t), rabLegs(doc, t).map(([k, v]) => `${k}: ${rupiah(num(v))}`).join("; "), t.jenis, a ? fmtDate(a) : "", b ? fmtDate(b) : "", num(t.hari), c.tr, c.uh, c.inap, c.hotel, c.jml, dn(t.key)]; }),
            ["", "", "Jumlah", "", "", "", "", "", "", "", "", "", "", "", rabSecTot(doc, s.id), ""]], [5, 10, 30, 24, 30, 60, 13, 18, 18, 6, 12, 12, 10, 10, 13, 44]);
    }
    const rows = rabTimelineRows(doc);
    if (rows.length) {
        const ts = rows.flatMap(r => r.trips), st = new Date(Math.min(...ts.map(t => isoDate(t.pergi).getTime()))), n = Math.min(92, Math.round((Math.max(...ts.map(t => rabTripEnd(t).getTime())) - st.getTime()) / 864e5) + 1);
        const days = Array.from({ length: n }, (_, i) => new Date(st.getFullYear(), st.getMonth(), st.getDate() + i));
        add("Timeline", [["Petugas", "Peran", ...days.map(d => `${d.getDate()} ${BLN_S[d.getMonth()]}`)], ...rows.map(r => [r.nama, r.peran, ...days.map(d => { const t = r.trips.find(x => isoDate(x.pergi) <= d && d <= rabTripEnd(x)); return t ? (rabDayMap(t).get(isoStr(d)) || []).map(rabKamNm).join(", ") || rabKamTxt(t) || RAB_DEF[t.sec].n : ""; })])], [30, 10, ...days.map(() => 11)]);
    }
    XLSX.writeFile(wb, `RAB ${doc.nama.replace(/[\\/:*?"<>|]+/g, " ").slice(0, 60)} ${angYear}.xlsx`);
    toast("RAB diekspor ke Excel.", "ok");
}
/* ================= DAFTAR RAB (seperti Daftar Surat Tugas) ================= */
function rblList() {
    const q = acNorm($("#rblQ").value.trim()).split(/\s+/).filter(Boolean), bl = $("#rblBln").value, P = pegMap();
    return [...rabDB].reverse().filter(d => (bl === "" || rabMonths(d).includes(+bl)) && (!q.length || q.every(t => acNorm([d.nama, d.ro, rabRoNama(d.ro), ...d.trips.map(x => (x.c && P[x.c]?.nama) || x.nama), ...d.items.map(l => l.uraian), ...[...d.items, ...d.trips].map(x => detMap()[x.key]?.a.mak || "")].join(" ")).includes(t))));
}
function renderRabList() {
    angYearUI();
    {
        const el = $("#rblBln"), v = el.value;
        el.innerHTML = `<option value="">Semua bulan</option>` + BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join("");
        el.value = v;
    }
    const list = rblList();
    let sum = 0;
    $("#rblTbl tbody").innerHTML = list.map(d => {
        const tot = rabTotal(d), pg = pokDetil().filter(x => x.a.ro === d.ro).reduce((s0, x) => s0 + rabPagu(x), 0), sisa = pg - tot;
        sum += tot;
        const maks = [...new Set([...d.items, ...d.trips].map(x => detMap()[x.key]?.a.mak).filter(Boolean))];
        return `<tr data-rbl="${esc(d._id)}"><td class="no"><b>${rabDB.length - rabDB.indexOf(d)}</b></td>
      <td><span class="lt-title" data-rba="open" title="Buka RAB">${esc(d.nama || "(tanpa nama)")}</span><div class="lsub one">dibuat ${esc(d.dibuat || "")} · ${d.trips.length} perjalanan · ${d.items.length} baris biaya</div><div class="rbl-secs">${rabSecsOf(d).map(s0 => `<span class="tag">${esc(RAB_DEF[s0].n)}</span>`).join("")}</div></td>
      <td><div style="font-size:13px">${esc(d.ro)}</div><div class="lsub one" title="${esc(maks.join(", "))}">${esc(roTitle(rabRoNama(d.ro)).slice(0, 60))}${maks.length ? ` · ${maks.length} MAK` : ""}</div></td>
      <td>${esc(rabBlnTxt(d))}</td>
      <td class="num"><b>Rp ${rupiah(tot)}</b></td>
      <td class="num"><span class="${sisa < 0 ? "bad" : "ok"}">${sisa < 0 ? "−" : ""}Rp ${rupiah(Math.abs(sisa))}</span></td>
      <td class="acts"><button class="btn sm pri" data-rba="open">Buka</button> <button class="btn sm" data-rba="xls">Excel</button> <button class="ib" data-rba="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-rba="del" title="Hapus">${IC.del}</button></td></tr>`;
    }).join("")
        || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">${rabDB.length ? "Tidak ada yang cocok." : `Belum ada RAB di T.A. ${esc(angYear)}. Klik <b>+ RAB baru</b>.`}</td></tr>`;
    $("#rblInfo").textContent = list.length ? `${list.length} RAB · total Rp ${rupiah(sum)}` : "";
}
$("#rblQ").addEventListener("input", debounce(() => renderRabList(), 150));
$("#rblBln").addEventListener("change", () => renderRabList());
$("#rblNew").onclick = () => { $("#rabHead").dataset.new = "1"; rabSecSel = new Set(); $("#rabNama").value = ""; show("rab"); $("#rabRo").value = ""; renderRab(); };
$("#rblTbl").addEventListener("click", e => {
    const tr = tg(e).closest("tr[data-rbl]"), a = tg(e).closest("[data-rba]")?.dataset.rba;
    if (!tr || !a)
        return;
    const d = rabDB.find(x => x._id === tr.dataset.rbl);
    if (!d)
        return;
    if (a === "open") {
        rabCur = d._id;
        LS.set("st.rabCur", d._id);
        $("#rabHead").dataset.new = "";
        show("rab");
        return;
    }
    if (a === "xls")
        return rabXlsx(d);
    if (a === "dup") {
        const c = { ...clone(d), _id: newId(), nama: d.nama + " (salinan)", dibuat: today() };
        delete c.rpdIn;
        c.items.forEach(l => l.id = newId());
        c.trips.forEach(t => t.id = newId());
        rabDB.push(c);
        rabSave();
        renderRabList();
        return toast("Salinan RAB dibuat.");
    }
    if (a === "del" && confirm(`Hapus RAB "${d.nama}"?`)) {
        if (d.rpdIn?.length && confirm("Kurangi juga isian RPD yang dulu dimasukkan dari RAB ini?"))
            for (const r of d.rpdIn) {
                const x = rpdOf(r.key);
                x[r.m] = Math.max(0, num(x[r.m]) - r.v);
            }
        rabDB = rabDB.filter(x => x !== d);
        if (rabCur === d._id)
            rabCur = null;
        rabSave();
        renderRabList();
        toast("RAB dihapus.");
    }
});
$("#rblExp").onclick = () => {
    const list = rblList();
    if (!list.length)
        return toast("Belum ada RAB untuk diekspor.", "warn");
    const aoa = [["No", "Nama RAB", "RO", "Judul RO", "Bulan", "Bagian", "Perjalanan", "Baris biaya", "Total RAB", "Pagu RO", "Sisa pagu RO", "Dibuat"]];
    list.forEach((d, i) => {
        const tot = rabTotal(d), pg = pokDetil().filter(x => x.a.ro === d.ro).reduce((s0, x) => s0 + rabPagu(x), 0);
        aoa.push([i + 1, d.nama, d.ro, roTitle(rabRoNama(d.ro)), rabBlnTxt(d), rabSecsOf(d).map(s0 => RAB_DEF[s0].n).join(", "), d.trips.length, d.items.length, tot, pg, pg - tot, d.dibuat || ""]);
    });
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [5, 36, 16, 40, 11, 40, 10, 10, 14, 14, 14, 16].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Daftar RAB");
    XLSX.writeFile(wb, `Daftar RAB ${angYear}.xlsx`);
    toast("Daftar RAB diekspor.", "ok");
};

/* ---- 90_beranda.ts ---- */
/* ================= BERANDA ================= */
const BLN3 = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
const recDate = (r) => parseTgl(r.TGL_TERBIT_ST) || parseTgl(r.TGL_PERGI);
const rp = (n) => "Rp " + rupiah(n);
const rpShort = (n) => n >= 1e9 ? "Rp " + (n / 1e9).toLocaleString("id-ID", { maximumFractionDigits: 2 }) + " M" : n >= 1e6 ? "Rp " + (n / 1e6).toLocaleString("id-ID", { maximumFractionDigits: 1 }) + " jt" : rp(n);
/** batang horizontal: [label, nilai, tooltip?] */
function hbars(el, rows, unit) {
    const max = Math.max(1, ...rows.map(r => r[1]));
    el.innerHTML = rows.length ? rows.map(([l, v, tip]) => `<div class="r" title="${esc(tip || `${l}: ${v} ${unit}`)}"><span class="l">${esc(l)}</span><span class="n">${v} ${unit}</span><span class="t"><i style="width:${(v / max * 100).toFixed(1)}%"></i></span></div>`).join("") : `<p class="muted">Belum ada data.</p>`;
}
let _homeKey = "", _homeIdle = 0;
/* Beranda: ringkasan dari semua fitur. Bagian ringan (kartu angka) langsung; grafik & daftar menyusul saat browser senggang. */
function renderHome(force) {
    const years = [...new Set(records.map(r => recDate(r)?.getFullYear()).filter((y) => !!y))].sort((a, b) => b - a);
    const ysel = $("#hYear"), now = new Date(), nowY = now.getFullYear();
    const cur = ysel.value || String(years.includes(nowY) ? nowY : years[0] || nowY);
    ysel.innerHTML = [...years.map(String), "semua"].map(y => `<option value="${y}" ${y === cur ? "selected" : ""}>${y === "semua" ? "Semua tahun" : "Tahun " + y}</option>`).join("");
    const Y = ysel.value, YN = Y === "semua" ? nowY : +Y, t0 = new Date(nowY, now.getMonth(), now.getDate());
    const hr = now.getHours();
    $("#hGreet").textContent = (hr < 11 ? "Selamat pagi" : hr < 15 ? "Selamat siang" : hr < 18 ? "Selamat sore" : "Selamat malam") + " · " + fmtDate(now);
    $("#hYearLbl").textContent = Y === "semua" ? "semua tahun" : "tahun " + Y;
    const inY = (d) => !!d && (Y === "semua" || d.getFullYear() === YN);
    // ---- surat tugas (pakai cache perhitungan) ----
    const key = [_dataVer, records.length, Y, t0.toDateString()].join("|"), heavy = force || key !== _homeKey;
    _homeKey = key;
    let n = 0, total = 0, thisMonth = 0, upcoming = 0, run = 0;
    const yr = [];
    for (const r of records) {
        const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG) || a;
        if (a && b && b >= t0) {
            upcoming++;
            if (a <= t0)
                run++;
        }
        const d = recDate(r);
        if (!inY(d))
            continue;
        yr.push(r);
        n++;
        total += computeC(r)._num.jmlTotal;
        if (d.getMonth() === now.getMonth() && d.getFullYear() === nowY)
            thisMonth++;
    }
    // ---- honor ----
    let hoN = 0, hoB = 0, hoP = 0;
    for (const h of honorDB || []) {
        const d = parseTgl(h.tglDaftar);
        if (Y !== "semua" && !inY(d))
            continue;
        const t = hoTot(h);
        hoN++;
        hoB += t.bruto;
        hoP += (h.rows || []).length;
    }
    // ---- nomor surat ----
    const sY = (suratDB || []).filter(x => Y === "semua" || Number(x.tahun) === YN), sMax = sY.reduce((m, x) => Math.max(m, +x.no || 0), 0);
    // ---- POK perjalanan dinas (POK aktif) ----
    const U = usage();
    let pagu = 0, blok = 0, used = 0;
    for (const a of pokDB.akun)
        if (/^5241/.test(a.akun)) {
            pagu += a.pagu;
            blok += a.blokir;
            used += U[a.mak]?.j || 0;
        }
    const avail = pagu - blok, sisa = avail - used;
    // ---- RPD / TUP / Revisi (tahun anggaran yang dipakai) ----
    const ay = String(YN), rpd = ay === angYear ? rpdDB : LS.get(angK("rpd", ay), {}), tupY = ay === angYear ? tupDB : LS.get(angK("tup", ay), {}), revY = ay === angYear ? revDB : LS.get(angK("revisi", ay), []);
    const pk = pokGet(ay), pkPagu = pk ? pk.akun.reduce((s0, a) => s0 + a.pagu - a.blokir, 0) : 0;
    let rpdTot = 0, rpdMon = 0;
    for (const v of Object.values(rpd || {})) {
        for (let m = 0; m < 12; m++) {
            const x = num(v[m]);
            rpdTot += x;
            if (m === now.getMonth())
                rpdMon += x;
        }
    }
    const tm = (tupY || {})[now.getMonth()], tupMon = tm ? Object.values(tm.val || {}).reduce((s0, v) => s0 + num(v), 0) : 0;
    const revA = (revY || []).filter(x => x.status === "Diajukan").length, revS = (revY || []).filter(x => x.status === "Disetujui").length;
    const K = [
        ["list", "Surat tugas", n.toLocaleString("id-ID"), `${thisMonth} dibuat bulan ini`],
        ["list", "Biaya perjalanan", rpShort(total), n ? `rata-rata ${rpShort(total / n)} / surat` : "belum ada"],
        ["list", "Sedang / akan berangkat", upcoming.toLocaleString("id-ID"), run ? `${run} sedang berlangsung` : "perjalanan belum selesai"],
        ["honor", "Honor petugas", rpShort(hoB), `${hoN} daftar · ${hoP} petugas`],
        ["nomor", "Nomor surat", sY.length.toLocaleString("id-ID"), sMax ? `nomor terakhir ${sMax}` : "belum ada"],
        ["pok", "Sisa perjalanan dinas", rpShort(sisa), avail ? `terpakai ${Math.round(used / avail * 100)}% dari pagu` : "POK belum ada", sisa < 0],
        ["rpd", `RPD ${ay}`, rpShort(rpdTot), pkPagu ? `${Math.round(rpdTot / pkPagu * 100)}% dari pagu · ${BLN3[now.getMonth()]} ${rpShort(rpdMon)}` : "POK belum ada"],
        ["tup", `TUP ${BLN3[now.getMonth()]}`, rpShort(tupMon), revA ? `${revA} revisi diajukan` : revS ? `${revS} revisi disetujui` : "tidak ada revisi menunggu"]
    ];
    $("#hKpi").innerHTML = K.map(([go, k, v, sub, bad]) => `<button type="button" class="kpi hk ${bad ? "bad" : ""}" data-go="${go}" title="Buka ${esc(k)}"><small>${esc(k)}</small><b>${v}</b><span class="sub">${esc(sub)}</span></button>`).join("");
    if (!heavy)
        return;
    renderCal();
    renderHomeUp(t0);
    cancelIdle(_homeIdle);
    _homeIdle = onIdle(() => renderHomeCharts(yr, Y, now));
}
const onIdle = (f) => ("requestIdleCallback" in window ? requestIdleCallback(f, { timeout: 400 }) : setTimeout(f, 30));
const cancelIdle = (h) => { if (!h)
    return; "cancelIdleCallback" in window ? cancelIdleCallback(h) : clearTimeout(h); };
/* daftar jadwal ringkas: 5 perjalanan terdekat */
function renderHomeUp(t0) {
    const P = pegMap(), up = tripsOf().filter(t => t.b >= t0).sort((x, z) => +x.a - +z.a), list = up.slice(0, 5);
    $("#hJadwal").innerHTML = list.length ? list.map(t => {
        const f = computeC(t.r), tm = teamOf(t.r, P), on = t.a <= t0;
        return `<div class="up" data-open="${esc(t.r._id)}" role="button" tabindex="0"><span class="ud ${on ? "run" : "next"}"><b>${t.a.getDate()}</b>${BLN3[t.a.getMonth()]}</span><span class="ut"><b>${esc(tm.label || (f.NAMA_PELAKSANA_SPD || "").split(",")[0])}</b><small>${esc(f.TEMPAT_TUJUAN || f.MAKSUD__TUJUAN || "")}</small></span><span class="tag ${on ? "ok" : ""}">${on ? "berlangsung" : "akan datang"}</span></div>`;
    }).join("")
        + (up.length > 5 ? `<button class="btn sm" type="button" data-go="list" style="margin-top:6px">Lihat semua (${up.length})</button>` : "")
        : `<p class="muted" style="margin:6px 0">Tidak ada perjalanan yang sedang / akan berlangsung.</p>`;
}
function renderHomeCharts(yr, Y, now) {
    _homeIdle = 0;
    const mon = Array.from({ length: 12 }, () => ({ n: 0, j: 0 })), P = pegMap(), people = {}, kegs = {};
    for (const r of yr) {
        const d = recDate(r);
        if (d) {
            mon[d.getMonth()].n++;
            mon[d.getMonth()].j += computeC(r)._num.jmlTotal;
        }
        const kg = String(r.kegiatan || "").trim() || "(tanpa kegiatan)";
        kegs[kg] = (kegs[kg] || 0) + 1;
        for (const ps of personsOf(r, P)) {
            const o = people[ps.key] ||= { nama: ps.nama, n: 0, hari: 0 };
            o.n++;
            o.hari += num(r.LAMA_JALAN);
        }
    }
    hbars($("#hKeg"), Object.entries(kegs).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => [k, v, `${k}: ${v} surat`]), "surat");
    hbars($("#hPeg"), Object.values(people).sort((a, b) => b.n - a.n || b.hari - a.hari).slice(0, 5).map((o) => [o.nama.split(",")[0], o.n, `${o.nama}: ${o.n} surat · ${o.hari} hari bertugas`]), "surat");
    const mx = Math.max(1, ...mon.map(m => m.n)), peak = mon.findIndex(m => m.n === mx);
    $("#hMonth").innerHTML = mon.map((m, i) => `<div class="col" title="${BLN3[i]}: ${m.n} surat · ${rp(m.j)}"><span class="v">${m.n && (i === peak || i === now.getMonth()) ? m.n : ""}</span><div class="b" style="height:${(m.n / mx * 100).toFixed(1)}%"></div></div>`).join("");
    $("#hMonthLbl").innerHTML = BLN3.map(x => `<span>${x}</span>`).join("");
    $("#hMonthNote").textContent = mon[peak].n ? `· tertinggi ${BLN3[peak]} (${mon[peak].n} surat)` : "";
    // aktivitas terakhir dari semua fitur
    const act = [];
    for (const r of records.slice(-8)) {
        const f = computeC(r);
        act.push({ t: parseTgl(r.TGL_TERBIT_ST) || recDate(r), ico: "ST", go: "", id: r._id, a: f.NOMOR_ST, b: `${(f.NAMA_PELAKSANA_SPD || "-").split(",")[0]} · ${String(f.MAKSUD__TUJUAN || "").slice(0, 70)}` });
    }
    for (const h of (honorDB || []).slice(-4))
        act.push({ t: parseTgl(h.tglDaftar), ico: "HO", go: "honor", a: h.judul2 || "Daftar honor", b: `${(h.rows || []).length} petugas · Rp ${rupiah(hoTot(h).bruto)}` });
    for (const x of (suratDB || []).slice(-4))
        act.push({ t: parseTgl(x.tgl), ico: "NS", go: "nomor", a: `${x.jenis || "Surat"} No. ${x.no}`, b: String(x.perihal || "").slice(0, 70) });
    for (const x of (revDB || []).slice(-3))
        act.push({ t: parseTgl(x.tgl), ico: "RV", go: "revisi", a: `Revisi: ${x.namaLama || ""}`.slice(0, 80), b: `${x.status} · selisih Rp ${rupiah((x.jmlBaru || 0) - (x.jmlLama || 0))}` });
    act.sort((x, z) => +(z.t || 0) - +(x.t || 0));
    $("#hRecent").innerHTML = act.slice(0, 6).map(x => `<div class="act" ${x.id ? `data-open="${esc(x.id)}"` : `data-go="${x.go}"`} role="button" tabindex="0"><span class="ai ai-${x.ico}">${x.ico}</span><span class="at"><b>${esc(x.a)}</b><small>${esc(x.b)}</small></span><span class="muted ad">${x.t ? x.t.getDate() + " " + BLN3[x.t.getMonth()] : ""}</span></div>`).join("") || `<p class="muted">Belum ada aktivitas.</p>`;
}
/* ---------- timeline kalender ---------- */
let calM = null, calSel = null;
const HARI = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"], BLN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
function tripsOf() {
    const out = [];
    for (const r of records) {
        const a = parseTgl(r.TGL_PERGI);
        if (!a)
            continue;
        let b = parseTgl(r.TGL_PULANG) || a;
        if (b < a)
            b = a;
        out.push({ r, a, b });
    }
    return out;
}
function renderCal() {
    const now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (!calM)
        calM = new Date(now.getFullYear(), now.getMonth(), 1);
    const y = calM.getFullYear(), m = calM.getMonth();
    $("#calTitle").textContent = BLN[m] + " " + y;
    const start = new Date(y, m, 1 - ((new Date(y, m, 1).getDay() + 6) % 7)), days = [];
    for (let i = 0; i < 42; i++)
        days.push(new Date(start.getFullYear(), start.getMonth(), start.getDate() + i));
    const end = days[41], trips = tripsOf().filter(t => t.b >= start && t.a <= end), P = pegMap();
    const st = (t) => t.b < t0 ? "done" : t.a > t0 ? "next" : "run";
    const TM = new Map(trips.map(t => [t.r, teamOf(t.r, P)])), tm = (r) => TM.get(r), name = (r) => tm(r).label;
    const order = (x, z) => tm(x.r).prio - tm(z.r).prio || +x.a - +z.a;
    let html = HARI.map(h => `<div class="dow">${h}</div>`).join("");
    for (const d of days) {
        const ev = trips.filter(t => t.a <= d && t.b >= d).sort(order);
        const key = d.toDateString(), cls = ["d", ev.some(t => st(t) === "run") ? "h-run" : "", ev.some(t => st(t) === "next") ? "h-next" : "", ev.some(t => st(t) === "done") ? "h-done" : "", d.getMonth() !== m ? "out" : "", key === t0.toDateString() ? "today" : "", calSel === key ? "sel" : ""].join(" ");
        html += `<div class="${cls}" data-day="${d.getFullYear()}-${d.getMonth()}-${d.getDate()}" title="${ev.length ? ev.length + " perjalanan" : ""}"><div class="dn">${d.getDate()}${ev.length ? `<small>${ev.length}</small>` : ""}</div>${ev.slice(0, 3).map(t => `<div class="ev ${st(t)}${tm(t.r).prio === 2 ? " mitra" : ""}" title="${esc(name(t.r) + " · " + (t.r.MAKSUD__TUJUAN || ""))}">${esc(name(t.r))}</div>`).join("")}${ev.length > 3 ? `<div class="more">+${ev.length - 3} lainnya — klik</div>` : ""}</div>`;
    }
    $("#cal").innerHTML = html;
    const inMonth = trips.filter(t => t.b >= new Date(y, m, 1) && t.a <= new Date(y, m + 1, 0)).length;
    $("#calDay").innerHTML = `<p class="muted" style="margin:0;font-size:13px">Bulan ini ${inMonth} perjalanan. Tiap tanggal menampilkan 3 surat (pegawai didahulukan) — klik tanggal untuk melihat semua.</p>`;
}
function openCalDay(dt) {
    const P = pegMap(), now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const ev = tripsOf().filter(t => t.a <= dt && t.b >= dt).map(t => ({ ...t, tm: teamOf(t.r, P) })).sort((x, z) => x.tm.prio - z.tm.prio || +x.a - +z.a);
    const st = (t) => t.b < t0 ? ["done", "selesai"] : t.a > t0 ? ["next", "akan datang"] : ["run", "berlangsung"];
    const nPeg = new Set(ev.flatMap(t => t.tm.peg)).size, nMit = new Set(ev.flatMap(t => t.tm.mit)).size;
    $("#cdTitle").textContent = fmtDate(dt);
    $("#cdSum").innerHTML = ev.length ? `<b>${ev.length}</b> surat tugas · <b>${nPeg}</b> pegawai · <b>${nMit}</b> mitra bertugas` : "Tidak ada perjalanan pada tanggal ini.";
    const item = (t) => {
        const f = compute(t.r), [c, lbl] = st(t);
        return `<div class="cd-it" data-open="${esc(t.r._id)}"><div class="cd-top"><span class="ev ${c}">${lbl}</span><span class="muted">${esc(f.NOMOR_ST)}</span><span class="muted" style="margin-left:auto;white-space:nowrap">${esc(t.r.TGL_PERGI)}${t.r.TGL_PULANG && t.r.TGL_PULANG !== t.r.TGL_PERGI ? " – " + esc(t.r.TGL_PULANG) : ""}</span></div>
      <div class="cd-m">${esc(f.MAKSUD__TUJUAN)}</div>
      <div class="cd-n">${t.tm.names.map(x => `<span class="${x.peg ? "pg" : "mt"}">${esc(x.nama)}</span>`).join("")}</div>
      <div class="muted" style="font-size:12px">${esc(f.TEMPAT_TUJUAN || "")}</div></div>`;
    };
    const grp = (title, list) => list.length ? `<div class="cd-g">${title} <span class="muted">(${list.length})</span></div>` + list.map(item).join("") : "";
    $("#cdList").innerHTML = grp("Surat tugas pegawai", ev.filter(t => t.tm.prio < 2)) + grp("Surat tugas mitra", ev.filter(t => t.tm.prio === 2));
    $("#dCalDay").showModal();
}
$("#calPrev").onclick = () => { const c = calM || new Date(); calM = new Date(c.getFullYear(), c.getMonth() - 1, 1); calSel = null; renderCal(); };
$("#calNext").onclick = () => { const c = calM || new Date(); calM = new Date(c.getFullYear(), c.getMonth() + 1, 1); calSel = null; renderCal(); };
$("#calToday").onclick = () => { calM = null; calSel = null; renderCal(); };
$("#cal").addEventListener("click", e => {
    const d = tg(e).closest("[data-day]");
    if (!d)
        return;
    const [y, m, dd] = (d.dataset.day ?? "").split("-").map(Number), dt = new Date(y, m, dd);
    calSel = dt.toDateString();
    renderCal();
    openCalDay(dt);
});
$("#cdClose").onclick = () => $("#dCalDay").close();
$("#cdList").addEventListener("click", e => {
    const it = tg(e).closest("[data-open]");
    if (!it)
        return;
    const rec = records.find(r => r._id === it.dataset.open);
    if (!rec)
        return;
    $("#dCalDay").close();
    homeView(rec);
});
/** Beranda hanya untuk melihat: surat tugas dibuka sebagai pratinjau (tidak bisa diedit dari sini) */
function homeView(rec) { openPreview([rec], `Lihat surat tugas ${compute(rec).NOMOR_ST} — hanya lihat; ubah lewat Daftar Surat Tugas`); }
$("#hYear").addEventListener("change", () => {
    const Y = $("#hYear").value, now = new Date();
    if (Y !== "semua") {
        const y = +Y;
        if (y === now.getFullYear())
            calM = new Date(y, now.getMonth(), 1);
        else {
            const ms = tripsOf().filter(t => t.a.getFullYear() === y).map(t => t.a.getMonth());
            calM = new Date(y, ms.length ? Math.max(...ms) : 0, 1);
        }
        calSel = null;
    }
    renderHome(true);
});
$("#v-home").addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && tg(e).matches("[role=button]")) {
    e.preventDefault();
    tg(e).click();
} });
$("#v-home").addEventListener("click", e => {
    const go = tg(e).closest("[data-go]");
    if (go) {
        if (go.dataset.go === "form")
            newForm();
        show(go.dataset.go ?? "home");
        window.scrollTo(0, 0);
        if (go.dataset.act)
            $("#" + go.dataset.act)?.click();
        return;
    }
    const tr = tg(e).closest("[data-open]");
    if (tr) {
        const rec = records.find(r => r._id === tr.dataset.open);
        if (rec)
            homeView(rec);
    }
});
const SCHEMES = {
    biru: { n: "Biru BPS", h: 214, s: 30, a: ["#2563a8", "#7cb0ee"] },
    langit: { n: "Biru Langit", h: 199, s: 40, a: ["#0e7490", "#5ccbe8"] },
    hijau: { n: "Hijau Daun", h: 142, s: 22, a: ["#1f7a45", "#6fd39a"] },
    teal: { n: "Toska", h: 172, s: 25, a: ["#0f766e", "#4fd1c0"] },
    hutan: { n: "Hutan", h: 95, s: 20, a: ["#4d6b1c", "#a9d662"] },
    ungu: { n: "Ungu", h: 262, s: 25, a: ["#6d3fc9", "#b49bf7"] },
    lavender: { n: "Lavender", h: 285, s: 28, a: ["#8a4fb8", "#d2a8f2"] },
    rose: { n: "Merah Marun", h: 345, s: 22, a: ["#b4234a", "#f58aa3"] },
    peach: { n: "Peach", h: 20, s: 45, a: ["#c0532b", "#f5a27c"] },
    oranye: { n: "Oranye", h: 24, s: 40, a: ["#c2410c", "#fb923c"] },
    sepia: { n: "Sepia (krem)", h: 36, s: 38, a: ["#8a5a2b", "#d9a86c"] },
    emas: { n: "Emas", h: 45, s: 45, a: ["#94660a", "#e8bf5a"] },
    slate: { n: "Abu Netral", h: 220, s: 8, a: ["#3d4a5c", "#c3ccd8"] },
    navy: { n: "Navy Malam", h: 224, s: 40, a: ["#1d4ed8", "#6b9dfa"] }
};
const SCH_KEYS = ["accent", "accent-soft", "accent-ink", "bg", "card", "side", "side-on", "line", "ro", "field", "ink", "muted", "warn-soft", "ok-soft", "danger-soft"];
const hsl = (h, s, l) => `hsl(${h} ${s}% ${l}%)`;
/* intensitas cahaya 0–100 (bawaan 50): menggeser kecerahan latar, kartu, menu & garis */
const lightK = () => { const v = +LS.get("st.light", 50); return Number.isFinite(v) ? Math.max(0, Math.min(100, v)) : 50; };
function schemeVars(sc, dark, lv = lightK()) {
    const { h, s } = sc, o = (lv - 50) / 50, L = (base, amt) => Math.max(2, Math.min(99.5, base + o * amt));
    const hsl = (hh, ss, l) => `hsl(${hh} ${ss}% ${(+l).toFixed(1)}%)`, Lb = (b) => L(b, dark ? 6 : 5), Lc = (b) => L(b, dark ? 6 : o < 0 ? 6 : (b > 98 ? 1.2 : 4.5));
    return dark ? {
        bg: hsl(h, s * .55, Lb(7)), card: hsl(h, s * .5, Lc(10.5)), side: hsl(h, s * .55, Lb(8.5)), "side-on": hsl(h, s * .6, Lc(15)), field: hsl(h, s * .5, Lb(8.5)),
        line: hsl(h, s * .4, Lc(19)), ro: hsl(h, s * .45, Lc(13)), ink: hsl(h, 12, 91), muted: hsl(h, 8, 64),
        accent: sc.a[1], "accent-soft": hsl(h, Math.min(60, s * 1.4), 17), "accent-ink": hsl(h, 30, 8),
        "warn-soft": "hsl(40 45% 14%)", "ok-soft": "hsl(145 35% 13%)", "danger-soft": "hsl(0 40% 15%)"
    } : {
        bg: hsl(h, s * .9, Lb(94.5)), card: hsl(h, s * .6, Lc(98.6)), side: hsl(h, s * .8, Lb(92.5)), "side-on": hsl(h, s, Lb(87.5)), field: hsl(h, s * .5, Lc(99)),
        line: hsl(h, s * .55, Lb(86.5)), ro: hsl(h, s * .7, Lb(92)), ink: hsl(h, 18, 17), muted: hsl(h, 9, 42),
        accent: sc.a[0], "accent-soft": hsl(h, Math.min(70, s * 1.6), 92), "accent-ink": "#ffffff",
        "warn-soft": "hsl(42 80% 93%)", "ok-soft": "hsl(145 45% 92%)", "danger-soft": "hsl(0 70% 95%)"
    };
}
/* jarak tepi kiri-kanan (px) & lebar isi halaman */
const padX = () => { const v = +LS.get("st.padx", 12); return Number.isFinite(v) ? Math.max(0, Math.min(48, v)) : 12; };
const FONT_SIZES = [["kecil", "A", .92, "Kecil"], ["normal", "A", 1, "Normal"], ["besar", "A", 1.1, "Besar"], ["xbesar", "A", 1.22, "Sangat besar"]];
const FONTS = {
    sistem: ["Sistem (bawaan)", 'ui-sans-serif,-apple-system,"Segoe UI Variable Text","Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif'],
    verdana: ["Verdana — mudah dibaca", 'Verdana,"DejaVu Sans",Geneva,sans-serif'],
    tahoma: ["Tahoma — ringkas", 'Tahoma,"Segoe UI",Geneva,sans-serif'],
    trebuc: ["Trebuchet — luwes", '"Trebuchet MS","Segoe UI",sans-serif'],
    calibri: ["Calibri — kantor", 'Calibri,Carlito,"Segoe UI",sans-serif'],
    arial: ["Arial", 'Arial,"Liberation Sans",Helvetica,sans-serif'],
    georgia: ["Georgia — serif", 'Georgia,"Times New Roman","DejaVu Serif",serif'],
    mono: ["Monospace", 'ui-monospace,"Cascadia Mono",Consolas,"DejaVu Sans Mono",monospace']
};
function applyTheme(t) {
    const root = document.documentElement;
    if (t)
        root.dataset.theme = t;
    else
        delete root.dataset.theme;
    const dark = t ? t === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    document.body.classList.toggle("is-dark", dark);
    root.style.colorScheme = dark ? "dark" : "light";
    const sc = SCHEMES[LS.get("st.scheme", "biru")] || SCHEMES.biru;
    for (const k of SCH_KEYS)
        root.style.removeProperty("--" + k);
    for (const [k, v] of Object.entries(schemeVars(sc, dark)))
        root.style.setProperty("--" + k, v);
    const fz = FONT_SIZES.find(f => f[0] === LS.get("st.fsize", "normal")) || FONT_SIZES[1];
    root.style.setProperty("--zoom", String(fz[2]));
    const fo = FONTS[LS.get("st.font", "sistem")] || FONTS.sistem;
    root.style.setProperty("--font", fo[1]);
    root.style.setProperty("--padx", padX() + "px");
    root.style.setProperty("--maxw", { penuh: "none", lebar: "1480px", normal: "1240px" }[LS.get("st.maxw", "penuh")] || "none");
    $("#themeBtn .tlabel").textContent = "Tema";
    renderThemePop();
}
function renderThemePop() {
    const t = LS.get("st.theme", null) || "auto", cur = LS.get("st.scheme", "biru"), dark = document.body.classList.contains("is-dark");
    $$("#tpMode [data-tm]").forEach(b => b.classList.toggle("on", b.dataset.tm === t));
    $("#tpSch").innerHTML = Object.entries(SCHEMES).map(([k, v]) => {
        const c = schemeVars(v, dark);
        return `<button type="button" data-sch="${k}" class="${k === cur ? "on" : ""}" title="${v.n}"><span class="sw" style="background:${c.bg};border-color:${c.line}"><span style="background:${c.card}"></span><i style="background:${c.accent}"></i></span><span>${v.n}</span></button>`;
    }).join("");
    const px = padX();
    $("#tpPad").value = String(px);
    $("#tpPadV").textContent = px + " px" + (px === 12 ? " (bawaan)" : "");
    $$("#tpW [data-tw]").forEach(b => b.classList.toggle("on", b.dataset.tw === LS.get("st.maxw", "penuh")));
    const lv = lightK();
    $("#tpLight").value = String(lv);
    $("#tpLightV").textContent = lv === 50 ? "Normal" : lv < 50 ? `Lebih redup (${lv})` : `Lebih terang (${lv})`;
    const fs = LS.get("st.fsize", "normal");
    $("#tpSize").innerHTML = FONT_SIZES.map(([k, a, z, n]) => `<button type="button" data-fs="${k}" class="${k === fs ? "on" : ""}" title="${n}"><span style="font-size:${Math.round(13 * z)}px">${a}</span><small>${n}</small></button>`).join("");
    const fo = LS.get("st.font", "sistem");
    $("#tpFont").innerHTML = Object.entries(FONTS).map(([k, [n, f]]) => `<option value="${k}" ${k === fo ? "selected" : ""} style="font-family:${f.replace(/"/g, "'")}">${n}</option>`).join("");
}
const themePopOpen = (on) => { $("#themePop").hidden = !on; $("#themeBtn").setAttribute("aria-expanded", String(on)); if (on) {
    const r = $("#themeBtn").getBoundingClientRect();
    $("#themePop").style.top = (r.bottom + 8) + "px";
    $("#themePop").style.right = Math.max(8, innerWidth - r.right) + "px";
} };
$("#themeBtn").onclick = e => { e.stopPropagation(); themePopOpen(Boolean($("#themePop").hidden)); };
$("#themePop").addEventListener("click", e => {
    e.stopPropagation();
    const m = tg(e).closest("[data-tm]")?.dataset.tm;
    if (m) {
        if (m === "auto")
            LS.del("st.theme");
        else
            LS.set("st.theme", m);
        applyTheme(m === "auto" ? null : m);
        toast(`Mode ${m === "light" ? "terang" : m === "dark" ? "gelap" : "otomatis (ikut perangkat)"} dipakai.`);
        return;
    }
    const k = tg(e).closest("[data-sch]")?.dataset.sch;
    if (k) {
        LS.set("st.scheme", k);
        applyTheme(LS.get("st.theme", null));
        toast(`Skema warna ${SCHEMES[k].n} dipakai.`);
        return;
    }
    const tw = tg(e).closest("[data-tw]")?.dataset.tw;
    if (tw) {
        LS.set("st.maxw", tw);
        applyTheme(LS.get("st.theme", null));
        toast(`Lebar isi halaman ${tw} dipakai.`);
        return;
    }
    const fs = tg(e).closest("[data-fs]")?.dataset.fs;
    if (fs) {
        LS.set("st.fsize", fs);
        applyTheme(LS.get("st.theme", null));
        themePopOpen(true);
        toast(`Ukuran teks ${(FONT_SIZES.find(f => f[0] === fs) || FONT_SIZES[1])[3].toLowerCase()} dipakai.`);
        return;
    }
    if (tg(e).closest("#tpReset")) {
        for (const x of ["st.theme", "st.scheme", "st.fsize", "st.font", "st.light", "st.padx", "st.maxw"])
            LS.del(x);
        applyTheme(null);
        themePopOpen(true);
        toast("Tema dikembalikan ke bawaan.");
    }
});
$("#tpPad").addEventListener("input", e => { LS.set("st.padx", +tg(e).value); applyTheme(LS.get("st.theme", null)); });
$("#tpPad").addEventListener("change", e => toast(`Jarak tepi ${tg(e).value} px dipakai.`));
$("#tpPad").addEventListener("dblclick", () => { LS.set("st.padx", 12); applyTheme(LS.get("st.theme", null)); });
$("#tpLight").addEventListener("input", e => { LS.set("st.light", +tg(e).value); applyTheme(LS.get("st.theme", null)); });
$("#tpLight").addEventListener("change", e => toast(`Intensitas cahaya ${+tg(e).value === 50 ? "normal" : +tg(e).value < 50 ? "lebih redup" : "lebih terang"} dipakai.`));
$("#tpLight").addEventListener("dblclick", () => { LS.set("st.light", 50); applyTheme(LS.get("st.theme", null)); });
$("#tpFont").addEventListener("change", e => { LS.set("st.font", tg(e).value); applyTheme(LS.get("st.theme", null)); toast(`Huruf ${(FONTS[tg(e).value] || FONTS.sistem)[0].split(" —")[0]} dipakai.`); });
document.addEventListener("click", () => { if (!$("#themePop").hidden)
    themePopOpen(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#themePop").hidden) {
    themePopOpen(false);
    $("#themeBtn").focus();
} });
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => { if (!LS.get("st.theme", null))
    applyTheme(null); });
applyTheme(LS.get("st.theme", null));
/* kolom angka: roda mouse tidak mengubah nilai */
document.addEventListener("wheel", e => { const a = document.activeElement; if (a instanceof HTMLInputElement && a.type === "number" && tg(e) === a)
    a.blur(); }, { passive: true });
/* tooltip untuk elemen ber-data-tip */
document.addEventListener("mouseover", e => { const t = tg(e).closest("[data-tip]"), tip = $("#tip"); if (!t) {
    tip.classList.remove("on");
    return;
} tip.textContent = t.dataset.tip ?? ""; tip.classList.add("on"); });
document.addEventListener("mousemove", e => { const tip = $("#tip"); if (!tip.classList.contains("on"))
    return; const x = Math.min(innerWidth - tip.offsetWidth - 8, e.clientX + 14), y = Math.min(innerHeight - tip.offsetHeight - 8, e.clientY + 14); tip.style.left = x + "px"; tip.style.top = y + "px"; });
/* ================= pop up setelah simpan ================= */
function afterSave(title, msg, alt) {
    $("#svTitle").textContent = title;
    $("#svMsg").textContent = msg;
    $("#svAlt").textContent = alt === "list" ? "Lihat di Daftar" : "Surat tugas baru";
    $("#svAlt").dataset.alt = alt || "new";
    $("#dSaved").showModal();
}
$$("#dSaved [data-sv]").forEach(b => b.onclick = () => {
    $("#dSaved").close();
    const a = b.dataset.sv;
    if (a === "home") {
        show("home");
        window.scrollTo(0, 0);
    }
    else if (a === "alt") {
        if (b.dataset.alt === "list") {
            show("list");
        }
        else {
            newForm();
            show("form");
        }
        window.scrollTo(0, 0);
    }
});
/* ================= KOTAK PENCARIAN (autocomplete) ================= */
/* data-ac="kode" → kode klasifikasi; "pel" → semua pegawai & mitra + Terlampir; "peg" → pegawai & mitra; "off" → hanya pegawai (PPK, Kepala, Bendahara) */
/** keadaan kotak pencarian yang sedang terbuka */
const AC = { el: null, items: [], idx: 0, quiet: false };
const acNorm = (t) => String(t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
function acHi(text, toks) { let h = esc(text); for (const t of toks)
    if (t.length > 1)
        h = h.replace(new RegExp("(" + t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "ig"), "<mark>$1</mark>"); return h; }
function acSource(kind, q) {
    if (kind === "detil")
        return detilAc(q);
    const toks = acNorm(q).split(/[\s,;/]+/).filter(Boolean);
    if (kind === "pokj") { // judul kegiatan = RO di POK (kode RO + nama RO), bukan detil MAK
        const U = usage(), ro = new Map();
        const akP = ST_AKUN(acPel(AC.el));
        for (const a of pokDB.akun) {
            if (!akP.includes(a.akun))
                continue;
            const o = ro.get(a.ro) || { ro: a.ro, nama: String(a.roNama).trim(), keg: a.kegNama, maks: [], sisa: 0 };
            o.maks.push(a.mak);
            o.sisa += a.pagu - a.blokir - (U[a.mak]?.j || 0);
            ro.set(a.ro, o);
        }
        return [...ro.values()].filter(o => { const h = acNorm(o.ro + " " + o.nama + " " + o.keg); return !toks.length || toks.every(t => h.includes(t)); })
            .sort((x, y) => x.ro.localeCompare(y.ro))
            .map(o => ({ v: o.nama, mak: o.maks.length === 1 ? o.maks[0] : null, ro: o.ro, maks: o.maks, html: `<b>${acHi(o.ro, toks)}</b><span class="d">${acHi(o.nama, toks)}<small>${esc(o.keg)} · ${o.maks.length} MAK · sisa Rp ${rupiah(o.sisa)}</small></span>`, score: 0 }));
    }
    if (kind === "makpj" || kind === "makho") {
        const allow = kind === "makho" ? HO_AKUN : ST_AKUN(acPel(AC.el)), U = usage(), res = [];
        const kf = kind === "makpj" && AC.el?.dataset.kegFrom ? ($(AC.el.dataset.kegFrom)?.value || "").trim() : "", roF = kf && pokJudul(allow).has(kf) ? kf : "";
        for (const a of pokDB.akun) {
            if (!allow.includes(a.akun))
                continue;
            const sisa = a.pagu - a.blokir - (U[a.mak]?.j || 0), names = a.items.map(i => String(i.u).trim());
            const hayA = acNorm([a.mak, a.kompNama, a.roNama, a.kegNama, a.nama, ...names].join(" "));
            if (roF && String(a.roNama).trim() !== roF)
                continue;
            {
                if (toks.length && !toks.every(t => hayA.includes(t)))
                    continue;
                res.push({ v: a.mak, html: `<b>${acHi(a.mak, toks)}</b><span class="d">${esc(names.join("; ") || a.kompNama)}<small>${esc(a.nama)} · ${esc(a.roNama)} · sisa Rp ${rupiah(sisa)}</small></span>`, score: 0 });
            }
        }
        return res.sort((x, y) => x.score - y.score).slice(0, 150);
    }
    if (kind === "rpdsup") { // supplier RPD: tautkan ke RAB (nama) atau Surat Tugas
        const res = [];
        for (const d of [...rabDB].reverse()) {
            const h = acNorm([d.nama, d.ro, "rab"].join(" "));
            if (toks.length && !toks.every(t => h.includes(t)))
                continue;
            res.push({ v: d.nama, key: "rab:" + d._id, html: `<span class="d"><b><span class="tag">RAB</span> ${acHi(d.nama, toks)}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></span>`, score: 0 });
        }
        for (const r of [...records].reverse()) {
            if (res.length > 120)
                break;
            const F = compute(r), nm = String(F.NAMA_PELAKSANA_SPD || "").split(",")[0];
            const h = acNorm([F.NOMOR_ST, nm, F.MAKSUD__TUJUAN, F.TEMPAT_TUJUAN, "st surat tugas"].join(" "));
            if (toks.length && !toks.every(t => h.includes(t)))
                continue;
            res.push({ v: `ST ${F.NOMOR_ST} — ${nm}`, key: "st:" + r._id, html: `<span class="d"><b><span class="tag">ST</span> ${acHi(F.NOMOR_ST, toks)}</b><small>${esc(nm)} · ${esc(String(F.MAKSUD__TUJUAN || "").slice(0, 60))}</small></span>`, score: 0 });
        }
        return res;
    }
    if (kind === "makall") { // semua MAK POK tahun anggaran (Permintaan Revisi: detil baru)
        const res = [];
        for (const a of angPok().akun) {
            const h = acNorm([a.mak, a.nama, a.roNama, a.kompNama, a.kegNama].join(" "));
            if (toks.length && !toks.every(t => h.includes(t)))
                continue;
            res.push({ v: a.mak, html: `<b>${acHi(a.mak, toks)}</b><span class="d">${acHi(a.nama, toks)}<small>${esc(roTitle(a.roNama))} · ${esc(a.kompNama)} · pagu Rp ${rupiah(a.pagu)}</small></span>`, score: 0 });
            if (res.length > 150)
                break;
        }
        return res;
    }
    if (kind === "kam") { // kampung SK Transport: nama / distrik
        const res = [];
        for (const k of kampungDB) {
            const h = acNorm(k.kampung + " " + k.distrik), nm = acNorm(k.kampung), q0 = toks.join(" ");
            if (toks.length && !toks.every(t => h.includes(t)))
                continue;
            res.push({ v: kamLabel(k), html: `<b>${acHi(title(k.kampung), toks)}</b><span class="d">${acHi(title(k.distrik), toks)}<small>Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""}</small></span>`, score: !toks.length ? 1 : nm.startsWith(q0) ? 0 : 1 });
        }
        return res.sort((a, b) => a.score - b.score).slice(0, 60);
    }
    if (kind === "kode") {
        const res = [];
        for (const c of kodeDB.codes) {
            const code = c.k.toLowerCase(), hay = acNorm(c.k + " " + c.k.replace(".", "") + " " + c.d + " " + kodeGroup(c.k));
            if (toks.length && !toks.every(t => hay.includes(t) || code.replace(".", "").includes(t.replace(".", ""))))
                continue;
            const q0 = toks.join(" ");
            const score = !toks.length ? 5 : code === q0 ? 0 : code.startsWith(q0) || code.split(".")[1]?.startsWith(q0) ? 1 : acNorm(c.d).startsWith(q0) ? 2 : 3 + (c.l || 0) * 0.1;
            res.push({ v: c.k, html: `<b>${acHi(c.k, toks)}</b><span class="d">${acHi(c.d, toks)}<small>${esc(kodeGroup(c.k))}</small></span>`, score });
            if (!toks.length && res.length > 80)
                break;
        }
        return res.sort((a, b) => a.score - b.score).slice(0, 60);
    }
    const rk = kind && kind.startsWith("role:") ? kind.slice(5).split("|") : null, holders = rk ? roleHolders(rk) : [];
    const list = rk && holders.length ? holders : pegawai.filter(p => kind === "pel" ? true : kind === "peg" ? !isSystemPeg(p) : !isMitra(p) && !isSystemPeg(p));
    const res = [];
    for (const p of list) {
        const hay = acNorm([p.nama, p.jabatan, p.nip, p.pangkat, p.gol].join(" "));
        if (toks.length && !toks.every(t => hay.includes(t)))
            continue;
        const nm = acNorm(p.nama), q0 = toks.join(" ");
        const score = (isSystemPeg(p) ? -1 : 0) + (!toks.length ? (isMitra(p) ? 2 : 1) : nm.startsWith(q0) ? 0 : nm.includes(q0) ? 1 : 2) + (isMitra(p) ? 0.5 : 0);
        res.push({ v: p.nama, mitra: isMitra(p), html: `<span class="d"><b>${acHi(p.nama, toks)}</b>${(p.roles || []).length ? ` <span class="rlbadge">${esc((p.roles || []).map(r => ROLE_NAME[r] || r).join(" · "))}</span>` : ""}<small>${esc([p.jabatan, p.nip && !/^-|terlampir/i.test(p.nip) ? "NIP " + p.nip : "", [p.pangkat, p.gol].filter(x => x && x !== "-").join(" ")].filter(Boolean).join(" · "))}</small></span>`, score });
    }
    return res.sort((a, b) => a.score - b.score).slice(0, 80);
}
function acRender() {
    const box = $("#acBox"), el = AC.el;
    if (!el)
        return;
    const ac = el.dataset.ac ?? "", rk = ac.startsWith("role:") ? ac.slice(5).split("|") : null;
    const rnote = rk ? (roleHolders(rk).length ? `<div class="hd">Pegawai dengan peran ${esc(rk.map(r => ROLE_NAME[r]).join(" / "))}</div>` : `<div class="hd bad">Belum ada pegawai berperan ${esc(rk.map(r => ROLE_NAME[r]).join(" / "))} — atur di Database → Pegawai</div>`) : "";
    if (!AC.items.length) {
        box.innerHTML = rnote + `<div class="hd">Tidak ada yang cocok</div>`;
    }
    else {
        let lastM = null;
        box.innerHTML = AC.items.map((it, i) => {
            let hd = "";
            if ((["pel", "peg", "off"].includes(ac) || ac.startsWith("role:")) && it.mitra !== lastM) {
                hd = `<div class="hd">${it.mitra ? "Mitra" : "Pegawai"}</div>`;
                lastM = it.mitra;
            }
            return hd + `<div class="it ${i === AC.idx ? "on" : ""}" data-i="${i}" role="option">${it.html}</div>`;
        }).join("");
        if (rnote)
            box.innerHTML = rnote + box.innerHTML.replace(/^<div class="hd">Pegawai<\/div>/, "");
    }
    const r = el.getBoundingClientRect(), w = Math.max(r.width, ["kode", "pokj", "makpj", "makho", "detil", "kam", "makall", "rpdsup"].includes(ac) ? 480 : 320);
    box.style.width = Math.min(w, innerWidth - 16) + "px";
    box.style.left = Math.max(8, Math.min(r.left, innerWidth - Math.min(w, innerWidth - 16) - 8)) + "px";
    const below = innerHeight - r.bottom;
    if (below < 220 && r.top > below) {
        box.style.top = "";
        box.style.bottom = (innerHeight - r.top + 4) + "px";
    }
    else {
        box.style.bottom = "";
        box.style.top = (r.bottom + 4) + "px";
    }
    box.hidden = false;
    const on = box.querySelector(".it.on");
    if (on)
        on.scrollIntoView({ block: "nearest" });
}
function acOpen(el, showAll) { AC.el = el; AC.items = acSource(el.dataset.ac, showAll ? "" : el.value); AC.idx = 0; acRender(); }
function acClose() { $("#acBox").hidden = true; AC.el = null; }
function acPick(i) {
    const it = AC.items[i], el = AC.el;
    if (!it || !el)
        return;
    AC.quiet = true;
    el.value = it.v;
    if (it.key)
        el.dataset.key = it.key;
    if (it.ro && el.dataset.makTarget) {
        const t = $(el.dataset.makTarget); // RO dipilih → MAK: satu-satunya MAK di RO itu, atau dikosongkan bila bukan dari RO ini
        if (t) {
            const nv = it.mak || ((it.maks || []).includes(normMak(t.value)) ? t.value : "");
            if (nv !== t.value) {
                t.value = nv;
                t.dispatchEvent(new Event("input", { bubbles: true }));
                t.dispatchEvent(new Event("change", { bubbles: true }));
            }
            if (!it.mak)
                setTimeout(() => { t.focus(); acOpen(t, true); }, 50);
        }
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    AC.quiet = false;
    acClose();
}
document.addEventListener("focusin", e => { const t = tg(e).closest?.("[data-ac]"); if (t)
    acOpen(t, true);
else if (!tg(e).closest("#acBox"))
    acClose(); });
document.addEventListener("input", e => { if (AC.quiet)
    return; const t = tg(e).closest?.("[data-ac]"); if (t)
    acOpen(t, false); }, true);
document.addEventListener("keydown", e => {
    if (!AC.el || tg(e) !== AC.el || $("#acBox").hidden)
        return;
    if (e.key === "ArrowDown") {
        e.preventDefault();
        AC.idx = Math.min(AC.items.length - 1, AC.idx + 1);
        acRender();
    }
    else if (e.key === "ArrowUp") {
        e.preventDefault();
        AC.idx = Math.max(0, AC.idx - 1);
        acRender();
    }
    else if (e.key === "Enter" && AC.items.length) {
        e.preventDefault();
        e.stopImmediatePropagation();
        acPick(AC.idx);
    }
    else if (e.key === "Escape") {
        acClose();
    }
    else if (e.key === "Tab")
        acClose();
}, true);
$("#acBox").addEventListener("mousedown", e => { e.preventDefault(); const it = tg(e).closest(".it"); if (it)
    acPick(Number(it.dataset.i)); });
document.addEventListener("click", e => { if (AC.el && !tg(e).closest("#acBox") && tg(e) !== AC.el)
    acClose(); });
addEventListener("scroll", e => { if (AC.el && !tg(e).closest?.("#acBox"))
    acRender(); }, true);
addEventListener("resize", () => AC.el && acRender());

/* ---- 92_users.ts ---- */
/** daftar fitur = tombol menu di bilah samping (dibaca sebelum menu dipangkas), kecuali Beranda & Manajemen User */
const FITUR = $$("nav button[data-v]").filter(b => b.dataset.v !== "home" && b.dataset.v !== "users").map(b => ({ v: b.dataset.v || "", n: b.dataset.title || b.querySelector("span")?.textContent || "",
    grp: b.closest(".navgroup")?.querySelector(".grp span")?.textContent || "Lainnya" }));
const fiturNama = (v) => FITUR.find(f => f.v === v)?.n || v;
/* menu dinamis: buang yang tidak boleh dibuka, lalu grup yang jadi kosong */
$$("nav button[data-v]").forEach(b => { if (!can(b.dataset.v || ""))
    b.remove(); });
$$("nav .navgroup").forEach(g => { if (!g.querySelector("button[data-v]"))
    g.remove(); });
$$("[data-go]").forEach(b => { const go = b.dataset.go || ""; if (FITUR.some(f => f.v === go) && !can(go))
    b.remove(); });
$("#suName").textContent = GC_USER.username;
$("#suRole").textContent = GC_USER.role;
async function gcApi(url, method = "GET", body) {
    const r = await fetch(url, { method, headers: body === undefined ? undefined : { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
    if (r.status === 401) {
        gcToLogin();
        throw new Error("Sesi berakhir");
    }
    const j = await r.json().catch(() => ({}));
    if (!r.ok)
        throw new Error(j.error || "HTTP " + r.status);
    return j;
}
$("#suOut").onclick = async () => { if (!confirm(`Keluar dari akun ${GC_USER.username}?`))
    return; try {
    await fetch("api/logout", { method: "POST" });
}
catch (e) { } gcToLogin(); };
/* ---------- ganti password sendiri ---------- */
const dPw = $("#dPw");
$("#suPw").onclick = () => { $("#pwOld").value = $("#pwNew").value = $("#pwNew2").value = ""; dPw.showModal(); $("#pwOld").focus(); };
$("#pwCancel").onclick = () => dPw.close();
$("#pwForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const baru = $("#pwNew").value;
    if (baru.length < 4)
        return toast("Password baru minimal 4 karakter.", "warn");
    if (baru !== $("#pwNew2").value)
        return toast("Ulangan password baru tidak sama.", "warn");
    try {
        await gcApi("api/password", "POST", { lama: $("#pwOld").value, baru });
        dPw.close();
        toast("Password diganti.", "ok");
    }
    catch (x) {
        toast(x.message, "err");
    }
});
/* ---------- Manajemen User (Admin) ---------- */
let usrList = [], usrEdit = null;
async function renderUsers() {
    if (!isAdmin)
        return;
    try {
        usrList = await gcApi("api/users");
    }
    catch (e) {
        toast("Daftar user gagal dimuat: " + e.message, "err");
        return;
    }
    $("#usrBody").innerHTML = usrList.map((u, i) => `<tr data-usr="${esc(u.username)}"><td class="muted">${i + 1}</td><td><b>${esc(u.username)}</b>${u.username.toLowerCase() === GC_USER.username.toLowerCase() ? ` <span class="tag">Anda</span>` : ""}</td>
    <td><span class="tag ${u.role === "Admin" ? "ok" : ""}">${esc(u.role)}</span></td>
    <td>${u.role === "Admin" ? `<span class="muted">Semua fitur</span>` : u.fitur.length ? `<div class="usr-f">${u.fitur.map(f => `<span class="tag">${esc(fiturNama(f))}</span>`).join("")}</div>` : `<span class="muted">Hanya Beranda</span>`}</td>
    <td class="muted" style="font-size:12.5px">${esc(u.diubah || "")}</td>
    <td class="acts"><button class="btn sm" type="button" data-ua="edit">Ubah</button> <button class="btn sm del" type="button" data-ua="del">Hapus</button></td></tr>`).join("");
}
function usrFiturHtml(sel) {
    const grp = [...new Set(FITUR.map(f => f.grp))];
    return grp.map(g => `<fieldset><legend>${esc(g)}</legend>${FITUR.filter(f => f.grp === g).map(f => `<label><input type="checkbox" value="${esc(f.v)}" ${sel.has(f.v) ? "checked" : ""}> ${esc(f.n)}</label>`).join("")}</fieldset>`).join("");
}
function usrRoleSync() {
    const adm = $("#usrRole").value === "Admin";
    $("#usrFitur").classList.toggle("all", adm);
    $("#usrHint").textContent = adm ? "Admin bisa membuka semua fitur dan mengelola user." : "Beranda selalu bisa dibuka. Centang menu lain yang boleh dipakai user ini.";
}
function usrOpen(u) {
    usrEdit = u ? u.username : null;
    $("#usrH").textContent = u ? `Ubah user ${u.username}` : "Tambah user";
    $("#usrName").value = u?.username || "";
    $("#usrName").disabled = !!u;
    $("#usrPass").value = "";
    $("#usrPass").placeholder = u ? "kosongkan bila tidak diganti" : "minimal 4 karakter";
    $("#usrRole").value = u?.role || "User";
    $("#usrFitur").innerHTML = usrFiturHtml(new Set(u?.fitur || []));
    usrRoleSync();
    $("#dUser").showModal();
    (u ? $("#usrPass") : $("#usrName")).focus();
}
$("#usrAdd").onclick = () => usrOpen(null);
$("#usrCancel").onclick = () => $("#dUser").close();
$("#usrRole").onchange = usrRoleSync;
$("#usrAll").onclick = () => $$("#usrFitur input").forEach(c => c.checked = true);
$("#usrNone").onclick = () => $$("#usrFitur input").forEach(c => c.checked = false);
$("#usrForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = $("#usrName").value.trim(), password = $("#usrPass").value, role = $("#usrRole").value, fitur = $$("#usrFitur input:checked").map(c => c.value);
    if (!usrEdit && !/^[A-Za-z0-9._-]{3,32}$/.test(username))
        return toast("Username 3–32 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.", "warn");
    if ((!usrEdit || password) && password.length < 4)
        return toast("Password minimal 4 karakter.", "warn");
    try {
        if (usrEdit)
            await gcApi("api/users/" + encodeURIComponent(usrEdit), "PUT", { role, fitur, password });
        else
            await gcApi("api/users", "POST", { username, password, role, fitur });
        $("#dUser").close();
        toast(usrEdit ? `User ${usrEdit} diperbarui — berlaku saat ia memuat ulang halaman.` : `User ${username} ditambahkan.`, "ok");
        renderUsers();
    }
    catch (x) {
        toast(x.message, "err");
    }
});
$("#usrBody").addEventListener("click", async (e) => {
    const b = tg(e).closest("[data-ua]"), name = b?.closest("[data-usr]")?.dataset.usr, u = usrList.find(x => x.username === name);
    if (!b || !u)
        return;
    if (b.dataset.ua === "edit")
        return usrOpen(u);
    if (!confirm(`Hapus user ${u.username}? Ia langsung tidak bisa masuk lagi.`))
        return;
    try {
        await gcApi("api/users/" + encodeURIComponent(u.username), "DELETE");
        toast(`User ${u.username} dihapus.`, "ok");
        renderUsers();
    }
    catch (x) {
        toast(x.message, "err");
    }
});

/* ---- 95_init.ts ---- */
/* ================= nav & init ================= */
/** true saat tombol kembali/maju browser: show() tidak menambah riwayat */
let _navPop = false;
const grpOf = (g) => ({ head: g.querySelector(".grp"), items: g.querySelector(".grp-items") });
function show(v) {
    if (!can(v)) {
        toast("Anda tidak punya akses ke menu itu. Hubungi Admin untuk membukanya.", "warn");
        v = "home";
    }
    if (v === "users")
        renderUsers();
    $$("nav button[data-v]").forEach(b => b.classList.toggle("on", b.dataset.v === v));
    for (const g of $$("nav .navgroup")) {
        const inG = !!g.querySelector(`[data-v="${v}"]`);
        grpOf(g).head.classList.toggle("has-on", inG);
        if (inG && grpOf(g).items.hidden)
            setGrpOpen(g, true);
    }
    const nbtn = $(`nav button[data-v="${v}"]`), nb = nbtn && nbtn.querySelector("span");
    if (nb)
        $("#pageTitle").textContent = nbtn.dataset.title || nb.textContent;
    const grpL = nbtn?.closest(".navgroup")?.querySelector(".grp span")?.textContent;
    $("#pageSub").textContent = grpL && nb ? `${grpL} › ${nb.textContent}` : "BPS Kabupaten Maybrat";
    if (!_navPop && location.hash !== "#" + v)
        try {
            history.pushState({ v }, "", "#" + v);
        }
        catch (e) { }
    window.scrollTo({ top: 0 });
    document.body.classList.remove("open");
    $$(".view").forEach(s => s.classList.toggle("on", s.id === "v-" + (v === "up" ? "tup" : v)));
    if (v === "mass")
        updateMassInfo();
    if (v === "pok")
        renderPOK();
    if (v === "tpl" && !tplState)
        loadTplEditor();
    if (v === "home")
        renderHome();
    if (v === "honor" && !hoCur)
        renderHonorList();
    if (v === "rpd")
        renderRpd();
    if (v === "tup" || v === "up") {
        if (tupMode !== v)
            tupOpen.clear();
        tupMode = v;
        renderTup();
    }
    if (v === "revisi")
        renderRev();
    if (v === "rab")
        renderRab();
    if (v === "rablist")
        renderRabList();
    if (v === "set")
        renderDefTarif();
    if (v === "nomor") {
        if (!nsIn("tgl").value)
            nsReset();
        renderNsFmt();
        renderSurat();
        nsPreview();
    }
}
$$("nav button[data-v]").forEach(b => b.onclick = () => show(b.dataset.v ?? "home"));
function setGrpOpen(g, open) { grpOf(g).items.hidden = !open; grpOf(g).head.setAttribute("aria-expanded", open ? "true" : "false"); LS.set("st.nav." + g.dataset.grp, open); }
for (const g of $$("nav .navgroup")) {
    grpOf(g).head.onclick = () => setGrpOpen(g, grpOf(g).items.hidden === true);
    setGrpOpen(g, !!LS.get("st.nav." + g.dataset.grp, g.dataset.grp === "st"));
}
const isMobile = () => matchMedia("(max-width:900px)").matches;
if (LS.get("st.sideCollapsed", false))
    document.body.classList.add("collapsed");
$("#burger").onclick = () => {
    if (isMobile())
        document.body.classList.toggle("open");
    else {
        document.body.classList.toggle("collapsed");
        LS.set("st.sideCollapsed", document.body.classList.contains("collapsed"));
    }
};
$("#scrim").onclick = () => document.body.classList.remove("open");
/* ================= POK tab ================= */
let pokOpen = new Set();
function pokSetYear(y0) { const y = String(y0), p = pokGet(y); if (!p)
    return; pokYear = y; pokDB = p; LS.set("st.pokYear", y); _use = null; _kIdx = null; _dataVer++; pokOpen.clear(); renderAll(); toast(`POK aktif: T.A. ${y} — dipakai untuk Surat Tugas & Honor.`); }
function renderPokImpYear() {
    const el = $("#pokImpYear"), cur = el.value, cy = new Date().getFullYear();
    const ys = [...new Set([...pokYears(), ...[cy - 1, cy, cy + 1, cy + 2].map(String)])].sort();
    el.innerHTML = `<option value="">— Pilih tahun POK —</option>` + ys.map(y => `<option value="${y}">T.A. ${y}${pokYearsL.includes(y) ? " (ganti)" : " (baru)"}</option>`).join("");
    el.value = ys.includes(cur) ? cur : "";
    $("#pokImpBtn").classList.toggle("off", !el.value);
}
$("#pokImpYear").addEventListener("change", e => $("#pokImpBtn").classList.toggle("off", !tg(e).value));
$("#pokImpBtn").addEventListener("click", e => { if (!$("#pokImpYear").value) {
    e.preventDefault();
    $("#pokImpYear").focus();
    toast("Pilih dulu tahun POK yang akan diimpor.");
} });
function renderPokYears() {
    renderPokImpYear();
    const cy = String(new Date().getFullYear());
    $("#pokYears").innerHTML = pokYears().map(y => {
        const p0 = pokGet(y), m0 = p0?.meta || {}, on = y === pokYear;
        return `<div class="pyc ${on ? "on" : ""}" data-py="${esc(y)}" title="${on ? "POK aktif" : "Klik untuk menjadikan POK aktif"}"><b>T.A. ${esc(y)}</b>${on ? `<span class="tag ok">aktif</span>` : ""}${y === cy ? `<span class="tag">tahun berjalan</span>` : ""}${m0.draft ? `<span class="tag warn">rancangan</span>` : ""}
      <small>${(p0?.akun || []).length} akun${m0.tanggal ? " · per " + esc(m0.tanggal) : m0.draft ? " · salinan POK " + esc(m0.dasar || "") : ""}</small>${on ? "" : `<button type="button" class="x" data-pydel="${esc(y)}" title="Hapus POK T.A. ${esc(y)}">×</button>`}</div>`;
    }).join("")
        + `<span class="muted" style="font-size:12px;align-self:center">Impor POK tahun lain tidak mengubah POK aktif.</span>`;
}
$("#pokYears").addEventListener("click", e => {
    const del = tg(e).closest("[data-pydel]")?.dataset.pydel;
    if (del) {
        if (!confirm(`Hapus POK T.A. ${del} dari aplikasi?\nRPD/TUP/Revisi tahun ${del} tetap tersimpan.`))
            return;
        pokDrop(del);
        if (typeof angYear !== "undefined" && angYear === del)
            angSetYear(pokYear, true);
        renderPOK();
        toast(`POK T.A. ${del} dihapus.`);
        return;
    }
    const y = tg(e).closest("[data-py]")?.dataset.py;
    if (y && y !== pokYear)
        pokSetYear(y);
});
function renderPOK() {
    renderPokYears();
    const U = usage(), q = $("#qpok").value.trim().toLowerCase(), pj = $("#pokPerjadin").checked;
    const m = pokDB.meta || {};
    $("#pokMeta").textContent = [m.satker, "T.A. " + (m.tahun || pokYear), m.tanggal && "per " + m.tanggal, m.draft && "rancangan (salinan POK " + m.dasar + ")"].filter(Boolean).join(" · ");
    const all = pokDB.akun, perj = all.filter(a => /^5241/.test(a.akun));
    const sum = (arr, f) => arr.reduce((s, a) => s + f(a), 0);
    const used = (a) => U[a.mak]?.j || 0;
    const outside = records.filter(r => r.MAK && !pokMap()[normMak(r.MAK)]).length;
    $("#pokKpi").innerHTML = [
        ["Alokasi (semua akun)", "Rp " + rupiah(m.alokasi || sum(all, a => a.pagu))],
        ["Pagu perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.pagu))],
        ["Blokir perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.blokir))],
        ["Terpakai oleh ST", "Rp " + rupiah(sum(perj, used))],
        ["Sisa perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.pagu - a.blokir - used(a)))],
        ["ST dengan MAK di luar POK", outside + " surat"]
    ].map(([k, v]) => `<div class="kpi"><small>${k}</small><b>${v}</b></div>`).join("");
    const rows = all.filter(a => (!pj || /^5241/.test(a.akun)) && (!q || [a.mak, a.nama, a.roNama, a.kompNama, a.kegNama, ...a.items.map(i => i.u)].join(" ").toLowerCase().includes(q)));
    $("#tPok tbody").innerHTML = rows.map(a => {
        const u = used(a), sisa = a.pagu - a.blokir - u, avail = a.pagu - a.blokir, pct = avail > 0 ? Math.min(100, u / avail * 100) : (u ? 100 : 0);
        const main = `<tr class="pk" data-mak="${esc(a.mak)}"><td style="white-space:nowrap"><b>${esc(a.mak)}</b></td><td>${esc(a.nama)}<div class="muted" style="font-size:12px">${esc(a.roNama)} · ${esc(a.kompNama)}</div></td>
      <td class="num">${rupiah(a.pagu)}</td><td class="num">${a.blokir ? rupiah(a.blokir) : "–"}</td><td class="num">${rupiah(u)}<div class="muted" style="font-size:11px">${U[a.mak]?.n || 0} ST</div></td>
      <td class="num"><b class="${sisa < 0 ? "bad" : ""}">${rupiah(sisa)}</b><div class="bar"><i class="${sisa < 0 ? "over" : ""}" style="width:${pct.toFixed(0)}%"></i></div></td>
      <td><button class="btn sm" data-use="${esc(a.mak)}">Pakai</button></td></tr>`;
        const det = pokOpen.has(a.mak) ? `<tr class="items"><td></td><td colspan="6">${a.items.map(i => `<div>• ${esc(i.u)} — Rp ${rupiah(i.j)}${i.b ? ' <span class="tag warn">blokir</span>' : ""}</div>`).join("")}</td></tr>` : "";
        return main + det;
    }).join("") || `<tr><td colspan="7" class="muted">Tidak ada MAK yang cocok.</td></tr>`;
}
$("#qpok").addEventListener("input", () => renderPOK());
$("#pokPerjadin").addEventListener("change", () => renderPOK());
$("#tPok").addEventListener("click", e => {
    const use = tg(e).dataset.use;
    if (use) {
        form.MAK.value = use;
        refresh();
        show("form");
        showSub("data");
        window.scrollTo(0, 0);
        toast("MAK " + use + " dipakai di Surat Tugas Personal.");
        return;
    }
    const tr = tg(e).closest("tr.pk");
    if (!tr)
        return;
    const k = tr.dataset.mak ?? "";
    pokOpen.has(k) ? pokOpen.delete(k) : pokOpen.add(k);
    renderPOK();
});
/** PDF → baris teks berkolom (spasi meniru posisi x) untuk parsePOK */
async function pdfToLines(buf) {
    if (!pdfjsLib.GlobalWorkerOptions.workerSrc)
        pdfjsLib.GlobalWorkerOptions.workerSrc = "vendor/pdf.worker.min.js";
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise, lines = [];
    for (let p = 1; p <= pdf.numPages; p++) {
        const tc = await (await pdf.getPage(p)).getTextContent();
        const items = tc.items.filter((i) => "str" in i && i.str != null && i.str.trim() !== "").map(i => ({ x: i.transform[4], y: i.transform[5], w: i.width, s: i.str }));
        items.sort((a, b) => b.y - a.y || a.x - b.x);
        const rows = [];
        for (const it of items) {
            const r = rows.find(r => Math.abs(r.y - it.y) <= 2.5);
            if (r)
                r.items.push(it);
            else
                rows.push({ y: it.y, items: [it] });
        }
        rows.sort((a, b) => b.y - a.y);
        const cws = items.filter(i => i.s.trim().length > 2).map(i => i.w / i.s.length).sort((a, b) => a - b);
        const cw = cws.length ? cws[Math.floor(cws.length / 2)] : 4; // median character width on this page
        for (const r of rows) {
            r.items.sort((a, b) => a.x - b.x);
            let out = "", end = null;
            for (const it of r.items) {
                const col = Math.round(it.x / cw);
                if (end == null)
                    out = " ".repeat(Math.max(0, col));
                else {
                    const gap = it.x - end;
                    if (gap > 1.5 * cw)
                        out += " ".repeat(Math.max(2, col - out.length));
                    else if (gap > 0.2 * cw && !/\s$/.test(out) && !/^\s/.test(it.s))
                        out += " ";
                }
                out += it.s;
                end = it.x + it.w;
            }
            lines.push(out);
        }
    }
    return lines;
}
$("#fPok").addEventListener("change", async (e) => {
    const f = tg(e).files?.[0];
    if (!f)
        return;
    try {
        const ySel = $("#pokImpYear").value;
        if (!ySel)
            return toast("Pilih dulu tahun POK yang akan diimpor.");
        toast("Membaca POK…");
        let res;
        if (/\.pdf$/i.test(f.name))
            res = parsePOK(await pdfToLines(new Uint8Array(await f.arrayBuffer())));
        else {
            const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
            res = parsePOKRows(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true, defval: null }));
        }
        if (!res.akun.length)
            throw new Error("tidak ada akun yang terbaca — pastikan file adalah Rincian Kertas Kerja Satker (unduhan Excel SAKTI)");
        if (res.meta.tahun && String(res.meta.tahun) !== ySel && !confirm(`File ini tertulis T.A. ${res.meta.tahun}, tetapi Anda memilih T.A. ${ySel}. Tetap simpan sebagai T.A. ${ySel}?`))
            return;
        res.meta.tahun = ySel;
        res.meta.satker ||= pokDB.meta?.satker || "BPS KABUPATEN MAYBRAT";
        const tot = res.akun.reduce((s, a) => s + a.pagu, 0);
        const check = res.meta.alokasi ? (tot === res.meta.alokasi ? "cocok dengan alokasi" : `⚠ total Rp ${rupiah(tot)} ≠ alokasi Rp ${rupiah(res.meta.alokasi)}`) : "";
        const y = ySel;
        const ada = pokYearsL.includes(y), aktif = y === pokYear;
        const msg = `POK T.A. ${y} terbaca: ${res.akun.length} akun, ${res.akun.reduce((s0, a) => s0 + a.items.length, 0)} detil, total pagu Rp ${rupiah(tot)} ${check}.\nTanggal POK: ${res.meta.tanggal || "-"}\n\n`
            + (aktif ? `Ganti POK T.A. ${y} (POK aktif) dengan file ini?` : ada ? `Ganti POK T.A. ${y} yang tersimpan dengan file ini?\nPOK aktif T.A. ${pokYear} TIDAK berubah.` : `Simpan sebagai POK T.A. ${y}?\nPOK aktif T.A. ${pokYear} TIDAK berubah.`);
        if (!confirm(msg))
            return;
        const oldP = pokGet(y);
        res._v2 = res._v3 = true;
        if (aktif) {
            pokDB = res;
            persist();
        }
        else {
            pokSave(y, res);
            _dataVer++;
        }
        const nMv = typeof angRemap === "function" ? angRemap(y, oldP, res) : 0;
        if (aktif) {
            renderAll();
            toast(`POK T.A. ${y} diperbarui.` + (nMv ? ` ${nMv} nama detil diperbaiki, isian RPD/TUP ikut dipindahkan.` : ""));
        }
        else {
            renderPOK();
            toast(`POK T.A. ${y} disimpan. POK aktif tetap T.A. ${pokYear}.` + (nMv ? ` ${nMv} nama detil diperbaiki, isian RPD/TUP ikut dipindahkan.` : ""));
        }
        if (typeof angYear !== "undefined" && angYear === y) {
            _dataVer++;
            angRefresh();
        }
    }
    catch (err) {
        console.error(err);
        toast("Gagal membaca POK: " + err.message);
    }
    finally {
        tg(e).value = "";
    }
});
function renderAll() { buildLists(); renderList(); renderPeg(); renderKam(); renderTarif(); renderKode(); renderMass(); renderPOK(); }
// migrasi: total transport tidak lagi disimpan terpisah — selalu dihitung dari baris
{
    let n = 0;
    for (const r of records)
        if ("TOTAL_TRANS" in r) {
            delete r.TOTAL_TRANS;
            n++;
        }
    if (n)
        persist();
}
// migrasi: surat Lokal yang baris transportnya masih format lama (tanpa "hari x") dihitung ulang
{
    let n = 0;
    for (const r of records) {
        if (!isLokal(r) || !normChips(r._kampung).length)
            continue;
        const rows = [...Array(MAXTR)].map((_, i) => r["KetTransport_" + (i + 1)] || "");
        if (rows.some(k => /^Biaya Transport Lokal dari /.test(k) && !/\(\d+ hari x /.test(k))) {
            applyKampungToRec(r);
            n++;
        }
    }
    if (n) {
        persist();
        setTimeout(() => toast(`${n} surat Lokal diperbarui: transport lokal sekarang dikali banyak hari.`), 600);
    }
}
// migrasi: transport lokal kampung berlabel Lokal pindah dari baris transport rincian ke Daftar Pengeluaran Riil (2. Uang Transport Lokal).
// Baris dipindahkan apa adanya (nilai tidak dihitung ulang); rincian khusus per anggota ikut dipindah.
{
    let n = 0;
    const split = (rows) => ({ lok: riilFilled(riilRows(rows.filter(([k]) => RIIL_LOK_RE.test(String(k ?? ""))))), rest: rows.filter(([k]) => !RIIL_LOK_RE.test(String(k ?? ""))) });
    for (const r of records) {
        if (!isLokal(r) || r._riilLok)
            continue;
        const rows = [];
        for (let i = 1; i <= MAXTR; i++)
            rows.push([r["KetTransport_" + i] ?? "", r["Nilai" + i] ?? ""]);
        const main = split(rows), po = Object.values(r._perOrang || {}).filter(o => Array.isArray(o.trans));
        if (!main.lok.length && !po.some(o => split(o.trans).lok.length))
            continue;
        for (const o of po) {
            const s = split(o.trans);
            o.riilLok = s.lok;
            o.trans = s.rest;
        }
        for (let i = 1; i <= MAXTR; i++) {
            delete r["KetTransport_" + i];
            delete r["Nilai" + i];
        }
        main.rest.filter(([k, v]) => k !== "" || (v !== "" && v != null)).forEach(([k, v], i) => { if (k !== "")
            r["KetTransport_" + (i + 1)] = k; if (v !== "" && v != null)
            r["Nilai" + (i + 1)] = v; });
        if (main.lok.length)
            r._riilLok = main.lok;
        n++;
    }
    if (n) {
        persist();
        setTimeout(() => toast(`${n} surat Lokal diperbarui: transport lokal sekarang tercatat di Daftar Pengeluaran Riil (jumlah tidak berubah).`), 900);
    }
}
{
    const miss = records.some(r => !r._id);
    if (miss) {
        ensureIds();
        persist();
    }
}
// migrasi: rincian biaya dipisah dari data surat (st.records → st.records + st.rincian)
if (LS.get("st.records", null) != null && LS.get("st.rincian", null) == null)
    persist();
{
    let n = 0;
    for (const r of records)
        if ("SIFAT" in r) {
            delete r.SIFAT;
            n++;
        }
    if (n)
        persist();
}
if (!LS.get("st.rolesInit", false) && !pegawai.some(p => (p.roles || []).length)) {
    const P = pegMap(), add = (c, k) => { const p = P[codeOf(c)]; if (!p || isSystemPeg(p) || isMitra(p))
        return; p.roles = [...new Set([...(p.roles || []), k])]; };
    for (const r of records) {
        add(r.No_PPK, "PPK");
        add(r.No_Bend, "BEND");
        for (const f of ["KD_NAMA_KA_PLT_PLH", "KDSPPD"]) {
            const p = P[codeOf(r[f])];
            if (p)
                add(r[f], /^kepala\b/i.test(String(p.jabatan || "")) ? "KEPALA" : "PLT");
        }
    }
    for (const p of pegawai) {
        const rs = p.roles;
        if (rs)
            p.roles = ROLES.map(([x]) => x).filter(x => rs.includes(x));
    }
    LS.set("st.rolesInit", true);
    persist();
}
if (!LS.get("st.batas1jt", false)) {
    const t = tarifDB.find(t => t.grup === RULES_GRUP && t.nama.startsWith("BATAS TRANSPORT"));
    if (t && num(t.nilai) === 5000000) {
        t.nilai = 1000000;
        persist();
    }
    LS.set("st.batas1jt", true);
}
// migrasi sekali: POK lama (hasil baca PDF) diganti POK Excel bawaan per tahun; isian RPD/TUP/Revisi ikut dipindah ke kunci baru
if (LS.get("st.pokXlsx", 0) < 2 && SEED.pokY) {
    for (const [y, v] of Object.entries(SEED.pokY)) {
        const old = pokGet(y);
        if (old && old.meta?.src === "xlsx" && !(old.meta.tanggal === v.meta.tanggal && (old.meta.seed || 0) < (v.meta.seed || 0)))
            continue; // POK Excel impor sendiri: biarkan
        const nw = clone(v);
        if (old)
            angRemap(y, old, nw);
        pokSave(y, nw);
        if (y === pokYear)
            pokDB = pokGet(y) || pokDB;
    }
    LS.set("st.pokXlsx", 2);
    _use = null;
    _kIdx = null;
    _dataVer++;
}
renderAll();
tplInfo();
newForm();
{
    const h0 = location.hash.slice(1);
    show($(`nav button[data-v="${h0}"]`) && h0 !== "form" ? h0 : "home");
}
window.addEventListener("popstate", () => { const v = location.hash.slice(1) || "home"; if (!$(`nav button[data-v="${v}"]`))
    return; _navPop = true; try {
    show(v);
}
finally {
    _navPop = false;
} });
$("#toast").addEventListener("click", () => $("#toast").classList.remove("on"));
$("#toTop").onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });
window.addEventListener("scroll", debounce(() => $("#toTop").classList.toggle("on", window.scrollY > 700), 80), { passive: true });
fillCommon(Object.keys(massCommon).length ? massCommon : commonFrom(defaults()));
_mY = yrOf(mIn("TGL_TERBIT_ST").value);
for (const k of ["No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD"]) {
    const e = mIn(k);
    if (e && e.value) {
        const c = resolvePeg(e.value);
        if (c)
            e.value = pegLabel(c);
    }
}
massRows.forEach(r => { if (/^\d+\s*—/.test(r.peg || "")) {
    const c = resolvePeg(r.peg);
    if (c)
        r.peg = pegLabel(c);
} });
updateMassInfo();
window.__app = { compute, buildDocx, buildMerged, records: () => records, fillForm, readForm, massRecords };
