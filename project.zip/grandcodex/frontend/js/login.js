"use strict";
/* Halaman login: kirim username & password ke /api/login; bila benar server memasang kuki sesi, lalu buka aplikasi. */
(() => {
  try{ const t = JSON.parse(localStorage.getItem("st.theme") || "null"); if (t === "light" || t === "dark") document.documentElement.dataset.theme = t; }catch(e){}
  const $ = id => document.getElementById(id), err = $("lgErr"), btn = $("lgBtn");
  $("lgShow").onchange = e => { $("lgPass").type = e.target.checked ? "text" : "password"; };
  $("loginForm").onsubmit = async e => {
    e.preventDefault(); err.hidden = true; btn.disabled = true; btn.textContent = "Memeriksa…";
    try{
      const r = await fetch("api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: $("lgUser").value.trim(), password: $("lgPass").value }) });
      const j = await r.json().catch(() => ({}));
      if (r.ok){ location.replace("./" + location.hash); return; }
      err.textContent = j.error || "Gagal masuk (HTTP " + r.status + ")";
    }catch(x){ err.textContent = "Server tidak bisa dihubungi. Periksa sambungan lalu coba lagi."; }
    err.hidden = false; btn.disabled = false; btn.textContent = "Masuk"; $("lgPass").select();
  };
})();
