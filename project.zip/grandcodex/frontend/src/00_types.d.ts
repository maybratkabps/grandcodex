/* Deklarasi tipe global GrandCodex: pustaka pihak ketiga (dimuat sebagai <script>) dan model data. */

/* ---------- pustaka ---------- */
declare const XLSX: typeof import("xlsx");
declare const JSZip: typeof import("jszip");
type JSZipT = InstanceType<typeof JSZip>;
type XlsxWB = import("xlsx").WorkBook;
type XlsxWS = import("xlsx").WorkSheet;
declare const docx: typeof import("docx-preview");
declare const pdfjsLib: typeof import("pdfjs-dist/types/src/pdf");
type PdfTextItem = import("pdfjs-dist/types/src/display/api").TextItem;

/* ---------- dari back end ---------- */
/* api/seed.js: data bawaan & template .docx (base64) dari database/seed/ */
declare const SEED: Seed;
/** template bawaan Surat Tugas (ST, SPD, Lampiran SPPD, Lampiran ST) */
declare const TEMPLATE_DEFAULT: string;
/** template bawaan Rincian Biaya (kuitansi, pengeluaran riil, rincian, pernyataan) */
declare const TEMPLATE_RB_DEFAULT: string;
declare const TUPREQ_TPL: string;
/* api/state.js: isi basis data saat halaman dimuat (kunci → teks JSON) */
declare const __GC_STATE: Record<string, string>;
/** user yang sedang login (disisipkan server lewat api/state.js); fitur = kode menu yang boleh dibuka */
interface GcUser { username: string; role: "Admin" | "User"; fitur: string[]; dibuat?: string; diubah?: string }
declare const __GC_USER: GcUser;

/* ---------- model data ---------- */
type RoleCode = "KEPALA" | "PLT" | "PPK" | "BEND";
interface Pegawai {
  kode: string; nama: string; nip?: string; pangkat?: string; gol?: string; jabatan?: string;
  roles?: RoleCode[];
}
/** Nilai isian surat tugas: teks dari form/Excel, angka hasil hitung, atau struktur bantu (_kampung, _pelExcl …). */
type FieldVal = string | number | boolean | null | undefined | object;
/** Satu surat tugas. Kunci mengikuti nama kolom template .docx / Excel (dinamis), jadi diindeks dengan string. */
interface StRecord {
  _id?: string; NO?: string | number; NoLengkap?: string; TGL_TERBIT_ST?: string; TGL_PERGI?: string; TGL_PULANG?: string;
  MAK?: string; kegiatan?: string; MAKSUD__TUJUAN?: string; TEMPAT_TUJUAN?: string; KD_NAMA_SPD?: string;
  [field: string]: any;   // kolom template dinamis (± 90 nama kolom berbeda dari .docx & Excel impor)
}
/** lokal = boleh untuk surat tugas Lokal (bila belum diatur: dari keterangan "Lokal") */
interface Kampung { distrik: string; kampung: string; tarif: number; ket?: string; lokal?: boolean }
interface Tarif { grup: string; nama: string; nilai: number | string }
interface KodeDB { groups: Record<string, string>; codes: { k: string; l?: number; d: string }[] }
interface PokItem { u: string; j: number; b: boolean; v?: number; s?: string; h?: number }
interface PokAkun {
  mak: string; keg: string; kegNama: string; ro: string; roNama: string; komp: string; kompNama: string; sub: string;
  akun: string; nama: string; pagu: number; blokir: number; sd?: string; items: PokItem[];
}
interface PokMeta { tahun?: string; satker?: string; alokasi?: number; tanggal?: string; src?: string; seed?: number; draft?: boolean; dasar?: string }
interface Pok { meta: PokMeta; akun: PokAkun[]; _v2?: boolean; _v3?: boolean }
interface Seed { pegawai: Pegawai[]; records: StRecord[]; kampung: Kampung[]; tarif: Tarif[]; kode: KodeDB; pok: Pok; pokY?: Record<string, Pok> }
/** Detil POK yang dipakai RPD/TUP/Revisi. */
interface Detil { key: string; a: PokAkun; u: string; j: number; blokir: boolean; v?: number; s?: string; h?: number }
type ToastType = "ok" | "warn" | "err" | "info";

/* ---------- tambahan pada objek bawaan ---------- */
interface Window { __app?: unknown }
interface HTMLInputElement { _dmy?: HTMLInputElement; _native?: HTMLInputElement }
interface HTMLElement { _h?: ReturnType<typeof setTimeout> }

/* ---------- Anggaran: RPD · TUP · Revisi ---------- */
/** RPD: kunci detil → 12 nilai bulanan */
type RpdDB = Record<string, number[]>;
/** keterangan RPD: kunci detil → 4 teks (per triwulan) */
type RpdKetDB = Record<string, string[]>;
interface TupPajak { dpp: number; ppnOn: boolean; ppnT: number; ppn: number; pphJ: string; pphT: number; pph: number }
/** det = detil POK tujuan (di MAK terpilih) yang menerima realisasi baris ini */
interface TupFields { nota?: string; spby?: string; kui?: string; sup?: string; mak?: string; det?: string; catat?: boolean; pajak?: boolean; pj?: TupPajak; [k: string]: string | boolean | TupPajak | undefined }
interface TupDup { id: string; src: string }
/** finalisasi TUP: RPD bulan itu diganti realisasi TUP; prev = nilai RPD sebelumnya (untuk dibatalkan) */
interface TupFinal { tgl: string; prev: Record<string, number>; total: number }
interface TupMonth {
  val: Record<string, number>; add: string[]; excl: string[]; tgl: string; ket: string;
  nama: Record<string, string>; kt: Record<string, string>; f: Record<string, TupFields>; dup: TupDup[]; fin?: TupFinal;
}
/** TUP per bulan (0–11); data lama bisa belum punya semua bagian → dilengkapi tupOf() */
type TupDB = Record<number, Partial<TupMonth>>;
/** supplier RPD per detil per BULAN (12 isian). t = teks tercatat; s = supplier yang dipilih / diketik;
    refs = tautan "st:<id>" / "rab:<id>" (boleh banyak); ref = tautan tunggal format lama */
interface RpdSup { t: string; ref?: string; refs?: string[]; s?: string[] }
type RpdSupDB = Record<string, RpdSup[]>;
/** RPD awal yang dikunci per bulan: total & nilai per detil (tanpa akun 51 — dasar TUP) */
interface RpdFin { tgl: string; total: number; val: Record<string, number> }
type RpdFinDB = Record<number, RpdFin>;
type RevStatus = "Diajukan" | "Disetujui" | "Ditolak";
interface Revisi {
  _id: string; tgl: string; key: string; mak: string; akun: string; namaLama: string; jmlLama: number;
  namaBaru: string; vol: number; sat: string; harga: number; jmlBaru: number; ket: string; status: RevStatus;
  /** "rab" = dibuat otomatis karena kebutuhan RAB melebihi pagu detil */
  auto?: "rab";
  /** true = usulan detil BARU di MAK ini (belum ada di POK); key = "baru:<MAK>#<id>" */
  baru?: boolean;
  /** nilai detil di POK saat permintaan dibuat (sebelum revisi) */
  volLama?: number; satLama?: string; hargaLama?: number;
  /** revisi untuk aplikasi: SAKTI, BOS, atau keduanya */
  sistem?: "SAKTI" | "BOS" | "SAKTI+BOS";
}
/* ---------- RAB (Rencana Anggaran Biaya) — menu Rencana PPIS ---------- */
type RabSec = "honor" | "bahan" | "pel" | "pemut" | "lokal" | "remote" | "sup" | "luar";
/** baris biaya non-perjalanan: orang × volume × harga, dibebankan ke satu detil POK */
interface RabLine { id: string; sec: RabSec; uraian: string; org: number; vol: number; sat: string; harga: number; key: string }
type RabPeran = "Pengawas" | "Pendata" | "Pelaksana";
/** satu perjalanan dinas satu petugas (biaya dihitung dengan aturan Surat Tugas: SK transport, uang harian, inap) */
interface RabTrip {
  id: string; sec: RabSec; peran: RabPeran; c: string; nama: string; pml: string; kam: string[]; kamBad: string[];
  jenis: "Lokal" | "Remote" | "Translok+Uhar"; pergi: string; hari: number; hotel: number; hotelTarif: number; tr: number; key: string; ket: string;
  /** lintasan & biaya transport yang disunting sendiri: [keterangan, nilai]; kosong = otomatis dari SK Transport */
  rute?: [string, number][];
  /** jadwal pengawas hasil "Sesuaikan jadwal pengawas": kampung (kunci) per hari; kosong = kampung dibagi rata sepanjang hari tugas */
  plan?: string[];
}
interface RabDoc {
  _id: string; nama: string; ro: string; bln: number; uh: number | null; inap: number | null; dibuat: string;
  items: RabLine[]; trips: RabTrip[];
  /** bagian RAB yang dipilih pengguna (kosong / tidak ada = semua, data lama) */
  secs?: RabSec[];
  /** bulan selesai pelaksanaan (lintas bulan s.d. setahun); kosong = sama dengan bln */
  blnTo?: number;
  /** jumlah yang pernah dimasukkan ke RPD (agar bisa diperbarui tanpa dobel) */
  rpdIn?: { key: string; m: number; v: number }[];
}
/** hasil autocomplete */
/** pilihan kotak pencarian; mitra → judul kelompok; ro/mak/maks → pilih RO lalu MAK */
interface AcItem { v: string; key?: string; html: string; score: number; mitra?: boolean; ro?: string; mak?: string | null; maks?: string[] }
