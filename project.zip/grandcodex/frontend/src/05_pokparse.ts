/* POK (Rincian Kertas Kerja Satker) text lines → [{mak, ro, roNama, komp, kompNama, sub, akun, nama, pagu, blokir, items:[{u,j,b}]}] */
/* nama RO bersih: buang sisa nama KRO ("Data dan Informasi Publik[Base Line]") / volume KRO yang ikut terbaca */
function cleanRoNama(n: string | null | undefined): string {
  let t = String(n || "").replace(/\s+/g, " ").trim();
  if (/\[Base Line\]/i.test(t)) t = t.replace(/^.*\[Base Line\]\s*/i, "");
  t = t.replace(/^(Data dan Informasi Publik|Peta, Data|dokumen,?)\s+/i, "").trim();
  const c = t.match(/^[^:]{3,100}?\s+:\s*(\S.*)$/); if (c) t = c[1].trim();   // "Data dan Informasi Lintas Bidang : LAYANAN STATISTIK TERPADU" → nama RO saja
  return t || String(n || "").trim();
}
/** Butir detil saat dibaca dari PDF (sementara menyimpan akun induk & tanda volume terpisah). */
interface PokItemParse extends PokItem { _ak?: PokAkun; _wantVol?: boolean }
interface BufLine { t: string; star: boolean }
function parsePOK(lines: string[]): Pok {
  const amt = (s: string): number => Number(String(s).replace(/,/g, "")) || 0;
  const out: Record<string, PokAkun> = {}, order: string[] = [], meta: PokMeta = {};
  let buf: BufLine[] = [], need = 0, lastIt: PokItemParse | null = null, roDone = false, keg = "", kegNama = "", ro = "", roNama = "", komp = "", kompNama = "", sub = "", akun: PokAkun | null = null, pending = "";
  const SKIP = /RINCIAN KERTAS KERJA|^\s*KEMEN|^\s*UNIT (ORG|KERJA)|Halaman\s*:|PROGRAM\/\s*KEGIATAN|^\s*KODE\s*$|SUBKOMP\/\s*DETIL|^\s*\(1\)|^\s*Catatan|^\s*\d\.\s*[UP*]\s*=|^\s*nip\s/i;
  /* Nama detil yang panjang ditulis beberapa baris, rata tengah terhadap baris angka:
     jumlah baris di atas baris angka = jumlah baris di bawahnya. Teks di antara dua baris angka
     dibagi: "need" baris pertama milik detil sebelumnya, sisanya awal nama detil berikutnya. */
  const give = (it: PokItemParse | null, xs: BufLine[]): void => { if (!it || !xs.length) return; it.u = [it.u, ...xs.map(x => x.t)].filter(Boolean).join(" "); if (xs.some(x => x.star) && !it.b){ it.b = true; if (it._ak) it._ak.blokir += it.j; } };
  const closeAk = () => { if (lastIt){ give(lastIt, buf.splice(0, need)); } if (buf.length) pending = buf.map(x => x.t).join(" "); buf = []; need = 0; lastIt = null; };
  for (const raw of lines){
    const l = String(raw).replace(/\s+$/, "");
    if (!l.trim()) continue;
    let m: RegExpMatchArray | null;
    if ((m = l.match(/^\s*ALOKASI\s+Rp\.?\s*([\d,]+)/))){ meta.alokasi = amt(m[1]); continue; }
    if ((m = l.match(/T\.A\.\s*(\d{4})/))){ meta.tahun = m[1]; continue; }
    if ((m = l.match(/^\s*UNIT KERJA\s+\((\d+)\)\s+(.*)$/))){ meta.satker = m[2].trim(); continue; }
    if ((m = l.match(/^\s*Maybrat,\s*(.+)$/i)) || (m = l.match(/^\s{40,}([A-Z][a-z]+,\s*\d{1,2}\s+\w+\s+\d{4})\s*$/))){ meta.tanggal = m[1].trim(); continue; }
    if (SKIP.test(l)) continue;
    if (akun && /\s{2,}(\d{1,3}(,\d{3})+|0)(\s|$)/.test(l) && (/^\s*(\d{4}(\.[A-Z]{3}(\.[A-Z0-9]{3})?)?|\d{6}|\d{3}|[A-Z]{1,2})(\s{2,}|\s*$)/.test(l) || /^\s*\d{3}\.\d{2}\.[A-Z]{2}\s/.test(l))) closeAk();
    if ((m = l.match(/^\s*(\d{4}\.[A-Z]{3}\.[A-Z0-9]{3})(?:\s{2,}(.*))?$/))){
      ro = m[1]; let nm = (m[2] || "").split(/\s{2,}/)[0].trim(); if (/^[\d.,]+$/.test(nm)) nm = "";
      roNama = (nm || pending).trim(); roDone = false; komp = sub = ""; akun = null; pending = ""; continue;
    }
    if ((m = l.match(/^\s*(\d{4}\.[A-Z]{3})(\s|$)/))){ akun = null; pending = ""; ro = ""; roNama = ""; continue; }
    if ((m = l.match(/^\s*\d{3}\.\d{2}\.[A-Z]{2}\s/))){ continue; }
    if ((m = l.match(/^\s*(\d{4})\s{2,}(\S.*)$/))){ keg = m[1]; kegNama = m[2].split(/\s{2,}/)[0]; akun = null; continue; }
    if ((m = l.match(/^\s*(\d{6})\s{2,}(\S.*?)\s{2,}([\d,]+)/))){
      const mak = `${ro}.${komp}.${sub}.${m[1]}`;
      if (!out[mak]){ out[mak] = { mak, keg, kegNama, ro, roNama, komp, kompNama, sub, akun: m[1], nama: m[2].trim(), pagu: 0, blokir: 0, items: [] }; order.push(mak); }
      akun = out[mak]; akun.pagu += amt(m[3]); const sd = l.match(/\s{2,}(RM|PNBP|PNP|PLN|HLN|BLU|SBSN|PDN|HDN|RMP|BLUP)\s*$/); if (sd && !akun.sd) akun.sd = sd[1]; continue;
    }
    if ((m = l.match(/^\s*(\d{3})\s{2,}(\S.*?)\s{2,}([\d,]+)/))){ komp = m[1]; kompNama = m[2].trim(); sub = ""; akun = null; continue; }
    if ((m = l.match(/^\s*(\d{3})\s{2,}([\d,]{3,})(\s|$)/))){ komp = m[1]; kompNama = pending || ""; pending = ""; sub = ""; akun = null; continue; }
    if ((m = l.match(/^\s*([A-Z]{1,2})\s{2,}(\S.*?)\s{2,}([\d,]+)/))){ sub = m[1]; akun = null; continue; }
    if ((m = l.match(/^\s*([A-Z]{1,2})\s{2,}([\d,]{3,})(\s|$)/))){ sub = m[1]; akun = null; pending = ""; continue; }
    if (!akun){
      const t = l.trim().split(/\s{2,}/)[0];
      if (/^Lokasi/.test(t)){ pending = ""; continue; }
      if (/^\(KPPN/.test(t) || /^[\d.,]+(\s|$)/.test(t)) continue;
      if (ro && !komp && roNama && !pending && !roDone) { roNama += " " + t; roDone = true; } else pending = (pending ? pending + " " : "") + t;
      continue;
    }
    // detail lines under an akun: "... harga  jumlah [*]"
    if ((m = l.match(/^(.*?)\s{2,}([\d,]{3,})\s{2,}([\d,]{3,})(\s+\*)?\s*$/))){
      const body = m[1].replace(/^\s*-(\s|$)/, " "), vs = body.match(/(?:^\s*|\s{2,})([\d.]+)\s+(\S.*?)\s*$/);
      const name = (vs ? body.slice(0, vs.index) : body).replace(/^\s*-\s*/, "").trim();
      const it: PokItemParse = { u: "", j: amt(m[3]), b: !!m[4] }; Object.defineProperty(it, "_ak", { value: akun, enumerable: false });
      if (vs){ it.v = Number(vs[1]) || 0; it.s = vs[2].trim(); } it.h = amt(m[2]);
      give(lastIt, buf.splice(0, need)); const pre = buf; buf = [];
      it.u = [...pre.map(x => x.t), name].filter(Boolean).join(" "); if (pre.some(x => x.star)) it.b = true;
      need = pre.length; lastIt = it; if (!vs && !name) it._wantVol = true;
      akun.items.push(it); if (it.b) akun.blokir += it.j; continue;
    }
    if (!/^\s*-/.test(l) && (/^\s*\S.*?\s{2,}[\d.]+\s+\S.*?\s{2,}[\d,]{3,}\s*$/.test(l) || /^\s*[A-Za-z].*?\s{2,}\d+\.\d\s+[A-Za-z][\w,.\- ]*$/.test(l))){   // header line of the next RO (name + volume + total)
      closeAk(); pending = l.trim().split(/\s{2,}/)[0]; akun = null; continue;
    }
    const li: PokItemParse | null = lastIt;
    if (li && li._wantVol && (m = l.match(/^\s*-\s+(.*?)\s{2,}([\d.]+)\s+(\S.*?)\s*$/))){   // baris angka terpisah dari baris nama+volume
      const lastIt = li; delete lastIt._wantVol; lastIt.v = Number(m[2]) || 0; lastIt.s = m[3].trim(); if (m[1].trim()) lastIt.u = [lastIt.u, m[1].trim()].filter(Boolean).join(" "); continue;
    }
    if (/^\s{70,}\S/.test(l)) continue;   // tanda tangan / catatan kaki halaman terakhir
    if (!/^\s*\(KPPN/.test(l)){   // potongan nama detil (di atas / di bawah baris angka)
      const t = l.replace(/^\s*-\s*/, "").replace(/\s{2,}[\d.]+\s+\S+.*$/, "").replace(/\s+\*\s*$/, "").trim();
      if (t && !/^[\d.]+\s+\S+$/.test(t)) buf.push({ t, star: /\*\s*$/.test(l) });
    }
  }
  closeAk();
  for (const k of order) out[k].roNama = cleanRoNama(out[k].roNama);
  return { meta, akun: order.map(k => out[k]) };
}
