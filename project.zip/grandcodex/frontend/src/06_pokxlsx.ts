/* POK format Excel (Rincian Kertas Kerja Satker, unduhan SAKTI .xlsx) → { meta, akun:[...] } — sama dengan parsePOK */
/** Sel lembar kerja dari XLSX.utils.sheet_to_json({ header: 1, raw: true }). */
type XCell = string | number | boolean | null | undefined;
function parsePOKRows(rows: XCell[][]): Pok {
  const S = (v: XCell): string => v == null ? "" : String(v).trim();
  const isNum = (v: XCell): boolean => typeof v === "number" || (typeof v === "string" && /^-?[\d.,]+$/.test(v.trim()) && /\d/.test(v));
  const N = (v: XCell): number => typeof v === "number" ? v : Number(String(v).replace(/,/g, "")) || 0;
  const out: Record<string, PokAkun> = {}, order: string[] = [], meta: PokMeta = { src: "xlsx" };
  let prevCode = "", keg = "", kegNama = "", ro = "", roNama = "", roRaw = "", komp = "", kompNama = "", sub = "", akun: PokAkun | null = null, last: "ro" | "keg" | "akun" | null = null, alokasi = 0;
  for (const r of rows){
    if (!r || !r.length) continue;
    const c0 = S(r[0]), d = S(r[3]);
    const nums = r.slice(6).map((v, i): [XCell, number] => [v, i + 6]).filter(([v]) => isNum(v) && !(typeof v === "string" && /^\d$/.test(v.trim())));
    const amt = nums.length ? N(nums[nums.length - 1][0]) : 0;
    const tgl = r.map(S).find(x => /^[A-Z][a-z]+,\s*\d{1,2}\s+\w+\s+\d{4}$/.test(x)); if (tgl && !c0){ meta.tanggal = tgl.replace(/^[^,]+,\s*/, ""); continue; }
    if (c0 && c0 === prevCode && !amt && d){                                                        // kode sama diulang = lanjutan nama baris sebelumnya
      if (last === "ro"){ roRaw = (roRaw + " " + d).replace(/\s+/g, " ").trim(); roNama = cleanRoNama(roRaw); for (const k of order) if (out[k].ro === ro) out[k].roNama = roNama; }
      else if (last === "keg") kegNama = (kegNama + " " + d).replace(/\s+/g, " ");
      else if (akun && akun.akun === c0) akun.nama = (akun.nama + " " + d).replace(/\s+/g, " ");
      else if (c0 === komp) kompNama = (kompNama + " " + d).replace(/\s+/g, " ");
      continue;
    }
    if (c0) prevCode = c0;
    if (c0){
      last = null;
      if (/^\d{3}\.\d{2}\.[A-Z]{2}$/.test(c0)){ alokasi += amt; continue; }                       // program
      if (/^\d{4}$/.test(c0)){ keg = c0; kegNama = d; last = "keg"; akun = null; continue; }        // kegiatan
      if (/^\d{4}\.[A-Z]{3}$/.test(c0)){ akun = null; continue; }                                   // KRO
      if (/^\d{4}\.[A-Z]{3}\.[A-Z0-9]{3}$/.test(c0)){ ro = c0; roRaw = d; roNama = cleanRoNama(d); last = "ro"; komp = sub = ""; akun = null; continue; }
      if (/^\d{6}$/.test(c0)){ last = "akun";
        const mak = `${ro}.${komp}.${sub}.${c0}`;
        if (!out[mak]){ out[mak] = { mak, keg, kegNama, ro, roNama, komp, kompNama, sub, akun: c0, nama: d, pagu: 0, blokir: 0, items: [] }; order.push(mak); }
        akun = out[mak]; akun.pagu += amt; const sd = r.map(S).find(x => /^(RM|PNBP|PNP|PLN|HLN|BLU|SBSN|PDN|HDN|RMP|BLUP)$/.test(x)); if (sd && !akun.sd) akun.sd = sd; continue;
      }
      if (/^\d{3}$/.test(c0)){ komp = c0; kompNama = d; sub = ""; akun = null; continue; }               // komponen
      if (/^[A-Z]{1,2}$/.test(c0)){ sub = c0; akun = null; continue; }                                 // sub komponen
      continue;
    }
    if (d === "-" && akun){                                                                            // detil
      const u = S(r[4]).replace(/\s+/g, " "), vs = S(r[6]).match(/^([\d.,]+)\s*(.*)$/);
      const it: PokItem = { u, j: amt, b: r.some(v => S(v) === "*"), h: nums.length > 1 ? N(nums[0][0]) : amt };
      if (vs){ it.v = Number(vs[1].replace(/,/g, "")) || 0; it.s = vs[2].trim(); }
      akun.items.push(it); if (it.b) akun.blokir += it.j; continue;
    }
    if (d && !/^\(KPPN|^Lokasi/i.test(d) && !r.slice(4).some(v => S(v))){                            // lanjutan nama (kegiatan/RO)
      if (last === "keg") kegNama = (kegNama + " " + d).replace(/\s+/g, " ");
      else if (last === "ro"){ roRaw = (roRaw + " " + d).replace(/\s+/g, " ").trim(); roNama = cleanRoNama(roRaw); for (const k of order) if (out[k].ro === ro) out[k].roNama = roNama; }
    }
  }
  if (alokasi) meta.alokasi = alokasi;
  return { meta, akun: order.map(k => out[k]) };
}
