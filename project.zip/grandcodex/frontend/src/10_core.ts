"use strict";
/* ================= storage & state ================= */
/* Data aplikasi disimpan di basis data lewat back end (/api/kv). Isi awalnya dimuat serentak oleh
   <script src="api/state.js"> (__GC_STATE: kunci → teks JSON), jadi pembacaan tetap sinkron; setiap
   perubahan dikirim ke server di latar belakang, berurutan, dan diulang bila gagal.
   Tampilan (tema, ukuran huruf, bilah samping) tetap per-browser di localStorage. */
const LOCAL_KEY = /^st\.(theme|scheme|fsize|font|light|padx|maxw|sideCollapsed|nav\..*)$/;
/* ---------- user yang login & hak akses menu ---------- */
const GC_USER: GcUser = __GC_USER, isAdmin = GC_USER.role === "Admin";
/** boleh membuka menu ini? Beranda selalu boleh; Manajemen User khusus Admin; Admin boleh semuanya */
const can = (v: string): boolean => v === "home" || isAdmin || (v !== "users" && GC_USER.fitur.includes(v));
/** sesi habis / keluar → kembali ke halaman login */
let gcLeaving = false;
function gcToLogin(): void { if (gcLeaving) return; gcLeaving = true; location.href = "login.html" + location.hash; }
const Remote = (() => {
  const cache: Record<string, string> = __GC_STATE;
  const pending = new Map<string, string | null>();   // kunci → teks JSON terbaru (null = hapus)
  let busy = false, failed = false;
  async function flush(): Promise<void> {
    if (busy) return; busy = true;
    while (pending.size){
      const [k, v] = pending.entries().next().value as [string, string | null]; pending.delete(k);
      try{
        const r = await fetch("api/kv/" + encodeURIComponent(k), v === null ? { method: "DELETE" } : { method: "PUT", headers: { "Content-Type": "application/json" }, body: v });
        if (r.status === 401){ pending.clear(); busy = false; alert("Sesi login sudah berakhir. Perubahan terakhir belum tersimpan — silakan masuk lagi."); gcToLogin(); return; }
        if (!r.ok) throw new Error("HTTP " + r.status);
        if (failed){ failed = false; toast("Tersambung lagi — perubahan sudah tersimpan ke server.", "ok"); }
      }catch(e){
        if (!pending.has(k)) pending.set(k, v);   // belum ada nilai yang lebih baru → antre ulang
        if (!failed){ failed = true; toast("Gagal menyimpan ke server: " + (e as Error).message + ". Akan dicoba lagi otomatis.", "err"); }
        busy = false; setTimeout(flush, 4000); return;
      }
    }
    busy = false;
  }
  addEventListener("beforeunload", e => { if (!gcLeaving && (pending.size || busy)) e.preventDefault(); });   // masih ada yang belum terkirim
  return {
    get: (k: string): string | undefined => cache[k],
    set(k: string, v: string): void { if (cache[k] === v) return; cache[k] = v; pending.set(k, v); void flush(); },
    del(k: string): void { if (!(k in cache)) return; delete cache[k]; pending.set(k, null); void flush(); }
  };
})();
const LS = {
  get<T = unknown>(k: string, d: T): T { try{ const v = LOCAL_KEY.test(k) ? localStorage.getItem(k) : Remote.get(k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
  set(k: string, v: unknown): boolean {
    try{ const s = JSON.stringify(v); if (LOCAL_KEY.test(k)) localStorage.setItem(k, s); else Remote.set(k, s); return true; }
    catch(e){ toast("Gagal menyimpan: " + (e as Error).message, "err"); return false; }
  },
  del(k: string): void { try{ if (LOCAL_KEY.test(k)) localStorage.removeItem(k); else Remote.del(k); }catch(e){} }
};
const clone = <T>(x: T): T => JSON.parse(JSON.stringify(x));
let pegawai: Pegawai[] = LS.get<Pegawai[] | null>("st.pegawai", null) || clone(SEED.pegawai);
/* Surat tugas disimpan dalam dua dokumen: st.records = data surat, st.rincian = rincian biaya tiap surat ({ _id: kolom biaya }).
   Di memori keduanya tetap satu rekaman per surat. Data lama (semuanya di st.records) tetap terbaca dan dipisah saat disimpan. */
const BIAYA_KEY = /^(LAMA_INAP|TDK_INAP_HOTEL|LAMA_UH|NILAI_UH|TOTAL_TRANS|TGL_KUI|No_Bend|HOTEL_TEMPAT|LAMA_HOTEL|TARIF_HOTEL|KetTransport_\d+|Nilai\d+|_perOrang|_riilLok|_riilBdr|_hotel2|_noBiaya|_pelExcl|_pelUH)$/;
function loadRecords(): StRecord[] {
  const rs = LS.get<StRecord[] | null>("st.records", null); if (!rs) return clone(SEED.records);
  const rb = LS.get<Record<string, StRecord>>("st.rincian", {});
  for (const r of rs){ const b = r._id ? rb[r._id] : null; if (b) Object.assign(r, b); }
  return rs;
}
function saveRecords(): boolean {
  const st: StRecord[] = [], rb: Record<string, StRecord> = {};
  for (const r of records){
    const a: StRecord = {}, b: StRecord = {};
    for (const k of Object.keys(r)) (r._id && BIAYA_KEY.test(k) ? b : a)[k] = r[k];
    st.push(a); if (r._id && Object.keys(b).length) rb[r._id] = b;
  }
  return LS.set("st.rincian", rb) && LS.set("st.records", st);
}
let records: StRecord[] = loadRecords();
const APP_VERSION = "2026.11.25";
interface TemplateFile { name: string; b64: string; kind?: "st" | "rb" }
let template: TemplateFile | null = LS.get<TemplateFile | null>("st.template", null);
let templateRB: TemplateFile | null = LS.get<TemplateFile | null>("st.templateRB", null);
let kampungDB: Kampung[] = LS.get<Kampung[] | null>("st.kampung", null) || clone(SEED.kampung);
let tarifDB: Tarif[] = LS.get<Tarif[] | null>("st.tarif", null) || clone(SEED.tarif);
let kodeDB: KodeDB = LS.get<KodeDB | null>("st.kode", null) || clone(SEED.kode);
let massRows: StRecord[] = LS.get<StRecord[] | null>("st.massRows", null) || [];
let massCommon: StRecord = LS.get<StRecord | null>("st.massCommon", null) || {};
/* POK disimpan per tahun anggaran: st.pok.<tahun>; daftar tahun di st.pokYears; tahun aktif (dipakai ST/Honor) di st.pokYear */
const pokKey = (y: string): string => "st.pok." + y, pokStore: Record<string, Pok | null> = {};
let pokYearsL: string[] = LS.get<string[] | null>("st.pokYears", null) || [];
if (!Array.isArray(pokYearsL) || !pokYearsL.length){ const old = LS.get<Pok | null>("st.pok", null); pokYearsL = [];
  if (old){ const y0 = String(old.meta?.tahun || new Date().getFullYear()); pokStore[y0] = old; LS.set(pokKey(y0), old); pokYearsL.push(y0); LS.del("st.pok"); }
  else { for (const [y, v] of Object.entries(SEED.pokY || { [SEED.pok.meta?.tahun || "2026"]: SEED.pok })){ pokStore[y] = clone(v); LS.set(pokKey(y), pokStore[y]); pokYearsL.push(y); } LS.set("st.pokXlsx", 2); }
  pokYearsL.sort(); LS.set("st.pokYears", pokYearsL); }
const pokGet = (y: string): Pok | null => pokStore[y] || (pokStore[y] = LS.get<Pok | null>(pokKey(y), null));
const pokYears = (): string[] => [...pokYearsL].sort();
function pokSave(y: string | number, data: Pok): void { y = String(y); pokStore[y] = data; LS.set(pokKey(y), data); if (!pokYearsL.includes(y)){ pokYearsL.push(y); pokYearsL.sort(); LS.set("st.pokYears", pokYearsL); } }
function pokDrop(y: string | number): void { y = String(y); delete pokStore[y]; LS.del(pokKey(y)); pokYearsL = pokYearsL.filter(x => x !== y); LS.set("st.pokYears", pokYearsL); }
let pokYear = String(LS.get("st.pokYear", ""));
if (!pokYearsL.includes(pokYear)) pokYear = pokYearsL.includes(String(new Date().getFullYear())) ? String(new Date().getFullYear()) : pokYears().at(-1) ?? String(new Date().getFullYear());
let pokDB: Pok = pokGet(pokYear) || clone(SEED.pok);
function pokEnrich(p0: Pok | null, y: string): void {   // POK lama (sebelum volume/harga dibaca): lengkapi dari POK bawaan bila itemnya sama; rapikan nama RO
  if (!p0 || p0._v3) return; const S: Record<string, PokAkun> = {}; for (const a of SEED.pok.akun){ S[a.mak] = a; }
  for (const a of p0.akun){ a.roNama = cleanRoNama(a.roNama); const b = S[a.mak]; if (b && !a.sd) a.sd = b.sd;
    if (b) a.items.forEach(it => { if (it.h != null) return; const q = b.items.find(x => x.u === it.u && x.j === it.j); if (q){ it.v = q.v; it.s = q.s; it.h = q.h; } }); }
  p0._v2 = p0._v3 = true; LS.set(pokKey(y), p0);
}
for (const y of pokYears()) pokEnrich(pokGet(y), y);
const RULES_GRUP = "ATURAN TRANSPORT 2026";
const minLintasMobil = () => rule("LINTASAN MOBIL") || 500000;   // minimal Biaya Lintasan Mobil — diatur di Pengaturan (bawaan Rp 500.000)
const RULE_DEFAULTS: [string, number][] = [["LINTASAN ANTAR KAMPUNG", 150000], ["LINTASAN MOBIL (TRANSPORT JAUH)", 500000], ["INAP MOBIL PER MALAM", 250000], ["BATAS TRANSPORT JAUH (LEBIH DARI)", 1000000]];
for (const [n, v] of RULE_DEFAULTS) if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n)) tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v });
const rule = (n: string): number => { const t = tarifDB.find(t => t.grup === RULES_GRUP && t.nama.startsWith(n)); return t ? num(t.nilai) : 0; };
let _use: Record<string, { j: number; n: number }> | null = null;   // cache: MAK → {j, n}
let editingId: string | null = null;
/** kampung tujuan terpilih di formulir: kunci "distrik|kampung" + pulang-pergi */
interface Chip { k: string; pp: boolean }
let chips: Chip[] = [];
/** isian formulir: pengeluaran riil transport lokal / mobil bandara, dan hotel tambahan */
let riilLok: RiilRow[] = [], riilBdr: RiilRow[] = [], hotel2: HotelX[] = [];
/** rincian biaya per anggota: { kodePegawai: { LAMA_UH, NILAI_UH, LAMA_INAP, TDK_INAP_HOTEL, trans:[[ket, nilai]…] } } */
type PerOrang = Record<string, StRecord>;
let perOrang: PerOrang = {};
const poOpen = new Set<string>();
let members: string[] = [];   // [kode pegawai]
/* tiap surat punya _id internal; nomor urut (NO) cukup unik per TAHUN tanggal terbit */
let _idSeq = 0;
/** akses kolom lewat nama dinamis (data-f, data-h …) — satu titik cast, bukan any tersebar */
const dyn = <T extends object>(o: T) => o as unknown as Record<string, unknown>;
const newId = () => "r" + Date.now().toString(36) + (++_idSeq).toString(36);
const ensureIds = (list: StRecord[] = records): void => { for (const r of list) if (!r._id) r._id = newId(); };
const stYear = (r: StRecord): number | null => { let d = parseTgl(r.TGL_TERBIT_ST); if (d) return d.getFullYear();
  const m = String(r.NoLengkap || "").match(/\/((?:19|20)\d\d)\s*$/); if (m) return +m[1];
  d = parseTgl(r.TGL_PERGI); if (d) return d.getFullYear(); const m2 = String(r.TGL_PERGI || "").match(/\b((?:19|20)\d\d)\b/); return m2 ? +m2[1] : null; };
const yrOf = (t: unknown): number | null => { const d = parseTgl(t); return d ? d.getFullYear() : null; };
/* No. urut surat tugas boleh berakhiran huruf (504A). Kunci unik = angka tanpa nol di depan + akhiran huruf besar:
   "504", "0504" → "504";  "504A", "504 a" → "504A"  (504 dan 504A adalah dua nomor berbeda). */
const noNorm = (n: unknown): string => String(n ?? "").trim().toUpperCase().replace(/\s+/g, "");
const noKey = (n: unknown): string => { const t = noNorm(n), m = t.match(/^0*(\d+)(.*)$/); return m ? m[1] + m[2] : t; };
const noNum = (n: unknown): number => parseInt(String(n ?? "").trim(), 10) || 0;
const recKey = (r: StRecord): string => (stYear(r) ?? "") + "|" + noKey(r.NO);
const byYearNo = (a: StRecord, b: StRecord): number => (stYear(a) || 0) - (stYear(b) || 0) || noNum(a.NO) - noNum(b.NO) || noKey(a.NO).localeCompare(noKey(b.NO));
const persist = () => { ensureIds(); LS.set("st.pegawai", pegawai); saveRecords(); LS.set("st.kampung", kampungDB); LS.set("st.tarif", tarifDB); LS.set("st.kode", kodeDB); pokStore[pokYear] = pokDB; LS.set(pokKey(pokYear), pokDB); _use = null; _kIdx = null; _dataVer++; };
let _dataVer = 0;
/* cache hasil compute per surat — dibuang otomatis tiap data berubah (_dataVer) */
const _cc = new WeakMap<StRecord, { v: number; F: StRecord; hay: string | null }>();
function computeC(r: StRecord): StRecord { const e = _cc.get(r); if (e && e.v === _dataVer) return e.F; const F = compute(r); _cc.set(r, { v: _dataVer, F, hay: null }); return F; }
function hayOf(r: StRecord): string { const F = computeC(r), e = _cc.get(r)!; if (e.hay == null) e.hay = [r.NO, F.NOMOR_ST, F.NAMA_PELAKSANA_SPD, F.MAKSUD__TUJUAN, F.TEMPAT_TUJUAN, F.kegiatan, F.TGL_TERBIT_ST, F.NAMALAMPIRAN_1, lampOf(r).map((c: string) => pegMap()[c]?.nama || "").join(" ")].join(" ").toLowerCase(); return e.hay; }
const debounce = <A extends unknown[]>(fn: (...a: A) => void, ms: number) => { let t: ReturnType<typeof setTimeout> | undefined; return (...a: A): void => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const persistMass = () => { LS.set("st.massRows", massRows); LS.set("st.massCommon", massCommon); };

/* ================= helpers ================= */
/* Pencari elemen bertipe. Bawaan HTMLInputElement karena hampir semua elemen yang dicari adalah kolom isian;
   elemen lain diminta eksplisit, mis. $<HTMLSelectElement>("#x"). Elemen dijamin ada di halaman (markup statis). */
const $ = <T extends HTMLElement = HTMLInputElement>(s: string): T => document.querySelector(s) as T;
const $$ = <T extends HTMLElement = HTMLInputElement>(s: string): T[] => [...document.querySelectorAll<T>(s)];
/** target event delegasi (klik/ketik di dalam tabel & daftar) sebagai elemen isian */
const tg = (e: Event): HTMLInputElement => e.target as HTMLInputElement;
const BULAN = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const fmtTgl = (iso: string): string => { const [y,m,d] = iso.split("-").map(Number); return `${d} ${BULAN[m-1]} ${y}`; };
const fmtDate = (d: Date): string => `${d.getDate()} ${BULAN[d.getMonth()]} ${d.getFullYear()}`;
const today = () => fmtDate(new Date());
/** tanggal pulang = tanggal pergi + (lama − 1) hari */
const tglPulang = (pergi: unknown, lama: unknown): string => { const a = parseTgl(pergi), n = Math.max(1, Math.round(num(lama)) || 1); return a ? fmtDate(new Date(a.getFullYear(), a.getMonth(), a.getDate() + n - 1)) : ""; };
const parseTgl = (s: unknown): Date | null => { const m = String(s||"").trim().match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/); if(!m) return null;
  const mi = BULAN.findIndex(b => b.toLowerCase() === m[2].toLowerCase()); return mi < 0 ? null : new Date(+m[3], mi, +m[1]); };
const dayDiff = (a: Date, b: Date): number => Math.round((+b - +a) / 864e5) + 1;
const num = (v: unknown): number => { if (v === "" || v == null) return 0; let t = String(v).trim(); if (/^-?\d{1,3}(\.\d{3})+$/.test(t.replace(/^Rp\s*/i, ""))) t = t.replace(/\./g, ""); const n = Number(t.replace(/[^\d.-]/g, "")); return isFinite(n) ? n : 0; };
/* ===== Kolom nominal (Rp) diberi pemisah ribuan otomatis: 1020000 → 1.020.000 =====
   Kolom angka uang (step 1000) diubah menjadi kolom teks bertanda data-money. Tampilan memakai titik,
   tetapi .value tetap memberi angka polos ("1020000"), sehingga semua perhitungan lama tidak berubah. */
const isoToDmy = (v: unknown): string => { const m = String(v || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}` : ""; };
const fmtRibuan = (v: unknown): string => { let t = String(v ?? "").replace(/[^\d-]/g, ""); const neg = t.startsWith("-"); t = t.replace(/-/g, "").replace(/^0+(?=\d)/, ""); return t ? (neg ? "-" : "") + t.replace(/\B(?=(\d{3})+(?!\d))/g, ".") : (neg ? "-" : ""); };
(() => {
  const D0 = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!;
  /** akses nilai asli (tanpa pemisah ribuan) */
  const D = { get: D0.get as (this: HTMLInputElement) => string, set: D0.set as (this: HTMLInputElement, v: string) => void, enumerable: D0.enumerable };
  const norm = (v: unknown): string => { if (typeof v === "number") return isFinite(v) ? String(Math.round(v)) : ""; let t = String(v ?? "").trim(); if (/^-?\d+[.,]\d{1,2}$/.test(t)) t = String(Math.round(+t.replace(",", "."))); return t; };
  Object.defineProperty(HTMLInputElement.prototype, "value", { configurable: true, enumerable: D.enumerable,
    get(this: HTMLInputElement){ const v = D.get.call(this); return this.hasAttribute("data-money") ? v.replace(/\./g, "") : v; },
    set(this: HTMLInputElement, v: unknown){ D.set.call(this, this.hasAttribute("data-money") ? fmtRibuan(norm(v)) : String(v ?? "")); if (this._dmy) this._dmy.value = isoToDmy(D.get.call(this)); } });
  const SEL = 'input[type="number"][step="1000"]';
  const conv = (el: HTMLInputElement): void => { if (el.hasAttribute("data-money")) return; const v = D.get.call(el); el.type = "text"; el.inputMode = "numeric"; el.autocomplete = "off"; el.setAttribute("data-money", ""); D.set.call(el, fmtRibuan(norm(v))); };
  const scan = (root: Node): void => { if (!(root instanceof Element)) return; if (root.matches(SEL)) conv(root as HTMLInputElement); root.querySelectorAll<HTMLInputElement>(SEL).forEach(conv); };
  scan(document.body);
  new MutationObserver(ms => { for (const m of ms) for (const n of m.addedNodes) scan(n); }).observe(document.body, { childList: true, subtree: true });
  /* ===== Kolom tanggal selalu DD/MM/YYYY (tidak tergantung bahasa browser) =====
     input[type=date] asli disembunyikan (tetap dipakai kode & kalender); yang terlihat kolom teks DD/MM/YYYY + tombol kalender. */
  const DSEL = 'input[type="date"]';
  const skipDate = (el: HTMLInputElement): boolean => !! el.closest<HTMLInputElement>(".row") || el.matches("[data-for],[data-hfor],[data-nsfor],[data-mfor],[data-kd]");
  const dmyToIso = (t: string): string | null => { const m = String(t || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); if (!m) return null; const d = +m[1], mo = +m[2], y = +m[3], dt = new Date(y, mo - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}` : null; };
  /** buka kalender bawaan browser (cadangan: fokus + klik) */
  const openPick = (el: HTMLInputElement): void => { if (el.disabled) return; try{ el.showPicker(); }catch(err){ el.focus(); el.click(); } };
  const fire = (el: HTMLInputElement): void => { el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
  const dconv = (el: HTMLInputElement): void => { if (el._dmy || skipDate(el)) return;
    const w = document.createElement("span"); w.className = "dmy"; const t = document.createElement("input"); t.type = "text"; t.className = "dmy-t"; t.inputMode = "numeric"; t.placeholder = "DD/MM/YYYY"; t.maxLength = 10; t.autocomplete = "off";
    if (el.getAttribute("aria-label")) t.setAttribute("aria-label", (el.getAttribute("aria-label") ?? "") + " (DD/MM/YYYY)"); if (el.title) t.title = el.title; if (el.id) t.dataset.dmyFor = el.id;
    const bt = document.createElement("button"); bt.type = "button"; bt.className = "dmy-b"; bt.tabIndex = -1; bt.title = "Pilih dari kalender"; bt.setAttribute("aria-label", "Pilih dari kalender");
    bt.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>`;
    const hadFocus = document.activeElement === el; el.parentNode?.insertBefore(w, el); w.append(t, bt, el); el.classList.add("dmy-n"); el.tabIndex = -1; el._dmy = t; t._native = el;
    t.value = isoToDmy(D.get.call(el)); t.readOnly = true; t.classList.add("tgl-ro"); if (el.disabled){ t.disabled = true; bt.disabled = true; } t.title = (el.title ? el.title + " — " : "") + "klik untuk memilih dari kalender";
    bt.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); openPick(el); });
    t.addEventListener("click", () => openPick(el));
    t.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown"){ e.preventDefault(); openPick(el); }
      else if ((e.key === "Backspace" || e.key === "Delete") && D.get.call(el) && !el.required){ e.preventDefault(); D.set.call(el, ""); t.value = ""; fire(el); } });
    el.addEventListener("input", () => { const v = isoToDmy(D.get.call(el)); if (t.value !== v && document.activeElement !== t) t.value = v; });
    el.addEventListener("change", () => { t.value = isoToDmy(D.get.call(el)); t.classList.remove("bad"); });
    t.addEventListener("input", e => { e.stopPropagation();
      let dg = t.value.replace(/\D/g, "").slice(0, 8); const f = dg.length > 4 ? `${dg.slice(0, 2)}/${dg.slice(2, 4)}/${dg.slice(4)}` : dg.length > 2 ? `${dg.slice(0, 2)}/${dg.slice(2)}` : dg;
      if (f !== t.value){ const end = t.selectionStart === t.value.length; t.value = f; if (end) t.setSelectionRange(f.length, f.length); }
      const iso = dmyToIso(t.value); t.classList.toggle("bad", t.value.length === 10 && !iso);
      if (iso && iso !== D.get.call(el)){ D.set.call(el, iso); fire(el); }
      else if (!t.value && D.get.call(el)){ D.set.call(el, ""); fire(el); } }, true);
    t.addEventListener("change", e => e.stopPropagation(), true);
    t.addEventListener("blur", () => { if (t.value && !dmyToIso(t.value)){ toast("Format tanggal DD/MM/YYYY, mis. 05/01/2027.", "warn"); t.value = isoToDmy(D.get.call(el)); t.classList.remove("bad"); } });
    if (hadFocus) t.focus();
  };
  /* kolom teks tanggal ("7 November 2026") berpasangan dengan kalender kecil di sebelahnya (.row): teks hanya-baca, klik → kalender */
  const pconv = (el: HTMLInputElement): void => {
    if (el.dataset.tglp) return; const t = el.parentElement?.querySelector<HTMLInputElement>('input:not([type="date"])'); if (!t) return; el.dataset.tglp = "1";
    const own = el.hasAttribute("data-tglfor");   // kalender dibuat otomatis untuk kolom data-tgl → isi teks sendiri
    if (own) el.addEventListener("change", () => { const v = D.get.call(el); if (!v) return; t.value = fmtTgl(v); t.dispatchEvent(new Event("input", { bubbles: true })); t.dispatchEvent(new Event("change", { bubbles: true })); });
    t.readOnly = true; t.classList.add("tgl-ro"); if (el.disabled) t.disabled = true; if (!t.title) t.title = "Klik untuk memilih dari kalender"; if (!t.placeholder) t.placeholder = "Pilih dari kalender";
    const open = (): void => { const d = parseTgl(t.value); if (d) D.set.call(el, `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`); openPick(el); };
    t.addEventListener("click", open);
    t.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown"){ e.preventDefault(); open(); }
      else if ((e.key === "Backspace" || e.key === "Delete") && t.value){ e.preventDefault(); t.value = ""; t.dispatchEvent(new Event("input", { bubbles: true })); t.dispatchEvent(new Event("change", { bubbles: true })); } });
  };
  /* kolom teks tanggal tanpa kalender (data-tgl) → beri kalender di sebelahnya */
  const tconv = (t: HTMLInputElement): void => {
    if (t.dataset.tglc) return; t.dataset.tglc = "1";
    const r = document.createElement("div"); r.className = "row"; t.parentNode?.insertBefore(r, t);
    const n = document.createElement("input"); n.type = "date"; n.setAttribute("data-tglfor", ""); n.title = "Pilih tanggal"; n.tabIndex = -1; r.append(t, n); pconv(n);
  };
  const dscan = (root: Node): void => { if (!(root instanceof Element)) return;
    const all = [...(root.matches("input[data-tgl]") ? [root as HTMLInputElement] : []), ...root.querySelectorAll<HTMLInputElement>("input[data-tgl]")]; all.forEach(tconv);
    const ds = [...(root.matches(DSEL) ? [root as HTMLInputElement] : []), ...root.querySelectorAll<HTMLInputElement>(DSEL)];
    for (const el of ds){ if (skipDate(el)) pconv(el); else dconv(el); } };
  dscan(document.body);
  new MutationObserver(ms => { for (const m of ms) for (const n of m.addedNodes) dscan(n); }).observe(document.body, { childList: true, subtree: true });
  document.addEventListener("input", e => { const el = tg(e); if (!el.hasAttribute || !el.hasAttribute("data-money")) return;
    const raw = D.get.call(el), pos = el.selectionStart ?? raw.length, before = raw.slice(0, pos).replace(/\D/g, "").length, f = fmtRibuan(raw);
    if (f === raw) return; D.set.call(el, f); let i = 0, c = 0; while (i < f.length && c < before){ if (/\d/.test(f[i])) c++; i++; } try{ el.setSelectionRange(i, i); }catch(err){} }, true);
})();
const rupiah = (n: number): string => Math.round(n).toLocaleString("id-ID");
const ESC_MAP: Record<string, string> = {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"};
const esc = (s: unknown): string => String(s ?? "").replace(/[&<>"]/g, c => ESC_MAP[c] ?? c);
const title = (s: unknown): string => String(s ?? "").toLowerCase().replace(/(^|[\s\-'(\/])([a-z])/g, (_m: string, a: string, b: string) => a + b.toUpperCase());
function toast(msg: unknown, type?: ToastType): void {
  const t = $("#toast"), m = String(msg ?? "");
  type ||= /gagal|error|tidak valid|tidak bisa/i.test(m) ? "err"
    : /^(pilih|isi\b|lengkapi|harap|mohon|belum|tidak ada|⚠|tanggal .* tidak|nomor .* sudah)/i.test(m) || /melebihi|bentrok|konflik|masih kosong/i.test(m) ? "warn"
    : /disimpan|diperbarui|berhasil|diekspor|diimpor|dihapus|ditambahkan|dipulihkan|disalin|diunduh|tersimpan|dikembalikan|dibuat|dipakai|dibersihkan|diganti|ditandai|diubah ke|diterapkan|✓/i.test(m) ? "ok" : "info";
  const ic = ({ ok: "✓", warn: "!", err: "✕", info: "i" } satisfies Record<ToastType, string>)[type];
  t.className = "toast on " + type; t.innerHTML = `<span class="ti">${ic}</span><span class="tm"></span>`; t.querySelector(".tm")!.textContent = m;
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("on"), Math.min(8000, 2600 + m.length * 35));
}
function terbilang(n0: unknown): string {
  const n = Math.floor(Math.abs(num(n0)));
  const s = ["","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan","sepuluh","sebelas"];
  const t = (x: number): string => x < 12 ? s[x] : x < 20 ? t(x-10)+" belas" : x < 100 ? t(Math.floor(x/10))+" puluh "+t(x%10)
    : x < 200 ? "seratus "+t(x-100) : x < 1000 ? t(Math.floor(x/100))+" ratus "+t(x%100)
    : x < 2000 ? "seribu "+t(x-1000) : x < 1e6 ? t(Math.floor(x/1000))+" ribu "+t(x%1000)
    : x < 1e9 ? t(Math.floor(x/1e6))+" juta "+t(x%1e6) : x < 1e12 ? t(Math.floor(x/1e9))+" miliar "+t(x%1e9)
    : t(Math.floor(x/1e12))+" triliun "+t(x%1e12);
  if (n === 0) return "Nol";
  return t(n).replace(/\s+/g," ").trim().replace(/\b\w/g, c => c.toUpperCase());
}
const pegMap = (): Record<string, Pegawai> => Object.fromEntries(pegawai.map(p => [String(p.kode), p]));
const codeOf = (v: unknown): string => { const m = String(v ?? "").trim().match(/^(\d+)(\s|$|—)/); return m ? m[1] : String(v ?? "").trim(); };
const normName = (s: unknown): string => String(s || "").toLowerCase().replace(/,.*$/, "").replace(/[^a-z\s]/g, " ").replace(/\s+/g, " ").trim();
function resolvePeg(text: unknown): string | null {         // kode / "kode — nama" / nama → kode or null
  const t = String(text ?? "").trim(); if (!t) return null;
  const P = pegMap(), c = codeOf(t); if (P[c]) return c;
  const lq = t.toLowerCase();
  let hit = pegawai.find(p => p.nama.toLowerCase() === lq) || pegawai.find(p => normName(p.nama) === normName(t));
  if (!hit){ const hs = pegawai.filter(p => p.nama.toLowerCase().includes(lq) || normName(p.nama).includes(normName(t))); if (hs.length === 1) hit = hs[0]; }
  return hit ? String(hit.kode) : null;
}
function splitPeople(s: unknown): string[] {
  const toks = String(s || "").split(/[;\n]/).flatMap(x => x.split(",")).map(t => t.trim()).filter(Boolean), out: string[] = [];
  for (const t of toks){ if (out.length && !resolvePeg(t) && /^(s\.|s\s|a\.|m\.|sh\b|se\b|sst|ss\b|dr|ir\b|amd|skm|spd)/i.test(t)) out[out.length-1] += ", " + t; else out.push(t); }
  return out;
}
const pegLabel = (c: string): string => { const p = pegMap()[c]; return p ? p.nama : String(c ?? ""); };
const isPegName = (v: unknown): boolean => { const t = String(v || "").trim(); return !!t && pegawai.some(p => p.nama === t); };

/* kampung & tarif */
const kKey = (k: Kampung): string => k.distrik + "|" + k.kampung;
const kamByKey = (): Record<string, Kampung> => Object.fromEntries(kampungDB.map(k => [kKey(k), k]));
/** kampung berlabel Lokal (kolom Lokal di Tarif Transport; bawaan dari keterangan "Lokal") */
const kamLokal = (k: Kampung): boolean => k.lokal ?? /lokal/i.test(k.ket ?? "");
/** kampung non-Lokal pada surat Lokal → pesan galat (null bila sah) */
function lokalErr(r: StRecord): string | null {
  if (!isLokal(r)) return null; const M = kamByKey(), bad = normChips(r._kampung).map(c => M[c.k]).filter((k): k is Kampung => !!k && !kamLokal(k));
  return bad.length ? `Surat tugas Lokal tidak bisa dipilih: kampung ${bad.map(k => title(k.kampung)).join(", ")} bukan kampung Lokal. Ganti jenis ke Remote, atau beri label Lokal di Database › Tarif Transport.` : null;
}
const kamLabel = (k: Kampung): string => `${title(k.kampung)} — ${title(k.distrik)} · Rp ${rupiah(k.tarif)}${k.ket ? " · " + k.ket : ""}${kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? " · Lokal" : ""}`;
const MAXTR = 30, TR_BASE = 12;   // baris transport: maksimal 30, 12 baris tampil di formulir & template
const AUTO_RE = /^(Transport (PP )?Kabupaten–Kampung |Biaya [Ll]intasan |Biaya [Ii]nap [Mm]obil |Biaya Transport (Lokal |Mobil )?dari )/;
const isLokal = (r: StRecord): boolean => String(r.JENIS || "").toLowerCase() === "lokal";
const isPelatihan = (r: StRecord): boolean => String(r.JENIS || "").toLowerCase() === "pelatihan";
/* Translok+Uhar: transport dihitung cara Lokal (tarif SK × hari) + uang harian boleh diisi; tanpa inap & hotel */
const JEN_TU = "Translok+Uhar";
const isTransUhar = (r: StRecord): boolean => String(r.JENIS || "").toLowerCase() === "translok+uhar";
const trLokal = (r: StRecord): boolean => isLokal(r) || isTransUhar(r);         // transport memakai aturan Lokal
const noUH = (r: StRecord): boolean => isLokal(r) || isPelatihan(r);          // uang harian = 0
const noInap = (r: StRecord): boolean => noUH(r) || isTransUhar(r);            // inap & hotel = 0
const formNoUH = (): boolean => ["Lokal", "Pelatihan"].includes(form.JENIS.value);
const formNoInap = (): boolean => formNoUH() || form.JENIS.value === JEN_TU;
const formTrLokal = (): boolean => form.JENIS.value === "Lokal" || form.JENIS.value === JEN_TU;
const jenisOf = (v: unknown): string | null => { const t = String(v ?? "").trim(); return /^trans/i.test(t) ? JEN_TU : /^lok/i.test(t) ? "Lokal" : /^rem/i.test(t) ? "Remote" : /^pel/i.test(t) ? "Pelatihan" : null; };
/* Daftar Pengeluaran Riil (tanpa bukti): baris [keterangan, nilai] untuk 2. Uang Transport Lokal (r._riilLok) dan 3. Uang Transport Mobil Bandara (r._riilBdr) */
type RiilRow = [string, number | string];
const riilRows = (v: unknown): RiilRow[] => Array.isArray(v) ? v.filter((x): x is unknown[] => Array.isArray(x)).map((x): RiilRow => [String(x[0] ?? ""), x[1] === "" || x[1] == null ? "" : num(x[1])]) : [];
const riilFilled = (rows: RiilRow[]): RiilRow[] => rows.filter(([k, v]) => k.trim() !== "" || v !== "");
const RIIL_LOK_RE = /^Biaya Transport Lokal dari /;
/* hotel / penginapan dengan bukti selain yang pertama (r._hotel2): t = tempat, l = malam, n = tarif per malam */
interface HotelX { t: string; l: number; n: number }
const hotelX = (r: StRecord): HotelX[] => Array.isArray(r._hotel2) ? (r._hotel2 as Record<string, unknown>[]).filter(h => h && typeof h === "object").map(h => ({ t: String(h.t ?? "").trim(), l: num(h.l), n: num(h.n) })) : [];
const hotelXN = (r: StRecord): number => hotelX(r).reduce((s, h) => s + h.l, 0);
const kamText = (k: Kampung, pp: boolean): string => `Transport Kabupaten–Kampung ${title(k.kampung)} (${pp ? "PP" : "sekali jalan"})`;
const kamValue = (k: Kampung, pp: boolean): number => pp ? k.tarif : Math.round(k.tarif / 2);
const normChips = (a: unknown): Chip[] => (Array.isArray(a) ? a : []).map((x: string | { k: string; pp?: boolean }) => typeof x === "string" ? { k: x, pp: true } : { k: x.k, pp: x.pp !== false });
interface KIdx { src: Kampung[]; n: number; label: Map<string, Kampung>; name: Map<string, Kampung>; loose: Map<string, Kampung> }
let _kIdx: KIdx | null = null;
function kIdx(): KIdx {
  if (_kIdx && _kIdx.src === kampungDB && _kIdx.n === kampungDB.length) return _kIdx;
  const label = new Map<string, Kampung>(), name = new Map<string, Kampung>(), loose = new Map<string, Kampung>();
  for (const k of kampungDB){
    label.set(kamLabel(k), k);
    const n = k.kampung.toLowerCase(); if (!name.has(n)) name.set(n, k);
    const l = n.replace(/[^a-z]/g, ""); if (!loose.has(l)) loose.set(l, k);
  }
  return _kIdx = { src: kampungDB, n: kampungDB.length, label, name, loose };
}
function findKampung(text: unknown): Kampung | null {
  const raw = String(text || "").trim(), q = raw.replace(/^(kampung|kp\.?|kelurahan)\s+/i, "").trim(); if (!q) return null;
  const I = kIdx(), lq = q.toLowerCase().replace(/\s+/g, " ");
  return I.label.get(raw) || I.name.get(lq) || I.loose.get(lq.replace(/[^a-z]/g, "")) || null;
}
function parseKampungList(text: unknown): { found: Kampung[]; unknown: string[] } {
  const parts = String(text || "").split(/,|;|\bdan\b|&/i).map(s => s.trim()).filter(Boolean);
  const found: Kampung[] = [], unknown: string[] = [];
  for (const p of parts){ const k = findKampung(p); if (k){ if (!found.includes(k)) found.push(k); } else unknown.push(p); }
  return { found, unknown };
}
/* Deteksi kampung dari teks yang ditempel / diketik bebas, mis.
   "Kampung Fiane, Isme dan Semu", "Kp. Framu - Distrik Ayamaru", "Pendataan di Kampung Kambuskato serta Isusu",
   atau daftar per baris. Urutan kemunculan = urutan rute. */
let _kNames: { src: Kampung[]; n: number; list: [string, Kampung][] } | null = null;
function kampungNameIndex(): [string, Kampung][] {
  if (_kNames && _kNames.src === kampungDB && _kNames.n === kampungDB.length) return _kNames.list;
  const seen = new Map<string, Kampung>();
  for (const k of kampungDB){ const nm = acNorm(k.kampung).replace(/['’]/g, "").replace(/\s+/g, " ").trim(); if (nm && !seen.has(nm)) seen.set(nm, k); }
  const list = [...seen.entries()].sort((a, b) => b[0].length - a[0].length);   // nama terpanjang dulu (mis. "kambuskato utara" sebelum "kambuskato")
  _kNames = { src: kampungDB, n: kampungDB.length, list };
  return list;
}
function detectKampung(text: unknown): { found: Kampung[]; unknown: string[] } {
  let t = " " + acNorm(text).replace(/['’]/g, "").replace(/[\n\r\t]+/g, ", ") + " ";
  t = t.replace(/\(([^)]*)\)/g, " , $1 , ");
  t = t.replace(/\bdistrik\s+[a-z ]+?(?=,|;|\.|$| dan | serta )/g, " , ");       // buang "Distrik …"
  t = t.replace(/[^a-z0-9]+/g, " ");
  const hits: { start: number; end: number; k: Kampung }[] = [];
  for (const [nm, k] of kampungNameIndex()){
    const re = new RegExp("(^| )" + nm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?= |$)", "g");
    let m: RegExpExecArray | null;
    while ((m = re.exec(t))){
      const start = m.index + m[1].length, end = start + nm.length;
      if (hits.some(h => start < h.end && end > h.start)) continue;     // sudah tertutup nama yang lebih panjang
      hits.push({ start, end, k });
    }
  }
  hits.sort((a, b) => a.start - b.start);
  const found: Kampung[] = []; for (const h of hits) if (!found.includes(h.k)) found.push(h.k);
  // potongan teks yang tidak dikenali (untuk info), abaikan kata umum
  let rest = t; for (const h of [...hits].sort((a, b) => b.start - a.start)) rest = rest.slice(0, h.start) + " | " + rest.slice(h.end);
  const STOP = /^(kampung|kp|kel|kelurahan|desa|dan|serta|di|ke|dari|ke|kabupaten|kab|maybrat|lokasi|tujuan|pendataan|wilayah|sekitar|kota|dsb|dll|yang)$/;
  const unknown = rest.split("|").map(x => x.trim().split(" ").filter(w => w && !STOP.test(w) && !/^\d+$/.test(w)).join(" ")).filter(x => x.length > 2);
  return { found, unknown };
}
const tujuanText = (list: Kampung[]): string => { const n = list.map(k => title(k.kampung)); if (!n.length) return "";
  return "Kampung " + (n.length < 3 ? n.join(" dan ") : n.slice(0, -1).join(", ") + ", dan " + n[n.length - 1]); };
function otherTransRef(): [string, number | string][] {
  const m: [string, number | string][] = [];
  for (const t of tarifDB){
    const g = t.grup.toUpperCase();
    if (g.startsWith("MOBIL BANDARA")) m.push(["Mobil bandara " + title(t.nama), t.nilai]);
    else if (g.startsWith("MOBIL")) m.push([/SEWA/i.test(t.nama) ? "Sewa mobil " + title(t.nama.replace(/-?\s*SEWA MOBIL/i, "")) : "Transport mobil " + title(t.nama), t.nilai]);
    else if (g.startsWith("TRANSLOK")) m.push(["Transport lokal " + t.nama.replace(/^TRANSLOK\s*/i, "").toLowerCase(), t.nilai]);
  }
  return m;
}
/* kode klasifikasi */
const kodeMap = (): Record<string, KodeDB["codes"][number]> => Object.fromEntries(kodeDB.codes.map(c => [c.k, c]));
const kodeFromNL = (nl: unknown): string => { const m = String(nl || "").match(/\/([A-Z]{2,3}\.\d{3,4})\//); return m ? m[1] : ""; };
const kodeGroup = (k: string): string => kodeDB.groups[k.split(".")[0]] || k.split(".")[0];
function composeNL(code: string, cur0: unknown, tgl: unknown): string {
  const y = (parseTgl(tgl) || new Date()).getFullYear();
  const cur = String(cur0 || "").trim();
  if (/^\/.*\/[A-Z]{2,3}\.\d{3,4}\/\d{4}$/.test(cur)) return cur.replace(/[A-Z]{2,3}\.\d{3,4}(?=\/\d{4}$)/, code).replace(/\/\d{4}$/, "/" + y);
  return `/BPS/ST/9204/${code}/${y}`;
}
function lookupKode(q0: unknown): { c: KodeDB["codes"][number] | null; n: number } {
  const q = String(q0 || "").trim(); if (!q) return { c: null, n: 0 };
  const c = kodeMap()[q.toUpperCase()]; if (c) return { c, n: 1 };
  const hits = kodeDB.codes.filter(x => x.d.toLowerCase().includes(q.toLowerCase()));
  return { c: hits.length === 1 ? hits[0] : null, n: hits.length };
}

