/* ================= record model ================= */
const lampOf = (r: StRecord): string[] => Array.isArray(r.lampiran) ? r.lampiran.map(String).filter(Boolean)
  : [1,2,3,4,5].map(i => r["KodeLampiran" + i] as unknown).filter(v => v != null && String(v).trim() !== "").map(v => String(v).trim());
function setLamp(r: StRecord, list: string[]): void {
  r.lampiran = list.slice();
  for (let i = 1; i <= 5; i++){ if (list[i-1] != null) r["KodeLampiran" + i] = String(list[i-1]); else delete r["KodeLampiran" + i]; }
}
/* rebuild SK-transport rows of a record from its _kampung list (manual rows kept, after SK rows) */
function applyKampungToRec(r: StRecord): boolean {
  const M = kamByKey(), list = normChips(r._kampung).map(c => ({ ...c, kam: M[c.k] })).filter(c => c.kam);
  const manual: [string, unknown][] = [];
  for (let i = 1; i <= MAXTR; i++){
    const ket = r["KetTransport_" + i], v = r["Nilai" + i];
    delete r["KetTransport_" + i]; delete r["Nilai" + i];
    if (ket && AUTO_RE.test(ket)) continue;
    if ((ket != null && ket !== "") || (v != null && v !== "")) manual.push([ket ?? "", v]);
  }
  const base = String(r.TEMPAT_BERANGKAT || "Kampung Semu").trim(), K = (c: { kam: Kampung }) => "Kampung " + title(c.kam.kampung);
  const rows: [string, unknown][] = [], riilAuto: RiilRow[] = [];
  if (trLokal(r)){
    // Lokal: tiap kampung = Biaya Transport Lokal dari <berangkat> ke <kampung> (tarif SK, PP / ½)
    // Lokal: tarif per hari × banyak hari perjalanan
    // beberapa kampung: lama hari dibagi rata, sisa pembagian ke kampung paling awal (4 hari, 3 kampung → 2, 1, 1)
    // kampung berlabel Lokal: tanpa bukti → Daftar Pengeluaran Riil baris "2. Uang Transport Lokal" (r._riilLok), bukan baris transport rincian
    const hari = Math.max(1, num(r.LAMA_JALAN) || 1), n = list.length, per = Math.floor(hari / n), sisa = hari % n;
    list.forEach((c, i) => { const h = per + (i < sisa ? 1 : 0); if (!h) return; const unit = kamValue(c.kam, c.pp);
      const row: RiilRow = [`Biaya Transport Lokal dari ${base} ke ${K(c)} (${h} hari x ${rupiah(unit)}${c.pp ? "" : ", sekali jalan"})`, unit * h];
      if (kamLokal(c.kam)) riilAuto.push(row); else rows.push(row); });
  } else if (list.length){
    // Remote: berangkat → kampung 1 (½ tarif SK), lintasan antar kampung, kampung terakhir → pulang (½ tarif SK)
    const first = list[0], last = list[list.length - 1];
    const mobil = list.some(c => c.kam.tarif > rule("BATAS TRANSPORT"));
    if (mobil){
      // tarif SK > batas: Transport Mobil (tarif SK penuh, tidak dibagi dua), Lintasan Mobil antar kampung, Inap Mobil (lama − 1) malam
      rows.push([`Biaya Transport Mobil dari ${base} ke ${K(first)}`, kamValue(first.kam, true)]);
      for (let i = 1; i < list.length; i++) rows.push([`Biaya Lintasan Mobil dari ${K(list[i-1])} ke ${K(list[i])}`, minLintasMobil()]);
      const nights = Math.max(0, num(r.LAMA_JALAN) - 1), im = rule("INAP MOBIL");
      if (nights) rows.push([`Biaya Inap Mobil (${nights} Malam x ${rupiah(im)})`, nights * im]);
    } else {
      rows.push([`Biaya Transport dari ${base} ke ${K(first)}`, kamValue(first.kam, false)]);
      for (let i = 1; i < list.length; i++) rows.push([`Biaya Lintasan dari ${K(list[i-1])} ke ${K(list[i])}`, rule("LINTASAN ANTAR")]);
      rows.push([`Biaya Transport dari ${K(last)} ke ${base}`, kamValue(last.kam, false)]);
    }
  }
  rows.push(...manual);
  { const all = [...riilAuto, ...riilFilled(riilRows(r._riilLok)).filter(([k]) => !AUTO_RE.test(k))]; if (all.length) r._riilLok = all; else delete r._riilLok; }
  rows.slice(0, MAXTR).forEach(([k, v], i) => { if (k !== "") r["KetTransport_" + (i+1)] = k; if (v != null && v !== "") r["Nilai" + (i+1)] = v; });
  return rows.length > MAXTR;
}
/** nilai turunan surat (nama, NIP, total biaya, terbilang) — kolom mengikuti MERGEFIELD template */
function compute(r: StRecord): StRecord {
  const P = pegMap(), g = (k: string): Pegawai | null => { const c = codeOf(r[k]); return c === "" ? null : (P[c] || null); };
  const o: StRecord = {};
  o.NO = r.NO ?? ""; o.NoLengkap = r.NoLengkap ?? "";
  o.NOSURTUG = "B-" + o.NO; o.NOMOR_ST = o.NOSURTUG + o.NoLengkap; o.NOMOR_SPD = o.NOMOR_ST;
  o.TGL_TERBIT_ST = r.TGL_TERBIT_ST ?? ""; o.TGL_SPD = o.TGL_TERBIT_ST;
  for (const k of ["kegiatan","MAKSUD__TUJUAN","ALAT_ANGKUTAN_YANG_DIGUNAKAN","TEMPAT_BERANGKAT","TEMPAT_TUJUAN","TGL_PERGI","TGL_PULANG","MAK","TGL_KUI"]) o[k] = r[k] ?? "";
  o.LAMA_JALAN = r.LAMA_JALAN ?? "";
  const pl = g("KD_NAMA_SPD");
  o.NAMA_PELAKSANA_SPD = pl ? pl.nama : ""; o.NIP_PELAKSANA_SPD = pl ? pl.nip : ""; o.JABATAN = pl ? pl.jabatan : ""; o.PANGKAT = pl ? pl.pangkat : ""; o.GOL = pl ? pl.gol : "";
  const ppk = g("No_PPK"); o.PPK = ppk ? ppk.nama : ""; o.NIP_PPK = ppk ? ppk.nip : "";
  const ka = g("KD_NAMA_KA_PLT_PLH"); o.KAPLTPLH = ka ? ka.nama : "";
  const ks = g("KDSPPD"); o.KepalaSPPD = ks ? ks.nama : ""; o.NIPKepala = ks ? ks.nip : "";
  const be = g("No_Bend"); o.BEND = be ? be.nama : ""; o.NIP_BEND = be ? be.nip : "";
  const lamp = lampOf(r); o._lampN = lamp.length;
  { const M = kamByKey(); o._kam = normChips(r._kampung).map(c => M[c.k]).filter((k): k is Kampung => !!k).map(k => title(k.kampung)); }
  for (let i = 1; i <= Math.max(5, lamp.length); i++){
    const p = lamp[i-1] != null ? P[lamp[i-1]] : null;
    o[i === 1 ? "NAMALAMPIRAN_1" : "NAMA_LAMPIRAN_" + i] = p ? p.nama : "";
    o["NIP_LAMPIRAN_" + i] = p ? p.nip : ""; o["JABATAN_LAMPIRAN_" + i] = p ? p.jabatan : "";
    o["PANGKAT_LAMPIRAN_" + i] = p ? p.pangkat : ""; o["GOL_LAMPIRAN_" + i] = p ? p.gol : "";
  }
  const lok = noUH(r), noI = noInap(r);
  const inap = noI ? 0 : num(r.LAMA_INAP), tdk = num(r.TDK_INAP_HOTEL), luh = lok ? 0 : num(r.LAMA_UH), nuh = num(r.NILAI_UH);
  let sumTr = 0;
  for (let i = 1; i <= MAXTR; i++){ o["KetTransport_" + i] = r["KetTransport_" + i] ?? ""; const v = r["Nilai" + i]; o["Nilai" + i] = (v === "" || v == null) ? "" : rupiah(num(v)); sumTr += num(v); }
  const totInap = inap * tdk, totUH = luh * nuh;
  /* pengeluaran riil tanpa bukti (Daftar Pengeluaran Riil): 1. penginapan, 2. transport lokal, 3. mobil bandara */
  const rLok = riilFilled(riilRows(r._riilLok)), rBdr = riilFilled(riilRows(r._riilBdr));
  const totLok = rLok.reduce((s, x) => s + num(x[1]), 0), totBdr = rBdr.reduce((s, x) => s + num(x[1]), 0), totRiil = totInap + totLok + totBdr;
  const totTr = sumTr + totLok + totBdr;      // seluruh transport: baris rincian (sumTr) + transport riil
  /* hotel dengan bukti: hotel pertama (HOTEL_TEMPAT / LAMA_HOTEL / TARIF_HOTEL) + hotel tambahan (_hotel2) */
  const th = num(r.TARIF_HOTEL), hotels: HotelX[] = noI ? [] : [{ t: String(r.HOTEL_TEMPAT || "").trim(), l: num(r.LAMA_HOTEL), n: th }, ...hotelX(r)].filter(h => h.l > 0);
  const lh = hotels.reduce((s, h) => s + h.l, 0), totHotel = hotels.reduce((s, h) => s + h.l * h.n, 0);
  const jml = totInap + totUH + totTr + totHotel;
  Object.assign(o, {
    LAMA_INAP: String(inap), TDK_INAP_HOTEL: rupiah(tdk), TOTAL_BIAYA_TDK_INAP_HOTEL: rupiah(totInap), PENG_RIIL: rupiah(totRiil),
    Terbilang3: terbilang(totRiil), LAMA_UH: String(luh), NILAI_UH: rupiah(nuh), TOTAL_UH: rupiah(totUH),
    TOTAL_TRANS: rupiah(totTr), JUMLAH: rupiah(jml), TERBILANG: terbilang(jml),
    HOTEL_TEMPAT: String(r.HOTEL_TEMPAT || "").trim(), LAMA_HOTEL: String(lh), TARIF_HOTEL: rupiah(th), TOTAL_HOTEL: rupiah(totHotel)
  });
  o._hotels = hotels; o._riilLok = rLok; o._riilBdr = rBdr;
  const ps = personCodes(r, P), orang = Math.max(1, ps.length);
  let jmlTotal = jml * orang;
  if (!r._isPerson && r._perOrang && ps.length > 1) jmlTotal = ps.reduce((sum: number, c) => sum + compute(personRec(r, c))._num.jml, 0);
  o._num = { totInap, totUH, totTr, totHotel, lh0: noI ? 0 : num(r.LAMA_HOTEL) * th, totLok, totBdr, totRiil, lh, th, jml, sumTr, inap, tdk, luh, nuh, orang, jmlTotal };
  return o;
}

/* orang yang menerima rincian biaya: pelaksana (bukan "Terlampir") + semua anggota lampiran */
function personCodes(r: StRecord, P: Record<string, Pegawai> = pegMap()): string[] {
  const out: string[] = [], k = codeOf(r.KD_NAMA_SPD);
  if (k && k !== "999" && P[k] && !/^terlampir$/i.test(String(P[k].nama).trim())) out.push(k);
  for (const c of lampOf(r)) if (P[c] && !out.includes(c)) out.push(c);
  return out;
}
/* tim surat: pegawai lebih dulu, lalu mitra; prioritas 0 = pelaksana pegawai, 1 = ada pegawai di tim, 2 = mitra saja */
/** tim surat untuk daftar: kode, pegawai, mitra, label singkat */
interface Team { codes: string[]; peg: string[]; mit: string[]; prio: number; label: string; names: { c: string; nama: string; peg: boolean }[] }
function teamOf(r: StRecord, P: Record<string, Pegawai> = pegMap()): Team {
  const cs = personCodes(r, P), isPeg = (c: string): boolean => !!P[c] && !isMitra(P[c]) && !isSystemPeg(P[c]);
  const peg = cs.filter(isPeg), mit = cs.filter(c => !isPeg(c)), pel = codeOf(r.KD_NAMA_SPD);
  const prio = isPeg(pel) ? 0 : peg.length ? 1 : 2;
  const first = isPeg(pel) ? pel : (peg[0] || cs[0]);
  const short = (c: string): string => String(P[c]?.nama || "").split(",")[0];
  return { codes: cs, peg, mit, prio, label: first ? short(first) + (cs.length > 1 ? ` +${cs.length - 1}` : "") : "-", names: [...peg, ...mit].map(c => ({ c, nama: short(c), peg: isPeg(c) })) };
}
/* satu surat → satu rekaman per orang untuk dokumen Rincian Biaya */
/* rincian satu orang: nilai surat + nilai khusus orang tsb (r._perOrang[kode]) */
const PO_FIELDS = ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL", "HOTEL_TEMPAT"];
function personRec(r: StRecord, c: string): StRecord {
  const o: StRecord = (r._perOrang || {})[c] || {}, x: StRecord = { ...r, KD_NAMA_SPD: c, _isPerson: true };
  delete x._perOrang;
  for (const k of PO_FIELDS) if (o[k] != null && o[k] !== "") x[k] = o[k];
  // malam hotel khusus orang ini → malam "tanpa hotel" ikut menyesuaikan (bila tidak diisi khusus & surat memakai hitungan otomatis)
  if (o.LAMA_HOTEL != null && o.LAMA_HOTEL !== "" && (o.LAMA_INAP == null || o.LAMA_INAP === "")){
    const L = num(r.LAMA_JALAN), xN = hotelXN(r), autoBase = Math.max(0, L - 1 - num(r.LAMA_HOTEL) - xN);
    if (L && num(r.LAMA_INAP) === autoBase) x.LAMA_INAP = Math.max(0, L - 1 - num(o.LAMA_HOTEL) - xN);
  }
  if (Array.isArray(o.trans)){
    for (let i = 1; i <= MAXTR; i++){ delete x["KetTransport_" + i]; delete x["Nilai" + i]; }
    o.trans.slice(0, MAXTR).forEach(([k, v]: [string, unknown], i: number) => { if (k) x["KetTransport_" + (i + 1)] = k; if (v !== "" && v != null) x["Nilai" + (i + 1)] = v; });
    delete x.TOTAL_TRANS;
  }
  if (Array.isArray(o.riilLok)){ if (o.riilLok.length) x._riilLok = o.riilLok; else delete x._riilLok; }   // transport lokal riil khusus orang ini
  return x;
}
function biayaRecs(r: StRecord): StRecord[] {
  const ps = personCodes(r);
  if (!ps.length) return [r];
  return ps.map(c => personRec(r, c));
}
const expandBiaya = (recs: StRecord[]): StRecord[] => recs.flatMap(biayaRecs);

