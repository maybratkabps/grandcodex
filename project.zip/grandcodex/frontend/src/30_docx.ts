/* ================= DOCX generation ================= */
const WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
/** simpul XML berupa elemen (nodeType 1) */
const isEl = (n: Node | null | undefined): n is Element => !!n && n.nodeType === 1;
const kids = (el: Node, name: string): Element[] => [...el.childNodes].filter((n): n is Element => isEl(n) && n.namespaceURI === WNS && n.localName === name);
/** leluhur terdekat (termasuk n sendiri) bernama `name` di namespace w: */
const upTo = (n: Node, name: string): Element | null => { for (let x: Node | null = n; x; x = x.parentNode) if (isEl(x) && x.namespaceURI === WNS && x.localName === name) return x; return null; };
const xmlOut = (doc: Document): string => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + new XMLSerializer().serializeToString(doc).replace(/^<\?xml[^>]*\?>\s*/, "");
/* add rows to the Lampiran ST table when there are more than 5 members */
function growLampiran(doc: Document, n: number): void {
  if (n <= 5) return;
  const instr = [...doc.getElementsByTagNameNS(WNS, "instrText")].find(t => /NAMA_LAMPIRAN_5\b/.test(t.textContent));
  if (!instr) return;
  const tr = upTo(instr, "tr");
  if (!tr) return;
  let after: Element = tr;
  for (let i = 6; i <= n; i++){
    const c = tr.cloneNode(true) as Element;
    for (const t of c.getElementsByTagNameNS(WNS, "instrText")) t.textContent = t.textContent.replace(/_LAMPIRAN_5\b/g, "_LAMPIRAN_" + i);
    const firstCell = c.getElementsByTagNameNS(WNS, "tc")[0];
    if (firstCell) for (const t of firstCell.getElementsByTagNameNS(WNS, "t")) if (/^\s*5\.?\s*$/.test(t.textContent)) t.textContent = i + ".";
    after.parentNode!.insertBefore(c, after.nextSibling); after = c;
  }
}
const ROMAN = (n: number): string => { const v: [number, string][] = [[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]]; let s = ""; for (const [a, r] of v) while (n >= a){ s += r; n -= a; } return s; };
const cellText = (tc: Element): string => [...tc.getElementsByTagNameNS(WNS, "t")].map(t => t.textContent).join("").trim();
function setCellText(doc: Document, tc: Element, text: string, like?: Element | null): void {
  const p = tc.getElementsByTagNameNS(WNS, "p")[0]; if (!p) return;
  for (const r of [...kids(p, "r")]) p.removeChild(r);
  const ppr = kids(p, "pPr")[0]; if (ppr) for (const j of kids(ppr, "jc")) ppr.removeChild(j);   // rata kiri
  const r = doc.createElementNS(WNS, "w:r"), lr = like && like.getElementsByTagNameNS(WNS, "r")[0], rp = lr && kids(lr, "rPr")[0];
  if (rp) r.appendChild(rp.cloneNode(true));
  const t = doc.createElementNS(WNS, "w:t"); t.setAttribute("xml:space", "preserve"); t.textContent = text; r.appendChild(t); p.appendChild(r);
}
/* Lampiran SPPD: pakai versi template 5-kolom, jumlah blok "Tiba di / Berangkat dari" = jumlah kampung tujuan */
function fitSppd(doc: Document, kam: string[], base: string): void {
  /* tidak ada kampung yang dikenali di SK Transport → 4 blok tanda tangan kosong (tempat diisi tangan) */
  const n0 = kam.length, n = n0 || 4;
  const body = doc.getElementsByTagNameNS(WNS, "body")[0], nodes = [...body.childNodes];
  const marks = nodes.filter((x): x is Element => isEl(x) && x.localName === "p" && cellText(x) === "Lampiran SPPD");
  if (marks.length < 2) return;
  const i1 = nodes.indexOf(marks[0]), i2 = nodes.indexOf(marks[1]);
  const after = nodes.slice(i2 + 1).filter((x): x is Element => isEl(x) && x.localName === "tbl");
  const tStops = after[0], tEnd = after[1]; if (!tStops || !tEnd) return;
  // buang versi 10-kolom (antara penanda pertama dan kedua)
  for (const x of nodes.slice(i1, i2)) if (!(isEl(x) && x.localName === "p" && kids(x, "pPr")[0] && kids(kids(x, "pPr")[0], "sectPr")[0])) body.removeChild(x);
  const rows = kids(tStops, "tr"), isRoman = (tr: Element) => { const c = kids(tr, "tc")[0]; return c && /^[IVX]+\.$/.test(cellText(c)); };
  const groups: Element[][] = []; let g: Element[] | null = null;
  rows.forEach(tr => { if (isRoman(tr) && cellText(kids(tr, "tc")[0]) !== "I."){ g = [tr]; groups.push(g); } else if (g) g.push(tr); });
  if (!groups.length) return;
  // semua blok disalin dari blok II supaya lebar kolom seragam
  while (groups.length > 1){ for (const tr of groups.pop()!) tStops.removeChild(tr); }
  while (groups.length < n){ const cl = groups[0].map(tr => tr.cloneNode(true) as Element); for (const tr of cl) tStops.appendChild(tr); groups.push(cl); }
  const nameOf = (i: number): string => i < n ? (n0 ? "Kampung " + kam[i] : "") : base;
  // baris I: "Ke : kampung pertama"
  for (const tr of rows.slice(0, 6)){ const cs = kids(tr, "tc"), ix = cs.findIndex(c => cellText(c) === "Ke"); if (ix >= 0 && cs[ix + 2]){ setCellText(doc, cs[ix + 2], nameOf(0), cs[ix]); break; } }
  groups.forEach((grp, i) => {
    setCellText(doc, kids(grp[0], "tc")[0], ROMAN(i + 2) + ".", kids(grp[0], "tc")[0]);
    for (const tr of grp){
      const cs = kids(tr, "tc");
      cs.forEach((c, j) => { const t = cellText(c), v = cs[j + 2];
        if (!v || cellText(cs[j + 1] || c) !== ":") return;
        if (t === "Tiba di" || t === "Berangkat dari") setCellText(doc, v, nameOf(i), c);
        else if (t === "Ke") setCellText(doc, v, nameOf(i + 1), c);
      });
    }
  });
  // nomor bagian penutup: Tiba kembali, Catatan, Perhatian
  let k = n + 2;
  for (const tr of kids(tEnd, "tr")){ const c = kids(tr, "tc")[0]; if (c && /^[IVX]+\.$/.test(cellText(c))) setCellText(doc, c, ROMAN(k++) + ".", c); }
}
/* Lampiran SPPD: "Pada tanggal" berangkat (blok I) = tgl pergi, "Pada tanggal" tiba kembali = tgl pulang */
function fillSppdDates(doc: Document, pergi?: string, pulang?: string): void {
  const body = doc.getElementsByTagNameNS(WNS, "body")[0], nodes = [...body.childNodes];
  const start = nodes.findIndex(x => isEl(x) && x.localName === "p" && cellText(x) === "Lampiran SPPD"); if (start < 0) return;
  const end = nodes.findIndex((x, i) => i > start && (x.textContent || "").includes("KUITANSI"));
  for (const t of nodes.slice(start, end < 0 ? undefined : end).filter((x): x is Element => isEl(x) && x.localName === "tbl")){
    let mode: string | null | undefined = null, left = 0;
    for (const tr of kids(t, "tr")){
      const cs = kids(tr, "tc"), tx = cs.map(cellText);
      if (tx.includes("Berangkat Dari")){ mode = pergi; left = 4; }
      else if (tx.includes("Tiba kembali di")){ mode = pulang; left = 4; }
      if (left-- > 0 && mode){ const j = tx.indexOf("Pada tanggal"); if (j >= 0 && cs[j + 2] && tx[j + 1] === ":"){ setCellText(doc, cs[j + 2], mode, cs[j]); mode = null; } }
    }
  }
}
/* Rincian baris 5: "Uang penginapan di … malam @ …" + jumlahnya; lebih dari satu hotel → baris ditambah */
function fillHotel(doc: Document, F: StRecord): void {
  const RE = /^\s*Uang penginapan di\s+malam\s*@\s*$/;
  const t = [...doc.getElementsByTagNameNS(WNS, "t")].find(x => RE.test(x.textContent));
  if (!t) return;
  const tr = upTo(t, "tr");
  if (!tr) return;
  const hs: HotelX[] = F._hotels || [];
  const put = (row: Element, h: HotelX | undefined, first: boolean): void => {
    const tt = [...row.getElementsByTagNameNS(WNS, "t")].find(x => RE.test(x.textContent));
    if (tt && h){ tt.textContent = `Uang penginapan di ${h.t ? h.t + " " : ""}${h.l} malam @ ${rupiah(h.n)}`; tt.setAttribute("xml:space", "preserve"); }
    const cells = kids(row, "tc");
    if (!first && cells[0]) for (const x of cells[0].getElementsByTagNameNS(WNS, "t")) x.textContent = "";   // nomor "5." hanya di baris pertama
    const amt = cells.slice(2).map(c => [...c.getElementsByTagNameNS(WNS, "t")]).find(ts => ts.some(x => /^\s*0\s*$/.test(x.textContent)));
    if (amt){ const z = amt.find(x => /^\s*0\s*$/.test(x.textContent))!; z.textContent = z.textContent.replace("0", rupiah(h ? h.l * h.n : 0)); }
  };
  const extra = hs.slice(1).map(() => tr.cloneNode(true) as Element);
  put(tr, hs[0], true);
  let after: Element = tr;
  extra.forEach((row, i) => { put(row, hs[i + 1], false); after.parentNode!.insertBefore(row, after.nextSibling); after = row; });
}
/* Daftar Pengeluaran Riil: "2. Uang Transport Lokal" dan "3. Uang Transport Mobil Bandara" — judul + satu baris per rincian (keterangan, Rp, nilai) */
function fillRiil(doc: Document, F: StRecord): void {
  const t = [...doc.getElementsByTagNameNS(WNS, "t")].find(x => x.textContent.trim() === "Uang Transport Lokal");
  if (!t) return;
  const tr = upTo(t, "tr"), run = upTo(t, "r");
  if (!tr || !run) return;
  const rPr = kids(run, "rPr")[0] || null, lok: RiilRow[] = F._riilLok || [], bdr: RiilRow[] = F._riilBdr || [];
  const say = (tc: Element | undefined, text: string): void => {
    const p = tc?.getElementsByTagNameNS(WNS, "p")[0]; if (!p) return;
    for (const r of [...kids(p, "r")]) p.removeChild(r);
    if (text === "") return;
    const r = doc.createElementNS(WNS, "w:r"); if (rPr) r.appendChild(rPr.cloneNode(true));
    const x = doc.createElementNS(WNS, "w:t"); x.setAttribute("xml:space", "preserve"); x.textContent = text; r.appendChild(x); p.appendChild(r);
  };
  /* tiga sel uraian (nama · banyaknya · @tarif) digabung jadi satu supaya keterangan panjang muat → sel: [no, uraian, Rp, nilai, ket, …] */
  const wide = (row: Element): Element[] => {
    const cs = kids(row, "tc"); if (cs.length < 6) return cs;
    const part = cs.slice(1, 4), pr = kids(part[0], "tcPr")[0];
    if (pr){
      let w = 0, g = 0;
      for (const c of part){ const q = kids(c, "tcPr")[0], tw = q && kids(q, "tcW")[0], gs = q && kids(q, "gridSpan")[0]; w += Number(tw?.getAttributeNS(WNS, "w") || 0); g += Number(gs?.getAttributeNS(WNS, "val") || 1); }
      const tw = kids(pr, "tcW")[0]; if (tw) tw.setAttributeNS(WNS, "w:w", String(w));
      let gs = kids(pr, "gridSpan")[0]; if (!gs){ gs = doc.createElementNS(WNS, "w:gridSpan"); pr.insertBefore(gs, tw ? tw.nextSibling : pr.firstChild); }
      gs.setAttributeNS(WNS, "w:val", String(g));
      const bo = kids(pr, "tcBorders")[0]; if (bo) for (const x of kids(bo, "right")) bo.removeChild(x);   // garis kanan mengikuti sel terakhir yang digabung
    }
    row.removeChild(part[1]); row.removeChild(part[2]);
    return kids(row, "tc");
  };
  const noNum = (tc: Element | undefined): void => { for (const p of tc ? [...tc.getElementsByTagNameNS(WNS, "numPr")] : []) p.parentNode!.removeChild(p); };
  const detail = (row: RiilRow): Element => { const x = tr.cloneNode(true) as Element, cs = wide(x); noNum(cs[0]); say(cs[1], "- " + row[0].trim()); say(cs[2], "Rp."); say(cs[3], rupiah(num(row[1]))); return x; };
  const head2 = tr.cloneNode(true) as Element;                       // "3." — nomor otomatis mengikuti daftar bernomor template
  const out: Element[] = [...lok.map(detail), head2, ...bdr.map(detail)];
  say(wide(head2)[1], "Uang Transport Mobil Bandara"); wide(tr);
  let after: Element = tr;
  for (const x of out){ after.parentNode!.insertBefore(x, after.nextSibling); after = x; }
  if (lok.length || bdr.length) for (const x of doc.getElementsByTagNameNS(WNS, "t")) if (x.textContent.includes("pada angka 1 di atas")) x.textContent = x.textContent.replace("pada angka 1 di atas", "pada angka 1 s.d. 3 di atas");
}
/** ganti setiap MERGEFIELD «NAMA» dengan nilai F[NAMA] */
interface MergeFrame { instr: string; phase: "instr" | "res"; runs: Element[]; rPr: Element | null }
function fillDoc(doc: Document, F: StRecord): void {
  const runs = [...doc.getElementsByTagNameNS(WNS, "r")];
  const stack: MergeFrame[] = [];
  for (const r of runs){
    for (const fr of stack) fr.runs.push(r);
    for (const ch of [...r.childNodes]){
      if (!isEl(ch) || ch.namespaceURI !== WNS) continue;
      if (ch.localName === "fldChar"){
        const ty = ch.getAttributeNS(WNS, "fldCharType");
        if (ty === "begin") stack.push({ instr:"", phase:"instr", runs:[r], rPr:null });
        else if (ty === "separate" && stack.length) stack[stack.length-1].phase = "res";
        else if (ty === "end" && stack.length){
          const fr = stack.pop()!;
          const m = fr.instr.trim().match(/^MERGEFIELD\s+"?([^\s"\\]+)/i);
          if (!m) continue;
          const val = m[1] in F ? String(F[m[1]] ?? "") : "";
          const nr = doc.createElementNS(WNS, "w:r");
          const rp = fr.rPr || kids(fr.runs[0], "rPr")[0];
          if (rp){ const c = rp.cloneNode(true) as Element; for (const h of kids(c, "highlight")) c.removeChild(h); nr.appendChild(c); }
          val.split("\n").forEach((line, i) => {
            if (i) nr.appendChild(doc.createElementNS(WNS, "w:br"));
            const t = doc.createElementNS(WNS, "w:t"); t.setAttribute("xml:space", "preserve"); t.textContent = line; nr.appendChild(t);
          });
          const first = fr.runs[0]; first.parentNode!.insertBefore(nr, first);
          for (const x of new Set(fr.runs)) if (x.parentNode) x.parentNode.removeChild(x);
          for (const o of stack) o.runs.push(nr);
        }
      } else if (ch.localName === "instrText" && stack.length && stack[stack.length-1].phase === "instr"){
        stack[stack.length-1].instr += ch.textContent;
      } else if (ch.localName === "t" && stack.length){
        const top = stack[stack.length-1];
        if (top.phase === "res" && !top.rPr) top.rPr = kids(r, "rPr")[0] || null;
      }
    }
  }
}
/* template sections: 0 = Surat Tugas, 1 = SPD, 2 = Lampiran SPPD + dokumen biaya, 3 = Lampiran ST.
   Section 2 is split at the KUITANSI block into "sppd" (hal. 3–5) and "biaya" (hal. 6–9). */
const PART_OF_SECTION = [["st"], ["spd"], ["sppd", "biaya"], ["lamp"]];
const FILE_ST = ["st", "spd", "sppd", "lamp"], FILE_BIAYA = ["biaya"];
function keepParts(doc: Document, keep: Set<string>): void {
  const body = doc.getElementsByTagNameNS(WNS, "body")[0];
  const secs: { nodes: ChildNode[]; sp: Element; body: boolean }[] = []; let cur: ChildNode[] = [];
  for (const n of [...body.childNodes]){
    if (isEl(n) && n.namespaceURI === WNS && n.localName === "sectPr"){ secs.push({ nodes: cur, sp: n, body: true }); cur = []; continue; }
    cur.push(n);
    const sp = isEl(n) && n.localName === "p" && kids(n, "pPr")[0] ? kids(kids(n, "pPr")[0], "sectPr")[0] : undefined;
    if (sp){ secs.push({ nodes: cur, sp, body: false }); cur = []; }
  }
  if (secs.length !== PART_OF_SECTION.length) return;      // unknown template layout → keep all
  const kept = secs.map((s, i) => PART_OF_SECTION[i].some(p => keep.has(p)));
  if (!kept.some(Boolean)) return;
  // partial keep inside the SPPD/biaya section
  const ks = secs[2];
  if (kept[2] && !(keep.has("sppd") && keep.has("biaya"))){
    const cut = ks.nodes.findIndex(n => (n.textContent || "").includes("KUITANSI"));
    if (cut > 0){
      const holder = ks.body ? null : ks.nodes[ks.nodes.length - 1];   // paragraph carrying the section break stays
      const drop = keep.has("sppd") ? ks.nodes.slice(cut) : ks.nodes.slice(0, cut);
      for (const n of drop) if (n !== holder && n.parentNode) n.parentNode.removeChild(n);
    }
  }
  const lastKept = kept.lastIndexOf(true);
  secs.forEach((s, i) => { if (!kept[i]) for (const n of s.nodes) if (n.parentNode) n.parentNode.removeChild(n); });
  const last = secs[secs.length - 1];
  if (!kept[secs.length - 1]){
    const sp = secs[lastKept].sp;
    sp.parentNode!.removeChild(sp);
    body.replaceChild(sp, last.sp);
  }
}
function fitTransport(doc: Document, n: number): void {
  const it = [...doc.getElementsByTagNameNS(WNS, "instrText")].find(x => /MERGEFIELD\s+"?KetTransport_1\b/.test(x.textContent));
  if (!it) return;
  const tc = upTo(it, "tc"), tr = tc?.parentNode;
  if (!tc || !isEl(tr) || tr.localName !== "tr") return;
  const K = kids(tc, "p").length;
  if (K < 2) return;
  const cells = kids(tr, "tc"), N = Math.max(K, n);
  const strip = (p: Element): Element => { for (const c of [...p.childNodes]) if (!(isEl(c) && c.namespaceURI === WNS && c.localName === "pPr")) p.removeChild(c);
    const pp = kids(p, "pPr")[0]; if (pp) for (const x of kids(pp, "numPr")) pp.removeChild(x); return p; };
  const out: Element[] = [];
  for (let j = 0; j < N; j++){
    const nt = tr.cloneNode(false) as Element;
    for (const ch of [...tr.childNodes]) if (!(isEl(ch) && ch.namespaceURI === WNS && ch.localName === "tc")) nt.appendChild(ch.cloneNode(true));
    for (const trPr of kids(nt, "trPr")) for (const h of kids(trPr, "trHeight")) trPr.removeChild(h);
    for (const c of cells){
      const ps = kids(c, "p"), nc = c.cloneNode(false) as Element;
      for (const ch of [...c.childNodes]) if (isEl(ch) && ch.namespaceURI === WNS && ch.localName === "tcPr") nc.appendChild(ch.cloneNode(true));
      let pa: Element;
      if (ps.length === K){
        pa = ps[Math.min(j, K - 1)].cloneNode(true) as Element;
        if (c === tc) for (const x of [...pa.getElementsByTagNameNS(WNS, "t")]) if (x.textContent.trim() === ".") x.textContent = "";   // titik nyasar di template (baris 8)
        if (j >= K){
          for (const x of pa.getElementsByTagNameNS(WNS, "instrText")) x.textContent = x.textContent.replace(/(KetTransport_|Nilai)\d+/, "$1" + (j + 1));
          for (const x of pa.getElementsByTagNameNS(WNS, "t")) if (!/^\s*Rp\.?\s*$/.test(x.textContent)) x.textContent = "";
        }
      } else pa = j === 0 ? ps[0].cloneNode(true) as Element : strip(ps[0].cloneNode(true) as Element);
      nc.appendChild(pa); nt.appendChild(nc);
    }
    out.push(nt);
  }
  for (const r of out) tr.parentNode!.insertBefore(r, tr);
  tr.parentNode!.removeChild(tr);
}
/* template terpisah: Surat Tugas (ST, SPD, Lampiran SPPD, Lampiran ST) dan Rincian Biaya (kuitansi, rincian, pernyataan).
   Template lama (satu file berisi semuanya, tanpa .kind) tetap dipakai untuk keduanya sampai diganti. */
const tplB64 = (kind = "st"): string => kind === "rb" ? (templateRB ? templateRB.b64 : template && !template.kind ? template.b64 : TEMPLATE_RB_DEFAULT) : (template ? template.b64 : TEMPLATE_DEFAULT);
const ALL_PARTS = ["st", "spd", "sppd", "biaya", "lamp"];
async function buildDocx(rec: StRecord, parts: string[]): Promise<Blob> {
  const F = compute(rec);
  const keep = new Set(parts || ALL_PARTS);
  if (isPelatihan(rec)){ keep.delete("spd"); keep.delete("sppd"); }   // pelatihan: hanya Surat Tugas (+ Lampiran ST)
  if (!F._lampN) keep.delete("lamp");
  if (!keep.size) keep.add("st");
  const kind = [...keep].every(p => FILE_BIAYA.includes(p)) ? "rb" : "st";
  const zip = await JSZip.loadAsync(tplB64(kind), { base64: true });
  let nTr = 0; for (let i = 1; i <= MAXTR; i++) if (F["KetTransport_" + i] || F["Nilai" + i]) nTr = i;
  for (const p of Object.keys(zip.files)){
    if (!/^word\/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$/.test(p)) continue;
    const x = await zip.file(p)!.async("string");
    if (!x.includes("MERGEFIELD") && p !== "word/document.xml") continue;
    const doc = new DOMParser().parseFromString(x, "application/xml");
    if (p === "word/document.xml"){ growLampiran(doc, F._lampN); fitSppd(doc, F._kam, F.TEMPAT_BERANGKAT || "Kampung Semu"); fillSppdDates(doc, F.TGL_PERGI, F.TGL_PULANG); fillHotel(doc, F); fillRiil(doc, F); keepParts(doc, keep); if (keep.has("biaya")) fitTransport(doc, nTr); }
    fillDoc(doc, F);
    zip.file(p, xmlOut(doc));
  }
  const sp = "word/settings.xml";
  if (zip.file(sp)){ let s = await zip.file(sp)!.async("string"); s = s.replace(/<w:mailMerge>[\s\S]*?<\/w:mailMerge>/, ""); zip.file(sp, s); }
  const rp = "word/_rels/settings.xml.rels";
  if (zip.file(rp)){ let s = await zip.file(rp)!.async("string"); s = s.replace(/<Relationship [^>]*mailMergeSource[^>]*\/>/g, ""); zip.file(rp, s); }
  return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
}
async function buildMerged(recs: StRecord[], parts: string[], onProgress?: (n: number) => void): Promise<Blob> {
  const docs: Blob[] = [];
  for (let i = 0; i < recs.length; i++){ docs.push(await buildDocx(recs[i], parts)); onProgress && onProgress(i + 1); }
  const base = await JSZip.loadAsync(docs[0]);
  const docOf = async (z: JSZipT) => new DOMParser().parseFromString(await z.file("word/document.xml")!.async("string"), "application/xml");
  const bdoc = await docOf(base), bbody = bdoc.getElementsByTagNameNS(WNS, "body")[0];
  let lastSect = kids(bbody, "sectPr").pop()!;
  // penomoran daftar (mis. "Mengingat 1–8") harus mulai ulang di setiap surat → tiap salinan dapat w:num sendiri
  const numPath = "word/numbering.xml", ndoc = base.file(numPath) ? new DOMParser().parseFromString(await base.file(numPath)!.async("string"), "application/xml") : null;
  const nroot = ndoc && ndoc.documentElement;
  let maxNum = 0; const absOf: Record<string, string> = {}, startOf: Record<string, Record<string, string>> = {};
  if (nroot){
    for (const n of kids(nroot, "num")){ const id = Number(n.getAttributeNS(WNS, "numId")); maxNum = Math.max(maxNum, id); const a = kids(n, "abstractNumId")[0]; if (a) absOf[id] = a.getAttributeNS(WNS, "val") ?? ""; }
    for (const a of kids(nroot, "abstractNum")){ const aid = a.getAttributeNS(WNS, "abstractNumId") ?? ""; startOf[aid] = {}; for (const l of kids(a, "lvl")){ const st = kids(l, "start")[0]; startOf[aid][l.getAttributeNS(WNS, "ilvl") ?? ""] = st ? st.getAttributeNS(WNS, "val") ?? "1" : "1"; } }
  }
  const cleanup = nroot && kids(nroot, "numIdMacAtCleanup")[0];
  function renumber(body: Element): void {
    if (!nroot || !ndoc) return;
    const map: Record<string, string> = {};
    for (const el of [...body.getElementsByTagNameNS(WNS, "numId")]){
      const old = el.getAttributeNS(WNS, "val") ?? ""; if (!(old in absOf)) continue;
      if (!map[old]){
        map[old] = String(++maxNum);
        const num = ndoc.createElementNS(WNS, "w:num"); num.setAttributeNS(WNS, "w:numId", map[old]);
        const an = ndoc.createElementNS(WNS, "w:abstractNumId"); an.setAttributeNS(WNS, "w:val", absOf[old]); num.appendChild(an);
        for (const [lv, st] of Object.entries(startOf[absOf[old]] || { 0: "1" })){
          const o = ndoc.createElementNS(WNS, "w:lvlOverride"); o.setAttributeNS(WNS, "w:ilvl", lv);
          const so = ndoc.createElementNS(WNS, "w:startOverride"); so.setAttributeNS(WNS, "w:val", st); o.appendChild(so); num.appendChild(o);
        }
        cleanup ? nroot.insertBefore(num, cleanup) : nroot.appendChild(num);
      }
      el.setAttributeNS(WNS, "w:val", map[old]);
    }
  }
  for (let i = 1; i < docs.length; i++){
    const d = await docOf(await JSZip.loadAsync(docs[i])), body = d.getElementsByTagNameNS(WNS, "body")[0];
    renumber(body);
    const p = bdoc.createElementNS(WNS, "w:p"), pPr = bdoc.createElementNS(WNS, "w:pPr");
    pPr.appendChild(lastSect.cloneNode(true)); p.appendChild(pPr); bbody.insertBefore(p, lastSect);
    for (const n of [...body.childNodes]){ if (isEl(n) && n.localName === "sectPr") continue; bbody.insertBefore(bdoc.importNode(n, true), lastSect); }
    const ns = kids(body, "sectPr")[0]; if (ns){ const imp = bdoc.importNode(ns, true); bbody.replaceChild(imp, lastSect); lastSect = imp; }
  }
  base.file("word/document.xml", xmlOut(bdoc));
  if (ndoc) base.file(numPath, xmlOut(ndoc));
  return base.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
}
const fileName = (rec: StRecord, prefix = "ST"): string => { const F = compute(rec);
  return (prefix + " " + F.NOMOR_ST.replace(/\//g, "-") + " " + (F.NAMA_PELAKSANA_SPD || "")).replace(/[\\/:*?"<>|]+/g, "").replace(/\s+/g, " ").trim().slice(0, 120) + ".docx"; };
function download(blob: Blob, name: string): void { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }
const pause = (ms: number): Promise<void> => new Promise(r => setTimeout(r, ms));
/* one surat → 2 files: Surat Tugas (hal. 1–5, 10) and Rincian Biaya (hal. 6–9) */
async function downloadRec(rec: StRecord, which = "st"): Promise<void> {
  try{
    if (which === "biaya"){
      if (rec._noBiaya) return toast("Rincian biaya surat ini belum dibuat — buka lewat Edit → Rincian Biaya, lalu Simpan.");
      const per = biayaRecs(rec);
      const blob = per.length > 1 ? await buildMerged(per, FILE_BIAYA) : await buildDocx(per[0], FILE_BIAYA);
      const nm = per.length > 1 ? fileName(rec, "Rincian Biaya").replace(/\.docx$/, ` (${per.length} orang).docx`) : fileName(per[0], "Rincian Biaya");
      download(blob, nm); toast(per.length > 1 ? `Rincian Biaya ${per.length} orang diunduh dalam satu file.` : "Rincian Biaya diunduh: " + nm);
    } else { download(await buildDocx(rec, FILE_ST), fileName(rec, "ST")); toast("Surat Tugas diunduh: " + fileName(rec, "ST")); }
  }catch(e){ console.error(e); toast("Gagal membuat dokumen: " + (e as Error).message); }
}

/* ================= print dialog ================= */
let printRecs: StRecord[] = [];
function openPrint(recs: StRecord[], stOnly = false): void {
  if (!recs.length) return toast("Pilih surat terlebih dahulu.");
  printRecs = recs; $("#pCount").textContent = String(recs.length);
  const nb = recs.filter(r => r._noBiaya).length;
  $('#dPrint [data-part="biaya"]').checked = !stOnly && !nb;
  $("#pNote").textContent = nb ? `${nb} surat belum punya rincian biaya (dibuat lewat Surat Tugas Kolektif) — File 2 tidak dicentang. Isi rinciannya lewat Daftar Surat Tugas → Edit → Rincian Biaya.` : "";
  $<HTMLDialogElement>("#dPrint").showModal();
}
const chosen = (group: string[]): string[] => $$("#dPrint [data-part]").map(c => c.checked ? c.dataset.part ?? "" : "").filter(p => p && group.includes(p));
$("#pCancel").onclick = () => $<HTMLDialogElement>("#dPrint").close();
const rangeName = () => { const nos = printRecs.map(r => r.NO); return `${nos[0]}${nos.length > 1 ? "-" + nos[nos.length-1] : ""} (${nos.length} surat)`; };
$$("#dPrint [data-go]").forEach(btn => btn.onclick = async () => {
  const go = btn.dataset.go;
  const jobs: [string, string[]][] = [];
  if (go !== "biaya"){ const p = chosen(FILE_ST); if (p.length) jobs.push(["Cetak Surat Tugas", p]); else if (go === "st") return toast("Centang minimal satu bagian File 1."); }
  if (go !== "st"){ const p = chosen(FILE_BIAYA); if (p.length) jobs.push(["Cetak Rincian Biaya", p]); else if (go === "biaya") return toast("Centang bagian File 2."); }
  if (!jobs.length) return toast("Centang minimal satu bagian.");
  const btns = $$<HTMLButtonElement>("#dPrint .df button"); btns.forEach(b => b.disabled = true); const label = btn.textContent;
  try{
    for (const [name, parts] of jobs){
      const list = name.includes("Rincian") ? expandBiaya(printRecs) : printRecs;
      const blob = await buildMerged(list, parts, i => btn.textContent = `${name.replace("Cetak ", "")} ${i}/${list.length}…`);
      download(blob, `${name} ${rangeName()}.docx`); await pause(400);
    }
    $<HTMLDialogElement>("#dPrint").close(); toast(jobs.length > 1 ? "2 file cetak siap — buka masing-masing di Word lalu Ctrl+P." : "File cetak siap — buka di Word lalu Ctrl+P.");
  }catch(e){ console.error(e); toast("Gagal: " + (e as Error).message); }
  btns.forEach(b => b.disabled = false); btn.textContent = label;
});
$("#pZip").onclick = async () => {
  const pS = chosen(FILE_ST), pB = chosen(FILE_BIAYA); if (!pS.length && !pB.length) return toast("Centang minimal satu bagian.");
  const btn = $("#pZip"); btn.disabled = true;
  try{
    const z = new JSZip(), fS = z.folder("Surat Tugas")!, fB = z.folder("Rincian Biaya")!;
    for (let i = 0; i < printRecs.length; i++){
      btn.textContent = `Menyiapkan ${i+1}/${printRecs.length}…`;
      if (pS.length) fS.file(fileName(printRecs[i], "ST"), await buildDocx(printRecs[i], pS));
      if (pB.length){ const per = biayaRecs(printRecs[i]); fB.file(fileName(printRecs[i], "Rincian Biaya").replace(/\.docx$/, per.length > 1 ? ` (${per.length} orang).docx` : ".docx"), per.length > 1 ? await buildMerged(per, pB) : await buildDocx(per[0], pB)); }
    }
    download(await z.generateAsync({ type: "blob" }), `Surat Tugas ${rangeName()}.zip`); $<HTMLDialogElement>("#dPrint").close();
  }catch(e){ toast("Gagal: " + (e as Error).message); }
  btn.disabled = false; btn.textContent = "Per surat (.zip)";
};

