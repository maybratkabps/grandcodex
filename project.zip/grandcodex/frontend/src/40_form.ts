/* ================= FORM ================= */
const form = $<HTMLFormElement>("#f");
(function buildTransRows(){
  let t = "";
  for (let i = 1; i <= MAXTR; i++) t += `<tr data-i="${i}"${i > TR_BASE ? " hidden" : ""}><td class="muted">${i}</td><td><input name="KetTransport_${i}" list="dl-trans" placeholder="Keterangan transport"></td><td class="src"></td><td><input name="Nilai${i}" type="number" min="0" step="1000" style="text-align:right"></td><td><button class="btn sm" type="button" data-clr="${i}" title="Kosongkan baris">×</button></td></tr>`;
  $("#trans").innerHTML = t;
})();
/* ---- pengeluaran riil tanpa bukti (B3): 2. transport lokal · 3. mobil bandara; hotel tambahan (B2) ---- */
const riilOf = (w: string | undefined): RiilRow[] => w === "bdr" ? riilBdr : riilLok;
function renderRiil(): void {
  for (const w of ["lok", "bdr"]){
    $(w === "lok" ? "#rlLok" : "#rlBdr").innerHTML = riilOf(w).map(([k, v], i) => `<tr><td class="muted">${i + 1}</td><td><input data-rl="${w}" data-i="${i}" data-k="0" value="${esc(k)}" placeholder="${w === "lok" ? "mis. Biaya Transport Lokal dari Kampung Semu ke Kampung …" : "mis. Mobil bandara DEO Sorong – Kota Sorong"}"></td><td class="src">${AUTO_RE.test(k) ? `<span class="tag">SK</span>` : ""}</td><td><input data-rl="${w}" data-i="${i}" data-k="1" type="number" min="0" step="1000" value="${esc(v)}" style="text-align:right"></td><td><button class="btn sm" type="button" data-rlx="${w}" data-i="${i}" title="Hapus baris">×</button></td></tr>`).join("")
      || `<tr><td colspan="5" class="muted" style="text-align:center;padding:10px">Belum ada rincian${w === "lok" ? " — terisi otomatis bila kampung tujuan berlabel Lokal, atau tambah manual" : " — klik tambah, isi rincian perjalanan & nominalnya"}.</td></tr>`;
  }
}
function renderHx(): void {
  const dis = formNoInap() ? " disabled" : "";
  $("#hxRows").innerHTML = hotel2.map((h, i) => `<div class="grid" style="margin-top:8px"><div class="c4"><input data-hx="${i}" data-k="t" value="${esc(h.t)}" placeholder="Nama hotel / penginapan ke-${i + 2}" list="dl-hotel"${dis}></div><div class="c2"><input data-hx="${i}" data-k="l" type="number" min="0" value="${h.l || ""}" placeholder="malam"${dis}></div><div class="c3"><input data-hx="${i}" data-k="n" type="number" min="0" step="1000" value="${h.n || ""}" placeholder="tarif per malam"${dis}></div><div class="c3"><div class="row"><input readonly tabindex="-1" data-hxsub="${i}"><button class="btn sm" type="button" data-hxx="${i}" style="flex:none" title="Hapus hotel ini">×</button></div></div></div>`).join("");
  $<HTMLButtonElement>("#hxAdd").disabled = !!dis;
}
/** jumlah malam semua hotel di formulir (hotel pertama + tambahan) */
const formHotelN = (): number => num(form.LAMA_HOTEL.value) + hotel2.reduce((s, h) => s + num(h.l), 0);
$("#riilCard").addEventListener("input", e => { const d = tg(e).dataset, row = d.rl ? riilOf(d.rl)[Number(d.i)] : null; if (!row) return; if (d.k === "0") row[0] = tg(e).value; else row[1] = tg(e).value === "" ? "" : Number(tg(e).value); });
$("#riilCard").addEventListener("click", e => {
  const d = tg(e).closest<HTMLElement>("[data-rladd],[data-rlx]")?.dataset; if (!d) return;
  if (d.rladd){ const rows = riilOf(d.rladd); rows.push(["", ""]); renderRiil(); refresh(); $(`#riilCard [data-rl="${d.rladd}"][data-i="${rows.length - 1}"][data-k="0"]`)?.focus(); }
  else if (d.rlx){ riilOf(d.rlx).splice(Number(d.i), 1); renderRiil(); refresh(); }
});
$("#riilCard").addEventListener("change", e => {
  const w = tg(e).dataset.rlpreset; if (!w) return;
  const ref = riilPresets(w)[+tg(e).value]; tg(e).value = ""; if (!ref) return;
  riilOf(w).push([ref[0], num(ref[1])]); renderRiil(); refresh();
});
const riilPresets = (w: string): [string, number | string][] => otherTransRef().filter(([k]) => w === "bdr" ? /^Mobil bandara /.test(k) : /^Transport lokal /.test(k));
$("#hxRows").addEventListener("input", e => { const d = tg(e).dataset, h = d.hx != null ? hotel2[Number(d.hx)] : null; if (!h) return; if (d.k === "t") h.t = tg(e).value; else if (d.k === "l") h.l = num(tg(e).value); else h.n = num(tg(e).value); });
$("#hxRows").addEventListener("click", e => { const i = tg(e).closest<HTMLElement>("[data-hxx]")?.dataset.hxx; if (i == null) return; hotel2.splice(Number(i), 1); renderHx(); refresh(); });
$("#hxAdd").onclick = () => { hotel2.push({ t: "", l: 0, n: 0 }); renderHx(); refresh(); $(`#hxRows [data-hx="${hotel2.length - 1}"][data-k="t"]`)?.focus(); };
/** kolom isian bernama di formulir (tanpa pemilih tanggal asli) */
const FIELDS = (): HTMLInputElement[] => ([...form.elements] as HTMLInputElement[]).filter(e => e.name && e.type !== "date");
function readForm(): StRecord {
  const r: StRecord = {};
  for (const e of FIELDS()){
    let v = e.value.trim();
    if (e.classList.contains("pick")) v = resolvePeg(v) ?? v;
    if (v === "") continue;
    r[e.name] = e.type === "number" || e.hasAttribute("data-money") ? Number(v) : v;
  }
  r.NO = noNorm(r.NO);
  if (chips.length) r._kampung = clone(chips);
  if ($("#kegLain").checked) r._kegLain = true;
  if (pelExcl.length) r._pelExcl = pelExcl.slice();
  if (Object.keys(pelUH).length) r._pelUH = clone(pelUH);
  setLamp(r, members);
  { const a = riilFilled(riilLok), b = riilFilled(riilBdr), h = hotel2.filter(x => x.t.trim() || x.l || x.n);
    if (a.length) r._riilLok = clone(a); if (b.length) r._riilBdr = clone(b); if (h.length) r._hotel2 = clone(h); }
  delete r.TOTAL_TRANS;
  { const ps = personCodes(r), po: PerOrang = {};
    for (const c of ps) if (perOrang[c] && Object.keys(perOrang[c]).length) po[c] = clone(perOrang[c]);
    if (Object.keys(po).length) r._perOrang = po; }
  return r;
}
function fillForm(r: StRecord): void {
  for (const e of FIELDS()){
    let v = r[e.name] ?? "";
    if (e.classList.contains("pick") && v !== "") v = pegLabel(v);
    e.value = v;
  }
  chips = normChips(r._kampung); members = lampOf(r);
  $("#trSyncInfo").textContent = ""; perOrang = clone(r._perOrang || {}); poOpen.clear();
  riilLok = riilRows(r._riilLok); riilBdr = riilRows(r._riilBdr); hotel2 = hotelX(r); renderRiil(); renderHx();
  if (!r.JENIS) form.JENIS.value = "Remote";
  form.JENIS.dataset.touched = r.JENIS ? "1" : "";
  // otomatis bila surat baru / belum ada rincian / nilainya memang sama dengan hitungan otomatis
  const L = num(r.LAMA_JALAN);
  if (!num(form.LAMA_JALAN.value)){ const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value); if (a && b && b >= a) form.LAMA_JALAN.value = dayDiff(a, b); }
  $("#autoLama").checked = true; _editMoved = false;
  pelExcl = Array.isArray(r._pelExcl) ? r._pelExcl.slice() : []; pelUH = r._pelUH ? clone(r._pelUH) : {};
  kegMode(form.kegiatan, $("#kegLain"), r._kegLain || (r.kegiatan && !pokJudul(akunST(r)).has(String(r.kegiatan).trim())));
  setTimeout(() => { const t = form.TEMPAT_TUJUAN.value.trim(), d = t ? detectKampung(t) : { found: [] }, M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
    $("#h-tujuan").innerHTML = list.length ? `Kampung SK: ${list.map((k, i) => `${i + 1}. ${esc(title(k.kampung))} <span class="muted">(${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)})</span>`).join(" → ")}` : (t && !d.found.length ? `<span class="muted">Tidak ada kampung SK Transport di teks ini — transport diisi manual.</span>` : ""); }, 0);
  if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0) form.NILAI_UH.value = defUH();
  if (form.TDK_INAP_HOTEL.value === "" || num(form.TDK_INAP_HOTEL.value) === 0) form.TDK_INAP_HOTEL.value = defInap();
  applyJenis(); renderChips(); renderMembers();
  if (r._noBiaya){ syncLama(); applyKampung(); toast("Rincian biaya diisi otomatis dari kampung, jenis & lama hari — periksa lalu Simpan."); }
  else {
    if ($("#autoLama").checked) syncLama();
    if (chips.length) applyKampung(true); else refresh();      // aturan transport terbaru (mis. Lokal × hari)
  }
}
function nextNo(extra: (string | number)[] = [], year: number = new Date().getFullYear()): string {
  const max = [...records.filter(r => stYear(r) === year).map(r => r.NO), ...extra].reduce((m: number, n) => Math.max(m, parseInt(String(n), 10) || 0), 0);
  return String(max + 1).padStart(3, "0");
}
const KEEP = ["NoLengkap","No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD","No_Bend","ALAT_ANGKUTAN_YANG_DIGUNAKAN","TEMPAT_BERANGKAT"];
const DEF_TARIF = 150000;
const defUH = (): number => num(tarifDB.find(t => t.nama.toUpperCase() === "UHAR PERJADIN")?.nilai) || DEF_TARIF;
const defInap = (): number => num(tarifDB.find(t => t.nama.toUpperCase() === "INAP PERJADIN")?.nilai) || DEF_TARIF;
function defaults(): StRecord {
  const last: StRecord = records[records.length - 1] || {};
  const r: StRecord = { TGL_TERBIT_ST: today() };
  for (const k of KEEP) if (last[k] != null) r[k] = last[k];
  r.ALAT_ANGKUTAN_YANG_DIGUNAKAN ??= "Darat"; r.TEMPAT_BERANGKAT ??= "Kampung Semu";
  r.NILAI_UH = defUH(); r.TDK_INAP_HOTEL = defInap();
  if (r.NoLengkap) r.NoLengkap = r.NoLengkap.replace(/\/\d{4}$/, "/" + new Date().getFullYear());
  for (const [f, rs] of SIGN_FIELDS){ const h = roleHolders(rs); if (h.length && !roleOk(codeOf(r[f]), rs)) r[f] = (rs.includes("KEPALA") ? (h.find(p => hasRole(p, ["KEPALA"])) || h[0]) : h[0]).kode; else if (h.length && !r[f]) r[f] = h[0].kode; }
  return r;
}
let _noYear: number | null = null;
function newForm(): void { trShown = TR_BASE; editingId = null; const d = defaults(); _noYear = yrOf(d.TGL_TERBIT_ST) || new Date().getFullYear(); fillForm({ ...d, NO: nextNo([], _noYear) }); setEditFlag(); showSub("data"); }
function setEditFlag(): void { const f = $("#editFlag"), r = editingId && records.find(x => x._id === editingId); f.hidden = !r; f.textContent = r ? `Mengubah surat No. ${r.NO}${stYear(r) ? " · tahun " + stYear(r) : ""}` : ""; }
/* surat baru: tahun tanggal terbit berubah → nomor urut ikut tahun itu */
let _editMoved = false;
function autoNoForYear(): void {
  const y0 = yrOf(form.TGL_TERBIT_ST.value);
  if (editingId){   // surat lama dipindah ke tahun lain → nomor ikut urutan tahun itu (mulai 001)
    const old = records.find(x => x._id === editingId); if (!old || !y0) return;
    if (y0 === stYear(old)){ if (_editMoved){ form.NO.value = old.NO; _editMoved = false; refresh(); toast(`Kembali ke tahun ${y0} — No. urut dikembalikan ke ${old.NO}.`); } return; }
    const nx = nextNo([], y0);
    if (!_editMoved || noKey(form.NO.value) !== noKey(nx)){ form.NO.value = nx; _editMoved = true; refresh(); toast(`Tahun terbit ${y0}: No. urut disesuaikan menjadi ${nx} — penomoran tiap tahun mulai dari 001.`); }
    return;
  }
  const y = y0; if (!y || y === _noYear) return;
  const wasAuto = _noYear == null || noKey(form.NO.value) === noKey(nextNo([], _noYear));
  _noYear = y;
  if (wasAuto || records.some(x => stYear(x) === y && noKey(x.NO) === noKey(form.NO.value))){ form.NO.value = nextNo([], y); refresh(); }
}
form.TGL_TERBIT_ST.addEventListener("change", autoNoForYear);
form.TGL_TERBIT_ST.addEventListener("input", () => setTimeout(autoNoForYear, 0));

function personText(p: Pegawai | undefined): string { return p ? [p.nama, p.nip && p.nip !== "-" ? "NIP " + p.nip : "", p.jabatan, [p.pangkat, p.gol].filter(x => x && x !== "-").join(" ")].filter(Boolean).join(" · ") : ""; }
function refresh(): void {
  if (!formNoInap() && $("#autoLama").checked){ const L = num(form.LAMA_JALAN.value); form.LAMA_UH.value = L || ""; form.LAMA_INAP.value = L ? Math.max(0, L - 1 - formHotelN()) : ""; }
  const r = readForm(), P = pegMap();
  const F = compute(r), n = F._num;
  $("#totTrans").value = "Rp " + rupiah(n.sumTr);
  $("#riilTot").textContent = `Jumlah pengeluaran riil (penginapan + transport): Rp ${rupiah(n.totRiil)}`;
  $$("[data-hxsub]").forEach(e => { const h = hotel2[Number(e.dataset.hxsub)]; e.value = h ? "Rp " + rupiah(num(h.l) * num(h.n)) : ""; });
  { let cnt = 0; for (let i = 1; i <= MAXTR; i++) if (num(form["Nilai" + i].value)) cnt++; $("#h-trans").textContent = `Jumlah ${cnt} baris transport — dihitung ulang otomatis`; }
  form.NOMOR_ST.value = F.NOMOR_ST; angLockUI();
  { const n = $("#makPelNote"); if (n) n.textContent = formPel() ? "· Pelatihan: boleh juga 521213" : ""; }
  { const kg = form.kegiatan.value.trim(), h = $("#h-keg"); if (h){ const ros = rosOfJudul(kg, ST_AKUN(formPel())), mro = pokMap()[normMak(form.MAK.value)]?.ro, ro = mro && ros.includes(mro) ? mro : ros.join(" / ");
      h.innerHTML = $("#kegLain").checked ? `<span class="muted">Kegiatan lainnya — diisi manual; MAK tetap dipilih dari POK (akun perjalanan dinas).</span>` : !kg ? "" : !ro ? `<span class="bad">Bukan judul RO di POK — pilih dari daftar, atau centang "Kegiatan lainnya"</span>` : `RO ${esc(ro)}` + (form.MAK.value && mro && !ros.includes(mro) ? ` · <span class="bad">MAK bukan dari RO ini</span>` : ""); } }
  { const y = yrOf(form.TGL_TERBIT_ST.value) || new Date().getFullYear(), nx = nextNo([], y), h = $("#h-no");
    if (h) h.innerHTML = editingId ? "" : (parseInt(form.NO.value, 10) > parseInt(nx, 10) ? `<span class="bad">Harus berurutan — nomor berikutnya tahun ${y}: ${nx}</span>` : `Nomor berikutnya tahun ${y}: ${nx}`); }
  const kk = kodeFromNL(form.NoLengkap.value), kc = kodeMap()[kk];
  if (document.activeElement !== $("#kodeKlas")) $("#kodeKlas").value = kk;
  $("#h-kode").textContent = kc ? `${kc.d} · ${kodeGroup(kk)}` : (form.NoLengkap.value ? "Kode tidak dikenali di daftar klasifikasi" : "");
  $("#h-kode").classList.toggle("bad", !kc && !!form.NoLengkap.value);
  $$("#f .person").forEach(d => {
    const raw = form[d.dataset.p ?? ""].value.trim(); const p = P[resolvePeg(raw) ?? ""];
    d.textContent = !raw ? "" : p ? personText(p) : "Kode tidak ditemukan di Data Pegawai";
    d.classList.toggle("bad", !!raw && !p);
  });
  $('[data-out="TOTAL_UH"]').value = "Rp " + F.TOTAL_UH;
  $('[data-out="PENG_RIIL"]').value = "Rp " + rupiah(n.totInap);
  const calc: Record<string, string> = { uh: `${n.luh} hari × Rp ${rupiah(n.nuh)}`, inap: `${n.inap} malam × Rp ${rupiah(n.tdk)}`, hotel: !n.lh ? "tidak ada" : F._hotels.length > 1 ? `${F._hotels.length} hotel · ${n.lh} malam` : `${n.lh} malam × Rp ${rupiah(F._hotels[0].n)}${F._hotels[0].t ? " · " + F._hotels[0].t : ""}`,
    lok: F._riilLok.length ? `${F._riilLok.length} rincian` : "tidak ada", bdr: F._riilBdr.length ? `${F._riilBdr.length} rincian` : "tidak ada", tr: `${[...Array(MAXTR)].filter((_, i) => form["KetTransport_" + (i+1)].value || form["Nilai" + (i+1)].value).length} baris` };
  $$("[data-calc]").forEach(e => e.textContent = calc[e.dataset.calc ?? ""]);
  const sums: Record<string, number> = { uh: n.totUH, inap: n.totInap, hotel: n.totHotel, lok: n.totLok, bdr: n.totBdr, tr: n.sumTr, jml: n.jml, tot: n.jmlTotal };
  $('[data-out="TOTAL_HOTEL"]').value = "Rp " + F.TOTAL_HOTEL;
  { const L = num(form.LAMA_JALAN.value), lim = Math.max(0, L - 1), tot = n.inap + n.lh, h = $('[data-calc="hotel"]');
    if (h && L && tot > lim) h.innerHTML = `<span class="bad">Malam hotel (${n.lh}) + malam tanpa hotel (${n.inap}) melebihi ${lim} malam perjalanan</span>`; }
  $$("[data-sum]").forEach(e => e.textContent = "Rp " + rupiah(sums[e.dataset.sum ?? ""]));
  $('[data-out-text="TERBILANG"]').textContent = "Terbilang: " + F.TERBILANG + " Rupiah";
  $("#sumJumlah").textContent = $("#tabSum").textContent = "Rp " + rupiah(n.jmlTotal) + (n.orang > 1 ? ` (${n.orang} orang)` : "");
  { const ps = personCodes(readForm(), P); $$("[data-multi]").forEach(e => e.hidden = ps.length < 2); $$("[data-orang]").forEach(e => e.textContent = String(ps.length));
    $$("[data-orang-list]").forEach(e => e.textContent = ps.map(c => (P[c]?.nama || "").split(",")[0]).join(", "));
    $("#rbPer").hidden = ps.length < 2; $("#rbPer").innerHTML = ps.length < 2 ? "" : `<b>Rincian biaya dibuat untuk tiap orang (${ps.length} orang):</b> ${ps.map(c => esc((P[c]?.nama || "").split(",")[0])).join(" · ")}. Satu file Rincian Biaya berisi kuitansi, rincian &amp; pernyataan untuk masing-masing.`; }
  $("#lamaInfo").textContent = `Lama perjalanan: ${num(form.LAMA_JALAN.value) || "–"} hari`;
  // transport source tags
  for (let i = 1; i <= MAXTR; i++){
    const ket = form["KetTransport_" + i].value;
    const src = /^Biaya Transport Mobil/.test(ket) ? `<span class="tag warn">SK · mobil</span>` : /^Biaya lintasan mobil/i.test(ket) ? (num(form["Nilai" + i].value) < minLintasMobil() ? `<span class="tag warn" style="color:var(--danger)">min Rp ${rupiah(minLintasMobil())}</span>` : `<span class="tag warn">lintasan mobil</span>`) : /^Biaya inap mobil/i.test(ket) ? `<span class="tag warn">inap mobil</span>` : /^Biaya [Ll]intasan/.test(ket) ? `<span class="tag">lintasan</span>`
      : /^Biaya Transport Lokal/.test(ket) ? `<span class="tag ok">SK · lokal</span>` : /^Biaya Transport dari/.test(ket) ? `<span class="tag">SK · ½</span>`
      : AUTO_RE.test(ket) ? `<span class="tag ${/sekali jalan/.test(ket) ? "warn" : ""}">SK · ${/sekali jalan/.test(ket) ? "½" : "PP"}</span>` : (ket || form["Nilai" + i].value ? `<span class="tag ok">manual</span>` : "");
    $(`#trans tr[data-i="${i}"] .src`).innerHTML = src;
  }
  trRows();
  { const pel = form.JENIS.value === "Pelatihan"; $("#tabPel").hidden = !pel; $('.subtabs [data-s="biaya"]').hidden = pel;
    if (!pel && $("#s-pel").classList.contains("on")) showSub("biaya");
    if (pel && $("#s-biaya").classList.contains("on")) showSub("pel");
    if (pel) renderPelTab(); }
  const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value);
  $("#h-lama").innerHTML = (a && b) ? (b < a ? `<span class="bad">Tanggal pulang sebelum tanggal pergi</span>` : `${a.getDate()} ${BULAN[a.getMonth()].slice(0, 3)} – ${fmtDate(b)}`) : (form.TGL_PERGI.value && !a ? `<span class="bad">Tanggal pergi tidak terbaca — tulis mis. 5 Januari 2026</span>` : "Isi tanggal pergi & pulang");
  $("#h-mak").innerHTML = budgetHtml(form.MAK.value, n.jmlTotal, editingId);
  { const le = lokalErr(r), h = $("#h-lokal"); if (h){ h.hidden = !le; h.textContent = le ? "⚠ " + le : ""; } }
  renderPerOrang();
  const cf = findConflicts(readForm(), records, editingId), dw = $("#dupWarn");
  const ob = obConflicts(readForm());
  dw.hidden = !cf.length && !ob.length;
  if (!cf.length && ob.length) dw.innerHTML = `<b>⚠ Petugas sedang dalam rentang OB/kontrak honor:</b><ul style="margin:6px 0 0;padding-left:20px">${ob.slice(0, 8).map(o => `<li>${esc(obMsg(o))}</li>`).join("")}</ul>`;
  if (cf.length) dw.innerHTML = `<b>⚠ Surat tugas tidak bisa dibuat — petugas sudah bertugas pada tanggal yang sama:</b><ul style="margin:6px 0 0;padding-left:20px">${cf.slice(0, 8).map(c => `<li>${esc(c.nama)} — ST ${esc(c.nomor)} (${esc(c.tgl)})</li>`).join("")}</ul>`;
}
form.addEventListener("input", e => {
  const n = tg(e).name;
  if (n === "TGL_PERGI") autoPulang();
  if (n === "TGL_PULANG") autoLama();
  if (n === "LAMA_JALAN"){ if (num(form.LAMA_JALAN.value) >= 1) autoPulang(); else autoUH(); }
  if (["LAMA_JALAN","TGL_PERGI","TGL_PULANG","TEMPAT_BERANGKAT"].includes(n) && chips.length) applyKampung();
  if (n === "TGL_TERBIT_ST"){ const d = parseTgl(tg(e).value); if (d) form.NoLengkap.value = form.NoLengkap.value.replace(/\/\d{4}$/, "/" + d.getFullYear()); }
  refresh();
});
form.addEventListener("change", e => {
  const m = (tg(e).name || "").match(/^KetTransport_(\d+)$/); if (!m) return;
  const t = tg(e).value.trim(); const ref = otherTransRef().find(([k]) => k === t);
  if (ref){ form["Nilai" + m[1]].value = ref[1]; refresh(); return; }
  const k = findKampung(t.replace(/^Transport (PP )?Kabupaten–Kampung /, "").replace(/\s*\(.*\)$/, ""));
  if (k && /kampung/i.test(t)){ const pp = !/sekali jalan/i.test(t); form["Nilai" + m[1]].value = kamValue(k, pp); refresh(); }
});
let trShown = TR_BASE;
function trRows(): void {
  let last = 0; for (let i = 1; i <= MAXTR; i++) if (form["KetTransport_" + i].value || form["Nilai" + i].value) last = i;
  const show = Math.min(MAXTR, Math.max(TR_BASE, trShown, last));
  for (let i = 1; i <= MAXTR; i++) $(`#trans tr[data-i="${i}"]`).hidden = i > show;
  $("#trAdd").disabled = show >= MAXTR;
  $("#trRowInfo").textContent = show > TR_BASE ? `${show} baris ditampilkan (maks. ${MAXTR}). Surat Word ikut menambah baris otomatis.` : `Lebih dari ${TR_BASE} baris? Klik tambah — maks. ${MAXTR} baris.`;
}
$("#bPelXls").onclick = () => downloadPelatihan(readForm()).catch((e: Error) => toast("Gagal: " + e.message));
/* tab 3 · transport pelatihan lokal: transport per orang tersimpan sebagai rincian khusus anggota */
const PEL_KET = "Transport lokal pelatihan";
const pelLunas = (r: StRecord): string => String(r.TGL_PULANG || r.TGL_PERGI || "").trim();   // pelatihan: lunas = tanggal terakhir surat tugas
/** pelatihan: kode yang dikeluarkan dari daftar; uang harian fullday/fullboard per kode */
let pelExcl: string[] = [], pelUH: Record<string, { full?: number; board?: number }> = {};
$("#pelTbl").addEventListener("input", e => { const k = tg(e).dataset.peluh; if (!k) return; const c = tg(e).dataset.c ?? "", o = pelUH[c] ||= {};
  o[k as "full" | "board"] = tg(e).value === "" ? 0 : num(tg(e).value); if (!o.full && !o.board) delete pelUH[c];
  const tr = tg(e).closest<HTMLInputElement>("tr"), x = pelatihanRows(readForm()).find(y => y.c === c); if (x) tr!.querySelector("[data-pj]")!.innerHTML = `<b>${rupiah(x.full + x.board + x.tr)}</b>`;
  refresh(); });
$$("[data-pelapply]").forEach(b => b.onclick = () => { const k = b.dataset.pelapply as "full" | "board", v = num($(k === "full" ? "#pelAllFull" : "#pelAllBoard").value);
  for (const x of pelatihanRows(readForm())){ const o = pelUH[x.c] ||= {}; o[k] = v; if (!o.full && !o.board) delete pelUH[x.c]; }
  refresh(); renderPelTab(); toast(`Uang harian ${k === "full" ? "fullday" : "fullboard"} Rp ${rupiah(v)} diterapkan ke semua petugas.`); });
$("#pelTbl").addEventListener("click", e => { const c = tg(e).closest<HTMLInputElement>("[data-pelx]")?.dataset.pelx; if (!c) return; (document.activeElement as HTMLElement | null)?.blur(); if (!pelExcl.includes(c)) pelExcl.push(c); refresh(); renderPelTab(); toast("Dihapus dari daftar transport pelatihan — tetap tercantum di surat tugas."); });
$("#pelExcl").addEventListener("click", e => { const c = tg(e).closest<HTMLInputElement>("[data-pelback]")?.dataset.pelback; if (!c) return; pelExcl = pelExcl.filter(x => x !== c); refresh(); renderPelTab(); });
const pelSync = (src: HTMLInputElement, field: string): void => { const c = resolvePeg(src.value); if (c){ form[field].value = pegLabel(c); src.value = pegLabel(c); } else if (!src.value.trim()) form[field].value = ""; refresh(); };
$("#pelBend").addEventListener("change", e => pelSync(tg(e), "No_Bend"));
$("#pelPpk").addEventListener("change", e => pelSync(tg(e), "No_PPK"));
$("#bPelPrev").onclick = () => { const r = readForm(); openPreview([r], `Pratinjau daftar transport pelatihan`, false, "pel"); };
function renderPelTab(): void {
  const r = readForm(), rows = pelatihanRows(r), tot = rows.reduce((a, x) => a + x.full + x.board + x.tr, 0), tr = rows.reduce((a, x) => a + x.tr, 0);
  $("#pelCount").textContent = rows.length + " petugas"; $("#tabPelSum").textContent = "Rp " + rupiah(tot);
  $("#sumJumlah").textContent = "Rp " + rupiah(tot) + (rows.length > 1 ? ` (${rows.length} orang)` : "");
  $("#pelTgl").value = tglLong(r.TGL_PERGI, r.TGL_PULANG);
  if (!$("#pelTbl").contains(document.activeElement)){
    $("#pelTbl tbody").innerHTML = rows.map((x, i) => `<tr data-c="${esc(x.c)}"><td class="muted">${i + 1}</td><td>${esc(x.nama)}${perOrang[x.c]?.trans ? ` <span class="tag warn">khusus</span>` : ""}</td><td>${esc(x.gol || "–")}</td><td>${esc(x.nip)}</td><td>${esc(x.jab)}</td><td class="num">${x.lama}</td>
      <td><input type="number" min="0" step="1000" data-peluh="full" data-c="${esc(x.c)}" value="${x.full}" style="text-align:right"></td>
      <td><input type="number" min="0" step="1000" data-peluh="board" data-c="${esc(x.c)}" value="${x.board}" style="text-align:right"></td>
      <td><input type="number" min="0" step="1000" data-pel="${esc(x.c)}" value="${x.tr}" style="text-align:right"></td><td class="num" data-pj><b>${rupiah(x.full + x.board + x.tr)}</b></td><td><button type="button" class="ib del" data-pelx="${esc(x.c)}" title="Hapus dari daftar transport (tetap di surat tugas)">${IC.del}</button></td></tr>`).join("")
      || `<tr><td colspan="11" class="muted" style="text-align:center;padding:18px">Isi pelaksana / anggota tim di tab 1 · Data Surat.</td></tr>`;
  }
  $("#pelFoot").innerHTML = rows.length ? `<tr><td></td><td colspan="5"><b>Jumlah</b></td><td class="num"><b>${rupiah(rows.reduce((a, x) => a + x.full, 0))}</b></td><td class="num"><b>${rupiah(rows.reduce((a, x) => a + x.board, 0))}</b></td><td class="num"><b>${rupiah(tr)}</b></td><td class="num"><b>${rupiah(tot)}</b></td><td></td></tr>` : "";
  { const P = pegMap(), ex = pelExcl.filter(c => P[c]); $("#pelExcl").innerHTML = ex.length ? `Tidak dimasukkan ke daftar: ${ex.map(c => `<span class="chip">${esc(P[c].nama.split(",")[0])}<button type="button" class="x" data-pelback="${esc(c)}" title="Masukkan lagi">↺</button></span>`).join(" ")}` : ""; }
  const act = document.activeElement;
  if (act !== $("#pelBend")) $("#pelBend").value = form.No_Bend.value;
  if (act !== $("#pelPpk")) $("#pelPpk").value = form.No_PPK.value;
  $("#pelKui").value = pelLunas(r);
  $("#pelTerb").textContent = rows.length ? "Terbilang: " + capFirst(terbilang(tot)) + " Rupiah" : "";
  $("#pelInfo").textContent = r.MAK ? (pokMap()[normMak(r.MAK)] ? "" : "MAK tidak ditemukan di POK — baris Program–Akun tidak lengkap.") : "MAK belum diisi (tab 1) — baris Program–Akun kosong.";
}
function setPelTr(c: string, v: unknown): void {
  const base = readForm(); delete base._perOrang; const baseTr = compute({ ...base, KD_NAMA_SPD: c })._num.totTr;
  const o = perOrang[c] ||= {};
  if (v === "" || num(v) === baseTr) delete o.trans; else o.trans = [[PEL_KET, num(v)]];
  poClean(c);
}
$("#pelTbl").addEventListener("input", e => { const c = tg(e).dataset.pel; if (c == null) return; setPelTr(c, tg(e).value); refresh(); renderPerOrang(true);
  const tr = tg(e).closest<HTMLInputElement>("tr"), x = pelatihanRows(readForm()).find(y => y.c === c); if (x) tr!.querySelector("[data-pj]")!.innerHTML = `<b>${rupiah(x.full + x.board + x.tr)}</b>`; });
$("#pelTbl").addEventListener("focusout", () => setTimeout(() => { if (!$("#pelTbl").contains(document.activeElement)) renderPelTab(); }, 0));
$("#pelApply").onclick = () => { const v = $("#pelAll").value; if (v === "") return toast("Isi nominal transport dulu.");
  for (const x of pelatihanRows(readForm())) setPelTr(x.c, v); refresh(); renderPerOrang(true); renderPelTab(); toast(`Transport lokal Rp ${rupiah(num(v))} diterapkan ke semua petugas.`); };
$("#pelAsal").addEventListener("input", () => LS.set("st.pelAsal", $("#pelAsal").value.trim()));
{ const a = LS.get("st.pelAsal", null); if (a) $("#pelAsal").value = a; }
{ const d = LS.get("st.pelTrDef", ""); if (d !== "" && d != null) $("#pelAll").value = d; }
$("#trAdd").onclick = () => { let last = 0; for (let i = 1; i <= MAXTR; i++) if (!$(`#trans tr[data-i="${i}"]`).hidden) last = i; trShown = Math.min(MAXTR, last + 1); trRows(); form["KetTransport_" + trShown].focus(); };
$("#trans").addEventListener("click", e => { const i = tg(e).dataset.clr; if (!i) return; form["KetTransport_" + i].value = ""; form["Nilai" + i].value = ""; refresh(); });
/* tanggal pergi / lama berubah → tanggal pulang = pergi + lama − 1 (lama kosong → 1 hari) */
function autoPulang(): void {
  const a = parseTgl(form.TGL_PERGI.value); if (!a){ form.TGL_PULANG.value = ""; return; }
  if (!(num(form.LAMA_JALAN.value) >= 1)) form.LAMA_JALAN.value = 1;
  form.TGL_PULANG.value = tglPulang(form.TGL_PERGI.value, form.LAMA_JALAN.value); autoUH();
}
/* tanggal pulang diisi dari luar (impor / data lama) → lama dihitung dari kedua tanggal */
function autoLama(): void {
  const a = parseTgl(form.TGL_PERGI.value), b = parseTgl(form.TGL_PULANG.value);
  if (a && b && b >= a){ form.LAMA_JALAN.value = dayDiff(a, b); autoUH(); }
  else if (a && !form.TGL_PULANG.value.trim()) autoPulang();
}
function autoUH(){ syncLama(); }
const tarifDefault = (n: string): number | string => { const t = tarifDB.find(t => t.nama.toUpperCase() === n); return t ? t.nilai : ""; };
/* Remote + otomatis: lama UH = lama perjalanan, inap = lama − 1, tarif kosong → tarif perjadin */
function syncLama(){
  if (formNoUH()){ form.LAMA_UH.value = 0; form.LAMA_INAP.value = 0; return; }
  const L = num(form.LAMA_JALAN.value);
  if (form.JENIS.value === JEN_TU){   // Translok+Uhar: inap 0; uang harian diisi sendiri (bawaan = lama perjalanan, tarif perjadin)
    form.LAMA_INAP.value = 0; if (form.LAMA_UH.value === "") form.LAMA_UH.value = L || "";
    if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0) form.NILAI_UH.value = defUH();
    return; }
  if (!$("#autoLama").checked) return;
  form.LAMA_UH.value = L || ""; form.LAMA_INAP.value = L ? Math.max(0, L - 1 - formHotelN()) : "";
  if (form.NILAI_UH.value === "" || num(form.NILAI_UH.value) === 0) form.NILAI_UH.value = defUH();
  if (form.TDK_INAP_HOTEL.value === "" || num(form.TDK_INAP_HOTEL.value) === 0) form.TDK_INAP_HOTEL.value = defInap();
}
$("#autoLama").addEventListener("change", () => { applyJenis(); syncLama(); refresh(); });
function applyJenis(){
  const lok = formNoUH(), noI = formNoInap(), tu = form.JENIS.value === JEN_TU, jen = form.JENIS.value, auto = $("#autoLama").checked;
  form.LAMA_UH.disabled = lok; form.LAMA_INAP.disabled = noI;
  form.LAMA_HOTEL.disabled = form.TARIF_HOTEL.disabled = form.HOTEL_TEMPAT.disabled = noI;
  form.LAMA_UH.readOnly = !lok && !tu && auto; form.LAMA_INAP.readOnly = !noI && auto;
  $$("[data-remote]").forEach(e => e.hidden = noI);
  $$("[data-autohint]").forEach(e => { const uh = e.dataset.autohint === "uh"; e.textContent = (uh ? lok : noI) ? jen + " = 0" : uh && tu ? "Diisi sendiri — bawaan = lama perjalanan" : auto ? (uh ? "Otomatis = lama perjalanan" : "Otomatis = lama perjalanan − 1 − malam hotel") : "Diisi manual"; });
  $$("[data-lokal]").forEach(e => e.hidden = !lok); $$("[data-noinap]").forEach(e => e.hidden = !noI); $$("[data-jenlbl]").forEach(e => e.textContent = jen);
  renderHx();
  $("#trMode").textContent = tu ? "— Translok+Uhar: transport lokal tiap kampung = banyak hari × tarif SK (kampung berlabel Lokal masuk ke B3 · Uang Transport Lokal), ditambah uang harian" : jen === "Lokal" ? "— Lokal: Biaya Transport Lokal tiap kampung = banyak hari × tarif SK (klik PP untuk ½); tercatat di B3 · Uang Transport Lokal" : jen === "Pelatihan" ? "— Pelatihan: transport berangkat & pulang (½ tarif SK masing-masing) + lintasan; tanpa uang harian & inap" : "— Remote: berangkat & pulang masing-masing ½ tarif SK, ditambah biaya lintasan antar kampung";
  $("#h-jenis").textContent = lok ? `${jen}: uang harian & inap = 0` : tu ? "Transport lokal + uang harian (bisa diisi); inap & hotel = 0" : "";
}
form.JENIS.addEventListener("change", () => { form.JENIS.dataset.touched = "1"; if (form.JENIS.value === JEN_TU) form.LAMA_UH.value = num(form.LAMA_JALAN.value) || ""; autoUH(); applyJenis(); applyKampung(); });
$$('#f input[type=date][data-for]').forEach(d => d.addEventListener("change", () => {
  if (!d.value) return; const t = form[d.dataset.for ?? ""]; t.value = fmtTgl(d.value);
  t.dispatchEvent(new Event("input", { bubbles: true }));
}));
$$("#f .pick").forEach(i => i.addEventListener("change", () => { const c = resolvePeg(i.value); if (c) i.value = pegLabel(c); refresh(); }));
/* presets (uang harian / inap) */
function fillPresets(){
  $$("select.preset").forEach(s => {
    const re = new RegExp(s.dataset.re ?? "", "i");
    s.innerHTML = `<option value="">Pilih tarif…</option>` + tarifDB.filter(t => re.test(t.grup)).map(t => `<option value="${t.nilai}">${esc(title(t.nama))} — ${rupiah(num(t.nilai))}</option>`).join("");
  });
  for (const w of ["lok", "bdr"]) $(w === "lok" ? "#rlLokPreset" : "#rlBdrPreset").innerHTML = `<option value="">+ Tambah dari tarif ${w === "lok" ? "translok" : "mobil bandara"}…</option>` + riilPresets(w).map(([k, v], i) => `<option value="${i}">${esc(k)} — Rp ${rupiah(num(v))}</option>`).join("");
  $("#trPreset").innerHTML = `<option value="">+ Tambah baris dari tarif lain (mobil, bandara, translok)…</option>` + otherTransRef().map(([k, v], i) => `<option value="${i}">${esc(k)} — Rp ${rupiah(num(v))}</option>`).join("");
}
$$("#f select.preset").forEach(s => s.addEventListener("change", () => { if (!s.value) return; form[s.dataset.for ?? ""].value = s.value; s.value = ""; refresh(); }));
$("#trPreset").addEventListener("change", e => {
  const ref = otherTransRef()[+tg(e).value]; tg(e).value = ""; if (!ref) return;
  for (let i = 1; i <= MAXTR; i++) if (!form["KetTransport_" + i].value && !form["Nilai" + i].value){ form["KetTransport_" + i].value = ref[0]; form["Nilai" + i].value = ref[1]; refresh(); return; }
  toast(`Rincian transport sudah penuh (${MAXTR} baris).`);
});
/* kode klasifikasi */
$("#kodeKlas").addEventListener("input", e => { const c = kodeMap()[tg(e).value.trim().toUpperCase()]; if (c){ form.NoLengkap.value = composeNL(c.k, form.NoLengkap.value, form.TGL_TERBIT_ST.value); refresh(); } });
$("#kodeKlas").addEventListener("change", e => {
  const { c, n } = lookupKode(tg(e).value);
  if (c){ tg(e).value = c.k; form.NoLengkap.value = composeNL(c.k, form.NoLengkap.value, form.TGL_TERBIT_ST.value); }
  else if (n) toast(`${n} kode cocok — pilih dari daftar.`);
  refresh();
});
/* kampung chips (rendered in Data Surat and Rincian Biaya) */
function renderChips(){
  const M = kamByKey();
  const html = chips.map((c, i) => { const k = M[c.k]; if (!k) return `<span class="chip">${esc(c.k)} <small class="bad">tidak ada di SK</small><button type="button" class="x" data-x="${i}">×</button></span>`;
    const lok = formTrLokal();
    return `<span class="chip"><b style="color:var(--muted);font-size:11px">${i+1}</b> ${esc(title(k.kampung))} <small>${esc(title(k.distrik))} · SK Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""}</small>${lok ? `<button type="button" class="pp ${c.pp ? "" : "half"}" data-pp="${i}" title="Klik untuk ganti PP / sekali jalan">${c.pp ? "PP" : "½ sekali jalan"}</button>` : ""}${i ? `<button type="button" class="x" data-left="${i}" title="Pindah ke kiri (urutan rute)">‹</button>` : ""}<button type="button" class="x" data-x="${i}" title="Hapus">×</button></span>`; }).join("");
  $$(".kchips").forEach(d => d.innerHTML = html);
}
function applyKampung(keepTujuan?: boolean): void {
  const r = readForm();
  const over = applyKampungToRec(r);
  for (let i = 1; i <= MAXTR; i++){ form["KetTransport_" + i].value = r["KetTransport_" + i] ?? ""; form["Nilai" + i].value = r["Nilai" + i] ?? ""; }
  riilLok = riilRows(r._riilLok); renderRiil();
  const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
  if (keepTujuan !== true){ setTujuanText(); $("#h-tujuan").textContent = ""; }
  if (over) toast(`Rincian transport lebih dari ${MAXTR} baris — sebagian tidak masuk.`);
  renderChips(); refresh();
}
/* "Kegiatan lainnya": kegiatan diketik manual (tidak harus judul RO POK); MAK tetap akun perjalanan dinas */
function kegMode(inp: HTMLInputElement, chk: HTMLInputElement, lain: boolean): void {
  chk.checked = !!lain;
  const lbl = inp.closest<HTMLInputElement>("div")!.querySelector(".keghd > label");
  if (lain){ delete inp.dataset.ac; inp.setAttribute("list", "dl-kegiatan"); inp.placeholder = "Tulis nama kegiatan, mis. Rapat koordinasi BPS Provinsi"; if (lbl) lbl.textContent = "Kegiatan — lainnya (diisi manual)"; }
  else { inp.dataset.ac = "pokj"; inp.removeAttribute("list"); inp.placeholder = "Cari RO di POK, mis. angkatan kerja atau 2905.BMA.004"; if (lbl) lbl.textContent = "Kegiatan — judul RO dari POK"; }
}
$("#kegLain").addEventListener("change", e => { kegMode(form.kegiatan, tg(e), tg(e).checked); if (!tg(e).checked && form.kegiatan.value && !pokJudul(ST_AKUN(formPel())).has(form.kegiatan.value.trim())) form.kegiatan.value = ""; form.kegiatan.focus(); refresh(); });
$("#mKegLain").addEventListener("change", e => { const inp = mIn("kegiatan"); kegMode(inp, tg(e), tg(e).checked); if (!tg(e).checked && inp.value && !pokJudul().has(inp.value.trim())) inp.value = ""; massCommon = readCommon(); persistMass(); updateMassInfo(); inp.focus(); });
let tujLuar: string[] = [];   // (tidak dipakai lagi — tujuan ditulis sebagai teks biasa)
function renderLuar(){}
function setTujuanText(){ const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean); if (!form.TEMPAT_TUJUAN.value.trim() && list.length) form.TEMPAT_TUJUAN.value = tujuanText(list); }
function addKampung(){
  const inp = $("#kamPick"), q = inp.value.trim(); if (!q) return;
  // 1) pilihan dari daftar (label lengkap) atau satu nama persis — huruf besar/kecil tidak berpengaruh
  let list = [];
  const one = kIdx().label.get(q) || findKampung(q);
  if (one) list = [one];
  else {
    // 2) teks tempelan / beberapa nama sekaligus: "KAMBUSKATO UTARA, kambuskato dan IsUsU"
    const d = detectKampung(q);
    if (d.found.length){ list = d.found; if (d.unknown.length) setTimeout(() => toast(`Tidak dikenali di SK: ${d.unknown.slice(0, 3).join(", ")}`), 1600); }
    else {
      // 3) potongan nama (mis. "kambus") → kalau hanya satu yang cocok, pakai itu
      const lq = acNorm(q).replace(/^(kampung|kp\.?|kelurahan)\s+/, "");
      const hits = kampungDB.filter(x => acNorm(x.kampung).includes(lq));
      if (hits.length === 1) list = hits;
      else if (hits.length > 1){ toast(`${hits.length} kampung cocok — pilih dari daftar.`); return; }
      else {   // bukan kampung SK → tetap jadi tujuan (chip kuning "luar SK"), transport diisi manual
        if (!tujLuar.some(t => acNorm(t) === acNorm(q))) tujLuar.push(q);
        inp.value = ""; renderLuar(); setTujuanText();
        $("#h-tujuan").innerHTML = `"${esc(q)}" bukan kampung di SK Transport — tetap ditulis sebagai tujuan; biaya transportnya diisi manual di Rincian Biaya.`;
        refresh(); return;
      }
    }
  }
  inp.value = "";
  const add = list.filter(k => !chips.some(c => c.k === kKey(k)));
  if (!add.length) return toast(list.length > 1 ? "Semua kampung itu sudah dipilih." : "Kampung sudah dipilih.");
  for (const k of add) chips.push({ k: kKey(k), pp: true });
  if (add.length > 1) toast(`${add.length} kampung ditambahkan: ${add.map(k => title(k.kampung)).join(", ")}`);
  if (!form.JENIS.dataset.touched){   // usulan otomatis: semua kampung bertanda "Lokal" di SK → Lokal
    const M = kamByKey(), all = chips.map(c => M[c.k]).filter(Boolean);
    const want = all.length && all.every(x => kamLokal(x)) ? "Lokal" : "Remote";
    if (form.JENIS.value !== want){ form.JENIS.value = want; autoUH(); applyJenis(); toast(`Jenis perjalanan diset ${want} (sesuai keterangan SK). Bisa diubah.`); }
  }
  applyKampung();
}
function suggestJenis(){
  if (form.JENIS.dataset.touched) return;
  const M = kamByKey(), all = chips.map(c => M[c.k]).filter(Boolean);
  const want = all.length && all.every(x => kamLokal(x)) ? "Lokal" : "Remote";
  if (form.JENIS.value !== want){ form.JENIS.value = want; autoUH(); applyJenis(); }
}
/* Tempat tujuan → kampung tujuan (saat teks ditempel, Enter, atau pindah kolom) */
function tujuanToChips(showToast?: boolean): void {
  const txt = form.TEMPAT_TUJUAN.value.trim(), h = $("#h-tujuan");
  const { found, unknown } = txt ? detectKampung(txt) : { found: [], unknown: [] };
  const old = new Map(chips.map(c => [c.k, c.pp]));
  const next = found.map(k => ({ k: kKey(k), pp: old.get(kKey(k)) ?? true }));
  const luar = unknown.filter(u => !/^(dan|ke|di|kampung|distrik|kab(upaten)?)$/i.test(u.trim()));
  h.innerHTML = !txt ? "" : (found.length ? `Terdeteksi <b>${found.length} kampung SK</b>: ${found.map((k, i) => `${i + 1}. ${esc(title(k.kampung))} <span class="muted">(${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""})</span>`).join(" → ")}` : `<span class="muted">Tidak ada kampung SK Transport di teks ini — biaya transport diisi manual di Rincian Biaya.</span>`)
    + (found.length && luar.length ? ` · <span class="bad">di luar SK (transport manual): ${esc(luar.slice(0, 4).map(u => title(u)).join(", "))}</span>` : "");
  const same = next.length === chips.length && next.every((c, i) => c.k === chips[i].k);
  if (same) return;
  chips = next; suggestJenis(); applyKampung(true);
  if (showToast && found.length) toast(`${found.length} kampung tujuan terdeteksi dari teks.`);
}
/* tombol di Rincian Biaya → C · Transport */
$("#trSync").onclick = () => {
  const txt = form.TEMPAT_TUJUAN.value.trim(), info = $("#trSyncInfo");
  let found: Kampung[] = [], unknown: string[] = [];
  if (txt) ({ found, unknown } = detectKampung(txt));
  if (!found.length && !chips.length){
    info.innerHTML = `<span class="bad">Tidak ada kampung yang dikenali dari Tempat tujuan${txt ? ` ("${esc(txt.slice(0, 60))}")` : " (kolom masih kosong)"}.</span> Isi Tempat tujuan di tab Data Surat, mis. "Kampung Fiane, Isme dan Semu".`;
    return toast("Tempat tujuan belum berisi kampung yang dikenali.");
  }
  if (found.length){
    const old = new Map(chips.map(c => [c.k, c.pp]));
    chips = found.map(k => ({ k: kKey(k), pp: old.get(kKey(k)) ?? true }));
    suggestJenis();
  }
  // transport khusus anggota ikut disamakan?
  const custom = Object.entries(perOrang).filter(([, o]) => o.trans).map(([c]) => c);
  if (custom.length && confirm(`${custom.length} anggota punya transport khusus. Samakan juga dengan transport hasil penyesuaian ini?`)){
    for (const c of custom){ delete perOrang[c].trans; delete perOrang[c].riilLok; poClean(c); }
  }
  applyKampung(true);
  const M = kamByKey(), list = chips.map(c => M[c.k]).filter(Boolean);
  let manual = 0; for (let i = 1; i <= MAXTR; i++){ const k = form["KetTransport_" + i].value; if (k && !AUTO_RE.test(k)) manual++; }
  info.innerHTML = `Disesuaikan dengan <b>${list.length} kampung</b>: ${list.map(k => esc(title(k.kampung))).join(" → ")} · jenis <b>${esc(form.JENIS.value)}</b>, ${num(form.LAMA_JALAN.value) || 1} hari`
    + (unknown.length ? ` · <span class="bad">tidak dikenali: ${esc(unknown.slice(0, 4).join(", "))}</span>` : "")
    + (manual ? ` · ${manual} baris manual tetap dipertahankan` : "")
    + (!found.length ? " · (Tempat tujuan tidak berisi kampung SK — memakai kampung yang sudah dipilih)" : "");
  $("#h-tujuan").innerHTML = found.length ? `Terdeteksi <b>${found.length} kampung</b>: ${found.map(k => esc(title(k.kampung))).join(" → ")}` : "";
  toast("Transport disesuaikan dengan kampung tujuan.");
};
form.TEMPAT_TUJUAN.addEventListener("paste", () => setTimeout(() => tujuanToChips(true), 0));
form.TEMPAT_TUJUAN.addEventListener("change", () => tujuanToChips(false));
form.TEMPAT_TUJUAN.addEventListener("keydown", (e: KeyboardEvent) => { if (e.key === "Enter"){ e.preventDefault(); tujuanToChips(true); } });
form.TEMPAT_TUJUAN.addEventListener("input", debounce(() => tujuanToChips(false), 350));
document.addEventListener("click", e => {
  if (!tg(e).closest<HTMLInputElement>(".kchips")) return;
  const x = tg(e).dataset.x, pp = tg(e).dataset.pp;
  if (x != null){ chips.splice(+x, 1); applyKampung(); }
  const lf = tg(e).dataset.left; if (lf != null){ const i = +lf; [chips[i-1], chips[i]] = [chips[i], chips[i-1]]; applyKampung(); }
  if (pp != null){ chips[+pp].pp = !chips[+pp].pp; applyKampung(); }
});
/* anggota tim — hanya bila pelaksana "Terlampir" (kosong → otomatis Terlampir saat anggota ditambah) */
function angLocked(): boolean { const v = form.KD_NAMA_SPD.value.trim(); if (!v) return false; const c = resolvePeg(v); return !(c === "999" || /^terlampir$/i.test(v) || /terlampir/i.test(pegMap()[c ?? ""]?.nama || "")); }
function angLockUI(): void { const L = angLocked(); $("#angPick").disabled = L; $("#angAdd").disabled = L;
  $("#angPick").placeholder = L ? "Pelaksana bukan Terlampir — anggota lampiran tidak bisa dipilih" : "Ketik nama anggota lalu pilih / Enter (boleh lebih dari 5 orang)";
  $("#angLockNote").hidden = !L; }
function renderMembers(){
  const P = pegMap();
  $("#angTbl tbody").innerHTML = members.map((c, i) => { const p = P[c];
    return `<tr><td>${i+1}.</td><td>${p ? esc(p.nama) : `<span class="bad">Kode ${esc(c)} tidak ditemukan</span>`}</td><td>${esc(p?.nip)}</td><td>${esc([p?.pangkat, p?.gol].filter(x => x && x !== "-").join(" / "))}</td><td>${esc(p?.jabatan)}</td>
    <td style="white-space:nowrap"><button class="btn sm" type="button" data-up="${i}" ${i ? "" : "disabled"}>↑</button> <button class="btn sm" type="button" data-dn="${i}" ${i < members.length - 1 ? "" : "disabled"}>↓</button> <button class="btn sm del" type="button" data-rm="${i}">×</button></td></tr>`; }).join("")
    || `<tr><td colspan="6" class="muted">Belum ada anggota — surat untuk satu orang tidak memerlukan lampiran.</td></tr>`;
  $("#angCount").textContent = members.length + " orang";
}
function addMember(){
  const inp = $("#angPick"), c = resolvePeg(inp.value);
  if (!inp.value.trim()) return;
  if (angLocked()){ inp.value = ""; return toast("Anggota lampiran hanya bisa dipilih bila Pelaksana diisi Terlampir.", "warn"); }
  if (!c) return toast("Pegawai tidak ditemukan. Tambahkan di tab Pegawai.");
  inp.value = "";
  if (members.includes(c)) return toast(`${pegMap()[c]?.nama || "Petugas ini"} sudah ada di daftar anggota — petugas yang sama tidak boleh dipilih dua kali.`, "warn");
  const cf = findConflicts({ ...readForm(), KD_NAMA_SPD: c, lampiran: [], KodeLampiran1: undefined }, records, editingId);
  if (cf.length) toast(`⚠ ${cf[0].nama.split(",")[0]} sudah bertugas ${cf[0].tgl} (ST ${cf[0].nomor}).`);
  members.push(c);
  if (!form.KD_NAMA_SPD.value.trim() && pegMap()["999"]) form.KD_NAMA_SPD.value = pegLabel("999");
  renderMembers(); refresh();
}
$("#angAdd").onclick = addMember;
$("#angPick").addEventListener("keydown", e => { if (e.key === "Enter"){ e.preventDefault(); addMember(); } });
$("#angPick").addEventListener("input", e => { if (isPegName(tg(e).value)) addMember(); });
$("#angTbl").addEventListener("click", e => {
  const d = tg(e).dataset; let i;
  if (d.rm != null) members.splice(+d.rm, 1);
  else if (d.up != null){ i = +d.up; [members[i-1], members[i]] = [members[i], members[i-1]]; }
  else if (d.dn != null){ i = +d.dn; [members[i+1], members[i]] = [members[i], members[i+1]]; }
  else return;
  renderMembers(); refresh();
});

/* ---- petugas ganda: nama sama + tanggal bertumpuk ---- */
function personsOf(r: StRecord, P: Record<string, Pegawai> = pegMap()): { key: string; nama: string }[] {
  const codes = [...new Set([r.KD_NAMA_SPD, ...lampOf(r)].map(codeOf).filter(c => c && c !== "999"))];
  return codes.map(c => P[c]).filter(p => p && !/^terlampir$/i.test(p.nama.trim())).map(p => ({ key: normName(p.nama), nama: p.nama }));
}
/* ---- OB / kontrak honor: petugas terikat pada rentang tanggal tertentu ---- */
const makRO = (m: unknown): string => { const p = normMak(m).split("."); return p.length >= 3 ? p.slice(0, 3).join(".") : ""; };   // mis. 2902.FAN.ZZI
const isoOf = (t: unknown): string => { const d = parseTgl(t); return d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}` : ""; };
/** petugas yang terikat OB/kontrak honor pada rentang surat */
interface ObConflict { nama: string; mit: boolean; judul: string; per: string; hro: string }
function obConflicts(r: StRecord): ObConflict[] {
  const R0 = rangeOf(r); if (!R0 || !R0.a || typeof honorDB === "undefined") return [];
  const P = pegMap(), people = new Set(personCodes(r, P)), out: ObConflict[] = [], ro = makRO(r.MAK);
  for (const h of honorDB){
    if (!(h.rows || []).some(x => x.unit === "OB")) continue;
    const fr = (h.rows || []).map(x => parseTgl(x.obFrom)?.getTime()).filter((t): t is number => t != null), to = (h.rows || []).map(x => parseTgl(x.obTo)?.getTime()).filter((t): t is number => t != null);
    const a = parseTgl(h.obFrom) || (fr.length ? new Date(Math.min(...fr)) : null), b = parseTgl(h.obTo) || (to.length ? new Date(Math.max(...to)) : a); if (!a || !b) continue;
    for (const x of h.rows){
    if (!x.c || !people.has(String(x.c))) continue;
    if (!(R0.a <= b && a <= R0.b)) continue;
    const p = P[x.c] || {}, hro = makRO(h.MAK), same = !!hro && hro === ro, mit = isMitra(p);
    if (mit ? same : (same && isPelatihan(r))) continue;   // mitra: MAK kegiatan sama; pegawai: Pelatihan + MAK kegiatan sama
    out.push({ nama: String(p.nama || x.nama || x.c).split(",")[0], mit, judul: h.judul2 || h.judul1 || "honor", per: `${fmtDate(a)} – ${fmtDate(b)}`, hro });
  } }
  return out;
}
const obMsg = (o: ObConflict): string => o.mit
  ? `${o.nama} (mitra) terikat OB/kontrak "${o.judul}" pada ${o.per} — surat tugas di rentang ini hanya boleh dengan MAK kegiatan yang sama (${o.hro || "MAK honor belum diisi"}).`
  : `${o.nama} (pegawai) terikat OB/kontrak "${o.judul}" pada ${o.per} — hanya boleh surat tugas jenis Pelatihan dengan MAK kegiatan yang sama (${o.hro || "MAK honor belum diisi"}).`;
/** rentang tanggal surat; raw = teks tanggal bila tidak terbaca (dibandingkan apa adanya) */
type StRange = { a: Date; b: Date; raw?: undefined } | { a?: undefined; b?: undefined; raw: string };
function rangeOf(r: StRecord): StRange | null {
  const a = parseTgl(r.TGL_PERGI); const b = parseTgl(r.TGL_PULANG) || a;
  if (a && b) return { a, b: b < a ? a : b };
  return r.TGL_PERGI ? { raw: String(r.TGL_PERGI).trim().toLowerCase() + "|" + String(r.TGL_PULANG || "").trim().toLowerCase() } : null;
}
const overlaps = (x: StRange | null, y: StRange | null): boolean => !!(x && y) && (x.a && y.a ? x.a <= y.b! && y.a <= x.b! : !!x.raw && x.raw === y.raw);
/** petugas yang sudah bertugas di surat lain pada tanggal yang bertumpuk */
interface StConflict { nama: string; no: unknown; nomor: string; tgl: string }
function findConflicts(r: StRecord, pool: StRecord[], excludeNO: string | null, P: Record<string, Pegawai> = pegMap()): StConflict[] {
  const R0 = rangeOf(r); if (!R0) return [];
  const mine = personsOf(r, P); if (!mine.length) return [];
  const keys = new Set(mine.map(p => p.key)), out: StConflict[] = [];
  for (const x of pool){
    if (excludeNO != null && x._id === excludeNO) continue;
    if (!overlaps(R0, rangeOf(x))) continue;
    for (const p of personsOf(x, P)) if (keys.has(p.key))
      out.push({ nama: p.nama, no: x.NO, nomor: "B-" + x.NO + (x.NoLengkap || ""), tgl: (x.TGL_PERGI || "") + (x.TGL_PULANG && x.TGL_PULANG !== x.TGL_PERGI ? " – " + x.TGL_PULANG : "") });
  }
  return out;
}
/* ---- anggaran POK ---- */
const normMak = (s: unknown): string => String(s || "").replace(/\s+/g, "").toUpperCase();
const PJ_AKUN = ["524111", "524113", "524114"], HO_AKUN = ["521213"];
const akunOf = (m: unknown): string => normMak(m).split(".").pop() ?? "";
/* akun MAK yang boleh untuk surat tugas: perjalanan dinas; jenis Pelatihan juga boleh akun honor 521213 */
const ST_AKUN = (pel: boolean): string[] => pel ? [...PJ_AKUN, ...HO_AKUN] : PJ_AKUN;
const akunST = (r: StRecord): string[] => ST_AKUN(isPelatihan(r));
const akunTxt = (ak: string[]): string => ak.join(" / ");
const formPel = () => form.JENIS.value === "Pelatihan";
const acPel = (el: HTMLElement | null): boolean => !el ? false : el.closest<HTMLInputElement>("#f") ? formPel() : el.closest<HTMLInputElement>("#mCommon") ? massRows.some(r => r.jenis === "Pelatihan") : false;
const pokJudul = (ak: string[] = PJ_AKUN): Set<string> => new Set(pokDB.akun.filter(a => ak.includes(a.akun)).map(a => String(a.roNama).trim()));
/** semua kode RO yang berjudul t (judul RO bisa sama di beberapa kegiatan, mis. 8130.BMA.007 & 2910.BMA.007) */
const rosOfJudul = (t: unknown, ak: string[] = PJ_AKUN): string[] => [...new Set(pokDB.akun.filter(a => ak.includes(a.akun) && String(a.roNama).trim() === String(t || "").trim()).map(a => a.ro))];
const roOfJudul = (t: unknown, ak: string[] = PJ_AKUN): string | null => { const a = pokDB.akun.find(a => ak.includes(a.akun) && String(a.roNama).trim() === String(t || "").trim()); return a ? a.ro : null; };
const pokMap = () => Object.fromEntries(pokDB.akun.map(a => [a.mak, a]));
function usage(): Record<string, { j: number; n: number }> {
  if (_use) return _use;
  _use = {};
  for (const r of records){ const k = normMak(r.MAK); if (!k) continue; const u = _use[k] ||= { j: 0, n: 0 }; u.j += computeC(r)._num.jmlTotal; u.n++; }
  for (const h of (honorDB || [])){ const k = normMak(h.MAK); if (!k) continue; const u = _use[k] ||= { j: 0, n: 0 }; u.j += hoTot(h).bruto; u.n++; }
  return _use;
}
function budgetOf(mak: unknown, excludeNO?: string | null) {
  const k = normMak(mak), a = pokMap()[k]; if (!a) return null;
  let j = usage()[k]?.j || 0, n = usage()[k]?.n || 0;
  if (excludeNO != null){ const r = records.find(x => x._id === excludeNO); if (r && normMak(r.MAK) === k){ j -= compute(r)._num.jml; n--; } }
  return { a, pagu: a.pagu, blokir: a.blokir, terpakai: j, n, sisa: a.pagu - a.blokir - j };
}
function budgetHtml(mak: unknown, add: number, excludeNO: string | null, addLabel = "surat ini"): string {
  if (!mak) return "";
  const b = budgetOf(mak, excludeNO);
  if (!b) return `<span class="neg">MAK tidak ditemukan di POK ${esc(pokDB.meta?.tanggal || "")}</span>`;
  const after = b.sisa - add;
  return `<b>${esc(b.a.nama)}</b> · ${esc(b.a.roNama)} · ${esc(b.a.kompNama)}<br>Pagu Rp ${rupiah(b.pagu)}${b.blokir ? ` · Blokir Rp ${rupiah(b.blokir)}` : ""} · Terpakai Rp ${rupiah(b.terpakai)} (${b.n} ST) · Sisa <b>Rp ${rupiah(b.sisa)}</b>`
    + (add ? ` → setelah ${addLabel} (Rp ${rupiah(add)}): <span class="${after < 0 ? "neg" : "pos"}">Rp ${rupiah(after)}${after < 0 ? " — anggaran tidak cukup" : ""}</span>` : "");
}
const pad3 = (n: unknown): string => String(n).padStart(3, "0");
function validate(r: StRecord, others: StRecord[] = records, editNo: string | null = null, seq = true): string | null {
  if (!r.NO) return "No. urut wajib diisi.";
  if (!/^\d+[A-Za-z]{0,3}$/.test(String(r.NO).trim())) return `No. urut "${r.NO}" tidak sah — isi angka, boleh diikuti huruf (mis. 504 atau 504A).`;
  if (seq){   // nomor harus berurutan: setelah 530 wajib 531 dulu
    const y = stYear(r), n = parseInt(String(r.NO), 10), old = editNo ? others.find(x => x._id === editNo) : undefined;
    if (n && (!old || noKey(old.NO) !== noKey(r.NO) || stYear(old) !== y)){
      const max = others.filter(x => x._id !== editNo && stYear(x) === y).reduce((m, x) => Math.max(m, parseInt(String(x.NO), 10) || 0), 0);
      if (n > max + 1) return `Nomor harus berurutan: nomor terakhir${y ? " tahun " + y : ""} adalah ${pad3(max)}, jadi surat berikutnya No. ${pad3(max + 1)} (tidak boleh langsung ${r.NO}).`;
    }
  }
  if (!r.MAKSUD__TUJUAN) return "Maksud / tujuan wajib diisi.";
  if (!r.KD_NAMA_SPD) return "Pelaksana SPD wajib diisi.";
  { const lp = lampOf(r).map(codeOf).filter(Boolean), pl = codeOf(r.KD_NAMA_SPD);
    if (lp.length && pl !== "999" && !/terlampir/i.test(pegMap()[pl]?.nama || "")) return "Anggota lampiran hanya boleh diisi bila Pelaksana = Terlampir. Kosongkan anggota atau ganti Pelaksana menjadi Terlampir.";
    if (new Set(lp).size !== lp.length) return "Ada petugas yang sama lebih dari sekali di anggota lampiran."; }
  { const le = lokalErr(r); if (le) return le; }
  { const y = stYear(r); if (others.some(x => x._id !== editNo && noKey(x.NO) === noKey(r.NO) && stYear(x) === y)) return `Nomor ${r.NO} sudah dipakai${y ? " pada tahun " + y : ""}.`; }
  const cf = findConflicts(r, others, editNo);
  if (cf.length) return `Tidak bisa dibuat: ${cf[0].nama.split(",")[0]} sudah punya surat tugas ${cf[0].nomor} pada ${cf[0].tgl}.`;
  return null;
}
function signErr(r: StRecord, old?: StRecord | null): string | null {
  for (const [f, rs, lbl] of SIGN_FIELDS){
    const c = codeOf(r[f]); if (!c) continue;
    if (old && codeOf(old[f]) === c) continue;   // surat lama: penanda tangan yang tidak diubah tetap boleh
    if (!roleOk(c, rs)) return `${lbl}: ${pegMap()[c]?.nama || c} tidak punya peran ${rs.map(x => ROLE_NAME[x]).join(" / ")}. Pilih dari daftar, atau atur perannya di Database → Pegawai.`;
  }
  return null;
}
function save(){
  const r = readForm();
  { const old = editingId ? records.find(x => x._id === editingId) : undefined, key = (x: StRecord) => JSON.stringify([x.TGL_PERGI, x.TGL_PULANG, normMak(x.MAK), x.JENIS, personCodes(x)]);
    if (!old || key(old) !== key(r)){ const ob = obConflicts(r); if (ob.length){ toast("⚠ " + obMsg(ob[0]) + (ob.length > 1 ? ` (+${ob.length - 1} lainnya)` : "")); showSub("data"); return null; } } }
  for (let i = 1; i <= MAXTR; i++) if (/^Biaya Lintasan Mobil/i.test(r["KetTransport_" + i] || "") && num(r["Nilai" + i]) < minLintasMobil()){ toast(`Baris transport ${i}: Biaya Lintasan Mobil minimal Rp ${rupiah(minLintasMobil())} (atur di Pengaturan → Tarif bawaan).`); showSub("biaya"); return null; }
  { const e = signErr(r, editingId == null ? null : records.find(x => x._id === editingId)); if (e){ toast(e); return null; } }
  { const old = editingId && records.find(x => x._id === editingId);
    if (!old || String(old.kegiatan || "").trim() !== String(r.kegiatan || "").trim()){
      if (!r.kegiatan){ toast(r._kegLain ? "Tulis nama kegiatan." : "Kegiatan wajib dipilih dari judul RO POK, atau centang \"Kegiatan lainnya\"."); return null; }
      if (!r._kegLain && !pokJudul(akunST(r)).has(String(r.kegiatan).trim())){ toast(`"${r.kegiatan}" bukan judul RO di POK — pilih dari daftar.`); return null; } }
    if (r.MAK && (!old || normMak(old.MAK) !== normMak(r.MAK) || old.JENIS !== r.JENIS) && !akunST(r).includes(akunOf(r.MAK))){ toast(isPelatihan(r) ? `MAK surat tugas Pelatihan harus akun ${akunTxt(akunST(r))}.` : `MAK surat tugas harus akun perjalanan dinas ${akunTxt(PJ_AKUN)} (akun 521213 hanya untuk jenis Pelatihan).`); return null; }
    if (r.MAK && (!old || normMak(old.MAK) !== normMak(r.MAK) || old.kegiatan !== r.kegiatan)){ const ros = rosOfJudul(r.kegiatan, akunST(r)), ro = ros.join(" / "), mro = pokMap()[normMak(r.MAK)]?.ro;
      if (ros.length && mro && !ros.includes(mro)){ toast(`MAK ${r.MAK} bukan bagian dari RO ${ro} (${r.kegiatan}).`); return null; } } }
  const err = validate(r, records, editingId); if (err){ toast(err); refresh(); return null; }
  const b = budgetOf(r.MAK, editingId), jml = compute(r)._num.jml;
  if (b && b.sisa - jml < 0 && !confirm(`Sisa anggaran MAK ${r.MAK} hanya Rp ${rupiah(b.sisa)}, sedangkan surat ini Rp ${rupiah(jml)}.\n\nTetap simpan?`)) return null;
  if (r.MAK && !b && !confirm(`MAK "${r.MAK}" tidak ada di POK. Tetap simpan?`)) return null;
  const i = editingId ? records.findIndex(x => x._id === editingId) : -1;
  if (i >= 0){ r._id = editingId ?? undefined; records[i] = r; } else { r._id = newId(); records.push(r); }
  editingId = r._id ?? null; persist(); setEditFlag(); renderList(); buildLists();
  toast("Tersimpan: " + compute(r).NOMOR_ST);
  return r;
}
const savedMsg = (r: StRecord, extra = ""): string => `${compute(r).NOMOR_ST} — ${compute(r).NAMA_PELAKSANA_SPD || "-"} berhasil disimpan${extra}. Kembali ke Beranda atau tetap di halaman ini?`;
$("#bSave").onclick = () => { const r = save(); if (r) toast(`✓ Berhasil disimpan ke Daftar: ${compute(r).NOMOR_ST}`); };
let dlRec: StRecord | null = null;
$("#bSaveDl").onclick = () => {
  const r = save(); if (!r) return; dlRec = r; const F = compute(r);
  $("#dlMsg").textContent = `${F.NOMOR_ST} — ${F.NAMA_PELAKSANA_SPD || "-"} sudah tersimpan. Pilih dokumen yang ingin diunduh:`;
  $$("#dDl [data-dl]").forEach(b => b.disabled = false);
  const pel = isPelatihan(r), bb = $('#dDl [data-dl="biaya"]'); bb.dataset.orig ||= bb.innerHTML;
  bb.innerHTML = pel ? `<span><b>Daftar Transport Pelatihan</b><br><small class="muted">Daftar bayar transport semua petugas (.xlsx)</small></span>` : bb.dataset.orig;
  $('#dDl [data-dl="both"] small').textContent = pel ? "Surat Tugas + daftar transport" : "2 file terpisah";
  $("#dlStNote").textContent = pel ? "Surat Tugas & Lampiran ST (pelatihan: tanpa SPD & Lampiran SPPD)" : "ST, SPD, Lampiran SPPD, Lampiran ST";
  $<HTMLDialogElement>("#dDl").showModal();
};
$$("#dDl [data-dl]").forEach(b => b.onclick = async () => {
  const w = b.dataset.dl, r = dlRec; if (!r) return;
  $$("#dDl [data-dl]").forEach(x => x.disabled = true);
  if (w === "st" || w === "both") await downloadRec(r, "st");
  if (w === "both") await pause(400);
  if (w === "biaya" || w === "both"){ if (isPelatihan(r)) await downloadPelatihan(r).catch(e => toast("Gagal: " + e.message)); else await downloadRec(r, "biaya"); }
  $<HTMLDialogElement>("#dDl").close();
  const what = w === "st" ? " dan Surat Tugas diunduh" : w === "biaya" ? (isPelatihan(r) ? " dan daftar transport pelatihan diunduh" : " dan Rincian Biaya diunduh") : w === "both" ? " dan kedua dokumen diunduh" : "";
  afterSave("Surat tugas tersimpan", savedMsg(r, what));
});
function formHasContent(){ const r = readForm(); return !!(r.MAKSUD__TUJUAN || r.kegiatan || r.KD_NAMA_SPD || r.TGL_PERGI || chips.length || members.length); }
$("#bNewSt").onclick = () => {
  if (formHasContent() && !confirm(editingId ? `Buat surat tugas baru? Perubahan pada surat No. ${form.NO.value} yang belum disimpan akan hilang.` : "Buat surat tugas baru? Isian yang belum disimpan akan hilang.")) return;
  newForm(); window.scrollTo(0, 0); toast("Formulir surat tugas baru siap diisi.", "ok");
};
$("#bClear").onclick = () => {
  if (formHasContent() && !confirm(editingId ? `Bersihkan formulir? Perubahan pada surat No. ${form.NO.value} yang belum disimpan akan hilang.` : "Bersihkan formulir? Isian yang belum disimpan akan hilang.")) return;
  newForm(); window.scrollTo(0, 0); toast("Surat Tugas Personal dibersihkan — siap untuk surat baru.");
};
function showSub(s: string): void { $$(".subtabs button").forEach(b => b.classList.toggle("on", b.dataset.s === s)); $$(".sub").forEach(x => x.classList.toggle("on", x.id === "s-" + s)); }
$$("[data-back]").forEach(b => b.onclick = () => { show("list"); window.scrollTo(0, 0); });
$$(".subtabs button[data-s]").forEach(b => b.onclick = () => { showSub(b.dataset.s ?? "data"); window.scrollTo(0, 0); });

/* ================= RINCIAN PER ANGGOTA ================= */
/** baris transport surat: [keterangan, nilai] × MAXTR */
function poBaseRows(r: StRecord): [string, unknown][] { const rows: [string, unknown][] = []; for (let i = 1; i <= MAXTR; i++) rows.push([r["KetTransport_" + i] ?? "", r["Nilai" + i] ?? ""]); return rows; }
function renderPerOrang(force?: boolean): void {
  const card = $("#poCard"); if (!card) return;
  const r = readForm(), P = pegMap(), ps = personCodes(r, P);
  card.hidden = ps.length < 2;
  if (ps.length < 2) return;
  $("#poCount").textContent = ps.length + " orang";
  if (!force && $("#poBody").contains(document.activeElement) && document.activeElement?.tagName === "INPUT") return updatePoNums(r, ps);
  const lok = noUH(r), noI = noInap(r), base = { ...r }; delete base._perOrang;
  const inp = (c: string, f: string, val: unknown, ph: unknown, cls = ""): string => `<input type="number" min="0" step="${/NILAI|TDK/.test(f) ? 1000 : 1}" class="${cls}${val != null && val !== "" ? " custom" : ""}" data-pc="${c}" data-f="${f}" value="${val ?? ""}" placeholder="${ph ?? ""}" ${(/_UH$/.test(f) ? lok : noI) ? "disabled" : ""}>`;
  $("#poBody").innerHTML = ps.map((c, i) => {
    const o = perOrang[c] || {}, nm = (P[c]?.nama || c).split(",")[0];
    let html = `<tr data-c="${c}"><td>${i + 1}.</td><td>${esc(nm)}${Object.keys(o).length ? ` <span class="tag warn">khusus</span>` : ""}</td>
      <td><div class="pair">${inp(c, "LAMA_UH", o.LAMA_UH, base.LAMA_UH)} × ${inp(c, "NILAI_UH", o.NILAI_UH, base.NILAI_UH, "w")}</div><div class="calc" data-o="uh"></div></td>
      <td><div class="pair">${inp(c, "LAMA_INAP", o.LAMA_INAP, base.LAMA_INAP)} × ${inp(c, "TDK_INAP_HOTEL", o.TDK_INAP_HOTEL, base.TDK_INAP_HOTEL, "w")}</div><div class="calc" data-o="inap"></div></td>
      <td><div class="pair">${inp(c, "LAMA_HOTEL", o.LAMA_HOTEL, base.LAMA_HOTEL || 0)} × ${inp(c, "TARIF_HOTEL", o.TARIF_HOTEL, base.TARIF_HOTEL || 0, "w")}</div><div class="calc" data-o="hotel"></div></td>
      <td style="white-space:nowrap"><span data-o="tr"></span> ${o.trans ? `<span class="tag warn">khusus</span>` : ""} <button class="btn sm" type="button" data-potr="${c}">${poOpen.has(c) ? "Tutup" : "Ubah"}</button></td>
      <td class="num"><b data-o="jml"></b></td>
      <td><button class="btn sm" type="button" data-poreset="${c}" title="Samakan dengan rincian utama" ${Object.keys(o).length ? "" : "disabled"}>↺</button></td></tr>`;
    if (poOpen.has(c)){
      const rows = o.trans || poBaseRows(base); let lf = -1; rows.forEach(([k, v]: [string, unknown], j: number) => { if (k || (v !== "" && v != null)) lf = j; }); const vis = Math.max(3, lf + 1);
      html += `<tr class="potr" data-c="${c}"><td></td><td colspan="7"><div style="font-size:12px;margin-bottom:6px" class="muted">Baris transport untuk <b>${esc(nm)}</b>${o.trans ? " (khusus)" : " (sama dengan rincian utama — ubah salah satu baris untuk membuat versi khusus)"}</div>
        <table class="tight"><tbody>${rows.map(([k, v]: [string, unknown], j: number) => j <= vis ? `<tr><td class="muted" style="width:24px">${j + 1}</td><td><input class="k" data-pc="${c}" data-tk="${j}" value="${esc(k)}" placeholder="Keterangan transport"></td><td style="width:150px"><input class="w" type="number" min="0" step="1000" data-pc="${c}" data-tv="${j}" value="${v ?? ""}"></td></tr>` : "").join("")}</tbody></table>
        ${o.trans ? `<button class="btn sm" type="button" data-potrreset="${c}" style="margin-top:6px">Samakan transport dengan rincian utama</button>` : ""}</td></tr>`;
    }
    return html;
  }).join("");
  updatePoNums(r, ps);
}
function updatePoNums(r: StRecord, ps: string[]): void {
  for (const c of ps){
    const tr = $(`#poBody tr[data-c="${c}"]:not(.potr)`); if (!tr) continue;
    const n = compute(personRec(r, c))._num;
    tr.querySelector('[data-o="uh"]')!.textContent = `= Rp ${rupiah(n.totUH)}`;
    tr.querySelector('[data-o="inap"]')!.textContent = `= Rp ${rupiah(n.totInap)}`;
    tr.querySelector('[data-o="hotel"]')!.textContent = `= Rp ${rupiah(n.totHotel)}`;
    tr.querySelector('[data-o="tr"]')!.textContent = `Rp ${rupiah(n.totTr)}`;
    tr.querySelector('[data-o="jml"]')!.textContent = `Rp ${rupiah(n.jml)}`;
  }
}
function poClean(c: string): void { const o = perOrang[c]; if (o && !Object.keys(o).length) delete perOrang[c]; }
$("#poBody").addEventListener("input", e => {
  const t = tg(e), c = t.dataset.pc; if (!c) return;
  const o = perOrang[c] ||= {};
  if (t.dataset.f){ if (t.value === "") delete o[t.dataset.f]; else o[t.dataset.f] = Number(t.value); t.classList.toggle("custom", t.value !== ""); }
  else if (t.dataset.tk != null || t.dataset.tv != null){
    if (!o.trans){ const base = readForm(); delete base._perOrang; o.trans = poBaseRows(base); }
    while (o.trans.length < MAXTR) o.trans.push(["", ""]);
    const j = Number(t.dataset.tk ?? t.dataset.tv);
    if (t.dataset.tk != null) o.trans[j][0] = t.value; else o.trans[j][1] = t.value === "" ? "" : Number(t.value);
  }
  poClean(c); refresh();
});
$("#poBody").addEventListener("focusout", e => { if (!$("#poBody").contains(e.relatedTarget as Node | null)) setTimeout(() => { if (!$("#poBody").contains(document.activeElement)) renderPerOrang(); }, 0); });
$("#poBody").addEventListener("click", e => {
  const d = tg(e).dataset;
  if (d.potr){ poOpen.has(d.potr) ? poOpen.delete(d.potr) : poOpen.add(d.potr); renderPerOrang(true); }
  else if (d.poreset){ delete perOrang[d.poreset]; refresh(); renderPerOrang(true); }
  else if (d.potrreset){ if (perOrang[d.potrreset]){ delete perOrang[d.potrreset].trans; delete perOrang[d.potrreset].riilLok; } poClean(d.potrreset); refresh(); renderPerOrang(true); }
});
$("#poResetAll").onclick = () => { if (!Object.keys(perOrang).length) return toast("Semua anggota sudah sama dengan rincian utama."); if (confirm("Samakan rincian semua anggota dengan rincian utama?")){ perOrang = {}; poOpen.clear(); refresh(); renderPerOrang(true); } };

