/* ================= MASSAL ================= */
const mIn = (k: string) => $(`#mCommon [data-m="${k}"]`);
var _mY: number | null = null;
/** isian "data bersama" surat kolektif ([data-m]) + kegLain */
function readCommon(): StRecord { const o: StRecord = {}; $$("#mCommon [data-m]").forEach(e => { if (e.dataset.m) o[e.dataset.m] = e.value.trim(); }); o.kegLain = $("#mKegLain").checked; return o; }
function fillCommon(o: StRecord): void { $$("#mCommon [data-m]").forEach(e => { const k = e.dataset.m ?? ""; if (o[k] != null) e.value = o[k]; });
  const kl = o.kegLain != null ? !!o.kegLain : !!(o.kegiatan && !pokJudul().has(String(o.kegiatan).trim())); kegMode(mIn("kegiatan"), $("#mKegLain"), kl); }
function commonFrom(r: StRecord): StRecord {
  const o: StRecord = { kode: kodeFromNL(r.NoLengkap), NoLengkap: r.NoLengkap || "", TGL_TERBIT_ST: r.TGL_TERBIT_ST || today(), kegiatan: r.kegiatan || "", MAK: r.MAK || "", MAKSUD__TUJUAN: r.MAKSUD__TUJUAN || "",
    ALAT_ANGKUTAN_YANG_DIGUNAKAN: r.ALAT_ANGKUTAN_YANG_DIGUNAKAN || "Darat", TEMPAT_BERANGKAT: r.TEMPAT_BERANGKAT || "Kampung Semu", NILAI_UH: r.NILAI_UH ?? "", TDK_INAP_HOTEL: r.TDK_INAP_HOTEL ?? "", TGL_KUI: r.TGL_KUI || "" };
  for (const k of ["No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD","No_Bend"]) o[k] = r[k] != null ? pegLabel(r[k]) : "";
  return o;
}
function massRecords(): StRecord[] {
  const c = readCommon(), mY = yrOf(c.TGL_TERBIT_ST) || new Date().getFullYear(), nxN = parseInt(nextNo([], mY), 10); const startN = parseInt(c.start, 10) || nxN;
  const pad = Math.max(3, String(c.start || "").length);
  const PJ_JUDUL = pokJudul(ST_AKUN(true));
  const out = massRows.map((row, idx) => {
    const errs: string[] = [];
    if (startN > nxN) errs.push(`nomor harus berurutan — No. urut mulai seharusnya ${pad3(nxN)}`);
    for (const [f, rs, lbl] of SIGN_FIELDS.slice(0, 3)){ const cc = resolvePeg(c[f]); if (cc && !roleOk(cc, rs)) errs.push(`${lbl} harus pegawai berperan ${rs.map(x => ROLE_NAME[x]).join(" / ")}`); }
    if (!c.kegiatan) errs.push(c.kegLain ? "kegiatan belum diisi di data bersama" : "kegiatan (judul RO POK) belum dipilih di data bersama"); else if (!c.kegLain && !PJ_JUDUL.has(c.kegiatan.trim())) errs.push("kegiatan harus judul RO dari POK (atau centang Kegiatan lainnya)");
    else if (!c.kegLain && c.MAK && pokMap()[normMak(c.MAK)] && !rosOfJudul(c.kegiatan, ST_AKUN(true)).includes(pokMap()[normMak(c.MAK)].ro)) errs.push("MAK bukan dari RO kegiatan");
    const r: StRecord = { NO: String(startN + idx).padStart(pad, "0"), ...(c.kegLain ? { _kegLain: true } : {}), NoLengkap: c.NoLengkap, TGL_TERBIT_ST: c.TGL_TERBIT_ST, kegiatan: c.kegiatan, MAK: c.MAK, MAKSUD__TUJUAN: String(row.maksud || "").trim() || c.MAKSUD__TUJUAN,
      ALAT_ANGKUTAN_YANG_DIGUNAKAN: c.ALAT_ANGKUTAN_YANG_DIGUNAKAN, TEMPAT_BERANGKAT: c.TEMPAT_BERANGKAT, TGL_PERGI: row.pergi || "", TGL_PULANG: row.pulang || "", _noBiaya: true };
    for (const k of ["No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD"]){ const v = resolvePeg(c[k]); if (v) r[k] = v; }
    migrateRow(row);
    const lampCodes = row.ang.filter((c: string) => pegMap()[c]);
    row.angBad.forEach((a: string) => errs.push(`anggota "${a}" tidak dikenal`));
    setLamp(r, lampCodes);
    const pl = row.peg ? resolvePeg(row.peg) : (lampCodes.length && pegMap()["999"] ? "999" : null);
    if (pl) r.KD_NAMA_SPD = pl; else errs.push(row.peg ? `pelaksana "${row.peg}" tidak dikenal` : "pelaksana kosong");
    if (pl && pl !== "999" && lampCodes.length) errs.push("anggota lampiran hanya boleh diisi bila Pelaksana Terlampir (kosongkan Pelaksana)");
    const KM = kamByKey(), found: Kampung[] = row.kam.map((k: string) => KM[k]).filter(Boolean), unknown: string[] = row.kamBad.slice();
    r._kampung = found.map(k => ({ k: kKey(k), pp: true }));
    r.TEMPAT_TUJUAN = found.length ? tujuanText(found) + (unknown.length ? ", " + unknown.join(", ") : "") : unknown.join(", ");
    r.JENIS = ["Lokal", "Remote", "Pelatihan", JEN_TU].includes(row.jenis) ? row.jenis : (found.length && found.every(k => kamLokal(k)) ? "Lokal" : "Remote");
    { const le = lokalErr(r); if (le) errs.push(le.replace(/\.$/, "")); }
    if (c.MAK && !akunST(r).includes(akunOf(c.MAK))) errs.push(isPelatihan(r) ? `MAK harus akun ${akunTxt(akunST(r))}` : `MAK harus akun ${akunTxt(PJ_AKUN)} (521213 hanya untuk Pelatihan)`);
    const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG);
    if (r.TGL_PERGI && !a) errs.push("tgl pergi tidak terbaca"); if (r.TGL_PULANG && !b) errs.push("tgl pulang tidak terbaca");
    if (a && b && b < a) errs.push("tgl pulang sebelum tgl pergi");
    const L = a && b && b >= a ? dayDiff(a, b) : (a && !r.TGL_PULANG ? 1 : 0);
    if (L) r.LAMA_JALAN = L;
    if (!r.TGL_PERGI) errs.push("tanggal pergi kosong");
    return { r, errs, L, luar: unknown };
  });
  // aturan yang sama dengan Formulir: wajib isi, nomor unik, petugas tidak bentrok tanggal
  const P = pegMap(), done: StRecord[] = [];
  for (const x of out){
    for (const o of obConflicts(x.r)) x.errs.push(obMsg(o));
    const v = validate(x.r, records, null, false);
    if (v && !/sudah punya surat tugas/.test(v)) x.errs.push(v.replace(/\.$/, ""));
    for (const cf of findConflicts(x.r, records, null, P)) x.errs.push(`${cf.nama.split(",")[0]} sudah bertugas ${cf.tgl} (ST ${cf.nomor})`);
    for (const cf of findConflicts(x.r, done, null, P)) x.errs.push(`${cf.nama.split(",")[0]} bentrok dengan baris No. ${cf.no} (${cf.tgl})`);
    x.errs = [...new Set(x.errs)];
    done.push(x.r);
  }
  return out;
}
/* ---- chip picker (anggota & kampung) per baris massal ---- */
/** baris lama (teks anggota/kampung) → daftar kode */
function migrateRow(row: StRecord): StRecord {
  if (!Array.isArray(row.ang)){
    const ang: string[] = [], angBad: string[] = [];
    for (const a of splitPeople(row.anggota)){ const c = resolvePeg(a); if (c){ if (!ang.includes(c)) ang.push(c); } else angBad.push(a); }
    row.ang = ang; row.angBad = angBad;
  }
  if (!Array.isArray(row.kam)){
    if (row.kamTxt == null && row.kampung) row.kamTxt = String(row.kampung);
    const pk = parseKampungList(row.kampung);
    row.kam = pk.found.map(kKey); row.kamBad = pk.unknown;
  }
  delete row.anggota; delete row.kampung;
  return row;
}
function cpickHtml(row: StRecord, kind: "ang" | "kam"): string {
  migrateRow(row);
  const P = pegMap(), M = kamByKey();
  const good = kind === "ang"
    ? row.ang.map((c: string, j: number) => `<span class="mchip" title="${esc(P[c]?.jabatan || "")}">${esc((P[c]?.nama || "Kode " + c).split(",")[0])}<button type="button" data-cx="ang" data-ci="${j}" title="Hapus">×</button></span>`)
    : row.kam.map((k: string, j: number) => { const x = M[k]; return `<span class="mchip"><small>${j + 1}</small>${esc(x ? title(x.kampung) : k)}<button type="button" data-cx="kam" data-ci="${j}" title="Hapus">×</button></span>`; });
  const bad = (kind === "ang" ? row.angBad : row.kamBad).map((t: string, j: number) => `<span class="mchip bad" title="Tidak dikenal">${esc(t)}<button type="button" data-cx="${kind}Bad" data-ci="${j}">×</button></span>`);
  return `<div class="cpick">${good.join("")}${bad.join("")}<input class="cp-in" data-cp="${kind}" ${kind === "ang" ? 'data-ac="peg" autocomplete="off"' : 'data-ac="kam" autocomplete="off"'} placeholder="${kind === "ang" ? (row.ang.length ? "+ tambah" : "ketik nama…") : (row.kam.length ? "+ kampung" : "ketik nama kampung…")}"></div>`;
}
/** tambah anggota / kampung dari teks; kembalikan jumlah yang ditambahkan */
function cpAdd(i: number, kind: string, text: string): number {
  const row = massRows[i]; if (!row) return 0; let n = 0;
  { const lk = kind === "kam" ? kIdx().label.get(String(text).trim()) : undefined;   // dipilih dari daftar saran → kampung itu saja
    if (lk){ if (row.kam.includes(kKey(lk))){ toast("Kampung sudah dipilih."); return 0; } row.kam.push(kKey(lk)); return 1; } }
  if (kind === "kam" && !kIdx().label.has(String(text).trim())){      // teks bebas / tempelan → deteksi semua kampung di dalamnya
    const d = detectKampung(text);
    if (d.found.length){
      for (const k of d.found) if (!row.kam.includes(kKey(k))){ row.kam.push(kKey(k)); n++; }
      if (d.unknown.length) toast(`Tidak dikenali di SK: ${d.unknown.slice(0, 3).join(", ")}`);
      else if (!n) toast("Kampung sudah dipilih.");
      return n;
    }
  }
  const parts = kind === "ang" ? splitPeople(text) : String(text).split(/,|;/).map(t => t.trim()).filter(Boolean);
  for (const t of parts){
    if (kind === "ang" && row.peg && resolvePeg(row.peg) && resolvePeg(row.peg) !== "999"){ toast("Anggota lampiran hanya bisa dipilih bila Pelaksana kosong / Terlampir.", "warn"); return n; }
    if (kind === "ang"){ const c = resolvePeg(t); if (!c){ toast(`"${t}" tidak ditemukan di Pegawai & Mitra.`); continue; } if (row.ang.includes(c)){ toast(`${pegMap()[c]?.nama || "Petugas"} sudah ada di anggota — tidak boleh dipilih dua kali.`, "warn"); continue; } row.ang.push(c); n++; }
    else if (parts.length === 1 && detectKampung(t).found.length > 1){ for (const k of detectKampung(t).found){ if (!row.kam.includes(kKey(k))){ row.kam.push(kKey(k)); n++; } } }
    else { let k = findKampung(t); if (!k){ const d = detectKampung(t).found; if (d.length === 1) k = d[0]; }
      if (!k){ const hs = kampungDB.filter(x => x.kampung.toLowerCase().includes(t.toLowerCase())); if (hs.length === 1) k = hs[0]; else { toast(hs.length ? `${hs.length} kampung cocok untuk "${t}" — pilih dari daftar.` : `Kampung "${t}" tidak ada di SK.`); continue; } }
      if (row.kam.includes(kKey(k))){ toast("Kampung sudah dipilih."); continue; } row.kam.push(kKey(k)); n++; }
  }
  return n;
}
function cpRefresh(i: number, kind: string, focus?: boolean): void {
  const td = $(`#mTbl .mrow[data-i="${i}"] .cp-cell[data-c="${kind}"]`); if (!td) return;
  td.querySelector(".cpick")!.outerHTML = cpickHtml(massRows[i], kind === "ang" ? "ang" : "kam");
  persistMass(); updateMassInfo();
  if (focus) td.querySelector<HTMLInputElement>(".cp-in")!.focus();
}
/** baris lama (pergi + pulang) → lama hari; pulang selalu = pergi + lama − 1 */
/** teks kampung tujuan → kampung SK Transport (urut sesuai teks) + yang tidak dikenali */
function massKamParse(row: StRecord): void {
  const t = String(row.kamTxt || "").trim(); if (!t){ row.kam = []; row.kamBad = []; return; }
  const d = detectKampung(t), keys: string[] = []; for (const k of d.found){ const kk = kKey(k); if (!keys.includes(kk)) keys.push(kk); }
  row.kam = keys; row.kamBad = d.unknown.map(u => u.trim()).filter(u => u && !/^(dan|ke|di|kampung|distrik|kab(upaten)?|serta)$/i.test(u));
}
function massLama(row: StRecord): void {
  const a = parseTgl(row.pergi), b = parseTgl(row.pulang);
  if (!(num(row.lama) >= 1)) row.lama = a && b && b >= a ? dayDiff(a, b) : a ? 1 : "";
  if (a && num(row.lama) >= 1) row.pulang = tglPulang(row.pergi, row.lama);
}
function renderMass(): void {
  massRows.forEach(r => { massLama(r); migrateRow(r); if (r.kamTxt == null){ const M = kamByKey(), ks = (r.kam as string[]).map(k => M[k]).filter((k): k is Kampung => !!k); r.kamTxt = [tujuanText(ks), ...(r.kamBad as string[])].filter(Boolean).join(", "); } });
  $("#mTbl").innerHTML = massRows.map((row, i) => `<div class="mrow" data-i="${i}">
    <div class="mhead"><span class="mno"></span><span class="mjml"></span><span class="minfo" data-info="lama"></span><span class="spacer"></span>
      <button class="btn sm" type="button" data-pv="${i}" title="Pratinjau surat ini">Pratinjau</button><button class="btn sm" type="button" data-dup="${i}" title="Duplikat surat ini">Duplikat</button><button class="btn sm del" type="button" data-rm="${i}" title="Hapus surat ini">Hapus</button></div>
    <div class="mgrid">
      <div><label>Pelaksana</label><input data-k="peg" data-ac="pel" autocomplete="off" value="${esc(row.peg)}" placeholder="nama (kosong = Terlampir)"><div class="info" data-info="peg"></div></div>
      <div><label>Jenis</label><select data-k="jenis">${["Otomatis","Remote","Lokal",JEN_TU,"Pelatihan"].map(o => `<option ${(row.jenis || "Otomatis") === o ? "selected" : ""}>${o}</option>`).join("")}</select><div class="info" data-info="jenis"></div></div>
      <div><label>Tanggal pergi</label><div class="row"><input data-k="pergi" value="${esc(row.pergi)}" placeholder="26 Januari 2026"><input type="date" data-kd="pergi"></div></div>
      <div><label>Lama (hari) · pulang otomatis</label><div class="mlama"><input type="number" min="1" step="1" data-k="lama" value="${esc(row.lama || "")}" placeholder="hari" title="Lama perjalanan (hari)"><input data-k="pulang" value="${esc(row.pulang)}" readonly tabindex="-1" data-autopulang placeholder="tanggal pulang" title="Dihitung otomatis: tanggal pergi + lama − 1"></div></div>
      <div class="full"><label>Maksud / tujuan <span class="muted" data-info="maksud" style="text-transform:none;letter-spacing:0"></span></label><textarea data-k="maksud" rows="1" placeholder="Isi maksud / tujuan">${esc(row.maksud || readCommon().MAKSUD__TUJUAN || "")}</textarea></div>
      <div class="half cp-cell" data-c="ang"><label>Anggota tim (Lampiran)</label>${cpickHtml(row, "ang")}<div class="info" data-info="anggota"></div></div>
      <div class="half" data-c="kam"><label>Kampung tujuan (urut rute)</label><input data-k="kamTxt" value="${esc(row.kamTxt || "")}" autocomplete="off" placeholder="mis. Kampung Isir dan Frawebo" title="Tulis nama kampung seperti biasa — kampung SK Transport terbaca otomatis sesuai urutan"><div class="info" data-info="kampung"></div></div>
    </div>
    <div class="merr" hidden></div></div>`).join("")
    || `<div class="mempty muted">Belum ada surat. Klik <b>+ Tambah surat</b>, atau <b>Impor Excel</b> memakai template.</div>`;
  updateMassInfo();
}
function updateMassInfo(): void {
  const P = pegMap(), recs = massRecords(); let total = 0, bad = 0;
  $$("#mTbl .merr").forEach(e => e.hidden = true);
  recs.forEach(({ r, errs, L, luar }, i) => {
    const tr = $(`#mTbl .mrow[data-i="${i}"]`); if (!tr) return;
    if (errs.length) bad++; else total++;
    const q = (sel: string) => tr.querySelector<HTMLInputElement>(sel)!;
    q(".mno").innerHTML = `<b>${esc(r.NO)}</b>`;
    q(".mjml").innerHTML = errs.length ? `<span class="tag warn">perbaiki</span>` : `<span class="tag ok">siap</span>`;
    const er = q(".merr"); er.hidden = !errs.length; er.textContent = errs.length ? "⚠ " + errs.join("; ") : ""; tr.classList.toggle("bad", !!errs.length); tr.classList.toggle("ok", !errs.length);
    const pl = P[r.KD_NAMA_SPD];
    q('[data-info="peg"]').textContent = pl ? pl.nama + (pl.jabatan ? " · " + pl.jabatan : "") : "";
    const lc = lampOf(r), angL = !!r.KD_NAMA_SPD && r.KD_NAMA_SPD !== "999";
    { const ci = tr.querySelector<HTMLInputElement>('.cp-cell[data-c="ang"] .cp-in'); if (ci){ ci.disabled = angL; ci.placeholder = angL ? "Pelaksana bukan Terlampir — anggota tidak bisa dipilih" : ci.dataset.ph || ci.placeholder; } }
    q('[data-info="anggota"]').textContent = lc.length ? `${lc.length} orang` : "";
    const ks = normChips(r._kampung).map(c => kamByKey()[c.k]);
    q('[data-info="kampung"]').textContent = [ks.length ? `${ks.length} kampung: ${ks.map(k => title(k.kampung)).join(" → ")}` : "", luar?.length ? `di luar SK (transport manual): ${luar.join(", ")}` : ""].filter(Boolean).join(" · ");
    q('[data-info="lama"]').textContent = [r.TGL_PERGI ? tglRange(r) : "", L ? `${L} hari` : "", r.JENIS].filter(Boolean).join(" · ");
    const mk = q('[data-k="maksud"]'), cm = readCommon().MAKSUD__TUJUAN || "", own = !!String(massRows[i].maksud || "").trim();
    if (!own && document.activeElement !== mk && mk.value !== cm) mk.value = cm;   // ikut data bersama sampai diubah di baris ini
    q('[data-info="maksud"]').textContent = own ? "· khusus surat ini" : cm ? "· dari data bersama — bisa diubah di sini" : "";
    q('[data-info="jenis"]').textContent = (massRows[i].jenis || "Otomatis") === "Otomatis" ? "→ " + r.JENIS : "";
  });
  $("#mCount").textContent = `${massRows.length} surat${bad ? ` · ${bad} perlu diperbaiki` : ""}`;
  $("#mCount").className = "tag" + (bad ? " warn" : "");
  $("#mTotal").textContent = `${total} surat`;
  { const ms = $("#mSumm"); if (ms) ms.innerHTML = massRows.length ? `<b>${massRows.length}</b> surat · <span class="${bad ? "bad" : ""}">${bad} perlu diperbaiki</span> · <b>${total}</b> siap dibuat` : "Belum ada surat di daftar."; }
  const c = readCommon(), kc = kodeMap()[kodeFromNL(c.NoLengkap)];
  $("#mh-mak").innerHTML = budgetHtml(c.MAK, 0, null);
  $("#mh-kode").textContent = kc ? kc.d : "";
  const mY = yrOf(c.TGL_TERBIT_ST) || new Date().getFullYear();
  const s = parseInt(c.start, 10) || parseInt(nextNo([], mY), 10), e = s + Math.max(0, massRows.length - 1);
  const clash = records.filter(x => { const n = noNum(x.NO); return stYear(x) === mY && n >= s && n <= e && noKey(x.NO) === String(n); }).map(x => x.NO);
  const nxS = parseInt(nextNo([], mY), 10);
  $("#mh-start").innerHTML = s > nxS ? `<span class="bad">Harus berurutan: mulai dari ${pad3(nxS)} (nomor terakhir tahun ${mY} = ${pad3(nxS - 1)})</span>` : clash.length ? `<span class="bad">Nomor ${esc(clash.slice(0, 5).join(", "))}${clash.length > 5 ? "…" : ""} sudah dipakai tahun ${mY}</span>` : (massRows.length ? `Nomor ${String(s).padStart(3, "0")} s.d. ${String(e).padStart(3, "0")} · tahun ${mY}` : `Kosong = lanjut dari nomor terakhir tahun ${mY}`);
}
$("#mTbl").addEventListener("paste", e => {
  const inp = tg(e).closest<HTMLInputElement>(".cp-in[data-cp=kam]"); if (!inp) return;
  setTimeout(() => { const i = Number(inp.closest<HTMLInputElement>(".mrow")!.dataset.i); if (inp.value.trim() && cpAdd(i, "kam", inp.value)) cpRefresh(i, "kam", true); }, 0);
});
$("#mTbl").addEventListener("keydown", e => {
  const inp = tg(e).closest<HTMLInputElement>(".cp-in"); if (!inp) return;
  const i = Number(inp.closest<HTMLInputElement>(".mrow")!.dataset.i), kind = inp.dataset.cp ?? "";
  if ((e.key === "Enter" || e.key === "Tab" && inp.value.trim()) && inp.value.trim()){ e.preventDefault(); if (cpAdd(i, kind, inp.value)) cpRefresh(i, kind, true); else inp.select(); }
  else if (e.key === "Backspace" && !inp.value){ const row = massRows[i], arr = row[kind]; if (arr.length){ arr.pop(); cpRefresh(i, kind, true); } }
});
$("#mTbl").addEventListener("input", e => {
  const inp = tg(e).closest<HTMLInputElement>(".cp-in");
  if (inp){ // memilih langsung dari daftar pilihan
    const v = inp.value, kind = inp.dataset.cp ?? "", i = Number(inp.closest<HTMLInputElement>(".mrow")!.dataset.i);
    const exact = kind === "ang" ? isPegName(v) : kIdx().label.has(v);
    if (exact && cpAdd(i, kind, v)) cpRefresh(i, kind, true);
    return;
  }
  const tr = tg(e).closest<HTMLInputElement>(".mrow"); const k = tg(e).dataset.k; if (!tr || !k || tg(e).tagName === "SELECT") return;
  const row = massRows[Number(tr.dataset.i)];
  if (k === "maksud"){ const v = tg(e).value, cm = String(readCommon().MAKSUD__TUJUAN || ""); row.maksud = v.trim() === cm.trim() ? "" : v; persistMass(); updateMassInfo(); return; }
  if (k === "kamTxt"){ row.kamTxt = tg(e).value; massKamParse(row); persistMass(); updateMassInfo(); return; }
  if (k === "lama"){ row.lama = num(tg(e).value) >= 1 ? Math.round(num(tg(e).value)) : ""; if (row.lama) row.pulang = tglPulang(row.pergi, row.lama); tr.querySelector<HTMLInputElement>('[data-k="pulang"]')!.value = row.pulang || ""; persistMass(); updateMassInfo(); return; }
  if (k === "pulang"){ row.pulang = tg(e).value; row.lama = ""; massLama(row); tr.querySelector<HTMLInputElement>('[data-k="lama"]')!.value = String(row.lama || ""); persistMass(); updateMassInfo(); return; }   // diisi dari luar
  row[k] = tg(e).type === "checkbox" ? tg(e).checked : tg(e).value;
  if (k === "pergi"){ massLama(row); tr.querySelector<HTMLInputElement>('[data-k="lama"]')!.value = String(row.lama || ""); tr.querySelector<HTMLInputElement>('[data-k="pulang"]')!.value = row.pulang || ""; }
  persistMass(); updateMassInfo();
});
$("#mTbl").addEventListener("change", e => {
  const tr = tg(e).closest<HTMLInputElement>(".mrow"); if (!tr) return; const row = massRows[Number(tr.dataset.i)];
  const kd = tg(e).dataset.kd;
  if (kd && tg(e).value){ row[kd] = fmtTgl(tg(e).value); tr.querySelector<HTMLInputElement>(`[data-k="${kd}"]`)!.value = row[kd];
    if (kd === "pergi"){ massLama(row); tr.querySelector<HTMLInputElement>('[data-k="lama"]')!.value = String(row.lama || ""); tr.querySelector<HTMLInputElement>('[data-k="pulang"]')!.value = row.pulang || ""; } }
  if (tg(e).dataset.k === "pp"){ row.pp = tg(e).checked; }
  if (tg(e).dataset.k === "jenis"){ row.jenis = tg(e).value; }
  persistMass(); updateMassInfo();
});
$("#mTbl").addEventListener("click", e => {
  const d = tg(e).dataset;
  if (d.cx != null){ const i = Number(tg(e).closest<HTMLInputElement>(".mrow")!.dataset.i); massRows[i][d.cx].splice(Number(d.ci), 1); cpRefresh(i, d.cx.replace("Bad", ""), true); return; }
  const cp = tg(e).closest<HTMLInputElement>(".cpick"); if (cp && tg(e) === cp){ cp.querySelector<HTMLInputElement>(".cp-in")!.focus(); return; }
  if (d.rm != null){ massRows.splice(+d.rm, 1); persistMass(); renderMass(); }
  if (d.dup != null){ massRows.splice(+d.dup + 1, 0, clone(massRows[+d.dup])); persistMass(); renderMass(); }
  if (d.pv != null){ const x = massRecords()[+d.pv]; if (x) openPreview([x.r], `Pratinjau ST No. ${x.r.NO}` + (x.errs.length ? " — masih ada yang perlu diperbaiki" : "")); }
});
$("#mPreview").onclick = () => { const xs = massRecords(); if (!xs.length) return toast("Belum ada baris."); openPreview(xs.map(x => x.r), `Pratinjau ${xs.length} surat (Surat Tugas Kolektif)`); };
$("#mAdd").onclick = () => { const last = massRows[massRows.length - 1]; massRows.push({ peg: "", ang: [], angBad: [], kam: [], kamBad: [], pp: true, pergi: last?.pergi || "", lama: last?.lama || "", pulang: last?.pulang || "" }); persistMass(); renderMass();
  $(`#mTbl .mrow[data-i="${massRows.length - 1}"]`)?.scrollIntoView({ block: "center" });
  $(`#mTbl .mrow[data-i="${massRows.length - 1}"] [data-k="peg"]`).focus(); };
function resetMass(): void {
  massRows = []; $("#mKegLain").checked = false;
  $$("#mCommon [data-m]").forEach(e => { e.value = e instanceof HTMLSelectElement ? (e.options[0] ? e.options[0].value : "") : ""; });
  fillCommon(commonFrom(defaults()));
  massCommon = readCommon(); persistMass(); renderMass();
}
$("#mNewSt").onclick = () => {
  const c = readCommon(), has = massRows.length || c.kegiatan || c.MAK || c.MAKSUD__TUJUAN;
  if (has && !confirm("Buat surat tugas kolektif baru? Data bersama dan semua baris yang belum disimpan akan dikosongkan.")) return;
  resetMass(); window.scrollTo(0, 0); toast("Surat tugas kolektif baru siap diisi.", "ok");
};
$$("[data-newst]").forEach(b => b.onclick = () => $(b.dataset.newst === "mass" ? "#mNewSt" : "#bNewSt").click());
$("#mClear").onclick = () => {
  const c = readCommon(), has = massRows.length || c.kegiatan || c.MAK || c.MAKSUD__TUJUAN;
  if (has && !confirm("Bersihkan Surat Tugas Kolektif? Data bersama dan semua baris akan dikosongkan.")) return;
  resetMass(); window.scrollTo(0, 0); toast("Surat Tugas Kolektif dibersihkan.");
};
/* template & impor Excel untuk daftar surat kolektif */
const MASS_HDR = ["Pelaksana", "Anggota tim (pisahkan dengan ;)", "Kampung tujuan (pisahkan dengan ,)", "Tanggal pergi", "Tanggal pulang", "Jenis (Otomatis / Remote / Lokal / Translok+Uhar / Pelatihan)", "Maksud / tujuan (kosong = data bersama)"];
$("#mTplXls").onclick = () => {
  const P = pegawai.filter(p => !isSystemPeg(p)), mit = P.filter(isMitra), peg = P.filter(p => !isMitra(p)), K = kampungDB.slice(0, 6).map(k => title(k.kampung));
  const nm = (arr: Pegawai[], i: number): string => (arr[i] || arr[0])?.nama || "";
  const ex = [
    [nm(peg, 1), "", K[0] || "", "5 Januari 2026", "6 Januari 2026", "Otomatis", ""],
    ["Terlampir", [nm(mit, 0), nm(mit, 1), nm(mit, 2)].filter(Boolean).join("; "), [K[1], K[2]].filter(Boolean).join(", "), "12 Januari 2026", "15 Januari 2026", "Remote", "Pendataan lapangan (contoh — maksud khusus baris ini)"],
    [nm(mit, 3), "", "Kota Sorong", "20 Januari 2026", "22 Januari 2026", "Pelatihan", "Pelatihan petugas (contoh)"]];
  const ws = XLSX.utils.aoa_to_sheet([MASS_HDR, ...ex]); ws["!cols"] = [34, 46, 36, 18, 18, 22, 46].map(w => ({ wch: w }));
  const info = XLSX.utils.aoa_to_sheet([["Petunjuk pengisian"], [""],
    ["1. Satu baris = satu surat tugas. Hapus baris contoh sebelum mengisi."], ["2. Pelaksana: nama persis seperti di Database → Pegawai & Mitra. Isi \"Terlampir\" bila surat untuk tim (anggota diisi di kolom Anggota)."],
    ["3. Anggota tim: beberapa nama dipisah titik koma ( ; )."], ["4. Kampung tujuan: nama kampung SK Transport, beberapa kampung dipisah koma sesuai urutan rute. Tujuan di luar SK ditulis apa adanya."],
    ["5. Tanggal: tulis mis. 5 Januari 2026 atau format tanggal Excel."], ["6. Jenis: Otomatis (mengikuti SK), Remote, Lokal, Translok+Uhar, atau Pelatihan."], ["7. Maksud kosong = memakai maksud di Data bersama."],
    [""], ["Data bersama (kode klasifikasi, tanggal terbit, kegiatan, MAK, penanda tangan) diisi di aplikasi, bagian 1."]]);
  info["!cols"] = [{ wch: 110 }];
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Daftar Surat"); XLSX.utils.book_append_sheet(wb, info, "Petunjuk");
  XLSX.writeFile(wb, "Template Surat Tugas Kolektif.xlsx"); toast("Template Excel diunduh — isi lalu klik Impor Excel.");
};
$("#fMassImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
    let rows: unknown[][] | null = null, H: string[] = [];
    for (const sn of wb.SheetNames){ const a = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: true }); const hi = a.findIndex(r => r.some(c => /^pelaksana/i.test(String(c).trim()))); if (hi >= 0){ H = a[hi].map(c => String(c).trim().toLowerCase()); rows = a.slice(hi + 1); break; } }
    if (!rows) return toast("Kolom 'Pelaksana' tidak ditemukan. Pakai Unduh template Excel.");
    const ix = (re: RegExp) => H.findIndex(h => re.test(h)), cP = ix(/^pelaksana/), cA = ix(/^anggota/), cK = ix(/^kampung|^tempat tujuan/), cG = ix(/pergi/), cU = ix(/pulang/), cJ = ix(/^jenis/), cM = ix(/^maksud/);
    const cell = (r: unknown[], i: number): string => { const v = i < 0 ? "" : r[i]; return v instanceof Date ? fmtDate(new Date(v.getTime() + 12 * 36e5)) : String(v ?? "").trim(); };
    const sd = (v: string): string => { const m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); return m ? `${+m[1]} ${BULAN[+m[2] - 1]} ${m[3]}` : v; };
    let n = 0;
    for (const r of rows){
      const peg = cell(r, cP), ang = cell(r, cA), kam = cell(r, cK);
      if (!peg && !ang && !kam) continue;
      const j = cell(r, cJ);
      massRows.push({ peg: /^terlampir$/i.test(peg) ? "" : peg, anggota: ang.replace(/\s*;\s*/g, "; "), kampung: kam, pergi: sd(cell(r, cG)), pulang: sd(cell(r, cU) || cell(r, cG)), maksud: cell(r, cM), pp: true,
        jenis: jenisOf(j) || "Otomatis" });
      n++;
    }
    persistMass(); renderMass(); toast(n ? `${n} surat diimpor dari ${f.name}. Periksa baris bertanda kuning.` : "Tidak ada baris yang terisi di file.");
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
});
$("#mPaste").onclick = () => { $("#pasteBox").value = ""; $<HTMLDialogElement>("#dPaste").showModal(); $("#pasteBox").focus(); };
$("#pasteCancel").onclick = () => $<HTMLDialogElement>("#dPaste").close();
$("#pasteGo").onclick = () => {
  const lines = $("#pasteBox").value.split(/\r?\n/).filter(l => l.trim());
  const sd = (v0: unknown): string => { const v = String(v0 || "").trim(); const m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); return m ? `${+m[1]} ${BULAN[+m[2]-1]} ${m[3]}` : v; };
  for (const l of lines){
    const c = l.split("\t");
    massRows.push({ peg: (c[0] || "").trim(), maksud: (c[7] || "").trim(), kampung: (c[1] || "").trim(), pergi: sd(c[2]), pulang: sd(c[3] || c[2]), anggota: (c[4] || "").trim(), pp: true, jenis: (() => { const j = [c[5], c[6]].map(x => String(x || "").trim()).find(x => /^(lok|rem|pel|trans)/i.test(x)) || ""; return jenisOf(j) || "Otomatis"; })() });
  }
  persistMass(); renderMass(); $<HTMLDialogElement>("#dPaste").close(); toast(`${lines.length} baris ditambahkan.`);
};
$("#mCommon").addEventListener("input", e => {
  const k = tg(e).dataset.m;
  if (k === "kode"){ const c = kodeMap()[tg(e).value.trim().toUpperCase()]; if (c) mIn("NoLengkap").value = composeNL(c.k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value); }
  if (k === "TGL_TERBIT_ST"){ const d = parseTgl(tg(e).value); if (d){ mIn("NoLengkap").value = mIn("NoLengkap").value.replace(/\/\d{4}$/, "/" + d.getFullYear());
      if (_mY != null && d.getFullYear() !== _mY && mIn("start").value.trim()){ mIn("start").value = ""; toast(`Tahun terbit ${d.getFullYear()}: No. urut mulai disesuaikan otomatis (${nextNo([], d.getFullYear())}).`); }
      _mY = d.getFullYear(); } }
  massCommon = readCommon(); persistMass(); updateMassInfo();
});
$("#mCommon").addEventListener("change", e => {
  const mf = tg(e).dataset.mfor ?? "";
  if (mf && tg(e).type === "date" && tg(e).value){ mIn(mf).value = fmtTgl(tg(e).value); mIn(mf).dispatchEvent(new Event("input", { bubbles: true })); }
  if (tg(e).matches("select.preset") && tg(e).value){ mIn(mf).value = tg(e).value; tg(e).value = ""; }
  if (tg(e).dataset.m === "kode"){ const { c, n } = lookupKode(tg(e).value); if (c){ tg(e).value = c.k; mIn("NoLengkap").value = composeNL(c.k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value); } else if (n > 1) toast(`${n} kode cocok — pilih dari daftar.`); }
  if (["No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD","No_Bend"].includes(tg(e).dataset.m ?? "")){ const c = resolvePeg(tg(e).value); if (c) tg(e).value = pegLabel(c); }
  massCommon = readCommon(); persistMass(); updateMassInfo();
});
$("#mFromForm").onclick = () => { const s = mIn("start").value; fillCommon({ ...commonFrom(readForm()), start: s }); massCommon = readCommon(); persistMass(); updateMassInfo(); toast("Data bersama disalin dari Surat Tugas Personal."); };
function saveMass(): StRecord[] | null {
  if (!massRows.length){ toast("Belum ada baris."); return null; }
  const recs = massRecords(), bad = recs.filter(x => x.errs.length);
  if (bad.length){ toast(`${bad.length} baris belum bisa dibuat: No. ${bad[0].r.NO} — ${bad[0].errs[0]}`); return null; }
  const mak = readCommon().MAK, b = budgetOf(mak);
  if (mak && !b && !confirm(`MAK "${mak}" tidak ada di POK. Tetap simpan?`)) return null;
  const clash = recs.find(x => records.some(y => recKey(y) === recKey(x.r)));
  if (clash){ toast(`Nomor ${clash.r.NO} sudah dipakai pada tahun ${stYear(clash.r)}. Ubah “No. urut mulai”.`); return null; }
  const out = recs.map(x => x.r); ensureIds(out);
  records.push(...out); persist(); renderList(); buildLists();
  resetMass();   // isian kembali kosong seperti awal
  toast(`${out.length} surat tugas tersimpan (No. ${out[0].NO}–${out[out.length - 1].NO}). Rincian biaya dibuat lewat Daftar Surat Tugas → Edit.`);
  return out;
}
const mSaveList = () => { const out = saveMass(); if (out) toast(`✓ Berhasil menyimpan ${out.length} surat tugas ke Daftar (No. ${out[0].NO} s.d. ${out[out.length - 1].NO}).`); };
const mSavePrint = () => { const out = saveMass(); if (out) openPrint(out, true); };
const mSaveXls = () => { const out = saveMass(); if (out){ exportST(out, `Surat Tugas ${out[0].NO}-${out[out.length - 1].NO} (${out.length} surat).xlsx`); afterSave(`${out.length} surat tugas tersimpan`, `No. ${out[0].NO} s.d. ${out[out.length - 1].NO} sudah masuk ke Daftar Surat Tugas dan diekspor ke Excel. Kembali ke Beranda atau tetap di halaman ini?`, "list"); } };
$("#mSaveAll").onclick = () => {
  if (!massRows.length) return toast("Belum ada baris.");
  const recs = massRecords(), bad = recs.filter(x => x.errs.length);
  if (bad.length) return toast(`${bad.length} baris belum bisa dibuat: No. ${bad[0].r.NO} — ${bad[0].errs[0]}`);
  $("#msMsg").textContent = `${recs.length} surat tugas siap disimpan (No. ${recs[0].r.NO} s.d. ${recs[recs.length - 1].r.NO}). Pilih tindakan:`;
  $<HTMLDialogElement>("#dMassSave").showModal();
};
$$("#dMassSave [data-ms]").forEach(b => b.onclick = () => {
  $<HTMLDialogElement>("#dMassSave").close();
  ({ list: mSaveList, print: mSavePrint, xls: mSaveXls } as Record<string, () => void>)[b.dataset.ms ?? ""]?.();
});

