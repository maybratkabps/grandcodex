/* ================= PREVIEW ================= */
const PREV_MAX = 15;
/** keadaan dialog pratinjau: surat, bagian (st | biaya | pel), zoom, hasil .docx terakhir */
interface PrevState { recs: StRecord[]; part: string; zoom: number; blob: Blob | null; tpl: boolean }
let prev: PrevState = { recs: [], part: "st", zoom: 1, blob: null, tpl: false };
async function renderPreview(): Promise<void> {
  const host = $("#prevDoc"); host.innerHTML = `<p style="color:#fff;padding:24px">Menyiapkan pratinjau…</p>`;
  try{
    let blob: Blob;
    if (prev.tpl) blob = await (await JSZip.loadAsync(tplB64(), { base64: true })).generateAsync({ type: "blob" });
    else if (prev.part === "pel"){
      prev.blob = null; host.innerHTML = prev.recs.filter(isPelatihan).slice(0, PREV_MAX).map(r => `<div class="hp-page" style="margin-bottom:18px">${pelatihanHtml(r)}</div>`).join("") || `<p style="color:#fff;padding:24px">Tidak ada surat Pelatihan.</p>`;
      applyZoom(); $("#prevDl").textContent = "Unduh .xlsx"; return;
    }
    else {
      const parts = prev.part === "st" ? FILE_ST : FILE_BIAYA, rs = prev.recs.slice(0, PREV_MAX);
      const list = prev.part === "st" ? rs : expandBiaya(rs).slice(0, PREV_MAX * 3);
      blob = list.length === 1 ? await buildDocx(list[0], parts) : await buildMerged(list, parts);
    }
    prev.blob = blob; host.innerHTML = ""; $("#prevDl").textContent = "Unduh .docx";
    await docx.renderAsync(blob, host, host, { inWrapper: true, breakPages: true, ignoreLastRenderedPageBreak: true, experimental: true, className: "docx" });
    applyZoom();
  }catch(e){ console.error(e); host.innerHTML = `<p style="color:#fff;padding:24px">Gagal membuat pratinjau: ${esc((e as Error).message)}</p>`; }
}
function applyZoom(): void { const h = $("#prevDoc"); h.style.transform = `scale(${prev.zoom})`; h.style.width = prev.zoom < 1 ? (100 / prev.zoom) + "%" : ""; h.style.marginLeft = prev.zoom < 1 ? `${-(100 / prev.zoom - 100) / 2}%` : ""; }
function openPreview(recs: StRecord[], title: string, tpl = false, part = "st"): void {
  prev = { recs, part, zoom: prev.zoom || 1, blob: null, tpl };
  if (!tpl && !recs.length) return toast("Tidak ada surat untuk dipratinjau.");
  if (innerWidth < 900) prev.zoom = Math.max(0.4, (innerWidth - 40) / 820);
  $("#prevTitle").textContent = title;
  const nb = !tpl && recs.every(r => r._noBiaya);
  $("#prevTabs").hidden = tpl;
  $<HTMLButtonElement>('#prevTabs [data-pv="biaya"]').disabled = nb;
  $('#prevTabs [data-pv="pel"]').hidden = tpl || !recs.some(isPelatihan);
  $('#prevTabs [data-pv="biaya"]').hidden = !tpl && recs.length > 0 && recs.every(isPelatihan);
  $$("#prevTabs button").forEach(b => b.classList.toggle("on", b.dataset.pv === prev.part));
  $("#prevNote").textContent = tpl ? "Template mentah (kolom data masih berupa «MERGEFIELD»)" : (recs.length > PREV_MAX ? `Menampilkan ${PREV_MAX} dari ${recs.length} surat` : "") + (nb ? " · Rincian biaya belum dibuat" : "") + " · Tata letak final mengikuti Word";
  $<HTMLDialogElement>("#dPrev").showModal(); renderPreview();
}
$$<HTMLButtonElement>("#prevTabs button").forEach(b => b.onclick = () => { if (b.disabled) return; prev.part = b.dataset.pv ?? "st"; $$<HTMLButtonElement>("#prevTabs button").forEach(x => x.classList.toggle("on", x === b)); renderPreview(); });
$("#prevClose").onclick = () => { $<HTMLDialogElement>("#dPrev").close(); $("#prevDoc").innerHTML = ""; };
$("#prevZoomIn").onclick = () => { prev.zoom = Math.min(2, +(prev.zoom + 0.1).toFixed(2)); applyZoom(); };
$("#prevZoomOut").onclick = () => { prev.zoom = Math.max(0.3, +(prev.zoom - 0.1).toFixed(2)); applyZoom(); };
$("#prevDl").onclick = () => { if (prev.part === "pel"){ const r = prev.recs.find(isPelatihan); if (r) downloadPelatihan(r).catch((e: Error) => toast("Gagal: " + e.message)); return; }
  if (!prev.blob) return; const r = prev.recs[0];
  download(prev.blob, prev.tpl ? (template ? template.name : "SURAT_TUGAS_2026.docx") : prev.recs.length === 1 ? fileName(r, prev.part === "st" ? "ST" : "Rincian Biaya") : `Pratinjau ${prev.part === "st" ? "Surat Tugas" : "Rincian Biaya"} (${Math.min(PREV_MAX, prev.recs.length)} surat).docx`); };
$("#bPreview").onclick = () => { const r = readForm(); openPreview([r], `Pratinjau ST No. ${r.NO || "-"}`); };

/* ================= TEMPLATE EDITOR ================= */
const MC = "http://schemas.openxmlformats.org/markup-compatibility/2006";
/** satu paragraf template yang bisa disunting (fb = salinan di mc:Fallback) */
interface TplPara { p: Element; part: number; orig: string; text: string; fields: boolean; fb: Element | null }
interface TplState { zip: JSZipT; doc: Document; paras: TplPara[]; dirty: Set<number> }
let tplState: TplState | null = null;
const PART_NAMES = ["Surat Tugas", "SPD", "Lampiran SPPD", "Rincian Biaya", "Lampiran ST"];
function ancestor(n: Node, ns: string, name: string): Element | null { for (let x = n.parentNode; x; x = x.parentNode) if (x instanceof Element && x.namespaceURI === ns && x.localName === name) return x; return null; }
function paraText(p: Element): string {
  let out = "", inF = 0, instr = "", phase = "";
  for (const el of p.getElementsByTagNameNS(WNS, "*")){
    if (el.localName === "fldChar"){ const t = el.getAttributeNS(WNS, "fldCharType"); if (t === "begin"){ inF++; instr = ""; phase = "i"; } else if (t === "separate") phase = "r"; else if (t === "end"){ const m = instr.match(/MERGEFIELD\s+"?([^\s"\\]+)/); if (m) out += "«" + m[1] + "»"; inF = Math.max(0, inF - 1); phase = ""; } }
    else if (el.localName === "instrText" && phase === "i") instr += el.textContent;
    else if (el.localName === "t" && !inF) out += el.textContent;
    else if (el.localName === "tab" && !inF) out += "\t";
  }
  return out;
}
async function loadTplEditor(): Promise<void> {
  const zip = await JSZip.loadAsync(tplB64(), { base64: true });
  const doc = new DOMParser().parseFromString(await zip.file("word/document.xml")!.async("string"), "application/xml");
  const body = doc.getElementsByTagNameNS(WNS, "body")[0];
  const partOf = new Map<Node, number>(); let sec = 0, seenKu = false;
  for (const n of [...body.childNodes]){
    if (sec === 2 && !seenKu && (n.textContent || "").includes("KUITANSI")) seenKu = true;
    const part = sec === 0 ? 0 : sec === 1 ? 1 : sec === 2 ? (seenKu ? 3 : 2) : 4;
    partOf.set(n, part);
    if (n instanceof Element && n.localName === "p" && kids(n, "pPr")[0] && kids(kids(n, "pPr")[0], "sectPr")[0]) sec++;
  }
  const top = (p: Node): Node => { let x = p; while (x.parentNode && x.parentNode !== body) x = x.parentNode; return x; };
  const paras: TplPara[] = [];
  for (const p of [...doc.getElementsByTagNameNS(WNS, "p")]){
    if (ancestor(p, MC, "Fallback")) continue;
    if (p.getElementsByTagNameNS(WNS, "p").length) continue;   // only innermost paragraphs
    const text = paraText(p); if (!/[A-Za-z0-9«]/.test(text)) continue;
    const fields = /«[^»]+»/.test(text) || p.getElementsByTagNameNS(WNS, "instrText").length > 0;
    let fb: Element | null = null; const ch = ancestor(p, MC, "Choice");
    if (ch){ const ac = ch.parentNode!, f = [...ac.childNodes].find((x): x is Element => x instanceof Element && x.localName === "Fallback");
      if (f){ const inner = [...ch.getElementsByTagNameNS(WNS, "p")].filter(x => !x.getElementsByTagNameNS(WNS, "p").length), idx = inner.indexOf(p);
        const fps = [...f.getElementsByTagNameNS(WNS, "p")].filter(x => !x.getElementsByTagNameNS(WNS, "p").length); fb = fps[idx] || null; } }
    paras.push({ p, part: partOf.get(top(p)) ?? 0, orig: text, text, fields, fb });
  }
  tplState = { zip, doc, paras, dirty: new Set() };
  $("#tplPart").innerHTML = `<option value="">Semua bagian</option>` + PART_NAMES.map((n, i) => `<option value="${i}">${n}</option>`).join("");
  renderTplEditor();
}
function renderTplEditor(): void {
  if (!tplState) return; const st = tplState;
  const q = $("#tplQ").value.trim().toLowerCase(), part = $<HTMLSelectElement>("#tplPart").value, showF = $("#tplFields").checked;
  const rows = st.paras.map((x, i) => [x, i] as const).filter(([x]) => (showF || !x.fields) && (part === "" || String(x.part) === part) && (!q || x.text.toLowerCase().includes(q)));
  $("#tplCount").textContent = `${rows.length} baris`;
  $("#tTpl tbody").innerHTML = rows.map(([x, i]) => `<tr><td class="muted" style="font-size:12px">${PART_NAMES[x.part]}</td><td>${x.fields
      ? `<div class="muted" style="white-space:pre-wrap">${esc(x.text)}</div>`
      : `<textarea data-ti="${i}" rows="${Math.min(4, Math.ceil(x.text.length / 110))}" style="min-height:34px${st.dirty.has(i) ? ";border-color:var(--warn)" : ""}">${esc(x.text)}</textarea>`}</td></tr>`).join("")
    || `<tr><td colspan="2" class="muted">Tidak ada teks yang cocok.</td></tr>`;
  $("#tplDirty").hidden = !st.dirty.size; $("#bTplSave").disabled = $("#bTplUndo").disabled = !st.dirty.size;
  $("#tplName").textContent = template ? template.name : "SURAT_TUGAS_2026.docx (bawaan)";
}
$("#tTpl").addEventListener("input", e => {
  const i = tg(e).dataset.ti; if (i == null || !tplState) return; const x = tplState.paras[+i];
  x.text = tg(e).value.replace(/\n/g, " "); x.text === x.orig ? tplState.dirty.delete(+i) : tplState.dirty.add(+i);
  tg(e).style.borderColor = tplState.dirty.has(+i) ? "var(--warn)" : "";
  $("#tplDirty").hidden = !tplState.dirty.size; $("#bTplSave").disabled = $("#bTplUndo").disabled = !tplState.dirty.size;
});
["#tplQ", "#tplPart", "#tplFields"].forEach(id => $(id).addEventListener(id === "#tplQ" ? "input" : "change", () => renderTplEditor()));
function setParaText(p: Element, text: string): void {
  const ts = [...p.getElementsByTagNameNS(WNS, "t")];
  if (!ts.length) return;
  // keep tabs as they were: put text segments around existing tabs
  const segs = text.split("\t");
  const tabsRuns = [...p.getElementsByTagNameNS(WNS, "tab")].filter(t => (t.parentNode as Element | null)?.localName === "r");
  if (segs.length > 1 && tabsRuns.length === segs.length - 1){
    // assign each segment to the first <w:t> before the matching tab
    const order = [...p.getElementsByTagNameNS(WNS, "*")].filter(e => (e.localName === "t" || e.localName === "tab") && (e.parentNode as Element | null)?.localName === "r");
    let seg = 0, used = false;
    for (const e of order){ if (e.localName === "tab"){ seg++; used = false; continue; } e.textContent = used ? "" : segs[seg]; e.setAttribute("xml:space", "preserve"); used = true; }
  } else {
    ts[0].textContent = text.replace(/\t/g, " "); ts[0].setAttribute("xml:space", "preserve"); ts.slice(1).forEach(t => t.textContent = "");
  }
}
$("#bTplSave").onclick = async () => {
  if (!tplState || !tplState.dirty.size) return;
  const st = tplState;
  for (const i of st.dirty){ const x = st.paras[i]; setParaText(x.p, x.text); if (x.fb) setParaText(x.fb, x.text); x.orig = x.text; }
  st.zip.file("word/document.xml", xmlOut(st.doc));
  const b64 = await st.zip.generateAsync({ type: "base64", compression: "DEFLATE" });
  const n = st.dirty.size;
  template = { name: (template ? template.name : "SURAT_TUGAS_2026.docx").replace(/( \(diedit\))?\.docx$/i, "") + " (diedit).docx", b64 };
  if (!LS.set("st.template", template)) toast("Template dipakai sementara (terlalu besar untuk disimpan permanen).");
  st.dirty.clear(); tplInfo(); renderTplEditor(); toast(`${n} teks template disimpan. Surat berikutnya memakai template ini.`);
};
$("#bTplUndo").onclick = () => { if (!tplState) return; const st = tplState; for (const i of st.dirty){ const x = st.paras[i]; x.text = x.orig; } st.dirty.clear(); renderTplEditor(); };
$("#bTplDown").onclick = async () => { const blob = await (await JSZip.loadAsync(tplB64(), { base64: true })).generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }); download(blob, template ? template.name : "SURAT_TUGAS_2026.docx"); };
$("#bTplPrev").onclick = () => openPreview([], "Pratinjau template", true);
$("#fTpl2").addEventListener("change", e => { const f = tg(e).files?.[0]; if (!f) return; const dt = new DataTransfer(); dt.items.add(f); $("#fTpl").files = dt.files; $("#fTpl").dispatchEvent(new Event("change")); tg(e).value = ""; });
$("#bTplReset2").onclick = () => { if (!template || confirm("Kembali ke template bawaan? Perubahan template akan hilang.")) $("#bTplReset").click(); };

