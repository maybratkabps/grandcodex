/* ================= LIST ================= */
const sel = new Set<string>();
let listYear = LS.get<string | null>("st.listYear", null);
/** isi pilihan tahun pada <select>; kembalikan tahun terpilih (atau "semua") */
function yearOptions(sel: HTMLElement, cur: string | null): string {
  const years = [...new Set(records.map(stYear).filter((y): y is number => !!y))].sort((a, b) => b - a), cnt: Record<string, number> = {};
  for (const r of records){ const y = stYear(r) || "?"; cnt[y] = (cnt[y] || 0) + 1; }
  const opts = [...years.map(String), "semua"];
  if (!cur || !opts.includes(cur)) cur = opts.includes(String(new Date().getFullYear())) ? String(new Date().getFullYear()) : opts[0];
  sel.innerHTML = opts.map(y => `<option value="${y}" ${y === cur ? "selected" : ""}>${y === "semua" ? `Semua tahun (${records.length})` : `Tahun ${y} (${cnt[y] || 0})`}</option>`).join("");
  return cur;
}
let listLimit = 100;
function listFilter(): (r: StRecord) => boolean {
  const q = $("#q").value.trim().toLowerCase(), Y = listYear;
  const toks = q.split(/\s+/).filter(Boolean);
  return (r: StRecord) => { if (Y && Y !== "semua" && String(stYear(r)) !== Y) return false; if (!toks.length) return true; const h = hayOf(r); return toks.every(t => h.includes(t)); };
}
function renderList(): void {
  $("#cnt").textContent = String(records.length);
  listYear = yearOptions($("#qYear"), listYear);
  const ok = listFilter(), P = pegMap();
  const rows: string[] = []; let nShow = 0, sumShow = 0;
  const all = [...records].sort(byYearNo).reverse().filter(ok);
  for (const r of all){ nShow++; sumShow += computeC(r)._num.jmlTotal || 0; }
  all.slice(0, listLimit).forEach(r => {
    const F = computeC(r);
    const tm = teamOf(r, P), y = stYear(r), noB = r._noBiaya;
    const tags = (isLokal(r) ? `<span class="tag ok">Lokal</span>` : isTransUhar(r) ? `<span class="tag ok">Translok+Uhar</span>` : isPelatihan(r) ? `<span class="tag ok">Pelatihan</span>` : "") + (noB && !isPelatihan(r) ? `<span class="tag warn">belum ada rincian</span>` : "");
    rows.push(`<tr data-no="${esc(r._id)}" class="${sel.has(r._id ?? "") ? "on" : ""}"><td><input type="checkbox" class="ck" ${sel.has(r._id ?? "") ? "checked" : ""}></td>
      <td class="no"><b>${esc(r.NO)}</b><div class="lsub">${y || ""}</div></td>
      <td><div><span class="lt-title" data-a="edit" title="Buka &amp; ubah">${esc(F.MAKSUD__TUJUAN || "(tanpa maksud)")}</span>${tags}</div><div class="lsub one" title="${esc(F.NOMOR_ST + (F.TEMPAT_TUJUAN ? " · " + F.TEMPAT_TUJUAN : ""))}">${esc(F.NOMOR_ST)}${F.TEMPAT_TUJUAN ? " · " + esc(F.TEMPAT_TUJUAN) : ""}</div>
        <div class="lcp"><button type="button" class="cpst" data-cpst="${esc(F.NOMOR_ST)}" title="Salin nomor surat tugas: ${esc(F.NOMOR_ST)}">${IC_CP}<span>No. ST</span></button>${F.TGL_TERBIT_ST ? `<button type="button" class="cpst" data-cptgl="${esc(F.TGL_TERBIT_ST)}" title="Salin tanggal surat tugas: ${esc(F.TGL_TERBIT_ST)}">${IC_CP}<span>${esc(F.TGL_TERBIT_ST)}</span></button>` : ""}</div></td>
      <td><div title="${esc(tm.names.map(x => x.nama).join(", "))}">${esc(tm.label)}</div>${tm.codes.length > 1 ? `<div class="lsub">${tm.peg.length} pegawai${tm.mit.length ? ` · ${tm.mit.length} mitra` : ""}</div>` : ""}</td>
      <td class="hide-sm" style="font-size:13px;white-space:nowrap">${esc(tglRange(r))}</td>
      <td class="num">${isPelatihan(r) ? (pr => pr.length ? "Rp " + esc(rupiah(pr.reduce((a, x) => a + x.full + x.board + x.tr, 0))) + (pr.length > 1 ? `<div class="lsub">${pr.length} orang</div>` : "") : `<span class="muted">–</span>`)(pelatihanRows(r)) : F._num.jml ? "Rp " + esc(rupiah(F._num.jmlTotal)) + (F._num.orang > 1 ? `<div class="lsub">${F._num.orang} orang</div>` : "") : `<span class="muted">–</span>`}</td>
      <td class="acts"><button class="btn sm pri" data-a="doc" title="Unduh Surat Tugas (ST, SPD, Lampiran SPPD, Lampiran ST)">ST</button><button class="btn sm${noB ? "" : " pri"}" data-a="biaya" title="${noB ? "Rincian biaya belum dibuat — buka Edit → Rincian Biaya" : "Unduh Rincian Biaya"}"${isPelatihan(r) ? " hidden" : ""}>Rincian</button>${isPelatihan(r) ? `<button class="btn sm pri" data-a="pel" title="Daftar transport pelatihan (.xlsx)">Transport</button>` : ""}
        <button class="ib" data-a="edit" title="Edit">${IC.edit}</button><button class="ib" data-a="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-a="del" title="Hapus">${IC.del}</button></td></tr>`);
  });
  $("#tList tbody").innerHTML = rows.join("") || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">Tidak ada surat tugas${listYear && listYear !== "semua" ? " pada tahun " + esc(listYear) : ""}.</td></tr>`;
  if (all.length > listLimit) $("#tList tbody").insertAdjacentHTML("beforeend", `<tr><td colspan="7" style="text-align:center;padding:12px"><button class="btn" type="button" id="listMore">Tampilkan ${Math.min(200, all.length - listLimit)} lagi (${all.length - listLimit} tersisa)</button></td></tr>`);
  $("#listInfo").textContent = nShow ? `${nShow} surat cocok${all.length > listLimit ? ` · ${listLimit} ditampilkan` : ""} · total Rp ${rupiah(sumShow)}` : "";
  updSelBtns();
}
function updSelBtns(): void { $("#selBar").hidden = !sel.size; $("#selInfo").textContent = `${sel.size} surat dipilih`; }
const IC = { edit: `<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
  dup: `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>`,
  del: `<svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>` };
function tglRange(r: StRecord): string {
  const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG), M = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
  if (!a) return r.TGL_PERGI || "–";
  const f = (d: Date, y: boolean): string => d.getDate() + " " + M[d.getMonth()] + (y ? " " + d.getFullYear() : "");
  if (!b || +b === +a) return f(a, true);
  if (a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth()) return `${a.getDate()}–${f(b, true)}`;
  return `${f(a, a.getFullYear() !== b.getFullYear())} – ${f(b, true)}`;
}
$("#q").addEventListener("input", debounce(() => { listLimit = 100; renderList(); }, 160));
$("#qYear").addEventListener("change", e => { listYear = tg(e).value; LS.set("st.listYear", listYear); sel.clear(); listLimit = 100; renderList(); });
$("#tList").addEventListener("click", async e => {
  if (tg(e).id === "listMore"){ listLimit += 200; renderList(); return; }
  { const c = tg(e).closest<HTMLElement>("[data-cpst],[data-cptgl]"); if (c){ e.preventDefault(); e.stopPropagation(); return salin(c.dataset.cpst ?? c.dataset.cptgl, c.dataset.cpst != null ? "Nomor surat tugas" : "Tanggal surat tugas"); } }
  const tr = tg(e).closest<HTMLInputElement>("tr[data-no]"); if (!tr) return;
  const no = tr.dataset.no ?? "", rec = records.find(r => r._id === no); if (!rec) return;
  if (tg(e).classList.contains("ck")){ tg(e).checked ? sel.add(no) : sel.delete(no); tr.classList.toggle("on", tg(e).checked); updSelBtns(); return; }
  const a = tg(e).closest<HTMLInputElement>("[data-a]")?.dataset.a; if (!a) return;
  if (a === "doc") await downloadRec(rec, "st");
  if (a === "biaya") await downloadRec(rec, "biaya");
  if (a === "pel") await downloadPelatihan(rec).catch((err: Error) => toast("Gagal: " + err.message));
  if (a === "edit"){ editingId = no; fillForm(rec); setEditFlag(); show("form"); showSub("data"); window.scrollTo(0, 0); }
  if (a === "dup"){ const c = { ...clone(rec), NO: nextNo(), TGL_TERBIT_ST: "", TGL_PERGI: "", TGL_PULANG: "", TGL_KUI: "", TGL_SPD: "" }; delete c._id; editingId = null; _noYear = new Date().getFullYear(); fillForm(c); setEditFlag(); show("form"); showSub("data"); window.scrollTo(0, 0); toast("Salinan dibuat — tanggal dikosongkan, pilih tanggal baru lalu simpan."); }
  if (a === "del" && confirm(`Hapus surat ${compute(rec).NOMOR_ST}?`)){ records = records.filter(r => r._id !== no); sel.delete(no); persist(); renderList(); if (editingId === no) newForm(); }
});
$("#chkAll").addEventListener("change", e => { $$("#tList tbody tr[data-no]").forEach(tr => tg(e).checked ? sel.add(tr.dataset.no ?? "") : sel.delete(tr.dataset.no ?? "")); renderList(); });
const selected = (): StRecord[] => records.filter(r => sel.has(r._id ?? "")).sort(byYearNo);
$("#bPrint").onclick = () => openPrint(selected());
$("#bSelClr").onclick = () => { sel.clear(); $("#chkAll").checked = false; renderList(); };
$("#bXls").onclick = () => {
  let rs = selected();
  if (!rs.length) rs = records.filter(listFilter()).sort(byYearNo);   // semua yang cocok, termasuk yang belum ditampilkan
  if (!rs.length) return toast("Tidak ada surat untuk diekspor.");
  const nos = rs.map(r => parseInt(String(r.NO), 10) || 0).sort((a, b) => a - b);
  const ys = [...new Set(rs.map(stYear).filter(Boolean))];
  exportST(rs, `Surat Tugas ${ys.length === 1 ? ys[0] + " " : ""}${nos[0]}-${nos[nos.length - 1]} (${rs.length} surat).xlsx`); toast(`${rs.length} surat diekspor ke Excel.`);
};
/** baris pratinjau impor surat tugas */
let recImport: { r: StRecord; exists: boolean }[] = [];
function riRefresh(): void {
  const mode = $("#riMode input:checked").value;
  const nNew = recImport.filter(x => !x.exists).length, nOld = recImport.length - nNew;
  $("#riGo").disabled = !(nNew || (mode === "update" && nOld) || pendingRB);
  $("#riGo").textContent = `Impor ${nNew + (mode === "update" ? nOld : 0)} surat` + (pendingRB ? " + rincian biaya" : "");
}
let recImpMode = "st";
$("#fRecImp").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f) importSTFile(f); });
async function importSTFile(f: File, wbIn?: XlsxWB): Promise<void> {
  try{
    const wb = wbIn || XLSX.read(await f.arrayBuffer(), { cellDates: true });
    if (!wbIn) pendingRB = null;
    let got = parseSTSheet(wb);
    if (!got || !got.recs.length){ const g = parseSurtugWorkbook(wb); got = { ...g, mode: "legacy" }; }
    recImpMode = got.mode ?? "st";
    if (!got.recs.length) return toast("Tidak ada sheet surat tugas yang dikenali. Pakai file hasil Ekspor surat tugas.");
    const have = new Set(records.map(recKey));
    recImport = got.recs.map(r => ({ r, exists: have.has(recKey(r)) }));
    const nNew = recImport.filter(x => !x.exists).length;
    $("#riSum").innerHTML = `File <b>${esc(f.name)}</b> (sheet <i>${esc(got.sheet)}</i>): ${recImport.length} surat — <span class="tag ok">${nNew} nomor baru</span> <span class="tag warn">${recImport.length - nNew} nomor sudah ada</span>`;
    $("#riRows").innerHTML = [...recImport.filter(x => !x.exists), ...recImport.filter(x => x.exists)].slice(0, 300).map(({ r, exists }) => { const F = compute(r);
      return `<tr><td><span class="tag ${exists ? "warn" : "ok"}">${exists ? "sudah ada" : "baru"}</span></td><td style="white-space:nowrap">${esc(F.NOMOR_ST)}</td><td>${esc((F.NAMA_PELAKSANA_SPD || "-").split(",")[0])}${F._lampN ? ` <span class="tag">+${F._lampN}</span>` : ""}</td><td>${esc(F.MAKSUD__TUJUAN).slice(0, 70)}</td><td style="white-space:nowrap">${esc(F.TGL_PERGI)}</td><td class="num">${rupiah(F._num.jmlTotal)}</td></tr>`; }).join("");
    $("#riNote").innerHTML = (got.unknown?.length ? `<span class="bad">${got.unknown.length} nama tidak ditemukan di Pegawai & Mitra</span> (mis. ${esc(got.unknown.slice(0, 3).join(", "))}) — impor Pegawai & Mitra dulu agar nama tampil benar. ` : "") + `Surat dicocokkan dengan nomor urut (NO) + tahun tanggal terbit. Kampung tujuan dicocokkan otomatis dengan SK Transport: ${recImport.filter(x => normChips(x.r._kampung).length).length} dari ${recImport.length} surat terhubung ke kampung SK.` + (pendingRB ? " <b>File juga berisi sheet Rincian Biaya</b> — rincian surat yang cocok ikut diperbarui." : "");
    $("#riMode input[value=skip]").checked = true; riRefresh();
    $<HTMLDialogElement>("#dRecImp").showModal();
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
}
$$("#riMode input").forEach(i => i.addEventListener("change", () => riRefresh()));
$("#riCancel").onclick = () => { pendingRB = null; $<HTMLDialogElement>("#dRecImp").close(); };
$("#riGo").onclick = () => {
  const mode = $("#riMode input:checked").value; let nb = 0, nu = 0;
  for (const { r, exists } of recImport){
    if (!exists){ if (recImpMode === "st") r._noBiaya = true; r._id = newId(); records.push(r); nb++; }
    else if (mode === "update"){ const i = records.findIndex(x => recKey(x) === recKey(r)); if (i < 0) continue;
      if (recImpMode === "st"){ const old = records[i]; for (const k of ST_KEYS) delete old[k]; for (const k of ST_KEYS) if (r[k] != null) old[k] = r[k]; }   // hanya data surat tugas, rincian tetap
      else { r._id = records[i]._id; records[i] = r; }
      nu++; }
  }
  records.sort(byYearNo);
  persist(); renderList(); buildLists(); $<HTMLDialogElement>("#dRecImp").close();
  const msg = `Impor selesai: ${nb} surat ditambahkan${nu ? `, ${nu} diperbarui` : ""}.`;
  if (pendingRB){ const w = pendingRB; pendingRB = null; importRBwb(w, false, msg + " "); return; }
  toast(msg + (recImpMode === "st" && nb ? " Rincian biaya surat baru dibuat lewat Edit / Impor." : ""));
};
$("#bDelSel").onclick = () => {
  const rs = selected(); if (!rs.length) return;
  const nos = rs.map(r => r.NO + (stYear(r) ? "/" + stYear(r) : ""));
  if (!confirm(`Hapus ${rs.length} surat tugas terpilih?\n\nNo. ${nos.slice(0, 12).join(", ")}${nos.length > 12 ? ", …" : ""}\n\nTindakan ini tidak bisa dibatalkan (kecuali dari file cadangan).`)) return;
  const del = new Set(rs.map(r => r._id)); records = records.filter(r => !del.has(r._id)); sel.clear();
  if (editingId && del.has(editingId)) newForm();
  persist(); renderList(); buildLists(); toast(`${rs.length} surat dihapus.`);
};
/* perbaiki nomor urut surat terpilih: lanjut dari nomor terakhir (surat lain di tahun yang sama), urut tanggal terbit */
$("#bRenum").onclick = () => {
  const rs = selected(); if (!rs.length) return toast("Centang surat yang nomornya akan diperbaiki.", "warn");
  const pad = (n: number, w: string) => String(n).padStart(Math.max(3, String(w || "").length), "0"), plan: { r: StRecord; old: string; neu: string }[] = [];
  const byY = new Map<number, StRecord[]>(); for (const r of rs){ const y = stYear(r) || 0, g = byY.get(y); if (g) g.push(r); else byY.set(y, [r]); }
  for (const [y, g] of byY){
    const ids = new Set(g.map(r => r._id)), base = records.filter(r => !ids.has(r._id) && (stYear(r) || 0) === y).reduce((m, r) => Math.max(m, parseInt(String(r.NO), 10) || 0), 0);
    g.sort((a, b) => (+(parseTgl(a.TGL_TERBIT_ST) || 0) - +(parseTgl(b.TGL_TERBIT_ST) || 0)) || (parseInt(String(a.NO), 10) || 0) - (parseInt(String(b.NO), 10) || 0));
    g.forEach((r, i) => plan.push({ r, old: String(r.NO), neu: pad(base + 1 + i, String(r.NO)) }));
  }
  const chg = plan.filter(x => x.old !== x.neu); if (!chg.length) return toast("Nomor urut surat terpilih sudah berurutan dari nomor terakhir.", "ok");
  const lines = chg.slice(0, 15).map(x => `${x.old} → ${x.neu}  (${String(x.r.MAKSUD__TUJUAN || "").slice(0, 40)})`).join("\n");
  if (!confirm(`Perbaiki nomor urut ${chg.length} surat tugas (lanjut dari nomor terakhir, urut tanggal terbit)?\n\n${lines}${chg.length > 15 ? "\n…" : ""}\n\nNomor surat tugas (B-…) ikut berubah.`)) return;
  for (const x of chg) x.r.NO = x.neu;
  records.sort(byYearNo); persist(); renderList(); buildLists(); toast(`${chg.length} nomor surat tugas diperbaiki.`, "ok");
};
$("#bZip").onclick = () => { const rs = selected(); if (!rs.length) return toast("Centang surat terlebih dahulu."); openPrint(rs); };

