/* ================= PEGAWAI & MITRA ================= */
let pegTab = "pegawai";
const selPeg = new Set<Pegawai>();
/* peran penanda tangan pegawai: PPK, Bendahara Pengeluaran, Plt Kepala, Kepala Kantor */
const ROLES: [RoleCode, string][] = [["KEPALA", "Kepala Kantor"], ["PLT", "Plt / Plh Kepala"], ["PPK", "PPK"], ["BEND", "Bendahara Pengeluaran"]];
const ROLE_NAME = Object.fromEntries(ROLES) as Record<RoleCode, string>;
const hasRole = (p: Pegawai | null | undefined, rs: RoleCode[]): boolean => !!p && Array.isArray(p.roles) && p.roles.some(r => rs.includes(r));
const roleHolders = (rs: RoleCode[]): Pegawai[] => pegawai.filter(p => hasRole(p, rs));
/* sah bila pegawai punya peran itu; bila belum ada satu pun pegawai berperan tsb, semua pegawai boleh (supaya tidak macet) */
const roleOk = (code: unknown, rs: RoleCode[]): boolean => { const h = roleHolders(rs); return !code || !h.length || h.some(p => String(p.kode) === String(code)); };
const SIGN_FIELDS: [string, RoleCode[], string][] = [["No_PPK", ["PPK"], "PPK"], ["KD_NAMA_KA_PLT_PLH", ["KEPALA", "PLT"], "Kepala / Plt / Plh"], ["KDSPPD", ["KEPALA", "PLT"], "Kepala pada Lampiran SPPD"], ["No_Bend", ["BEND"], "Bendahara Pengeluaran"]];
const isSystemPeg = (p: Pegawai): boolean => String(p.kode) === "999" || /^terlampir$/i.test(String(p.nama).trim());
const isMitra = (p: Pegawai): boolean => !isSystemPeg(p) && (!String(p.pangkat || "").trim() || /^-+$/.test(String(p.pangkat).trim()));
function pegUsage(): Record<string, number> {
  const u: Record<string, number> = {};
  for (const r of records) for (const c of new Set([r.KD_NAMA_SPD, r.No_PPK, r.KD_NAMA_KA_PLT_PLH, r.KDSPPD, r.No_Bend, ...lampOf(r)].map(codeOf).filter(Boolean))) u[c] = (u[c] || 0) + 1;
  return u;
}
function pegShown(): Pegawai[] {
  const q = $("#qp").value.trim().toLowerCase();
  return pegawai.filter(p => (pegTab === "mitra" ? isMitra(p) : !isMitra(p)) && (!q || Object.values(p).join(" ").toLowerCase().includes(q)));
}
function renderPeg(): void {
  const U = pegUsage(), rows = pegShown();
  $("#cPeg").textContent = String(pegawai.filter(p => !isMitra(p) && !isSystemPeg(p)).length);
  $("#cMit").textContent = String(pegawai.filter(isMitra).length);
  $("#tPeg tbody").innerHTML = rows.map(p => { const sys = isSystemPeg(p);
    return `<tr data-k="${esc(p.kode)}"><td>${sys ? "" : `<input type="checkbox" class="pk" ${selPeg.has(p) ? "checked" : ""}>`}</td>${["nama","nip","pangkat","gol","jabatan"].map(f => `<td>${sys ? esc(dyn(p)[f]) : `<input class="pe" data-f="${f}" value="${esc(dyn(p)[f])}" placeholder="${f === "pangkat" ? (pegTab === "mitra" ? "kosong = mitra" : "") : ""}">`}</td>`).join("")}<td class="rolecol">${sys || isMitra(p) ? "" : `<div class="rlgrid">` + ROLES.map(([k, n]) => `<button type="button" class="rl ${hasRole(p, [k]) ? "on" : ""}" data-role="${k}" title="${hasRole(p, [k]) ? "Hapus" : "Beri"} peran ${n}">${k === "BEND" ? "Bendahara" : k === "PLT" ? "Plt" : k === "KEPALA" ? "Kepala" : "PPK"}</button>`).join("") + `</div>`}</td><td class="num muted">${U[p.kode] || ""}</td><td>${sys ? `<span class="tag">sistem</span>` : `<button class="btn sm del" data-a="del">Hapus</button>`}</td></tr>`; }).join("")
    || `<tr><td colspan="8" class="muted">Tidak ada data.</td></tr>`;
  $("#pegAll").checked = rows.length > 0 && rows.filter(p => !isSystemPeg(p)).every(p => selPeg.has(p));
  $("#pegSel").textContent = selPeg.size ? `${selPeg.size} dipilih` : "";
  $("#bPegDel").disabled = !selPeg.size; $("#bPegDel").textContent = selPeg.size ? `Hapus terpilih (${selPeg.size})` : "Hapus terpilih";
  $("#bPegAdd").textContent = pegTab === "mitra" ? "+ Tambah mitra" : "+ Tambah pegawai";
  $$("#tPeg .rolecol").forEach(c => c.hidden = pegTab === "mitra");
  $("#roleSum").hidden = pegTab === "mitra";
  $("#roleSum").innerHTML = `<b>Penanda tangan</b> <span class="muted">— hanya pegawai dengan peran ini yang bisa dipilih di Surat Tugas, Rincian Biaya &amp; Honor:</span><div class="rsgrid">` + ROLES.map(([k, n]) => { const h = roleHolders([k]);
    return `<div><small>${esc(n)}</small>${h.length ? h.map(p => `<span>${esc(p.nama.split(",")[0])}</span>`).join("") : `<span class="muted">belum ada — semua pegawai boleh dipilih</span>`}</div>`; }).join("") + `</div>`;
}
$("#tPeg").addEventListener("click", e => {
  const b = tg(e).closest<HTMLInputElement>("button[data-role]"); if (!b) return;
  const p = pegawai.find(x => x.kode === b.closest<HTMLInputElement>("tr")!.dataset.k); if (!p) return;
  const k = b.dataset.role as RoleCode, rs = new Set<RoleCode>(p.roles || []); rs.has(k) ? rs.delete(k) : rs.add(k);
  p.roles = ROLES.map(([x]) => x).filter(x => rs.has(x)); if (!p.roles.length) delete p.roles;
  persist(); renderPeg(); toast(`${p.nama.split(",")[0]}: ${rs.has(k) ? "diberi" : "dilepas dari"} peran ${ROLE_NAME[k]}.`);
});
$("#qp").addEventListener("input", () => renderPeg());
$$("#pegTabs button").forEach(b => b.onclick = () => { pegTab = b.dataset.pt ?? "pegawai"; $$("#pegTabs button").forEach(x => x.classList.toggle("on", x === b)); selPeg.clear(); renderPeg(); });
$("#tPeg").addEventListener("change", e => {
  if (!tg(e).classList.contains("pk")) return;
  const p = pegawai.find(x => x.kode === tg(e).closest<HTMLInputElement>("tr")!.dataset.k); if (!p) return;
  tg(e).checked ? selPeg.add(p) : selPeg.delete(p); renderPeg();
});
$("#pegAll").addEventListener("change", e => { for (const p of pegShown()) if (!isSystemPeg(p)) tg(e).checked ? selPeg.add(p) : selPeg.delete(p); renderPeg(); });
function deletePeople(list: Pegawai[]): void {
  if (!list.length) return;
  const U = pegUsage(), used = list.filter(p => U[p.kode]);
  const msg = `Hapus ${list.length} ${pegTab === "mitra" ? "mitra" : "pegawai"}?` + (used.length ? `\n\n${used.length} di antaranya dipakai di surat tugas (${used.slice(0, 3).map(p => p.nama.split(",")[0]).join(", ")}${used.length > 3 ? ", …" : ""}). Nama mereka akan kosong di surat tersebut.` : "");
  if (!confirm(msg)) return;
  const del = new Set(list); pegawai = pegawai.filter(p => !del.has(p)); list.forEach(p => selPeg.delete(p));
  persist(); renderPeg(); buildLists(); toast(`${list.length} data dihapus.`);
}
$("#bPegDel").onclick = () => deletePeople([...selPeg]);
$("#tPeg").addEventListener("change", e => {
  const inp = tg(e).closest<HTMLInputElement>("input.pe"); if (!inp) return;
  const p = pegawai.find(x => x.kode === inp.closest<HTMLInputElement>("tr")!.dataset.k); if (!p) return;
  const v = inp.value.trim(), f = inp.dataset.f ?? "";
  if (dyn(p)[f] === v) return;
  if (f === "nama" && !v){ toast("Nama tidak boleh kosong."); inp.value = p.nama; return; }
  dyn(p)[f] = v; persist(); buildLists(); inp.style.borderColor = "var(--ok)"; setTimeout(() => inp.style.borderColor = "", 900);
  if (f === "pangkat" && isMitra(p) !== (pegTab === "mitra")) { selPeg.delete(p); renderPeg(); toast(`${p.nama.split(",")[0]} dipindah ke tab ${isMitra(p) ? "Mitra" : "Pegawai"}.`); }
});
$("#tPeg").addEventListener("click", e => {
  if (tg(e).dataset.a !== "del") return; const k = tg(e).closest<HTMLInputElement>("tr")!.dataset.k;
  const p = pegawai.find(x => x.kode === k); if (p) deletePeople([p]);
});
/* ---- ekspor & impor pegawai / mitra ---- */
const PEG_HDR = ["NO", "NAMA LENGKAP", "NIP BARU", "NIP LAMA", "PANGKAT", "GOLONGAN", "JABATAN", "STATUS"];
$("#bPegExp").onclick = () => {
  const row = (p: Pegawai) => [/^\d+$/.test(p.kode) ? +p.kode : p.kode, p.nama, p.nip, "", p.pangkat, p.gol, p.jabatan, isSystemPeg(p) ? "Sistem" : isMitra(p) ? "Mitra" : "Pegawai", (p.roles || []).map(r => ROLE_NAME[r]).join("; ")];
  const mitra = pegTab === "mitra", list = pegawai.filter(p => !isSystemPeg(p) && isMitra(p) === mitra), nm = mitra ? "Mitra" : "Pegawai";
  const ws = XLSX.utils.aoa_to_sheet([[...PEG_HDR, "Peran Tanda Tangan"], ...list.map(row)]); ws["!cols"] = [6, 38, 22, 12, 22, 10, 40, 10, 34].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, nm);
  XLSX.writeFile(wb, `${nm} (${list.length} orang).xlsx`);
  toast(`${list.length} ${nm.toLowerCase()} diekspor.`);
};
/** pegawai dari file impor (tanpa kode) */
interface PegIn { nama: string; nip: string; pangkat: string; gol: string; jabatan: string }
let pegImport: { x: PegIn; m: Pegawai | null; status: string }[] = [];
const normNip = (v: unknown): string => String(v ?? "").replace(/\D/g, "");
function readPegSheet(wb: XlsxWB): PegIn[] {
  const out: PegIn[] = [];
  for (const sn of wb.SheetNames){
    if (/^hanya/i.test(sn) && wb.SheetNames.some(n => /^pegawai$/i.test(n))) continue;   // ekspor aplikasi: cukup baca sheet utama
    const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: false });
    const hi = rows.findIndex(r => r.some(c => /nama/i.test(String(c))));
    if (hi < 0) continue;
    const H = rows[hi].map(c => String(c).trim().toUpperCase());
    const col = (...re: RegExp[]) => H.findIndex(h => re.some(x => x.test(h)));
    const cNama = col(/^NAMA/), cNip = col(/^NIP( BARU)?$/, /^NIP/), cPkt = col(/^PANGKAT/), cGol = col(/^GOL/), cJab = col(/^JABATAN/), cSt = col(/^STATUS/);
    if (cNama < 0) continue;
    for (const r of rows.slice(hi + 1)){
      const nama = String(r[cNama] ?? "").trim(); if (!nama || /^terlampir$/i.test(nama)) continue;
      const st = cSt >= 0 ? String(r[cSt]).trim() : "";
      if (/^sistem$/i.test(st)) continue;
      let pangkat = cPkt >= 0 ? String(r[cPkt]).trim() : "";
      if (/^mitra$/i.test(st)) pangkat = pangkat && pangkat !== "-" ? pangkat : "-";
      out.push({ nama, nip: cNip >= 0 ? String(r[cNip]).trim() || "-" : "-", pangkat: pangkat || "-", gol: cGol >= 0 ? String(r[cGol]).trim() || "-" : "-", jabatan: cJab >= 0 ? String(r[cJab]).trim() : (/^mitra$/i.test(st) ? "Mitra Statistik" : "") });
    }
    if (out.length) break;
  }
  return out;
}
function matchPeg(x: PegIn): Pegawai | null {
  const nip = normNip(x.nip);
  if (nip.length >= 8){ const m = pegawai.find(p => normNip(p.nip) === nip); if (m) return m; }
  return pegawai.find(p => p.nama.trim().toLowerCase() === x.nama.toLowerCase()) || pegawai.find(p => normName(p.nama) === normName(x.nama)) || null;
}
$("#fPegImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
    const list = readPegSheet(wb);
    if (!list.length) return toast("Tidak ditemukan kolom NAMA di file ini.");
    const seen = new Set<string>();
    pegImport = list.filter(x => { const k = normNip(x.nip).length >= 8 ? normNip(x.nip) : normName(x.nama); if (seen.has(k)) return false; seen.add(k); return true; }).map(x => {
      const m = matchPeg(x);
      const nv = (v: unknown): string => { const t = String(v ?? "").trim(); return /^-+$/.test(t) ? "" : t; };
      const changed = m && ["nama", "nip", "pangkat", "gol", "jabatan"].some(k => nv(dyn(m)[k]) !== nv(dyn(x)[k]));
      return { x, m, status: !m ? "baru" : changed ? "diperbarui" : "sama" };
    });
    const c = (k: string) => pegImport.filter(i => i.status === k).length;
    $("#piSum").innerHTML = `File <b>${esc(f.name)}</b>: ${pegImport.length} orang — <span class="tag ok">${c("baru")} baru</span> <span class="tag warn">${c("diperbarui")} diperbarui</span> <span class="tag">${c("sama")} sama</span>`;
    const show = pegImport.filter(i => i.status !== "sama").concat(pegImport.filter(i => i.status === "sama")).slice(0, 300);
    $("#piRows").innerHTML = show.map(({ x, m, status }) => `<tr><td><span class="tag ${status === "baru" ? "ok" : status === "diperbarui" ? "warn" : ""}">${status}</span></td><td>${esc(x.nama)}${m && m.nama !== x.nama ? `<div class="muted" style="font-size:11px">sebelumnya: ${esc(m.nama)}</div>` : ""}</td><td>${esc(x.nip)}</td><td>${esc([x.pangkat, x.gol].filter(v => v && v !== "-").join(" / ") || "Mitra")}</td><td>${esc(x.jabatan)}</td></tr>`).join("");
    $("#piGo").disabled = !c("baru") && !c("diperbarui");
    $<HTMLDialogElement>("#dPegImp").showModal();
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
});
$("#piCancel").onclick = () => $<HTMLDialogElement>("#dPegImp").close();
$("#piGo").onclick = () => {
  let max = pegawai.reduce((m, p) => (+p.kode < 999 ? Math.max(m, +p.kode || 0) : m), 0), nb = 0, nu = 0;
  for (const { x, m, status } of pegImport){
    if (status === "baru"){ pegawai.push({ kode: String(++max === 999 ? ++max : max), ...x }); nb++; }
    else if (status === "diperbarui" && m){ Object.assign(m, x); nu++; }
  }
  persist(); renderPeg(); buildLists(); $<HTMLDialogElement>("#dPegImp").close();
  toast(`Impor selesai: ${nb} ditambahkan, ${nu} diperbarui.`);
};

$("#bPegAdd").onclick = () => {
  const max = pegawai.reduce((m, p) => (+p.kode < 999 ? Math.max(m, +p.kode || 0) : m), 0);
  pegawai.push(pegTab === "mitra" ? { kode: String(max + 1), nama: "Nama mitra baru", nip: "-", pangkat: "-", gol: "-", jabatan: "Mitra Statistik" }
    : { kode: String(max + 1), nama: "Nama pegawai baru", nip: "", pangkat: "Isi pangkat", gol: "", jabatan: "" });
  persist(); $("#qp").value = ""; renderPeg(); buildLists();
  const last = $("#tPeg tbody tr:last-child input[data-f=nama]"); if (last){ last.scrollIntoView({ block: "center" }); last.focus(); last.select(); }
};

/* ================= datalists ================= */
function buildLists(): void {
  $("#dl-peg").innerHTML = pegawai.map(p => `<option value="${esc(p.nama)}">${esc([p.jabatan, p.nip && p.nip !== "-" && p.nip !== "Terlampir" ? "NIP " + p.nip : ""].filter(Boolean).join(" · "))}</option>`).join("");
  const uniq = (k: string): string[] => [...new Set(records.map(r => r[k]).filter(Boolean).map(String))].sort();
  const set = (id: string, k: string) => $(id).innerHTML = uniq(k).map(v => `<option value="${esc(v)}">`).join("");
  set("#dl-nolengkap", "NoLengkap"); set("#dl-kegiatan", "kegiatan"); set("#dl-angkut", "ALAT_ANGKUTAN_YANG_DIGUNAKAN");
  set("#dl-berangkat", "TEMPAT_BERANGKAT"); set("#dl-hotel", "HOTEL_TEMPAT"); set("#dl-tujuan", "TEMPAT_TUJUAN");
  const U = usage();
  $("#dl-mak").innerHTML = [...pokDB.akun].sort((x, y) => (+/^5241/.test(y.akun) - +/^5241/.test(x.akun))).map(a => { const sisa = a.pagu - a.blokir - (U[a.mak]?.j || 0);
    return `<option value="${esc(a.mak)}">${esc(a.nama)} · ${esc(a.roNama)} · sisa Rp ${rupiah(sisa)}</option>`; }).join("");
  $("#dl-kode").innerHTML = kodeDB.codes.map(c => `<option value="${esc(c.k)}">${esc(c.d)} — ${esc(kodeGroup(c.k))}</option>`).join("");
  $("#dl-kampung").innerHTML = kampungDB.map(k => `<option value="${esc(kamLabel(k))}">`).join("");
  $("#dl-kampung-nama").innerHTML = kampungDB.map(k => `<option value="${esc(title(k.kampung))}">${esc(title(k.distrik))} · Rp ${rupiah(k.tarif)}</option>`).join("");
  if (!$("#dl-trans")) document.body.insertAdjacentHTML("beforeend", `<datalist id="dl-trans"></datalist>`);
  $("#dl-trans").innerHTML = otherTransRef().map(([t, v]) => `<option value="${esc(t)}">Rp ${rupiah(num(v))}</option>`).join("");
  fillPresets();
}

/* ================= referensi ================= */
const selKam = new Set<Kampung>(), selKode = new Set<KodeDB["codes"][number]>();
function renderKam(): void {
  const q = $("#qk").value.trim().toLowerCase();
  const rows = kampungDB.map((k, i) => [k, i] as const).filter(([k]) => !q || (k.distrik + " " + k.kampung).toLowerCase().includes(q));
  $("#kInfo").textContent = `${rows.length} dari ${kampungDB.length} kampung`;
  $("#kamAll").checked = rows.length > 0 && rows.every(([k]) => selKam.has(k));
  $("#bKamTarif").disabled = !selKam.size; $("#bKamTarif").textContent = selKam.size ? `Ubah tarif terpilih (${selKam.size})…` : "Ubah tarif terpilih…";
  $("#bKamDel").disabled = !selKam.size; $("#bKamDel").textContent = selKam.size ? `Hapus terpilih (${selKam.size})` : "Hapus terpilih";
  $("#tKam tbody").innerHTML = rows.map(([k, i]) => `<tr data-i="${i}"><td><input type="checkbox" class="kk" ${selKam.has(k) ? "checked" : ""}></td><td contenteditable="true" data-f="distrik">${esc(k.distrik)}</td><td contenteditable="true" data-f="kampung">${esc(k.kampung)}</td><td class="num"><input type="number" class="tarif-in" min="0" step="1000" value="${k.tarif}" style="width:140px;text-align:right" title="Tarif PP — ketik lalu Enter / klik di luar"></td><td class="num muted">${rupiah(k.tarif / 2)}</td><td style="text-align:center"><input type="checkbox" class="kl" ${kamLokal(k) ? "checked" : ""} title="Kampung Lokal — boleh dipakai surat tugas Lokal"></td><td contenteditable="true" data-f="ket">${esc(k.ket)}</td><td><button class="btn sm del" data-a="del">Hapus</button></td></tr>`).join("");
}
$("#qk").addEventListener("input", () => renderKam());
$("#tKam").addEventListener("focusout", e => {
  const td = tg(e).closest<HTMLInputElement>("td[data-f]"); if (!td) return; const k = kampungDB[Number((td.parentNode as HTMLElement).dataset.i)]; if (!k) return;
  const f = td.dataset.f ?? "", v = td.textContent.trim();
  dyn(k)[f] = f === "tarif" ? num(v.replace(/\./g, "")) : (f === "ket" ? v : v.toUpperCase());
  if (f === "tarif"){ td.textContent = rupiah(k.tarif); td.nextElementSibling!.textContent = rupiah(k.tarif / 2); }
  persist(); buildLists(); renderChips();
});
$("#tKam").addEventListener("click", e => {
  if (tg(e).dataset.a !== "del") return; const i = Number(tg(e).closest<HTMLInputElement>("tr")!.dataset.i);
  if (confirm("Hapus kampung " + title(kampungDB[i].kampung) + "?")){ selKam.delete(kampungDB[i]); kampungDB.splice(i, 1); persist(); renderKam(); buildLists(); }
});
$("#tKam").addEventListener("change", e => {
  if (tg(e).classList.contains("tarif-in")){
    const k = kampungDB[Number(tg(e).closest<HTMLInputElement>("tr")!.dataset.i)]; if (!k) return;
    k.tarif = Math.max(0, num(tg(e).value)); tg(e).closest<HTMLInputElement>("td")!.nextElementSibling!.textContent = rupiah(k.tarif / 2);
    persist(); buildLists(); renderChips(); toast(`Tarif PP ${title(k.kampung)} = Rp ${rupiah(k.tarif)}`); return;
  }
  if (tg(e).classList.contains("kl")){ const k = kampungDB[Number(tg(e).closest<HTMLInputElement>("tr")!.dataset.i)]; if (!k) return; k.lokal = tg(e).checked; persist(); buildLists(); _dataVer++; toast(`${title(k.kampung)} ${k.lokal ? "diberi" : "dilepas dari"} label Lokal.`); return; }
  if (!tg(e).classList.contains("kk")) return; const k = kampungDB[Number(tg(e).closest<HTMLInputElement>("tr")!.dataset.i)]; tg(e).checked ? selKam.add(k) : selKam.delete(k); renderKam(); });
$("#kamAll").addEventListener("change", e => { const q = $("#qk").value.trim().toLowerCase(); kampungDB.filter(k => !q || (k.distrik + " " + k.kampung).toLowerCase().includes(q)).forEach(k => tg(e).checked ? selKam.add(k) : selKam.delete(k)); renderKam(); });
$("#bKamTarif").onclick = () => {
  if (!selKam.size) return;
  const v = prompt(`Tarif PP baru (Rp) untuk ${selKam.size} kampung terpilih:\n(boleh juga +50000 / -50000 untuk menaikkan / menurunkan)`, "");
  if (v == null || !v.trim()) return;
  const t = v.trim().replace(/\./g, ""), rel = /^[+-]/.test(t), d = num(t);
  if (!rel && !(d >= 0)) return toast("Nilai tidak valid.");
  for (const k of selKam) k.tarif = Math.max(0, rel ? k.tarif + d : d);
  persist(); renderKam(); buildLists(); renderChips(); toast(`Tarif ${selKam.size} kampung diperbarui.`);
};
$("#bKamDel").onclick = () => {
  if (!selKam.size || !confirm(`Hapus ${selKam.size} kampung dari SK Transport?`)) return;
  const n = selKam.size; kampungDB = kampungDB.filter(k => !selKam.has(k)); selKam.clear(); persist(); renderKam(); buildLists(); renderChips(); toast(`${n} kampung dihapus.`);
};
$("#bKamAdd").onclick = () => {
  kampungDB.push({ distrik: "DISTRIK", kampung: "KAMPUNG BARU", tarif: 0, ket: "" }); persist(); $("#qk").value = ""; renderKam(); buildLists();
  const td = $("#tKam tbody tr:last-child td[data-f=kampung]"); td.scrollIntoView({ block: "center" }); td.focus(); document.execCommand && document.execCommand("selectAll", false);
};
function renderTarif(): void {
  const grups = [...new Set(tarifDB.map(t => t.grup))];
  $("#tTarif tbody").innerHTML = tarifDB.map((t, i) => { const rule = t.grup === RULES_GRUP;
    return `<tr data-i="${i}"><td>${rule ? `<span class="muted">${esc(t.grup)}</span>` : `<input class="tf" data-f="grup" value="${esc(t.grup)}" list="dl-tgrup">`}</td>
      <td>${rule ? `${esc(t.nama)} <span class="tag" title="Dipakai aturan biaya otomatis — uraian tidak bisa diubah">aturan</span>` : `<input class="tf" data-f="nama" value="${esc(t.nama)}">`}</td>
      <td><input class="tf" data-f="nilai" type="number" min="0" step="1000" value="${t.nilai}" style="text-align:right"></td>
      <td>${rule ? "" : `<button class="btn sm del" data-tdel="${i}">Hapus</button>`}</td></tr>`; }).join("");
  if (!$("#dl-tgrup")) document.body.insertAdjacentHTML("beforeend", `<datalist id="dl-tgrup"></datalist>`);
  $("#dl-tgrup").innerHTML = [...new Set(["MOBIL 2026", "MOBIL BANDARA 2026", "UHAR 2026", "INAP 2026", "TRANSLOK 2026", ...grups.filter(g => g !== RULES_GRUP)])].map(g => `<option value="${esc(g)}">`).join("");
}
$("#tTarif").addEventListener("change", e => {
  const inp = tg(e).closest<HTMLInputElement>("input.tf"); if (!inp) return; const t = tarifDB[Number(inp.closest<HTMLInputElement>("tr")!.dataset.i)]; if (!t) return;
  const f = inp.dataset.f === "grup" ? "grup" : inp.dataset.f === "nilai" ? "nilai" : "nama", v = inp.value.trim();
  if (f === "nilai") t.nilai = Math.max(0, num(v));
  else { if (!v){ toast((f === "grup" ? "Grup" : "Uraian") + " tidak boleh kosong."); inp.value = t[f]; return; } t[f] = v.toUpperCase(); inp.value = t[f]; }
  persist(); buildLists(); inp.style.borderColor = "var(--ok)"; setTimeout(() => inp.style.borderColor = "", 900);
});
$("#tTarif").addEventListener("click", e => {
  const i = tg(e).dataset.tdel; if (i == null) return; const t = tarifDB[+i];
  if (!confirm(`Hapus tarif "${t.nama}" (${t.grup})?`)) return;
  tarifDB.splice(+i, 1); persist(); renderTarif(); buildLists(); toast("Tarif dihapus.");
});
$("#bTarifAdd").onclick = () => {
  const at = tarifDB.findIndex(t => t.grup === RULES_GRUP); const t: Tarif = { grup: "MOBIL 2026", nama: "URAIAN BARU", nilai: 0 };
  at < 0 ? tarifDB.push(t) : tarifDB.splice(at, 0, t);
  persist(); renderTarif(); buildLists();
  const inp = $(`#tTarif tr[data-i="${tarifDB.indexOf(t)}"] input[data-f=nama]`); inp.scrollIntoView({ block: "center" }); inp.focus(); inp.select();
};
function renderKode(): void {
  const q = $("#qc").value.trim().toLowerCase();
  const all = kodeDB.codes.filter(c => !q || (c.k + " " + c.d + " " + kodeGroup(c.k)).toLowerCase().includes(q)), rows = all.slice(0, 400);
  $("#cInfo").textContent = `${all.length} dari ${kodeDB.codes.length} kode${all.length > 400 ? " (400 pertama ditampilkan — persempit pencarian)" : ""}`;
  $("#kodeAll").checked = rows.length > 0 && rows.every(c => selKode.has(c));
  $("#bKodeDel").disabled = !selKode.size; $("#bKodeDel").textContent = selKode.size ? `Hapus terpilih (${selKode.size})` : "Hapus terpilih";
  $("#tKode tbody").innerHTML = rows.map(c => `<tr data-ci="${kodeDB.codes.indexOf(c)}"><td><input type="checkbox" class="kc" ${selKode.has(c) ? "checked" : ""}></td><td style="white-space:nowrap;padding-left:${8 + (c.l || 0) * 14}px" contenteditable="true" data-f="k"><b>${esc(c.k)}</b></td><td contenteditable="true" data-f="d">${esc(c.d)}</td><td class="muted">${esc(kodeGroup(c.k))}</td><td style="white-space:nowrap"><button class="btn sm" data-k="${esc(c.k)}" data-to="form">Pakai di Personal</button> <button class="btn sm" data-k="${esc(c.k)}" data-to="mass">Massal</button></td></tr>`).join("");
}
$("#qc").addEventListener("input", () => renderKode());
$("#tKode").addEventListener("change", e => { if (!tg(e).classList.contains("kc")) return; const c = kodeDB.codes[Number(tg(e).closest<HTMLInputElement>("tr")!.dataset.ci)]; tg(e).checked ? selKode.add(c) : selKode.delete(c); renderKode(); });
$("#kodeAll").addEventListener("change", e => { const q = $("#qc").value.trim().toLowerCase(); kodeDB.codes.filter(c => !q || (c.k + " " + c.d + " " + kodeGroup(c.k)).toLowerCase().includes(q)).slice(0, 400).forEach(c => tg(e).checked ? selKode.add(c) : selKode.delete(c)); renderKode(); });
$("#tKode").addEventListener("focusout", e => {
  const td = tg(e).closest<HTMLInputElement>("td[data-f]"); if (!td) return; const c = kodeDB.codes[Number((td.parentNode as HTMLElement).dataset.ci)]; if (!c) return;
  const f = td.dataset.f, v = td.textContent.trim();
  if (f === "k"){
    const k = v.toUpperCase().replace(/\s+/g, "");
    if (k === c.k) return;
    if (!/^[A-Z]{2,3}\.\d{3,4}$/.test(k)){ toast("Format kode harus seperti VS.330"); td.innerHTML = `<b>${esc(c.k)}</b>`; return; }
    if (kodeDB.codes.some(x => x !== c && x.k === k)){ toast("Kode " + k + " sudah ada."); td.innerHTML = `<b>${esc(c.k)}</b>`; return; }
    c.k = k; td.innerHTML = `<b>${esc(k)}</b>`; td.nextElementSibling!.nextElementSibling!.textContent = kodeGroup(k);
  } else { if (v === c.d) return; c.d = v; }
  persist(); buildLists();
});
$("#bKodeDel").onclick = () => {
  if (!selKode.size || !confirm(`Hapus ${selKode.size} kode klasifikasi?`)) return;
  const n = selKode.size; kodeDB.codes = kodeDB.codes.filter(c => !selKode.has(c)); selKode.clear(); persist(); renderKode(); buildLists(); toast(`${n} kode dihapus.`);
};
$("#bKodeAdd").onclick = () => {
  let i = 1, k = ""; do { k = "XX." + String(i++).padStart(3, "0"); } while (kodeDB.codes.some(c => c.k === k));
  const c: KodeDB["codes"][number] = { k, l: 0, d: "Uraian kode baru" }; kodeDB.codes.unshift(c); persist(); $("#qc").value = ""; renderKode(); buildLists();
  const td = $("#tKode tbody tr:first-child td[data-f=k]"); td.scrollIntoView({ block: "center" }); td.focus(); document.execCommand && document.execCommand("selectAll", false);
  toast("Ketik kode baru (mis. VS.340) lalu uraiannya.");
};
$("#tKode").addEventListener("click", e => {
  const k = tg(e).dataset.k; if (!k) return;
  if (tg(e).dataset.to === "mass"){ mIn("kode").value = k; mIn("NoLengkap").value = composeNL(k, mIn("NoLengkap").value, mIn("TGL_TERBIT_ST").value); massCommon = readCommon(); persistMass(); updateMassInfo(); show("mass"); }
  else { form.NoLengkap.value = composeNL(k, form.NoLengkap.value, form.TGL_TERBIT_ST.value); refresh(); show("form"); showSub("data"); }
  window.scrollTo(0, 0); toast("Kode " + k + " dipakai pada nomor surat.");
});
function parseKodeSheet(rows: unknown[][]): KodeDB {
  const groups: Record<string, string> = { KP: "Kepegawaian", KU: "Keuangan" }, codes: KodeDB["codes"] = [], seen = new Set<string>(); let cur: string | null = null;
  for (const r of rows){
    const v = Array.from({ length: 7 }, (_, i) => r[i] == null ? "" : String(r[i]).replace(/\s+/g, " ").trim());
    if (!v.some(Boolean)) continue;
    const g = v[0], rest = v.slice(1);
    if (!g){ const m = rest[0].match(/\(([A-Z]{2,3})\)\s*$/); if (m){ cur = m[1]; continue; } }
    const idx = rest.findIndex(x => /^\d{3,4}$/.test(x));
    if (/^[A-Z]{2,3}$/.test(g)){ cur = g; if (idx < 0){ groups[g] = title(rest[0]); continue; } }
    if (idx < 0 || !cur) continue;
    const k = cur + "." + rest[idx]; if (seen.has(k)) continue; seen.add(k);
    let d = rest.slice(idx + 1).find(Boolean) || "";
    const raw = r[idx + 2]; if (raw && /\s{6,}/.test(String(raw))) d = String(raw).trim().split(/\s{6,}/)[0].trim();
    d = d.replace(/\.$/, ""); if (d === d.toUpperCase()) d = title(d);
    codes.push({ k, l: idx, d });
  }
  return { groups, codes };
}
function parseTransSheet(rows: unknown[][]): { kam: Kampung[]; tar: Tarif[] } {
  const h = rows[0].map(x => String(x ?? ""));
  const tc = h.map((x, i) => [x, i] as const).filter(([x]) => /transport.*\(pp\)/i.test(x)).pop();
  const ci = tc ? tc[1] : 3;
  const kam: Kampung[] = [], tar: Tarif[] = []; let sect: string | null = null;
  for (const r of rows.slice(1)){
    if (r[0] && r[1]) kam.push({ distrik: String(r[0]).trim(), kampung: String(r[1]).trim(), tarif: num(r[ci]), ket: String(r[ci + 1] ?? "").trim() });
    const lab = r[ci + 2]; if (!lab) continue;
    if (r[ci + 3] == null || r[ci + 3] === ""){ sect = String(lab).trim(); continue; }
    const nv = r[ci + 3]; if (typeof nv === "number") tar.push({ grup: sect || "MOBIL", nama: String(lab).trim(), nilai: nv });
  }
  return { kam, tar };
}

