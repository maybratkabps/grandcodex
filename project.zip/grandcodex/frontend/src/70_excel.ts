/* ================= excel import/export ================= */
const COLS = ["NO","NOSURTUG","NoLengkap","NOMOR_ST","TGL_TERBIT_ST","KD_NAMA_SPD","NAMA_PELAKSANA_SPD","NIP_PELAKSANA_SPD","JABATAN","PANGKAT","GOL","kegiatan","MAKSUD__TUJUAN","NOMOR_SPD","ALAT_ANGKUTAN_YANG_DIGUNAKAN","TEMPAT_BERANGKAT","TEMPAT_TUJUAN","LAMA_JALAN","TGL_PERGI","TGL_PULANG","MAK","TGL_SPD","No_PPK","PPK","NIP_PPK","KD_NAMA_KA_PLT_PLH","KAPLTPLH","KDSPPD","KepalaSPPD","NIPKepala","LAMA_INAP","TDK_INAP_HOTEL","TOTAL_BIAYA_TDK_INAP_HOTEL","PENG_RIIL","Terbilang3","LAMA_UH","NILAI_UH","TOTAL_UH","TOTAL_TRANS","JUMLAH","TERBILANG","TGL_KUI","No)Bend","BEND","NIP_BEND",
  ...[1,2,3,4,5].flatMap(i => [`KodeLampiran${i}`, i === 1 ? "NAMALAMPIRAN_1" : `NAMA_LAMPIRAN_${i}`, `NIP_LAMPIRAN_${i}`, `JABATAN_LAMPIRAN_${i}`, `PANGKAT_LAMPIRAN_${i}`, `GOL_LAMPIRAN_${i}`]),
  ...Array.from({ length: MAXTR }, (_, i) => [`KetTransport_${i+1}`, `Nilai${i+1}`]).flat(), "KodeLampiranLain", "NamaLampiranLain", "KampungSK", "JENIS", "RINCIAN", "PER_ORANG", "HOTEL_TEMPAT", "LAMA_HOTEL", "TARIF_HOTEL", "TOTAL_HOTEL"];
function exportXlsxLegacy(recs: StRecord[], fname: string): void {
  const aoa = [COLS];
  for (const r of recs){
    const F = compute(r), lamp = lampOf(r);
    aoa.push(COLS.map(c => {
      if (c === "No)Bend") return r.No_Bend ?? "";
      if (c === "KodeLampiranLain") return lamp.slice(5).join(", ");
      if (c === "JENIS") return r.JENIS || "";
      if (c === "RINCIAN") return r._noBiaya ? "Belum dibuat" : "Ada";
      if (c === "HOTEL_TEMPAT") return r.HOTEL_TEMPAT || "";
      if (c === "LAMA_HOTEL") return r.LAMA_HOTEL == null ? "" : num(r.LAMA_HOTEL);
      if (c === "TARIF_HOTEL") return r.TARIF_HOTEL == null ? "" : num(r.TARIF_HOTEL);
      if (c === "TOTAL_HOTEL") return F._num.totHotel || "";
      if (c === "PER_ORANG") return r._perOrang ? JSON.stringify(Object.fromEntries(Object.entries(r._perOrang).map(([k, v]) => [pegMap()[k]?.nama || k, v]))) : "";
      if (c === "NamaLampiranLain") return lamp.slice(5).map(x => pegMap()[x]?.nama || x).join("; ");
      if (c === "KampungSK") return normChips(r._kampung).map(x => x.k + (x.pp ? "" : "|1/2")).join("; ");
      const ml = c.match(/^KodeLampiran(\d)$/); if (ml){ const v = lamp[+ml[1] - 1]; return v == null ? "" : (/^\d+$/.test(v) ? +v : v); }
      if (/^(KD_NAMA_SPD|No_PPK|KD_NAMA_KA_PLT_PLH|KDSPPD)$/.test(c)) return r[c] != null && /^\d+$/.test(r[c]) ? +r[c] : (r[c] ?? "");
      const nums: Record<string, number> = { TDK_INAP_HOTEL: num(r.TDK_INAP_HOTEL), TOTAL_BIAYA_TDK_INAP_HOTEL: F._num.totInap, PENG_RIIL: F._num.totRiil, NILAI_UH: num(r.NILAI_UH), TOTAL_UH: F._num.totUH, TOTAL_TRANS: F._num.totTr, JUMLAH: F._num.jml };
      if (c in nums) return nums[c];
      if (/^Nilai\d+$/.test(c)) return r[c] == null ? "" : num(r[c]);
      if (["LAMA_JALAN","LAMA_INAP","LAMA_UH"].includes(c)) return r[c] == null ? (c === "LAMA_JALAN" ? "" : num(F[c])) : num(r[c]);
      return F[c] ?? "";
    }));
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "Surtug 2026");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["NO","NAMA LENGKAP","NIP BARU","NIP LAMA","PANGKAT","GOLONGAN","JABATAN"], ...pegawai.map(p => [/^\d+$/.test(p.kode) ? +p.kode : p.kode, p.nama, p.nip, "", p.pangkat, p.gol, p.jabatan])]), "Pegawai");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["Distrik","Kampung","Transport Kabupaten-Kampung (PP) 2026","Keterangan"], ...kampungDB.map(k => [k.distrik, k.kampung, k.tarif, kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? [k.ket, "Lokal"].filter(Boolean).join(" · ") : !kamLokal(k) && /lokal/i.test(k.ket ?? "") ? String(k.ket).replace(/\s*·?\s*lokal/ig, "").trim() : k.ket])]), "SK TRANS 2026");
  // sheet ringkas yang mudah dibaca
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([["No","Nomor Surat Tugas","Tanggal Terbit","Pelaksana","NIP","Anggota Tim","Kegiatan","Maksud / Tujuan","Jenis","Tempat Tujuan","Tgl Pergi","Tgl Pulang","Lama (hari)","MAK","Uang Harian","Penginapan riil","Penginapan hotel","Transport","Jumlah per orang","Jumlah orang","Total biaya","Status Rincian"],
    ...recs.map(r => { const F = compute(r); return [r.NO, F.NOMOR_ST, F.TGL_TERBIT_ST, F.NAMA_PELAKSANA_SPD, F.NIP_PELAKSANA_SPD, lampOf(r).map(c => pegMap()[c]?.nama || c).join("; "), F.kegiatan, F.MAKSUD__TUJUAN, r.JENIS || "Remote", F.TEMPAT_TUJUAN, F.TGL_PERGI, F.TGL_PULANG, num(r.LAMA_JALAN) || "", F.MAK, F._num.totUH, F._num.totInap, F._num.totHotel, F._num.totTr, F._num.jml, F._num.orang, F._num.jmlTotal, r._noBiaya ? "Belum dibuat" : "Ada"]; })]), "Daftar Surat Tugas");
  wb.SheetNames.unshift(wb.SheetNames.pop()!);
  XLSX.writeFile(wb, fname);
}
/* ---------- SURAT TUGAS: satu sheet ---------- */
const ST_HDR = ["No", "Nomor Surat Tugas", "Akhiran Nomor", "Tanggal Terbit", "Pelaksana", "NIP Pelaksana", "Anggota Tim", "Kegiatan", "Maksud / Tujuan", "Lokal / Remote", "Alat Angkutan", "Tempat Berangkat", "Tempat Tujuan", "Kampung Tujuan (SK)", "Tgl Pergi", "Tgl Pulang", "Lama (hari)", "MAK", "PPK", "Kepala / Plt / Plh", "Kepala Lampiran SPPD", "Status Rincian"];
function kamCellText(r: StRecord): string { const M = kamByKey(); return normChips(r._kampung).map(c => { const k = M[c.k]; return k ? `${title(k.kampung)} (${title(k.distrik)})${c.pp ? "" : " ½"}` : c.k; }).join("; "); }
/** tanpa nama berkas → kembalikan lembar kerja (untuk digabung); dengan nama → langsung unduh */
function exportST(recs: StRecord[]): XlsxWS;
function exportST(recs: StRecord[], fname: string): void;
function exportST(recs: StRecord[], fname?: string): XlsxWS | void {
  const P = pegMap();
  const rows = recs.map(r => { const F = compute(r);
    return [r.NO, F.NOMOR_ST, r.NoLengkap || "", F.TGL_TERBIT_ST, F.NAMA_PELAKSANA_SPD, F.NIP_PELAKSANA_SPD, lampOf(r).map(c => P[c]?.nama || c).join("; "), F.kegiatan, F.MAKSUD__TUJUAN, r.JENIS || "Remote", F.ALAT_ANGKUTAN_YANG_DIGUNAKAN, F.TEMPAT_BERANGKAT, F.TEMPAT_TUJUAN, kamCellText(r), F.TGL_PERGI, F.TGL_PULANG, num(r.LAMA_JALAN) || "", F.MAK, F.PPK, F.KAPLTPLH, F.KepalaSPPD, r._noBiaya ? "Belum dibuat" : "Ada"]; });
  const ws = XLSX.utils.aoa_to_sheet([ST_HDR, ...rows]);
  ws["!cols"] = [6, 30, 24, 16, 30, 22, 40, 26, 44, 12, 10, 16, 34, 40, 18, 18, 8, 28, 28, 28, 28, 12].map(w => ({ wch: w }));
  if (!fname) return ws;
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Surat Tugas"); XLSX.writeFile(wb, fname);
}
function findKampungCell(txt: string): Chip | null {
  const m = String(txt).trim().match(/^(.*?)\s*(?:\(([^)]*)\))?\s*(½|1\/2)?$/);
  const nm = (m ? m[1] : txt).trim(), ds = m && m[2] ? m[2].trim().toLowerCase() : "";
  const k = (ds && kampungDB.find(x => x.kampung.toLowerCase() === nm.toLowerCase() && x.distrik.toLowerCase() === ds)) || findKampung(nm);
  return k ? { k: kKey(k), pp: !(m && m[3]) } : null;
}
/* baca sheet "Surat Tugas" hasil ekspor di atas */
/** hasil membaca sheet surat tugas dari Excel */
interface StImport { recs: StRecord[]; sheet: string | null; unknown?: string[]; mode?: string }
function parseSTSheet(wb: XlsxWB): StImport | null {
  for (const sn of wb.SheetNames){
    const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: false });
    const hi = rows.findIndex(r => r.some(c => /^nomor surat tugas$/i.test(String(c).trim())) && r.some(c => /^pelaksana$/i.test(String(c).trim())));
    if (hi < 0) continue;
    const H = rows[hi].map(c => String(c).trim().toLowerCase()), col = (name: string) => H.indexOf(name.toLowerCase());
    const get = (row: unknown[], name: string): string => { const i = col(name); return i < 0 ? "" : String(row[i] ?? "").trim(); };
    const unknown = new Set<string>(), recs: StRecord[] = [];
    const byName = (nm: string): string | null => { if (!nm) return null; if (/^terlampir$/i.test(nm)) return pegMap()["999"] ? "999" : null; const c = resolvePeg(nm); if (!c) unknown.add(nm); return c; };
    for (const row of rows.slice(hi + 1)){
      const NO = get(row, "No"); if (!NO || !get(row, "Maksud / Tujuan")) continue;
      const r: StRecord = { NO: String(NO), NoLengkap: get(row, "Akhiran Nomor"), TGL_TERBIT_ST: get(row, "Tanggal Terbit"), kegiatan: get(row, "Kegiatan"), MAKSUD__TUJUAN: get(row, "Maksud / Tujuan"),
        JENIS: ((v: string) => jenisOf(v) || "Remote")(get(row, "Lokal / Remote") || get(row, "Jenis Perjalanan")), ALAT_ANGKUTAN_YANG_DIGUNAKAN: get(row, "Alat Angkutan"), TEMPAT_BERANGKAT: get(row, "Tempat Berangkat"), TEMPAT_TUJUAN: get(row, "Tempat Tujuan"),
        TGL_PERGI: get(row, "Tgl Pergi"), TGL_PULANG: get(row, "Tgl Pulang"), MAK: get(row, "MAK") };
      const L = num(get(row, "Lama (hari)")); if (L) r.LAMA_JALAN = L;
      for (const [k, h] of [["KD_NAMA_SPD", "Pelaksana"], ["No_PPK", "PPK"], ["KD_NAMA_KA_PLT_PLH", "Kepala / Plt / Plh"], ["KDSPPD", "Kepala Lampiran SPPD"]]){ const c = byName(get(row, h)); if (c) r[k] = c; }
      setLamp(r, get(row, "Anggota Tim").split(";").map(x => x.trim()).filter(Boolean).map(byName).filter((c): c is string => !!c));
      const ks = get(row, "Kampung Tujuan (SK)").split(";").map(x => x.trim()).filter(Boolean).map(findKampungCell).filter((c): c is Chip => !!c);
      if (ks.length) r._kampung = ks;
      else if (r.TEMPAT_TUJUAN){ const d = detectKampung(r.TEMPAT_TUJUAN); if (d.found.length) r._kampung = d.found.map(k => ({ k: kKey(k), pp: true })); }
      for (const k of Object.keys(r)) if (r[k] === "") delete r[k];
      recs.push(r);
    }
    return { recs, sheet: sn, unknown: [...unknown], mode: "st" };
  }
  return null;
}
const ST_KEYS = ["NoLengkap", "TGL_TERBIT_ST", "KD_NAMA_SPD", "kegiatan", "MAKSUD__TUJUAN", "JENIS", "ALAT_ANGKUTAN_YANG_DIGUNAKAN", "TEMPAT_BERANGKAT", "TEMPAT_TUJUAN", "TGL_PERGI", "TGL_PULANG", "LAMA_JALAN", "MAK", "No_PPK", "KD_NAMA_KA_PLT_PLH", "KDSPPD", "_kampung", "lampiran", "KodeLampiran1", "KodeLampiran2", "KodeLampiran3", "KodeLampiran4", "KodeLampiran5"];


/* ---------- RINCIAN BIAYA: satu sheet ---------- */
const rbHdr = (nT: number): string[] => ["No", "Nomor Surat Tugas", "Untuk", "Jenis", "Lama Perjalanan", "Lama Uang Harian", "Tarif Uang Harian", "Lama Inap (tanpa hotel)", "Tarif Inap", "Hotel / Tempat", "Malam Hotel", "Tarif Hotel",
  ...Array.from({ length: nT }, (_, i) => [`Keterangan Transport ${i + 1}`, `Nilai Transport ${i + 1}`]).flat(), "Hotel lain (dengan bukti)", "Transport Lokal (riil)", "Mobil Bandara (riil)", "Jumlah", "Tanggal Kuitansi", "Bendahara"];
const lastTr = (r: StRecord): number => { let n = 0; for (let i = 1; i <= MAXTR; i++) if ((r["KetTransport_" + i] ?? "") !== "" || (r["Nilai" + i] ?? "") !== "") n = i; return n; };
function rbRow(r: StRecord, untuk: string, F: StRecord, nT: number): unknown[] {
  return [r.NO, F.NOMOR_ST, untuk, r.JENIS || "Remote", num(r.LAMA_JALAN) || "", F._num.luh, F._num.nuh, F._num.inap, F._num.tdk, F.HOTEL_TEMPAT, F._num.lh || "", F._num.th || "",
    ...Array.from({ length: nT }, (_, i) => [r["KetTransport_" + (i + 1)] ?? "", r["Nilai" + (i + 1)] === "" || r["Nilai" + (i + 1)] == null ? "" : num(r["Nilai" + (i + 1)])]).flat(),
    Math.max(0, F._num.totHotel - F._num.lh0) || "", F._num.totLok || "", F._num.totBdr || "", F._num.jml, F.TGL_KUI, F.BEND];
}
function rbSheet(recs: StRecord[]): XlsxWS | null {
  const P = pegMap(), items: [StRecord, string, StRecord][] = [];
  for (const r of recs){
    if (r._noBiaya) continue;
    const ps = personCodes(r, P), F = compute(r);
    items.push([r, ps.length > 1 ? `Semua anggota (${ps.length} orang)` : (F.NAMA_PELAKSANA_SPD || ""), F]);
    if (ps.length > 1) for (const c of ps){ const x = personRec(r, c); items.push([x, P[c]?.nama || c, compute(x)]); }
  }
  if (!items.length) return null;
  const nT = Math.max(TR_BASE, ...items.map(([x]) => lastTr(x)));
  const ws = XLSX.utils.aoa_to_sheet([rbHdr(nT), ...items.map(([x, u, F]) => rbRow(x, u, F, nT))]);
  ws["!cols"] = [6, 30, 32, 10, 8, 8, 12, 8, 12, 26, 8, 12, ...Array.from({ length: nT }, () => [46, 12]).flat(), 14, 14, 14, 14, 18, 28].map(w => ({ wch: w }));
  return ws;
}
$("#bAllExp").onclick = () => {
  if (!records.length) return toast("Belum ada surat tugas.");
  const recs = [...records].sort(byYearNo), wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, exportST(recs), "Surat Tugas");
  const rb = rbSheet(recs); if (rb) XLSX.utils.book_append_sheet(wb, rb, "Rincian Biaya");
  const nb = recs.filter(r => !r._noBiaya).length;
  XLSX.writeFile(wb, `Surat Tugas & Rincian Biaya (${recs.length} surat).xlsx`);
  toast(`${recs.length} surat tugas & rincian biaya ${nb} surat diekspor dalam satu file.`);
};
let pendingRB: XlsxWB | null = null;
$("#fAllImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{
    const buf = await f.arrayBuffer(), wbST = XLSX.read(buf, { cellDates: true }), wbRB = XLSX.read(buf, { type: "array" });
    const hasST = (parseSTSheet(wbST)?.recs.length || 0) > 0, hasRB = !!rbRowsOf(wbRB);
    if (!hasST && !hasRB) return toast("Tidak ditemukan sheet 'Surat Tugas' atau 'Rincian Biaya'. Pakai file hasil Ekspor.");
    if (hasST){ pendingRB = hasRB ? wbRB : null; importSTFile(f, wbST); }
    else importRBwb(wbRB, true);
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
});
function rbRowsOf(wb: XlsxWB): unknown[][] | null {
  for (const sn of wb.SheetNames){ const a = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: true }); const hi = a.findIndex(r => r.some(c => String(c).trim() === "Untuk") && r.some(c => String(c).trim() === "Tarif Uang Harian")); if (hi >= 0) return a.slice(hi); }
  return null;
}
function importRBwb(wb: XlsxWB, ask = true, prefix = ""): void {
  try{
    let rows = rbRowsOf(wb);
    if (!rows) return toast("Tidak ditemukan sheet Rincian Biaya (kolom 'Untuk', 'Tarif Uang Harian', …). Pakai file hasil Ekspor rincian biaya.");
    const H = rows[0].map(c => String(c).trim()), ix = (n: string) => H.indexOf(n), val = (row: unknown[], n: string): unknown => { const i = ix(n); return i < 0 ? "" : row[i]; };
    /** nilai rincian satu baris; trans = [keterangan, nilai] per baris transport */
    type RbVals = { LAMA_UH: number; NILAI_UH: number; LAMA_INAP: number; TDK_INAP_HOTEL: number; HOTEL_TEMPAT: string; LAMA_HOTEL: number; TARIF_HOTEL: number; trans: [string, number | ""][] };
    const toRec = (row: unknown[]): RbVals => { const o: RbVals = { LAMA_UH: num(val(row, "Lama Uang Harian")), NILAI_UH: num(val(row, "Tarif Uang Harian")), LAMA_INAP: num(val(row, "Lama Inap (tanpa hotel)")), TDK_INAP_HOTEL: num(val(row, "Tarif Inap")),
        HOTEL_TEMPAT: String(val(row, "Hotel / Tempat") || "").trim(), LAMA_HOTEL: num(val(row, "Malam Hotel")), TARIF_HOTEL: num(val(row, "Tarif Hotel")), trans: [] };
      for (let i = 1; i <= MAXTR; i++){ const k = String(val(row, `Keterangan Transport ${i}`) ?? "").trim(), v = val(row, `Nilai Transport ${i}`); o.trans.push([k, v === "" || v == null ? "" : num(v)]); }
      return o; };
    const groups = new Map<string, unknown[][]>();
    for (const row of rows.slice(1)){ const no = String(val(row, "No") ?? "").trim(); if (!no) continue; const g = no + "|" + String(val(row, "Nomor Surat Tugas") ?? "").trim(); const g0 = groups.get(g); if (g0) g0.push(row); else groups.set(g, [row]); }
    let nOk = 0; const missing: string[] = [];
    const plan: { rec: StRecord; base: RbVals; baseRow: unknown[]; people: { code: string; o: RbVals }[] }[] = [];
    for (const [g, rs] of groups){
      const [no, nomor] = [g.slice(0, g.indexOf("|")), g.slice(g.indexOf("|") + 1)];
      const rec = (nomor && records.find(r => compute(r).NOMOR_ST === nomor)) || records.find(r => noKey(r.NO) === noKey(no) && (!nomor || !/\/(\d{4})$/.test(nomor) || String(stYear(r)) === nomor.match(/\/(\d{4})$/)![1]));
      if (!rec){ missing.push(no); continue; }
      const baseRow = rs.find(r => /^semua anggota/i.test(String(val(r, "Untuk")))) || rs[0];
      plan.push({ rec, base: toRec(baseRow), baseRow, people: rs.filter(r => r !== baseRow).map(r => ({ code: resolvePeg(String(val(r, "Untuk"))), o: toRec(r) })).filter((x): x is { code: string; o: RbVals } => !!x.code) });
    }
    if (!plan.length) return toast(`Tidak ada nomor surat yang cocok${missing.length ? ` (mis. No. ${missing.slice(0, 3).join(", ")})` : ""}.`);
    if (ask && !confirm(`Perbarui rincian biaya ${plan.length} surat dari file?${missing.length ? `\n\n${missing.length} nomor tidak ditemukan dan dilewati.` : ""}`)) return;
    for (const { rec, base, baseRow, people } of plan){
      for (const k of ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL"] as const) rec[k] = base[k];
      if (base.HOTEL_TEMPAT) rec.HOTEL_TEMPAT = base.HOTEL_TEMPAT; else delete rec.HOTEL_TEMPAT;
      for (let i = 1; i <= MAXTR; i++){ const [k, v] = base.trans[i - 1]; if (k) rec["KetTransport_" + i] = k; else delete rec["KetTransport_" + i]; if (v !== "") rec["Nilai" + i] = v; else delete rec["Nilai" + i]; }
      const kui = String(val(baseRow, "Tanggal Kuitansi") || "").trim(); if (kui) rec.TGL_KUI = kui;
      const bd = resolvePeg(String(val(baseRow, "Bendahara") || "")); if (bd) rec.No_Bend = bd;
      delete rec._noBiaya; delete rec.TOTAL_TRANS;
      const po: Record<string, Partial<RbVals>> = {};
      for (const { code, o } of people){
        const d: Record<string, unknown> = {};
        for (const k of ["LAMA_UH", "NILAI_UH", "LAMA_INAP", "TDK_INAP_HOTEL", "LAMA_HOTEL", "TARIF_HOTEL"] as const) if (o[k] !== base[k]) d[k] = o[k];
        if (o.HOTEL_TEMPAT !== base.HOTEL_TEMPAT) d.HOTEL_TEMPAT = o.HOTEL_TEMPAT;
        if (JSON.stringify(o.trans) !== JSON.stringify(base.trans)) d.trans = o.trans;
        if (Object.keys(d).length) po[code] = d;
      }
      if (Object.keys(po).length) rec._perOrang = po; else delete rec._perOrang;
      nOk++;
    }
    persist(); renderList(); buildLists();
    toast(prefix + `Rincian biaya ${nOk} surat diperbarui${missing.length ? `, ${missing.length} nomor dilewati` : ""}.`);
  }catch(err){ console.error(err); toast("Gagal membaca file rincian: " + (err as Error).message); }
}
/* baca sheet "Surtug …" (format mail merge / hasil ekspor aplikasi) → rekaman surat tugas.
   Kode pegawai dicocokkan ulang lewat NAMA bila kolom nama tersedia, supaya aman dipakai di perangkat lain. */
function parseSurtugWorkbook(wb: XlsxWB): StImport {
  const ds = (v: unknown) => v instanceof Date ? fmtDate(v) : v;
  const sn = wb.SheetNames.find(n => /surtug/i.test(n) && wb.Sheets[n]["A1"] && /^NO$/i.test(String(wb.Sheets[n]["A1"].v).trim()))
    || wb.SheetNames.find(n => { const a = wb.Sheets[n]["A1"], b = wb.Sheets[n]["B1"]; return a && /^NO$/i.test(String(a.v).trim()) && b && /NOSURTUG|NOMOR/i.test(String(b.v)); });
  if (!sn) return { recs: [], sheet: null };
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[sn], { defval: null });
  const IN = ["NO","NoLengkap","TGL_TERBIT_ST","KD_NAMA_SPD","kegiatan","MAKSUD__TUJUAN","ALAT_ANGKUTAN_YANG_DIGUNAKAN","TEMPAT_BERANGKAT","TEMPAT_TUJUAN","LAMA_JALAN","TGL_PERGI","TGL_PULANG","MAK","No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD","LAMA_INAP","TDK_INAP_HOTEL","LAMA_UH","NILAI_UH","TOTAL_TRANS","TGL_KUI","No)Bend","HOTEL_TEMPAT","LAMA_HOTEL","TARIF_HOTEL","KodeLampiran1","KodeLampiran2","KodeLampiran3","KodeLampiran4","KodeLampiran5", ...Array.from({ length: MAXTR }, (_, i) => [`KetTransport_${i+1}`, `Nilai${i+1}`]).flat()];
  const CODES = /^(KD_NAMA_SPD|No_PPK|KD_NAMA_KA_PLT_PLH|KDSPPD|No_Bend|KodeLampiran\d)$/;
  const NAMECOL: Record<string, string> = { KD_NAMA_SPD: "NAMA_PELAKSANA_SPD", No_PPK: "PPK", KD_NAMA_KA_PLT_PLH: "KAPLTPLH", KDSPPD: "KepalaSPPD", No_Bend: "BEND", KodeLampiran1: "NAMALAMPIRAN_1", KodeLampiran2: "NAMA_LAMPIRAN_2", KodeLampiran3: "NAMA_LAMPIRAN_3", KodeLampiran4: "NAMA_LAMPIRAN_4", KodeLampiran5: "NAMA_LAMPIRAN_5" };
  const P = pegMap(), unknown = new Set<string>(), recs: StRecord[] = [];
  const byName = (nm: unknown): string | null => { const t = String(nm ?? "").trim(); if (!t || t === "0") return null; if (/^terlampir$/i.test(t)) return P["999"] ? "999" : null; const c = resolvePeg(t); if (!c) unknown.add(t); return c; };
  for (const row of rows){
    if (!row.MAKSUD__TUJUAN) continue;
    const r: StRecord = {};
    for (const k of IN){ let v = ds(row[k]); if (v == null || v === "") continue; const key = k === "No)Bend" ? "No_Bend" : k; r[key] = CODES.test(key) ? String(v).trim() : (typeof v === "number" ? v : String(v)); }
    for (const [k, nc] of Object.entries(NAMECOL)){ if (row[nc] == null || row[nc] === "") continue; const c = byName(row[nc]); if (c) r[k] = c; }
    r.NO = String(r.NO ?? "").trim();
    let extra = String(row.KodeLampiranLain ?? "").split(/[,;]/).map(x => x.trim()).filter(Boolean);
    const extraN = String(row.NamaLampiranLain ?? "").split(";").map(x => x.trim()).filter(Boolean);
    if (extraN.length) extra = extraN.map((n, i) => byName(n) || extra[i]).filter(Boolean);
    if (extra.length || r.KodeLampiran1) setLamp(r, [...[1,2,3,4,5].map(i => r["KodeLampiran" + i]).filter(Boolean), ...extra]);
    if (row.JENIS) r.JENIS = String(row.JENIS);
    if (/belum/i.test(String(row.RINCIAN ?? ""))) r._noBiaya = true;
    if (row.PER_ORANG){ try{ const po: Record<string, unknown> = {}; for (const [nm, v] of Object.entries(JSON.parse(String(row.PER_ORANG)))){ const c = byName(nm) || nm; po[c] = v; } if (Object.keys(po).length) r._perOrang = po; }catch(e){} }
    if (row.KampungSK) r._kampung = String(row.KampungSK).split(";").map(x => x.trim()).filter(Boolean).map(x => ({ k: x.replace(/\|1\/2$/, ""), pp: !/\|1\/2$/.test(x) }));
    else if (r.TEMPAT_TUJUAN){ const d = detectKampung(String(r.TEMPAT_TUJUAN)); if (d.found.length) r._kampung = d.found.map(k => ({ k: kKey(k), pp: true })); }
    if (r.NO) recs.push(r);
  }
  return { recs, sheet: sn, unknown: [...unknown] };
}
$("#fXls").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; if (!f) return;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
    const ds = (v: unknown) => v instanceof Date ? fmtDate(v) : v;
    const aoa = (n: string) => XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[n], { header: 1, defval: null, raw: true });
    const msg: string[] = []; let nR = 0, nU = 0;
    if (wb.Sheets.Pegawai){
      const rows = aoa("Pegawai").slice(1);
      const np = rows.filter(r => r[0] != null && r[1] != null).map(r => ({ kode: String(r[0]).trim(), nama: String(r[1]).trim(), nip: String(r[2] ?? "").trim(), pangkat: String(r[4] ?? "").trim(), gol: String(r[5] ?? "").trim(), jabatan: String(r[6] ?? "").trim() }));
      if (np.length){ pegawai = np; msg.push(`${np.length} pegawai`); }
    }
    const tsn = wb.SheetNames.filter(n => /^SK\s*TRANS/i.test(n)).sort().pop();
    if (tsn){ const { kam, tar } = parseTransSheet(aoa(tsn)); if (kam.length){ kampungDB = kam; msg.push(`${kam.length} kampung`); } if (tar.length) tarifDB = tar; }
    const ksn = wb.SheetNames.find(n => /KODE\s*ARSIP/i.test(n));
    if (ksn){ const kd = parseKodeSheet(aoa(ksn)); if (kd.codes.length){ kodeDB = kd; msg.push(`${kd.codes.length} kode klasifikasi`); } }
    const got = parseSurtugWorkbook(wb);
    for (const r of got.recs){ const i = records.findIndex(x => recKey(x) === recKey(r)); if (i >= 0){ r._id = records[i]._id; records[i] = r; nU++; } else { records.push(r); nR++; } }
    if (nR || nU) msg.push(`${nR} surat baru, ${nU} diperbarui`);
    persist(); renderAll();
    toast(msg.length ? "Impor selesai: " + msg.join(", ") + "." : "Tidak ada sheet yang dikenali di file ini.");
  }catch(err){ console.error(err); toast("Gagal membaca Excel: " + (err as Error).message); }
  tg(e).value = "";
});
$("#bBackup").onclick = () => download(new Blob([JSON.stringify({ pegawai, records, kampung: kampungDB, tarif: tarifDB, kode: kodeDB, pok: pokDB, pokY: Object.fromEntries(pokYears().map(y => [y, pokGet(y)])), pokYear, honor: honorDB, rekening: rekMap, surat: suratDB, suratFmt: nsFmt, ang: (() => { persistAng(); const o: Record<string, unknown> = {}; for (const y of angYearsOpt()){ const v = Object.fromEntries(ANG_N.map(n => [n, LS.get<unknown>(angK(n, y), null)]).filter(x => x[1] != null)); if (Object.keys(v).length) o[y] = v; } return o; })(), angYear }, null, 1)], { type: "application/json" }), "cadangan-surat-tugas.json");
$("#fJson").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; if (!f) return;
  try{ const d = JSON.parse(await f.text()); if (!Array.isArray(d.records) || !Array.isArray(d.pegawai)) throw new Error("format tidak dikenali");
    pegawai = d.pegawai; records = d.records;
    if (Array.isArray(d.kampung)) kampungDB = d.kampung; if (Array.isArray(d.tarif)) tarifDB = d.tarif; if (d.kode && Array.isArray(d.kode.codes)) kodeDB = d.kode; if (d.pokY && typeof d.pokY === "object"){ for (const [y, v] of Object.entries(d.pokY as Record<string, Pok | null>)) if (v && Array.isArray(v.akun)) pokSave(y, v); if (d.pokYear && pokGet(String(d.pokYear))) pokYear = String(d.pokYear); pokDB = pokGet(pokYear) || pokDB; LS.set("st.pokYear", pokYear); }
    else if (d.pok && Array.isArray(d.pok.akun)){ pokYear = String(d.pok.meta?.tahun || pokYear); pokDB = d.pok; pokSave(pokYear, pokDB); LS.set("st.pokYear", pokYear); } if (Array.isArray(d.honor)){ honorDB = d.honor; if (d.rekening) rekMap = d.rekening; persistHonor(); } if (d.ang && typeof d.ang === "object"){ for (const [y, v] of Object.entries(d.ang as Record<string, Record<string, unknown>>)) for (const n of ANG_N) if (v[n] != null) LS.set(angK(n, y), v[n]); angLoad(angYear); }
    else { if (d.rpd) rpdDB = d.rpd; if (d.rpdKet) rpdKet = d.rpdKet; if (d.tup) tupDB = d.tup; if (d.up) upDB = d.up; if (Array.isArray(d.revisi)) revDB = d.revisi; persistAng(); } if (Array.isArray(d.surat)){ suratDB = d.surat; if (d.suratFmt) nsFmt = { ...NS_FMT0, ...d.suratFmt }; persistSurat(); }
    persist(); renderAll(); newForm(); toast("Cadangan dipulihkan."); }
  catch(err){ toast("Gagal memulihkan: " + (err as Error).message); }
  tg(e).value = "";
});
async function importTemplate(f: File, kind: "st" | "rb"): Promise<void> {
  const buf = await f.arrayBuffer(), b = new Uint8Array(buf); let s = ""; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000));
  let xml = ""; try{ xml = await (await JSZip.loadAsync(buf)).file("word/document.xml")!.async("string"); }catch(e){ return toast("File bukan dokumen Word (.docx) yang valid."); }
  const hasST = /MERGEFIELD\s+"?(NOMOR_ST|MAKSUD__TUJUAN)\b/.test(xml), hasRB = /MERGEFIELD\s+"?KetTransport_1\b/.test(xml);
  if (kind === "rb" && !hasRB && !confirm("File ini tidak berisi kolom «KetTransport_1» — sepertinya bukan template Rincian Biaya. Tetap pakai?")) return;
  if (kind === "st" && !hasST && !confirm("File ini tidak berisi kolom «NOMOR_ST» — sepertinya bukan template Surat Tugas. Tetap pakai?")) return;
  const t = { name: f.name, b64: btoa(s), kind };
  if (kind === "rb"){ templateRB = t; if (!LS.set("st.templateRB", t)) toast("Template dipakai sementara (terlalu besar untuk disimpan permanen)."); }
  else {
    if (template && !template.kind && !templateRB){ templateRB = { ...template, kind: "rb" }; LS.set("st.templateRB", templateRB); }   // template lama tetap dipakai untuk rincian
    template = t; if (!LS.set("st.template", t)) toast("Template dipakai sementara (terlalu besar untuk disimpan permanen).");
  }
  tplInfo(); toast(`Template ${kind === "rb" ? "Rincian Biaya" : "Surat Tugas"} diganti: ${f.name}`);
}
$("#fTpl").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f) importTemplate(f, "st").catch((err: Error) => toast("Gagal impor template: " + err.message)); });
$("#fTplRB").addEventListener("change", e => { const f = tg(e).files?.[0]; tg(e).value = ""; if (f) importTemplate(f, "rb").catch((err: Error) => toast("Gagal impor template: " + err.message)); });
async function exportTemplate(kind = "st"): Promise<void> {
  const zip = await JSZip.loadAsync(tplB64(kind), { base64: true });
  for (const p of Object.keys(zip.files)){
    if (!/^word\/(document|header\d*|footer\d*)\.xml$/.test(p)) continue;
    const x = await zip.file(p)!.async("string"); if (!x.includes("MERGEFIELD") && p !== "word/document.xml") continue;
    const doc = new DOMParser().parseFromString(x, "application/xml");
    if (p === "word/document.xml") keepParts(doc, new Set(kind === "rb" ? FILE_BIAYA : FILE_ST));
    /** field MERGEFIELD yang sedang dibaca: instruksi, fase (i = instruksi, r = hasil), teks hasil, run pembuka */
    type Fld = { instr: string; phase: string; res: Element[]; begin: Element; runs: Element[] };
    const stack: Fld[] = [];
    for (const r of [...doc.getElementsByTagNameNS(WNS, "r")]){
      for (const fr of stack) if (fr.runs[fr.runs.length - 1] !== r) fr.runs.push(r);
      for (const ch of [...r.childNodes]){
        if (!isEl(ch) || ch.namespaceURI !== WNS) continue;
        if (ch.localName === "fldChar"){
          const ty = ch.getAttributeNS(WNS, "fldCharType");
          if (ty === "begin") stack.push({ instr: "", phase: "i", res: [], begin: r, runs: [r] });
          else if (ty === "separate" && stack.length) stack[stack.length - 1].phase = "r";
          else if (ty === "end" && stack.length){
            const f = stack.pop()!, m = f.instr.match(/MERGEFIELD\s+"?([^\s"\\]+)/);
            if (!m) continue;
            if (!f.res.length){   // field tanpa hasil di template → tambahkan hasil «NAMA» sebelum akhir field
              const mk = (fld: string | null): Element => { const nr = doc.createElementNS(WNS, "w:r"), rp0 = kids(f.begin, "rPr")[0]; if (rp0) nr.appendChild(rp0.cloneNode(true));
                if (fld){ const fc = doc.createElementNS(WNS, "w:fldChar"); fc.setAttributeNS(WNS, "w:fldCharType", fld); nr.appendChild(fc); } return nr; };
              if (f.phase !== "r") r.parentNode!.insertBefore(mk("separate"), r);
              const nr = mk(null), t = doc.createElementNS(WNS, "w:t"); t.setAttribute("xml:space", "preserve"); nr.appendChild(t); r.parentNode!.insertBefore(nr, r); f.res.push(t);
            }
            // tampilkan «NAMA_KOLOM» + sorot kuning di hasil field
            f.res.forEach((t, i) => { t.textContent = i ? "" : "«" + m[1] + "»"; });
            for (const rr of new Set([...f.runs, ...f.res.map(t => t.parentNode).filter(isEl)])){
              let rp = kids(rr, "rPr")[0]; if (!rp){ rp = doc.createElementNS(WNS, "w:rPr"); rr.insertBefore(rp, rr.firstChild); }
              for (const h of kids(rp, "highlight")) rp.removeChild(h);
              const h = doc.createElementNS(WNS, "w:highlight"); h.setAttributeNS(WNS, "w:val", "yellow");
              // urutan elemen rPr wajib sesuai skema OOXML: highlight sebelum u/effect/bdr/shd/…/lang
              const AFTER = ["u", "effect", "bdr", "shd", "fitText", "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath", "rPrChange"];
              const before = [...rp.childNodes].find(n => isEl(n) && n.namespaceURI === WNS && AFTER.includes(n.localName));
              rp.insertBefore(h, before || null);
            }
          }
        } else if (ch.localName === "instrText" && stack.length && stack[stack.length - 1].phase === "i") stack[stack.length - 1].instr += ch.textContent;
        else if (ch.localName === "t" && stack.length && stack[stack.length - 1].phase === "r") stack[stack.length - 1].res.push(ch);
      }
    }
    zip.file(p, xmlOut(doc));
  }
  const blob = await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
  download(blob, kind === "rb" ? "Template Rincian Biaya.docx" : "Template Surat Tugas.docx");
  toast(`Template ${kind === "rb" ? "Rincian Biaya" : "Surat Tugas"} diekspor — bagian kuning «…» adalah kolom data otomatis.`);
}
$("#bTplExp").onclick = () => exportTemplate("st").catch((e: Error) => toast("Gagal ekspor template: " + e.message));
$("#bTplExpRB").onclick = () => exportTemplate("rb").catch((e: Error) => toast("Gagal ekspor template: " + e.message));

/* ---------- tarif bawaan (Pengaturan) ---------- */
/** [nama tarif, label, petunjuk, grup?, cocokkan awalan?] */
const DEF_TARIF_FIELDS: [string, string, string, string?, boolean?][] = [
  ["UHAR PERJADIN", "Uang harian per hari", "Remote & Translok+Uhar; Lokal & Pelatihan tetap 0", "UHAR 2026"],
  ["INAP PERJADIN", "Uang inap per malam (tanpa hotel)", "pengeluaran riil tidak menginap di hotel", "INAP 2026"],
  ["LINTASAN ANTAR KAMPUNG", "Biaya lintasan antar kampung", "Remote biasa: kampung ke-2 dst.", RULES_GRUP, true],
  ["LINTASAN MOBIL (TRANSPORT JAUH)", "Biaya lintasan mobil", "transport mobil: nilai otomatis sekaligus batas minimal Biaya Lintasan Mobil", RULES_GRUP, true],
  ["INAP MOBIL PER MALAM", "Biaya inap mobil per malam", "transport mobil: (lama perjalanan − 1) malam", RULES_GRUP, true],
  ["BATAS TRANSPORT JAUH (LEBIH DARI)", "Batas tarif SK transport mobil", "tarif SK di atas nilai ini → Transport Mobil (tidak dibagi dua) + Inap Mobil", RULES_GRUP, true],
  ["__UP", "Total UP setahun (T.A. aktif)", "nominal baku Uang Persediaan setahun — batas Catat UP tiap bulan"],
  ["__PTKP", "Batas honor PTKP (mitra)", "honor mitra (bruto) di atas nilai ini → PPh 21 otomatis 5%"],
  ["__PEL", "Transport pelatihan per orang", "isi awal tab Transport Pelatihan (kosong = ikut rincian transport)"]];
const tarifRow = (n: string, g?: string, pre?: boolean): Tarif | undefined => tarifDB.find(t => (pre ? t.nama.startsWith(n) : t.nama.toUpperCase() === n) && (!g || t.grup === g)) || tarifDB.find(t => pre ? t.nama.startsWith(n) : t.nama.toUpperCase() === n);
function renderDefTarif(): void {
  $("#defTarif").innerHTML = DEF_TARIF_FIELDS.map(([n, lbl, hint, g, pre]) => { const v = n === "__PEL" ? LS.get("st.pelTrDef", "") : n === "__UP" ? (upTotal() || "") : n === "__PTKP" ? ptkpBatas() : num(tarifRow(n, g, pre)?.nilai);
    return `<div class="c4"><label>${esc(n === "__UP" ? lbl.replace("T.A. aktif", "T.A. " + angYear) : lbl)} (Rp)</label><input type="number" min="0" step="1000" data-dt="${esc(n)}" value="${v === "" ? "" : v}" style="text-align:right"><div class="hint">${esc(hint)}</div></div>`; }).join("");
}
$("#bDefTarif").onclick = () => {
  let n = 0;
  for (const e of $$("#defTarif [data-dt]")){
    const k = e.dataset.dt ?? "", f = DEF_TARIF_FIELDS.find(x => x[0] === k); if (!f) continue;
    if (k === "__UP"){ const all = upTotalAll(); if (e.value === "") delete all[angYear]; else all[angYear] = num(e.value); LS.set("st.upTotal", all); n++; continue; }
    if (k === "__PTKP"){ LS.set("st.ptkp", e.value === "" ? 4500000 : num(e.value)); n++; continue; }
    if (k === "__PEL"){ LS.set("st.pelTrDef", e.value === "" ? "" : num(e.value)); $("#pelAll").value = e.value; n++; continue; }
    if (e.value === "") continue;
    let t = tarifRow(k, f[3], f[4]); if (!t){ t = { grup: f[3] || "", nama: k, nilai: 0 }; tarifDB.push(t); }
    const v = num(e.value);
    if (num(t.nilai) !== v){ t.nilai = v; n++; }
  }
  persist(); renderTarif(); buildLists(); if (!editingId) newForm(); renderDefTarif();
  toast(`Tarif bawaan disimpan — berlaku untuk surat tugas baru.`);
};
/* ---------- ekspor & impor tarif ---------- */
$("#bTarExp").onclick = () => {
  const wb = XLSX.utils.book_new();
  const ws1 = XLSX.utils.aoa_to_sheet([["Distrik", "Kampung", "Transport Kabupaten-Kampung (PP) 2026", "Keterangan"], ...kampungDB.map(k => [k.distrik, k.kampung, k.tarif, kamLokal(k) && !/lokal/i.test(k.ket ?? "") ? [k.ket, "Lokal"].filter(Boolean).join(" · ") : !kamLokal(k) && /lokal/i.test(k.ket ?? "") ? String(k.ket).replace(/\s*·?\s*lokal/ig, "").trim() : k.ket])]);
  ws1["!cols"] = [{ wch: 24 }, { wch: 24 }, { wch: 22 }, { wch: 14 }];
  const ws2 = XLSX.utils.aoa_to_sheet([["Grup", "Uraian", "Nilai"], ...tarifDB.map(t => [t.grup, t.nama, t.nilai])]);
  ws2["!cols"] = [{ wch: 26 }, { wch: 36 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(wb, ws1, "SK TRANS 2026"); XLSX.utils.book_append_sheet(wb, ws2, "Tarif lain");
  XLSX.writeFile(wb, `Tarif Transport (${kampungDB.length} kampung).xlsx`);
  toast(`${kampungDB.length} kampung & ${tarifDB.length} tarif lain diekspor.`);
};
$("#fTarImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
    const aoa = (n: string) => XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[n], { header: 1, defval: null, raw: true });
    const tsn = wb.SheetNames.filter(n => /^SK\s*TRANS/i.test(n)).sort().pop();
    let kam: Kampung[] = [], tar: Tarif[] = [];
    if (tsn){ const got = parseTransSheet(aoa(tsn)); kam = got.kam.filter(k => k.kampung); tar = got.tar; }
    const lsn = wb.SheetNames.find(n => /tarif\s*lain/i.test(n));
    if (lsn){
      const rows = aoa(lsn), H = (rows[0] || []).map(x => String(x ?? "").trim().toUpperCase());
      const cg = H.findIndex(h => /^GRUP/.test(h)), cu = H.findIndex(h => /^URAIAN|^NAMA/.test(h)), cn = H.findIndex(h => /^NILAI|^TARIF/.test(h));
      const list = rows.slice(1).filter(r => r[cu] != null && String(r[cu]).trim()).map(r => ({ grup: String(r[cg] ?? "").trim().toUpperCase() || "LAINNYA", nama: String(r[cu]).trim().toUpperCase(), nilai: num(r[cn]) }));
      if (list.length) tar = list;
    }
    if (!kam.length && !tar.length) return toast("Tidak ditemukan sheet 'SK TRANS …' atau 'Tarif lain' di file ini.");
    const msg = [kam.length ? `${kam.length} kampung (sekarang ${kampungDB.length})` : "", tar.length ? `${tar.length} tarif lain (sekarang ${tarifDB.length})` : ""].filter(Boolean).join(" dan ");
    if (!confirm(`Ganti data tarif dengan isi file?\n\n${msg}\n\nSurat yang sudah tersimpan tidak berubah sampai dibuka & disesuaikan lagi.`)) return;
    if (kam.length) kampungDB = kam;
    if (tar.length){ tarifDB = tar; for (const [n, v] of RULE_DEFAULTS) if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n)) tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v }); }
    persist(); renderKam(); renderTarif(); buildLists(); renderChips();
    $("#tarInfo").textContent = `Diimpor dari ${f.name}`; toast("Tarif diperbarui: " + msg.replace(/ \(sekarang \d+\)/g, ""));
  }catch(err){ console.error(err); toast("Gagal membaca file tarif: " + (err as Error).message); }
});

$("#bTplReset").onclick = () => {
  if (template && !template.kind && !templateRB){ templateRB = { ...template, kind: "rb" }; LS.set("st.templateRB", templateRB); }
  template = null; LS.del("st.template"); tplInfo(); toast("Template Surat Tugas kembali ke bawaan."); };
$("#bTplResetRB").onclick = () => {
  templateRB = null; LS.del("st.templateRB");
  if (template && !template.kind){ template = { ...template, kind: "st" }; LS.set("st.template", template); }
  tplInfo(); toast("Template Rincian Biaya kembali ke bawaan."); };
const tplInfo = (): void => {
  $("#tplInfo").textContent = "Aktif: " + (template ? template.name : "bawaan (SURAT_TUGAS_2026.docx)");
  $("#tplInfoRB").textContent = "Aktif: " + (templateRB ? templateRB.name : template && !template.kind ? template.name : "bawaan (rincian_biaya.docx)");
};
$("#bReset").onclick = () => { if (!confirm("Semua perubahan yang tersimpan di server akan hilang dan data kembali seperti bawaan. Lanjutkan?")) return;
  pegawai = clone(SEED.pegawai); records = clone(SEED.records); kampungDB = clone(SEED.kampung); tarifDB = clone(SEED.tarif); kodeDB = clone(SEED.kode); pokDB = clone(SEED.pok);
  for (const y of pokYears()) pokDrop(y); for (const [y, v] of Object.entries(SEED.pokY || {})) pokSave(y, clone(v));
  pokYear = String(pokDB.meta?.tahun || new Date().getFullYear()); pokSave(pokYear, pokDB); LS.set("st.pokYear", pokYear);
  for (const [n, v] of RULE_DEFAULTS) if (!tarifDB.some(t => t.grup === RULES_GRUP && t.nama === n)) tarifDB.push({ grup: RULES_GRUP, nama: n, nilai: v });
  persist(); renderAll(); newForm(); toast("Data dikembalikan."); };

/* ================= PENULIS .XLSX BERGAYA (daftar bayar pelatihan & honor) ================= */
const XS = { n: 0, title: 1, b: 2, wrap: 3, th: 4, td: 5, tdl: 6, num: 7, numb: 8, tdb: 9, c: 10, nameU: 11, numP: 12, thn: 13, bl: 14, it: 15, tdlb: 16 };
function xlsxStylesXml(){
  const fonts = ['<font><sz val="10"/><name val="Arial"/></font>', '<font><b/><sz val="10"/><name val="Arial"/></font>', '<font><b/><sz val="12"/><name val="Arial"/></font>',
    '<font><b/><u/><sz val="10"/><name val="Arial"/></font>', '<font><i/><sz val="9"/><name val="Arial"/></font>', '<font><i/><sz val="10"/><name val="Arial"/></font>'];
  const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>', '<fill><patternFill patternType="solid"><fgColor rgb="FFEDEFF3"/><bgColor indexed="64"/></patternFill></fill>'];
  const bd = '<left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/>';
  const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>', `<border>${bd}</border>`];
  const al = (h: string, v = "center", w = 1): string => `<alignment horizontal="${h}" vertical="${v}"${w ? ' wrapText="1"' : ""}/>`;
  const x = (font: number, fill: number, border: number, fmt: number, align: string): string => `<xf numFmtId="${fmt}" fontId="${font}" fillId="${fill}" borderId="${border}" xfId="0"${font ? ' applyFont="1"' : ""}${fill ? ' applyFill="1"' : ""}${border ? ' applyBorder="1"' : ""}${fmt ? ' applyNumberFormat="1"' : ""}${align ? ' applyAlignment="1">' + align + "</xf>" : "/>"}`;
  const xfs = [x(0, 0, 0, 0, ""), x(2, 0, 0, 0, al("center")), x(1, 0, 0, 0, al("left", "top", 0)), x(0, 0, 0, 0, al("left", "top")),
    x(1, 2, 1, 0, al("center")), x(0, 0, 1, 0, al("center")), x(0, 0, 1, 0, al("left")), x(0, 0, 1, 164, al("right", "center", 0)), x(1, 0, 1, 164, al("right", "center", 0)),
    x(1, 0, 1, 0, al("center")), x(0, 0, 0, 0, al("center")), x(3, 0, 0, 0, al("center", "bottom", 0)), x(0, 0, 0, 164, al("right", "center", 0)), x(4, 2, 1, 0, al("center")),
    x(1, 0, 0, 0, al("center", "top")), x(5, 0, 0, 0, al("left", "top")), x(1, 0, 1, 0, al("left"))];
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0;-#,##0;&quot;-&quot;"/></numFmts><fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="${borders.length}">${borders.join("")}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
}
const xCol = (n: number): string => { let s = ""; n++; while (n){ const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
const xEsc = (t: unknown): string => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
/* lembar kerja: set(baris, kolom, nilai, gaya, rumus) — baris & kolom mulai 1 */
/** sel lembar kerja: nilai, indeks gaya (XS), rumus */
type XsCell = { v: unknown; st: number; f: string | null };
/** lembar kerja .xlsx bergaya buatan sendiri (lihat xSheet) */
interface XSheet {
  name: string; widths: number[]; opt: { portrait?: boolean; paper?: number }; rows: Map<number, Map<number, XsCell>>; merges: string[]; heights: Record<number, number>;
  set(r: number, c: number, v: unknown, st?: number, f?: string | null): XSheet;
  merge(r1: number, c1: number, r2: number, c2: number, st?: number): XSheet;
  h(r: number, ht: number): XSheet;
  xml(): string;
}
function xSheet(name: string, widths: number[], opt: XSheet["opt"] = {}): XSheet {
  const rows = new Map<number, Map<number, XsCell>>(), merges: string[] = [], heights: Record<number, number> = {};
  const sh: XSheet = {
    name, widths, opt, rows, merges, heights,
    set(r, c, v, st = 0, f = null){ let row = rows.get(r); if (!row){ row = new Map(); rows.set(r, row); } row.set(c, { v, st, f }); return sh; },
    merge(r1, c1, r2, c2, st){ merges.push(`${xCol(c1 - 1)}${r1}:${xCol(c2 - 1)}${r2}`); if (st != null) for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++){ const cur = rows.get(r)?.get(c); if (!cur) sh.set(r, c, "", st); else if (cur.st === 0) cur.st = st; } return sh; },
    h(r, ht){ heights[r] = ht; return sh; },
    xml(){
      const out = [...rows.keys()].sort((a, b) => a - b).map(r => {
        const cells = [...rows.get(r)!.entries()].sort((a, b) => a[0] - b[0]).map(([c, { v, st, f }]) => {
          const ref = xCol(c - 1) + r;
          if (f) return `<c r="${ref}" s="${st}"><f>${xEsc(f)}</f>${typeof v === "number" ? `<v>${v}</v>` : ""}</c>`;
          if (typeof v === "number" && isFinite(v)) return `<c r="${ref}" s="${st}"><v>${v}</v></c>`;
          if (v === "" || v == null) return `<c r="${ref}" s="${st}"/>`;
          return `<c r="${ref}" s="${st}" t="inlineStr"><is><t xml:space="preserve">${xEsc(v)}</t></is></c>`;
        }).join("");
        return `<row r="${r}"${heights[r] ? ` ht="${heights[r]}" customHeight="1"` : ""}>${cells}</row>`;
      }).join("");
      const cols = widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("");
      return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>${cols}</cols><sheetData>${out}</sheetData>${merges.length ? `<mergeCells count="${merges.length}">${merges.map(m => `<mergeCell ref="${m}"/>`).join("")}</mergeCells>` : ""}<pageMargins left="0.4" right="0.3" top="0.5" bottom="0.5" header="0.3" footer="0.3"/><pageSetup paperSize="${opt.paper || 9}" orientation="${opt.portrait ? "portrait" : "landscape"}" fitToWidth="1" fitToHeight="0"/></worksheet>`;
    }
  };
  return sh;
}
async function xlsxSave(sheets: XSheet[], fname: string): Promise<void> {
  const z = new JSZip(), safe = (n: unknown): string => String(n).replace(/[\\/?*[\]:]/g, " ").slice(0, 31) || "Sheet";
  const names: string[] = []; for (const sh of sheets){ let n = safe(sh.name), k = 2; while (names.includes(n)) n = safe(sh.name).slice(0, 28) + " " + k++; names.push(n); }
  z.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`);
  z.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
  z.file("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${names.map((n, i) => `<sheet name="${xEsc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
  z.file("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
  z.file("xl/styles.xml", xlsxStylesXml());
  sheets.forEach((sh, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, sh.xml()));
  download(await z.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", compression: "DEFLATE" }), fname);
}
/* baris "Program … Akun" dari POK */
const KRO_NAMA: Record<string, string> = { BMA: "Data dan Informasi Publik", BMB: "Data dan Informasi Publik", EBA: "Layanan Dukungan Manajemen Internal", EBB: "Layanan Sarana dan Prasarana Internal", EBC: "Layanan Manajemen SDM Internal", EBD: "Layanan Manajemen Kinerja Internal", BDB: "Fasilitasi dan Pembinaan Lembaga", QDB: "Fasilitasi dan Pembinaan Lembaga" };
function makLines(mak: unknown): [string, string][] {
  const k = normMak(mak), a = pokMap()[k], p = k.split(".");
  if (!a) return [["Akun", String(mak || "-")]];
  const kro = p[1] || "", prog = a.keg === "2886" ? "(054.01.WA) Program Dukungan Manajemen" : "(054.01.GG) Penyediaan dan Pelayanan Informasi Statistik";
  return [["Program", prog], ["Aktivitas", `(${a.keg}) ${a.kegNama}`], ["KRO", `(${a.keg}.${kro}) ${KRO_NAMA[kro] || ""}`.trim()], ["RO", `(${a.ro}) ${a.roNama}`],
    ["Komponen", `(${a.komp}) ${a.kompNama}`], ["Sub-Komponen", `(${a.sub}) ${a.sub === "A" ? "Tanpa Sub Komponen" : ""}`.trim()], ["Akun/Detil", `(${a.akun}) ${a.nama}`]];
}
const capFirst = (t: unknown): string => String(t || "").trim().replace(/\s+/g, " ").replace(/^./, c => c.toUpperCase());
const tglLong = (a: unknown, b: unknown): string => { const A = parseTgl(a), B = parseTgl(b); if (!A) return String(a || ""); if (!B || +A === +B) return fmtDate(A);
  if (A.getFullYear() === B.getFullYear() && A.getMonth() === B.getMonth()) return `${A.getDate()}-${fmtDate(B)}`;
  if (A.getFullYear() === B.getFullYear()) return `${A.getDate()} ${BULAN[A.getMonth()]} - ${fmtDate(B)}`; return `${fmtDate(A)} - ${fmtDate(B)}`; };
const nipText = (p: Pegawai | null | undefined): string => p && p.nip && !/^-|terlampir/i.test(p.nip) && /\d{8}/.test(String(p.nip).replace(/\s/g, "")) ? "NIP. " + p.nip : "";

/* ================= DAFTAR TRANSPORT LOKAL PELATIHAN ================= */
/** satu baris daftar transport pelatihan */
interface PelRow { c: string; nama: string; gol: string; nip: string; jab: string; lama: number; full: number; board: number; tr: number }
function pelatihanRows(r: StRecord): PelRow[] {
  const P = pegMap(), tm = teamOf(r, P), L = num(r.LAMA_JALAN) || 1;
  const ex = new Set<string>(r._pelExcl || []), U: Record<string, { full?: unknown; board?: unknown }> = r._pelUH || {};
  return [...tm.peg, ...tm.mit].filter(c => !ex.has(c)).map(c => { const p: Pegawai = P[c] || { kode: c, nama: "" }, x = personRec(r, c), n = compute(x)._num, mit = isMitra(p);
    return { c, nama: p.nama || c, gol: mit || !p.gol || p.gol === "-" ? "" : p.gol, nip: mit ? "-" : (p.nip || "-"), jab: mit ? "Mitra" : (p.jabatan || ""), lama: L, full: num(U[c]?.full), board: num(U[c]?.board), tr: n.totTr || 0 }; });
}
function pelatihanHtml(r: StRecord): string {
  const F = compute(r), P = pegMap(), rows = pelatihanRows(r), bend = P[codeOf(r.No_Bend)], ppk = P[codeOf(r.No_PPK)];
  const info = [...makLines(r.MAK), ["Nomor Surat Tugas, Tanggal", `${F.NOMOR_ST} ${F.TGL_TERBIT_ST}`], ["Tanggal Pelaksanaan", tglLong(r.TGL_PERGI, r.TGL_PULANG)]];
  const sum = (k: "full" | "board" | "tr") => rows.reduce((a, x) => a + x[k], 0), tot = sum("full") + sum("board") + sum("tr"), asal = $("#pelAsal")?.value.trim() || "BPS Kab. Maybrat", d = (v: number) => v ? rupiah(v) : "-";
  return `<div class="hp-title">BIAYA PERJALANAN DINAS DALAM RANGKA<br>${esc(String(F.MAKSUD__TUJUAN || F.kegiatan || "").toUpperCase())}</div>
    <table class="hp-info">${info.map(([k, v]) => `<tr><td style="width:170px">${esc(k)}</td><td>: ${esc(v || "")}</td></tr>`).join("")}</table>
    <table class="hp-tbl"><thead><tr><th rowspan="3">No</th><th rowspan="3">Nama Pelaksana Perjalanan Dinas</th><th rowspan="3">Gol</th><th rowspan="3">NIP</th><th rowspan="3">Jabatan</th><th rowspan="3">Asal Penugasan</th><th colspan="2" rowspan="2">Lama Tugas (O-H)</th><th colspan="2">Biaya</th><th rowspan="3">Pengeluaran Riil Transport Lokal</th><th rowspan="3">Jumlah Biaya (Rp) ∑ = 9 s.d 11</th><th rowspan="3" colspan="2">Tanda Tangan Penerima</th></tr>
      <tr><th rowspan="2">Uang Harian Fullday</th><th rowspan="2">Uang Harian Fullboard</th></tr><tr><th>hari</th><th>huruf</th></tr>
      <tr class="n">${Array.from({ length: 12 }, (_, i) => `<td>(${i + 1})</td>`).join("")}<td colspan="2">(13)</td></tr></thead>
      <tbody>${rows.map((x, i) => `<tr><td class="c">${i + 1}</td><td>${esc(x.nama)}</td><td class="c">${esc(x.gol || "")}</td><td class="c">${esc(x.nip)}</td><td class="c">${esc(x.jab)}</td><td class="c">${esc(asal)}</td><td class="c">${x.lama}</td><td class="c">(${esc(capFirst(terbilang(x.lama)))})</td><td class="r">${d(x.full)}</td><td class="r">${d(x.board)}</td><td class="r">${d(x.tr)}</td><td class="r">${rupiah(x.full + x.board + x.tr)}</td><td>${i % 2 ? "" : (i + 1) + ". ……"}</td><td>${i % 2 ? (i + 1) + ". ……" : ""}</td></tr>`).join("")}
      <tr class="tot"><td colspan="8" class="c">Jumlah</td><td class="r">${d(sum("full"))}</td><td class="r">${d(sum("board"))}</td><td class="r">${d(sum("tr"))}</td><td class="r">${rupiah(tot)}</td><td colspan="2"></td></tr></tbody></table>
    <p class="hp-terb"><i>Terbilang : ${esc(capFirst(terbilang(tot)))} Rupiah</i></p>
    <div class="hp-sign" style="grid-template-columns:1fr 1fr"><div>Lunas Pada Tanggal : ${esc(pelLunas(r))}<br>Bendahara Pengeluaran<br>BPS Kabupaten Maybrat<br><br><br><br><b>${esc(bend?.nama || "")}</b><br>${esc(nipText(bend))}</div>
      <div>Setuju dibayar<br>Pejabat Pembuat Komitmen<br>BPS Kabupaten Maybrat<br><br><br><br><b>${esc(ppk?.nama || "")}</b><br>${esc(nipText(ppk))}</div></div>`;
}
async function downloadPelatihan(r: StRecord): Promise<void> {
  const F = compute(r), P = pegMap(), rows = pelatihanRows(r);
  if (!rows.length) return toast("Belum ada pelaksana / anggota di surat ini.");
  const sh = xSheet("Daftar Transport", [5, 27, 8, 21, 15, 13, 6, 10, 12, 12, 13, 14, 12, 12]);
  sh.set(1, 1, "BIAYA PERJALANAN DINAS DALAM RANGKA\n" + String(F.MAKSUD__TUJUAN || F.kegiatan || "").toUpperCase(), XS.title).merge(1, 1, 1, 14).h(1, 36);
  let y = 3;
  const info = [...makLines(r.MAK), ["Nomor Surat Tugas, Tanggal", `${F.NOMOR_ST} ${F.TGL_TERBIT_ST}`], ["Tanggal Pelaksanaan", tglLong(r.TGL_PERGI, r.TGL_PULANG)]];
  for (const [k, v] of info){ sh.set(y, 2, k, XS.wrap).set(y, 3, ":", XS.wrap).set(y, 4, v, XS.wrap).merge(y, 4, y, 14); if (String(v).length > 95) sh.h(y, 27); y++; }
  y++;
  const h0 = y;
  sh.set(y, 1, "No", XS.th).merge(y, 1, y + 2, 1, XS.th); sh.set(y, 2, "Nama Pelaksana Perjalanan Dinas", XS.th).merge(y, 2, y + 2, 2, XS.th); sh.set(y, 3, "Gol", XS.th).merge(y, 3, y + 2, 3, XS.th);
  sh.set(y, 4, "NIP", XS.th).merge(y, 4, y + 2, 4, XS.th); sh.set(y, 5, "Jabatan", XS.th).merge(y, 5, y + 2, 5, XS.th); sh.set(y, 6, "Asal Penugasan", XS.th).merge(y, 6, y + 2, 6, XS.th);
  sh.set(y, 7, "Lama Tugas (O-H)", XS.th).merge(y, 7, y + 1, 8, XS.th); sh.set(y + 2, 7, "hari", XS.th).set(y + 2, 8, "huruf", XS.th);
  sh.set(y, 9, "Biaya", XS.th).merge(y, 9, y, 10, XS.th); sh.set(y + 1, 9, "Uang Harian Fullday", XS.th).merge(y + 1, 9, y + 2, 9, XS.th); sh.set(y + 1, 10, "Uang Harian Fullboard", XS.th).merge(y + 1, 10, y + 2, 10, XS.th);
  sh.set(y, 11, "Pengeluaran Riil Transport Lokal", XS.th).merge(y, 11, y + 2, 11, XS.th); sh.set(y, 12, "Jumlah Biaya (Rp)\n∑ = 9 s.d 11", XS.th).merge(y, 12, y + 2, 12, XS.th);
  sh.set(y, 13, "Tanda Tangan Penerima", XS.th).merge(y, 13, y + 2, 14, XS.th);
  sh.h(y, 18).h(y + 1, 24).h(y + 2, 24);
  y += 3;
  for (let c = 1; c <= 13; c++) sh.set(y, c, `(${c})`, XS.thn); sh.merge(y, 13, y, 14, XS.thn); y++;
  const d0 = y;
  rows.forEach((x, i) => {
    sh.set(y, 1, i + 1, XS.td).set(y, 2, x.nama, XS.tdl).set(y, 3, x.gol || "", XS.td).set(y, 4, x.nip, XS.td).set(y, 5, x.jab, XS.td).set(y, 6, ($("#pelAsal")?.value.trim() || "BPS Kab. Maybrat"), XS.td)
      .set(y, 7, x.lama, XS.td).set(y, 8, `(${capFirst(terbilang(x.lama))})`, XS.td).set(y, 9, x.full, XS.num).set(y, 10, x.board, XS.num).set(y, 11, x.tr, XS.num)
      .set(y, 12, x.full + x.board + x.tr, XS.num, `SUM(I${y}:K${y})`).set(y, 13, i % 2 ? "" : `${i + 1}. ………`, XS.tdl).set(y, 14, i % 2 ? `${i + 1}. ………` : "", XS.tdl);
    sh.h(y, 30); y++;
  });
  const sum = (k: "full" | "board" | "tr") => rows.reduce((a, x) => a + x[k], 0);
  sh.set(y, 2, "Jumlah", XS.tdb).merge(y, 1, y, 8, XS.tdb); sh.set(y, 1, "Jumlah", XS.tdb);
  sh.set(y, 9, sum("full"), XS.numb, `SUM(I${d0}:I${y - 1})`).set(y, 10, sum("board"), XS.numb, `SUM(J${d0}:J${y - 1})`).set(y, 11, sum("tr"), XS.numb, `SUM(K${d0}:K${y - 1})`)
    .set(y, 12, sum("full") + sum("board") + sum("tr"), XS.numb, `SUM(L${d0}:L${y - 1})`).merge(y, 13, y, 14, XS.td);
  sh.h(y, 20); y++;
  const tot = sum("full") + sum("board") + sum("tr");
  sh.set(y, 2, "Terbilang", XS.it).set(y, 3, ":", XS.it).set(y, 4, capFirst(terbilang(tot)) + " Rupiah", XS.it).merge(y, 4, y, 14); y += 2;
  const bend = P[codeOf(r.No_Bend)], ppk = P[codeOf(r.No_PPK)];
  sh.set(y, 4, "Lunas Pada Tanggal : " + pelLunas(r), XS.n).set(y, 11, "Setuju dibayar", XS.n); y++;
  sh.set(y, 4, "Bendahara Pengeluaran", XS.n).set(y, 11, "Pejabat Pembuat Komitmen", XS.n); y++;
  sh.set(y, 4, "BPS Kabupaten Maybrat", XS.n).set(y, 11, "BPS Kabupaten Maybrat", XS.n); y += 5;
  sh.set(y, 4, bend?.nama || F.BEND || "", XS.b).set(y, 11, ppk?.nama || F.PPK || "", XS.b); y++;
  sh.set(y, 4, nipText(bend) || (F.NIP_BEND ? "NIP. " + F.NIP_BEND : ""), XS.n).set(y, 11, nipText(ppk) || (F.NIP_PPK ? "NIP. " + F.NIP_PPK : ""), XS.n);
  await xlsxSave([sh], `Daftar Transport Pelatihan ${F.NOMOR_ST.replace(/\//g, "-")}.xlsx`);
  toast(`Daftar transport pelatihan ${rows.length} orang diunduh (total Rp ${rupiah(tot)}).` + (r._noBiaya ? " Rincian biaya surat ini belum dibuat — transport masih 0." : ""));
}

