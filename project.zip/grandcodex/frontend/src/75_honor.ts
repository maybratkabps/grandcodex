/* ================= HONOR PETUGAS ================= */
/** satu baris petugas di daftar honor; dok/sat/pph "" = belum diisi, pph dalam persen dari bruto */
interface HonorRow { nama: string; c: string; rek: string; dok: number | ""; unit: string; unitOther?: boolean; jab: string; jabOther?: boolean; sat: number | ""; pph: number | ""; pphManual?: boolean; obFrom?: string; obTo?: string }
/** satu daftar pembayaran honor */
interface Honor { _id: string; judul1: string; judul2: string; MAK: string; unit: string; sk: string; skId?: string; tglSk: string; tglDaftar: string; tempat: string;
  bend: string; ppk: string; pembuat: string; defJab: string; defSat: string | number; defUnit?: string; obFrom?: string; obTo?: string; rows: HonorRow[] }
/** cukup untuk menghitung bruto / PPh */
type HoCalc = { c?: string | null; dok?: unknown; sat?: unknown; pph?: unknown };
/** isi kolom isian bebas (data-h / data-hr) lewat nama kolom dinamis */
const hoField = dyn;
var honorDB = LS.get<Honor[]>("st.honor", []).map(h => ({ ...h, rows: (h.rows || []).map(x => { const b = num(x.dok) * num(x.sat), v = num(x.pph); return v > 100 && b ? { ...x, pph: Math.round(v / b * 10000) / 100 } : x; }) })).map(h => (h.judul1 === "DAFTAR PEMBAYARAN HONOR " + "PETUGAS LAPANGAN" ? { ...h, judul1: "DAFTAR PEMBAYARAN HONOR" } : h)), rekMap = LS.get<Record<string, string>>("st.rekening", {}), hoCur: Honor | null = null, hoSaved: Honor | null | undefined = null;
const persistHonor = () => { LS.set("st.honor", honorDB); LS.set("st.rekening", rekMap); _use = null; _dataVer++; };
/* PPh 21 diisi persen (%) dari bruto; bawaan dari golongan: IV → 15%, III → 5%, II/I & mitra → 0% */
const pphPctGol = (c: string): number => { const g = String(pegMap()[c]?.gol || "").trim().toUpperCase(); return /^IV/.test(g) ? 15 : /^III/.test(g) ? 5 : 0; };
const hoBruto = (x: HoCalc): number => num(x.dok) * num(x.sat);
const ptkpBatas = () => num(LS.get("st.ptkp", 4500000)) || 4500000;   // batas honor PTKP (Pengaturan)
/* PPh otomatis: pegawai → golongan (IV 15%, III 5%, II 0%); mitra / nama di luar data → 5% bila bruto melebihi batas PTKP, selain itu 0% */
function pphAuto(x: HoCalc): number { const c = x.c || "", p = c ? pegMap()[c] : undefined; if (p && !isMitra(p) && !isSystemPeg(p)) return pphPctGol(c); return hoBruto(x) > ptkpBatas() ? 5 : 0; }
const HO_UNITS = ["Dokumen", "OB", "EA", "PLOT", "RUTA", "OJP"];
/* jabatan honor: mitra memilih dari daftar baku (semua mitra satu jabatan); pegawai otomatis jabatan di Database (boleh berbeda) */
const HO_JAB_MITRA = ["Petugas Pendata Lapangan", "Petugas Pemeriksa Lapangan"];
type HoKind = "mitra" | "pegawai" | "";
const hoKind = (x: { c?: string }): HoKind => { const p = x.c ? pegMap()[x.c] : undefined; return !p || isSystemPeg(p) ? "" : isMitra(p) ? "mitra" : "pegawai"; };
const hoPegJab = (x: HonorRow): string => String(pegMap()[x.c]?.jabatan || "").trim();
/** pilihan jabatan baris: mitra → daftar baku; pegawai → jabatan di Database; + Lainnya */
function hoJabOpts(x: HonorRow): string[] { const k = hoKind(x); return k === "mitra" ? HO_JAB_MITRA : k === "pegawai" ? [hoPegJab(x)].filter(Boolean) : []; }
const hoJabOther = (x: HonorRow): boolean => !!x.jabOther || (!!x.jab && !hoJabOpts(x).includes(x.jab));
/** jenis petugas yang sudah ada di daftar (selain baris i) */
const hoListKind = (h: Honor, skip = -1): HoKind => { for (let i = 0; i < h.rows.length; i++){ if (i === skip) continue; const k = hoKind(h.rows[i]); if (k) return k; } return ""; };
/** jabatan bersama mitra (baris mitra pertama selain baris i) */
const hoMitraJab = (h: Honor, skip = -1): string => h.rows.find((r, i) => i !== skip && hoKind(r) === "mitra" && r.jab)?.jab || "";
function hoRulesErr(h: Honor): string | null {
  const ks = new Set(h.rows.filter(x => hoName(x)).map(hoKind).filter(Boolean));
  if (ks.size > 1) return "Anggota honor tidak boleh campuran mitra dan pegawai — buat daftar honor terpisah.";
  const mj = new Set(h.rows.filter(x => hoKind(x) === "mitra").map(x => x.jab.trim()));
  if (mj.size > 1) return `Semua mitra dalam satu daftar honor harus berjabatan sama (sekarang: ${[...mj].map(j => j || "kosong").join(", ")}).`;
  return null;
}
const hoUnitOther = (x: HonorRow): boolean => !!x.unitOther || (!!x.unit && !HO_UNITS.includes(x.unit));
const pphAmt = (x: HoCalc): number => Math.round(hoBruto(x) * num(x.pph) / 100);
const hoTot = (h: Honor) => (h.rows || []).reduce((a, x) => { const b = hoBruto(x), t = pphAmt(x); a.bruto += b; a.pph += t; a.net += b - t; return a; }, { bruto: 0, pph: 0, net: 0 });
const hoName = (x: HonorRow): string => (x.c && pegMap()[x.c]?.nama) || x.nama || "";
function hoBlank(): Honor {
  const d = defaults() as Record<string, string>;
  return { _id: newId(), judul1: "DAFTAR PEMBAYARAN HONOR", judul2: "", MAK: "", unit: "BPS Kabupaten Maybrat (690691)", sk: "", tglSk: "", tglDaftar: today(), tempat: "Maybrat",
    bend: codeOf(d.No_Bend) || "", ppk: codeOf(d.No_PPK) || "", pembuat: codeOf(d.No_PPK) || "", defJab: "Petugas Lapangan", defSat: "", rows: [] };
}
/* ---------- daftar ---------- */
function renderHonorList(): void {
  const q = acNorm($("#hoQ").value.trim()), toks = q.split(/\s+/).filter(Boolean);
  const list = [...honorDB].reverse().filter(h => !toks.length || toks.every(t => acNorm([h.judul2, h.judul1, h.sk, h.MAK, ...(h.rows || []).map(hoName)].join(" ")).includes(t)));
  let sum = 0;
  $("#hoTbl tbody").innerHTML = list.map((h, i) => { const t = hoTot(h); sum += t.net; const a = pokMap()[normMak(h.MAK)];
    return `<tr data-ho="${esc(h._id)}"><td class="no"><b>${honorDB.length - honorDB.indexOf(h)}</b></td>
      <td><span class="lt-title" data-hoa="edit">${esc(h.judul2 || "(tanpa nama kegiatan)")}</span><div class="lsub one">${esc(h.judul1 || "")}${h.tglDaftar ? " · " + esc(h.tglDaftar) : ""}</div></td>
      <td><div class="one" style="font-size:13px">${esc(skOf(h)[0] || "–")}</div><div class="lsub one" title="${esc(h.MAK || "")}">${esc(a ? a.kompNama + " · " + h.MAK : h.MAK || "MAK belum diisi")}</div></td>
      <td class="num">${(h.rows || []).length}</td><td class="num">Rp ${rupiah(t.net)}${t.pph ? `<div class="lsub">bruto ${rupiah(t.bruto)}</div>` : ""}</td>
      <td class="acts"><button class="btn sm pri" data-hoa="xls">Excel</button> <button class="ib" data-hoa="edit" title="Edit">${IC.edit}</button><button class="ib" data-hoa="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-hoa="del" title="Hapus">${IC.del}</button></td></tr>`; }).join("")
    || `<tr><td colspan="6" class="muted" style="text-align:center;padding:24px">${honorDB.length ? "Tidak ada yang cocok." : "Belum ada daftar honor. Klik <b>+ Daftar honor baru</b>."}</td></tr>`;
  $("#hoInfo").textContent = list.length ? `${list.length} daftar · total diterima Rp ${rupiah(sum)}` : "";
}
$("#hoQ").addEventListener("input", debounce(() => renderHonorList(), 150));
$("#hoTbl").addEventListener("click", e => {
  const tr = tg(e).closest<HTMLInputElement>("tr[data-ho]"), a = tg(e).closest<HTMLInputElement>("[data-hoa]")?.dataset.hoa; if (!tr || !a) return;
  const h = honorDB.find(x => x._id === tr.dataset.ho); if (!h) return;
  if (a === "edit") openHonor(h);
  if (a === "xls") honorXlsx(h);
  if (a === "dup"){ const c = clone(h); c._id = newId(); c.judul2 = (c.judul2 || "") + " (salinan)"; c.sk = ""; openHonor(c, true); toast("Salinan dibuat — ubah lalu simpan."); }
  if (a === "del" && confirm(`Hapus daftar honor "${h.judul2 || h.judul1}"?`)){ honorDB = honorDB.filter(x => x !== h); persistHonor(); renderHonorList(); }
});
$("#hoNew").onclick = () => openHonor(hoBlank(), true);
/* ---------- editor ---------- */
const hoIn = (k: string) => $(`#hoForm [data-h="${k}"]`);
function openHonor(h: Honor, isNew = false): void {
  hoCur = clone(h); hoSaved = isNew ? null : h;
  for (const e of $$("#hoForm [data-h]")){ const k = e.dataset.h ?? "", v = String(hoField(hoCur)[k] ?? ""); e.value = ["bend", "ppk", "pembuat"].includes(k) ? (v ? pegLabel(v) : "") : v; }
  if (!hoCur.obFrom){ const fr = hoCur.rows.map(x => parseTgl(x.obFrom)?.getTime()).filter((t): t is number => t != null), to = hoCur.rows.map(x => parseTgl(x.obTo)?.getTime()).filter((t): t is number => t != null);   // data lama: rentang per petugas → satu rentang
    if (fr.length) hoCur.obFrom = fmtDate(new Date(Math.min(...fr))); if (to.length) hoCur.obTo = fmtDate(new Date(Math.max(...to))); }
  $("#hoObFrom").value = isoOf(hoCur.obFrom); $("#hoObTo").value = isoOf(hoCur.obTo);
  hoCur.judul1 = hoCur.judul1 || "DAFTAR PEMBAYARAN HONOR"; hoSkOpts(); hoIn("tglSk").value = skOf(hoCur)[1] || "";
  $("#hoAllJab").value = hoCur.defJab || ""; $("#hoAllSat").value = String(hoCur.defSat || "");
  $("#hoFlag").textContent = isNew ? "Daftar honor baru" : "Mengubah daftar honor"; $("#hoFlag").hidden = false;
  $("#hoListCard").hidden = true; $("#hoEdit").hidden = false; renderHoRows(); window.scrollTo(0, 0);
}
function closeHonor(): void { hoCur = null; $("#hoEdit").hidden = true; $("#hoListCard").hidden = false; renderHonorList(); }
$("#hoBack").onclick = () => { if (hoCur && JSON.stringify(hoCur) !== JSON.stringify(hoSaved || {}) && hoCur.rows.length && !confirm("Tinggalkan tanpa menyimpan?")) return; closeHonor(); };
/* tanggal daftar honor tidak boleh sebelum tanggal SK (minimal sama) */
function hoTglErr(h: Honor): string | null {
  const sk = parseTgl(skOf(h)[1]), d = parseTgl(h.tglDaftar);
  if (h.tglDaftar && !d) return "Tanggal daftar tidak terbaca — tulis mis. 8 November 2026.";
  if (sk && d && d < sk) return `Tanggal daftar (${fmtDate(d)}) tidak boleh sebelum tanggal SK (${fmtDate(sk)}) — minimal sama dengan tanggal SK.`;
  return null;
}
function skOf(h: Honor): [string, string, Surat | null] { const x = h.skId ? suratDB.find(s0 => s0._id === h.skId) : undefined; return x ? [nsNomor(x), x.tgl, x] : [h.sk || "", h.tglSk || "", null]; }
function hoSkOpts(): void {
  if (!hoCur) return; const cur = hoCur;
  const sel = hoIn("skId"), list = suratDB.filter(x => /keputusan/i.test(String(x.jenis || ""))).sort((a, b) => (nsYearOf(b) || 0) - (nsYearOf(a) || 0) || b.no - a.no);
  const old = !cur.skId && cur.sk ? `<option value="__old" selected disabled>${esc(cur.sk)} (lama, bukan dari daftar SK — pilih ulang)</option>` : "";
  sel.innerHTML = `<option value="">${list.length ? "— pilih Surat Keputusan —" : "Belum ada Surat Keputusan — catat di tab Nomor Surat"}</option>` + old
    + list.map(x => `<option value="${esc(x._id)}" ${x._id === cur.skId ? "selected" : ""}>${esc(nsNomor(x))} — ${esc(String(x.perihal).slice(0, 55))}</option>`).join("");
  $("#ho-skInfo").textContent = skOf(cur)[2]?.perihal || "";
}
$("#hoForm").addEventListener("input", e => { const k = tg(e).dataset.h; if (!k || !hoCur) return;

  if (k === "skId") return; if (!["bend", "ppk", "pembuat"].includes(k)) hoField(hoCur)[k] = tg(e).value.trim(); hoSums(); });
$("#hoForm").addEventListener("change", e => {
  if (!hoCur) return;
  const hf = tg(e).dataset.hfor; if (hf && tg(e).value){ const t = hoIn(hf); t.value = fmtTgl(tg(e).value); hoField(hoCur)[hf] = t.value; }
  const k = tg(e).dataset.h ?? "";
  if (["bend", "ppk", "pembuat"].includes(k)){ const c = resolvePeg(tg(e).value); hoField(hoCur)[k] = c || ""; if (c) tg(e).value = pegLabel(c); }
  if (k === "skId" && tg(e).value !== "__old"){ const x = suratDB.find(s0 => s0._id === tg(e).value);
    hoCur.skId = x ? x._id : ""; hoCur.sk = x ? nsNomor(x) : ""; hoCur.tglSk = x ? x.tgl : ""; hoIn("tglSk").value = hoCur.tglSk; $("#ho-skInfo").textContent = x ? x.perihal : ""; }
  hoSums();
});
function hoRowHtml(x: HonorRow, i: number): string {
  const b = num(x.dok) * num(x.sat);
  return `<tr data-r="${i}"><td class="muted">${i + 1}</td>
    <td><input data-hr="nama" data-ac="peg" autocomplete="off" value="${esc(hoName(x))}" placeholder="Cari nama…"></td>
    <td><input data-hr="rek" value="${esc(x.rek || "")}" placeholder="-"></td>
    <td><div class="volin"><input data-hr="dok" type="number" min="0" value="${esc(x.dok ?? "")}" style="text-align:right"><select data-hr="unit">${HO_UNITS.map(u => `<option ${!hoUnitOther(x) && (x.unit || "Dokumen") === u ? "selected" : ""}>${u}</option>`).join("")}<option value="__lain" ${hoUnitOther(x) ? "selected" : ""}>Lainnya…</option></select></div>${hoUnitOther(x) ? `<input data-hr="unitLain" value="${esc(x.unit)}" placeholder="tulis satuan" style="margin-top:4px;height:28px">` : ""}</td>
    <td>${hoKind(x) ? `<select data-hr="jabSel" title="${hoKind(x) === "mitra" ? "Mitra: pilih jabatan — semua mitra di daftar ini ikut sama" : "Pegawai: otomatis jabatan di Database"}">${hoJabOpts(x).map(j => `<option ${!hoJabOther(x) && x.jab === j ? "selected" : ""}>${esc(j)}</option>`).join("")}<option value="__lain" ${hoJabOther(x) ? "selected" : ""}>Lainnya…</option></select>${hoJabOther(x) ? `<input data-hr="jab" value="${esc(x.jab || "")}" placeholder="tulis jabatan" style="margin-top:4px;height:28px">` : ""}<div class="lsub">${hoKind(x)}</div>` : `<input data-hr="jab" value="${esc(x.jab || "")}" placeholder="pilih nama dulu">`}</td>
    <td><input data-hr="sat" type="number" min="0" step="1000" value="${esc(x.sat ?? "")}" style="text-align:right"></td>
    <td class="num" data-o="bruto">${rupiah(b)}</td>
    <td><div class="pctin"><input data-hr="pph" type="number" min="0" max="100" step="0.5" value="${esc(x.pph ?? "")}" placeholder="0" style="text-align:right" title="Persen dari bruto — otomatis: pegawai dari golongan (IV 15%, III 5%, II 0%); mitra 5% bila bruto melebihi batas PTKP"><span>%</span></div><div class="lsub" data-o="pphrp" style="text-align:right">${pphAmt(x) ? "Rp " + rupiah(pphAmt(x)) : ""}</div></td>
    <td class="num" data-o="net"><b>${rupiah(b - pphAmt(x))}</b></td>
    <td><button class="ib del" type="button" data-hdel="${i}" title="Hapus baris">${IC.del}</button></td></tr>`
;
}
function renderHoRows(): void {
  if (!hoCur) return;
  $("#hoRows tbody").innerHTML = hoCur.rows.map(hoRowHtml).join("") || `<tr><td colspan="10" class="muted" style="text-align:center;padding:18px">Belum ada petugas. Klik <b>+ Tambah petugas</b> atau impor dari Excel.</td></tr>`;
  hoSums();
}
function hoObUI(): void {
  if (!hoCur) return;
  const ob = hoCur.rows.some(x => x.unit === "OB"); $("#hoObWrap").hidden = !ob; if (!ob) return;
  const a = parseTgl(hoCur.obFrom), b = parseTgl(hoCur.obTo);
  $("#hoObInfo").innerHTML = a && b ? (b < a ? `<span class="bad">tanggal selesai sebelum tanggal mulai</span>` : `${dayDiff(a, b)} hari · ${fmtDate(a)} – ${fmtDate(b)}`) : `<span class="bad">isi tanggal mulai & selesai</span>`;
}
$("#hoObFrom").addEventListener("change", e => { if (!hoCur) return; hoCur.obFrom = tg(e).value ? fmtTgl(tg(e).value) : ""; hoObUI(); });
$("#hoObTo").addEventListener("change", e => { if (!hoCur) return; hoCur.obTo = tg(e).value ? fmtTgl(tg(e).value) : ""; hoObUI(); });
function hoSums(): void {
  if (!hoCur) return;
  hoObUI();
  const t = hoTot(hoCur), n = hoCur.rows.length;
  $("#hoCount").textContent = n + " petugas";
  $("#hoFoot").innerHTML = n ? `<tr><td></td><td colspan="5"><b>Jumlah</b></td><td class="num"><b>${rupiah(t.bruto)}</b></td><td class="num"><b>${rupiah(t.pph)}</b></td><td class="num"><b>${rupiah(t.net)}</b></td><td></td></tr>` : "";
  $("#hoSum").textContent = "Rp " + rupiah(t.net);
  { const e = hoTglErr(hoCur), el = $("#ho-tgl"); if (el) el.innerHTML = e ? `<span class="bad">${esc(e)}</span>` : ""; }
  $("#ho-judul").textContent = "Di dokumen: " + (hoCur.judul1 || "DAFTAR PEMBAYARAN HONOR") + " / " + String(hoCur.judul2 || "…").toUpperCase();
  $("#hoTerb").textContent = n ? "Terbilang: " + capFirst(terbilang(t.net)) + " Rupiah" : "";
  const saved = hoSaved && normMak(hoSaved.MAK) === normMak(hoCur.MAK) ? hoTot(hoSaved).bruto : 0;
  $("#ho-mak").innerHTML = budgetHtml(hoCur.MAK, t.bruto - saved, null, "daftar ini");
}
$("#hoRows").addEventListener("input", e => {
  const tr = tg(e).closest<HTMLInputElement>("tr[data-r]"), k = tg(e).dataset.hr; if (!tr || !k || !hoCur) return;
  const ri = +tr.dataset.r!, x = hoCur.rows[ri];
  if (k === "nama"){ x.nama = tg(e).value.trim(); x.c = ""; }
  else if (k === "jabSel"){ if (tg(e).value === "__lain"){ x.jabOther = true; x.jab = ""; } else { x.jabOther = false; x.jab = tg(e).value; }
    if (hoKind(x) === "mitra" && x.jab){ let n = 0; for (const r of hoCur.rows) if (r !== x && hoKind(r) === "mitra" && r.jab !== x.jab){ r.jab = x.jab; r.jabOther = x.jabOther; n++; } if (n) toast(`Jabatan ${n} mitra lain ikut diubah menjadi "${x.jab}" — mitra dalam satu daftar harus berjabatan sama.`); }
    renderHoRows(); if (x.jabOther) $(`#hoRows tr[data-r="${ri}"] [data-hr="jab"]`)?.focus(); return; }
  else if (k === "unit"){ if (tg(e).value === "__lain"){ x.unit = ""; x.unitOther = true; tr.outerHTML = hoRowHtml(x, ri); $(`#hoRows tr[data-r="${tr.dataset.r}"] [data-hr="unitLain"]`)?.focus(); hoSums(); return; } const wasOB = x.unit === "OB"; x.unit = tg(e).value; if (wasOB !== (x.unit === "OB")){ x.unitOther = false; renderHoRows(); return; } if (x.unitOther){ x.unitOther = false; tr.outerHTML = hoRowHtml(x, ri); hoSums(); return; } }
  else if (k === "unitLain") x.unit = tg(e).value.trim();
  else if (k === "obFrom" || k === "obTo"){ x[k] = tg(e).value ? fmtTgl(tg(e).value) : ""; const a = parseTgl(x.obFrom), b2 = parseTgl(x.obTo), inf = tr.querySelector('[data-o="obinfo"]');
    if (inf) inf.innerHTML = a && b2 ? (b2 < a ? `<span class="bad">tanggal selesai sebelum tanggal mulai</span>` : dayDiff(a, b2) + " hari · petugas tidak bisa diberi surat tugas lain di luar MAK kegiatan yang sama") : "isi tanggal mulai & selesai"; hoSums(); return; }
  else hoField(x)[k] = ["dok", "sat", "pph"].includes(k) ? (tg(e).value === "" ? "" : Number(tg(e).value)) : tg(e).value.trim();
  if (k === "pph" && e.isTrusted) x.pphManual = true;   // diketik pengguna → tidak diubah otomatis lagi
  if ((k === "dok" || k === "sat") && !x.pphManual){ const a = pphAuto(x); if (num(x.pph) !== a){ x.pph = a; tr.querySelector<HTMLInputElement>('[data-hr="pph"]')!.value = String(a); } }
  const b = num(x.dok) * num(x.sat);
  tr.querySelector('[data-o="bruto"]')!.textContent = rupiah(b); tr.querySelector('[data-o="net"]')!.innerHTML = `<b>${rupiah(b - pphAmt(x))}</b>`; tr.querySelector('[data-o="pphrp"]')!.textContent = pphAmt(x) ? "Rp " + rupiah(pphAmt(x)) : "";
  hoSums();
});
$("#hoRows").addEventListener("change", e => {
  const tr = tg(e).closest<HTMLInputElement>("tr[data-r]"); if (!tr || !hoCur) return;
  if (tg(e).dataset.hr === "jab"){ const x = hoCur.rows[+tr.dataset.r!];   // jabatan "Lainnya" mitra → semua mitra sama
    if (hoKind(x) === "mitra" && x.jab){ let n = 0; for (const r of hoCur.rows) if (r !== x && hoKind(r) === "mitra" && r.jab !== x.jab){ r.jab = x.jab; r.jabOther = true; n++; } if (n){ toast(`Jabatan ${n} mitra lain ikut diubah menjadi "${x.jab}".`); renderHoRows(); } }
    return; }
  if (tg(e).dataset.hr !== "nama") return;
  const ri = +tr.dataset.r!, x = hoCur.rows[ri], c = resolvePeg(tg(e).value);
  if (c){ const nk = hoKind({ c }), lk = hoListKind(hoCur, ri);
    if (nk && lk && nk !== lk){ x.nama = ""; x.c = ""; tg(e).value = ""; return toast(`${pegMap()[c].nama} adalah ${nk}, sedangkan daftar ini berisi ${lk} — anggota honor tidak boleh campuran mitra dan pegawai.`, "warn"); }
    if (hoCur.rows.some((r, i) => i !== ri && r.c === c)){ x.nama = ""; x.c = ""; tg(e).value = ""; return toast(`${pegMap()[c].nama} sudah ada di daftar honor ini.`, "warn"); }
    x.c = c; x.jabOther = false;
    if (nk === "pegawai") x.jab = hoPegJab(x) || x.jab;
    else if (nk === "mitra"){ const mj = hoMitraJab(hoCur, ri); x.jab = mj || (HO_JAB_MITRA.includes(x.jab) ? x.jab : HO_JAB_MITRA.includes($("#hoAllJab").value.trim()) ? $("#hoAllJab").value.trim() : HO_JAB_MITRA[0]); x.jabOther = !!mj && !HO_JAB_MITRA.includes(mj); }
    x.nama = pegMap()[c].nama; { const q = () => document.querySelector<HTMLElement>(`#hoRows tr[data-r="${ri}"]`), ae = document.activeElement as HTMLElement | null;
      if (ae && q()?.contains(ae)) ae.blur();   // blur dulu: "change" bawaan peramban dijalankan sebelum baris diganti
      const cur = q(); if (cur?.isConnected) cur.outerHTML = hoRowHtml(x, ri); } hoSums();
    const tr2 = $(`#hoRows tr[data-r="${ri}"]`), pi = tr2.querySelector<HTMLInputElement>('[data-hr="pph"]')!;
    x.pphManual = false; x.pph = pphAuto(x); pi.value = String(x.pph); pi.dispatchEvent(new Event("input", { bubbles: true }));
    if (!x.rek && rekMap[c]){ x.rek = rekMap[c]; tr2.querySelector<HTMLInputElement>('[data-hr="rek"]')!.value = x.rek; }
  }
});
$("#hoRows").addEventListener("click", e => { const d = tg(e).closest<HTMLInputElement>("[data-hdel]")?.dataset.hdel; if (d == null || !hoCur) return; hoCur.rows.splice(+d, 1); renderHoRows(); });
$("#hoAllUnit").innerHTML = HO_UNITS.map(u => `<option>${u}</option>`).join("");
$("#hoAdd").onclick = () => { if (!hoCur) return; const cur = hoCur; cur.rows.push({ nama: "", c: "", rek: "", dok: "", unit: $<HTMLSelectElement>("#hoAllUnit").value || "Dokumen", jab: hoMitraJab(cur) || $("#hoAllJab").value.trim() || "Petugas Lapangan", sat: $("#hoAllSat").value === "" ? "" : Number($("#hoAllSat").value), pph: "" });
  renderHoRows(); $(`#hoRows tr[data-r="${cur.rows.length - 1}"] [data-hr="nama"]`).focus(); };
$("#hoApply").onclick = () => { if (!hoCur) return; const j = $("#hoAllJab").value.trim(), s0 = $("#hoAllSat").value; hoCur.defJab = j; hoCur.defSat = s0;
  const u = $<HTMLSelectElement>("#hoAllUnit").value; hoCur.defUnit = u;
  for (const x of hoCur.rows){ if (j && hoKind(x) !== "pegawai"){ x.jab = j; x.jabOther = hoKind(x) === "mitra" && !HO_JAB_MITRA.includes(j); } if (s0 !== "") x.sat = Number(s0); if (u) x.unit = u; if (!x.pphManual) x.pph = pphAuto(x); } renderHoRows(); toast(hoListKind(hoCur) === "pegawai" ? "Satuan diterapkan — jabatan pegawai tetap mengikuti Database." : "Jabatan & satuan diterapkan ke semua petugas."); };
$("#hoSave").onclick = () => {
  if (!hoCur) return;
  if (!hoCur.judul2) return toast("Isi judul / nama kegiatan.");
  { const e = hoTglErr(hoCur); if (e) return toast(e); }
  if (hoCur.rows.some(x => x.unit === "OB" && hoName(x))){ const a = parseTgl(hoCur.obFrom), b = parseTgl(hoCur.obTo);
    if (!a || !b || b < a) return toast("Isi rentang tanggal OB / kontrak di bagian 1 · Data kegiatan."); }
  if (hoCur.MAK && !HO_AKUN.includes(akunOf(hoCur.MAK))) return toast("MAK honor harus akun 521213 (Belanja Honor Output Kegiatan).");
  if (hoCur.bend && !roleOk(hoCur.bend, ["BEND"]) && hoCur.bend !== hoSaved?.bend) return toast("Bendahara Pengeluaran harus pegawai berperan Bendahara — atur di Database → Pegawai.");
  if (hoCur.ppk && !roleOk(hoCur.ppk, ["PPK"]) && hoCur.ppk !== hoSaved?.ppk) return toast("PPK harus pegawai berperan PPK — atur di Database → Pegawai.");
  hoCur.rows = hoCur.rows.filter(x => hoName(x));
  if (!hoCur.rows.length) return toast("Belum ada petugas.");
  for (const x of hoCur.rows) if (!x.c){ const c = resolvePeg(x.nama); if (c) x.c = c; }
  { const e = hoRulesErr(hoCur); if (e){ renderHoRows(); return toast(e, "warn"); } }
  const bad = hoCur.rows.filter(x => !num(x.dok) || !num(x.sat)); if (bad.length && !confirm(`${bad.length} petugas belum berisi banyak dokumen / satuan. Tetap simpan?`)) return;
  for (const x of hoCur.rows){ if (!x.c){ const c = resolvePeg(x.nama); if (c) x.c = c; } if (x.c && x.rek && x.rek !== "-") rekMap[x.c] = x.rek; }
  const cur = hoCur, i = honorDB.findIndex(h => h._id === cur._id);
  if (i >= 0) honorDB[i] = clone(cur); else honorDB.push(clone(cur));
  hoSaved = honorDB.find(h => h._id === cur._id); persistHonor(); renderHoRows(); $("#hoFlag").textContent = "Tersimpan";
  $("#hsvMsg").textContent = `${hoCur.judul2} — ${hoCur.rows.length} petugas, jumlah diterima Rp ${rupiah(hoTot(hoCur).net)}.`;
  $<HTMLDialogElement>("#dHoSaved").showModal();
};
$$("#dHoSaved [data-hsv]").forEach(b => b.onclick = () => { const a = b.dataset.hsv; $<HTMLDialogElement>("#dHoSaved").close();
  if (a === "list") closeHonor(); else if (a === "xls" && hoCur) honorXlsx(hoCur); else if (a === "prev" && hoCur) honorPreview(hoCur); });
/* pratinjau dokumen honor (tampilan sama dengan hasil Excel) */
function honorHtml(h: Honor): string {
  const P = pegMap(), t = hoTot(h), rows = (h.rows || []).filter(x => hoName(x)), [skNo, skTgl] = skOf(h);
  const lines = makLines(h.MAK).filter(([k]) => k !== "Sub-Komponen").map(([k, v]) => [k === "Akun/Detil" ? "Akun" : k, v]);
  const info = [...lines, ["Unit Kerja", h.unit || "BPS Kabupaten Maybrat (690691)"], ["Nomor SK", skNo], ["Tanggal SK", skTgl]];
  const bend = P[h.bend], ppk = P[h.ppk], pb = P[h.pembuat];
  return `<div class="hp-title">${esc(h.judul1 || "DAFTAR PEMBAYARAN HONOR")}<br>${esc(String(h.judul2 || "").toUpperCase())}</div>
    <table class="hp-info">${info.map(([k, v]) => `<tr><td>${esc(k)}</td><td>: ${esc(v || "")}</td></tr>`).join("")}</table>
    <table class="hp-tbl"><thead><tr><th>No</th><th>Nama</th><th>No Rekening</th><th>Volume</th><th>Satuan</th><th>Jabatan</th><th>Harga Satuan (Rp)</th><th>Jumlah Bruto (Rp)</th><th>PPh 21 (Rp)</th><th>Jumlah yang Diterima (Rp)</th><th colspan="2">Tanda Tangan</th></tr>
      <tr class="n">${[1,2,3,4,5,6,7,8,9,10].map(i => `<td>(${i})</td>`).join("")}<td colspan="2">(11)</td></tr></thead>
      <tbody>${rows.map((x, i) => { const b = num(x.dok) * num(x.sat); return `<tr><td class="c">${i + 1}</td><td>${esc(hoName(x))}</td><td class="c">${esc(x.rek || "-")}</td><td class="c">${num(x.dok)}</td><td class="c">${esc(x.unit || "Dokumen")}</td><td>${esc(x.jab || "")}</td><td class="r">${rupiah(num(x.sat))}</td><td class="r">${rupiah(b)}</td><td class="r">${pphAmt(x) ? rupiah(pphAmt(x)) : "-"}</td><td class="r">${rupiah(b - pphAmt(x))}</td><td>${i % 2 ? "" : (i + 1) + ". ……"}</td><td>${i % 2 ? (i + 1) + ". ……" : ""}</td></tr>`; }).join("")}
      <tr class="tot"><td colspan="7" class="c">Jumlah</td><td class="r">${rupiah(t.bruto)}</td><td class="r">${t.pph ? rupiah(t.pph) : "-"}</td><td class="r">${rupiah(t.net)}</td><td colspan="2"></td></tr></tbody></table>
    <p class="hp-terb"><i>Terbilang : ${esc(capFirst(terbilang(t.net)))} Rupiah</i></p>
    <p>Lunas pada tanggal</p>
    <div class="hp-sign"><div><br>Bendahara Pengeluaran<br><br><br><br><b>${esc(bend?.nama || "")}</b><br>${esc(nipText(bend))}</div>
      <div>Setuju dibayar,<br>Pejabat Pembuat Komitmen<br><br><br><br><b>${esc(ppk?.nama || "")}</b><br>${esc(nipText(ppk))}</div>
      <div>${esc(h.tempat || "Maybrat")}, ${esc(h.tglDaftar || "")}<br>Pembuat Daftar<br><br><br><br><b>${esc(pb?.nama || "")}</b><br>${esc(nipText(pb))}</div></div>`;
}
function honorPreview(h: Honor): void {
  if (!(h.rows || []).some(x => hoName(x))) return toast("Belum ada petugas untuk dipratinjau.");
  $("#hpDoc").innerHTML = honorHtml(h); $<HTMLDialogElement>("#dHoPrev").showModal();
}
$("#hoPrev").onclick = () => { if (hoCur) honorPreview(hoCur); };
$("#hpClose").onclick = () => $<HTMLDialogElement>("#dHoPrev").close();
$("#hpXls").onclick = () => { if (hoCur) honorXlsx(hoCur); };
$("#hoDel").onclick = () => { if (!hoCur) return; if (!confirm("Hapus daftar honor ini?")) return; const id = hoCur._id; honorDB = honorDB.filter(h => h._id !== id); persistHonor(); closeHonor(); };
$("#hoXls").onclick = () => { if (hoCur) honorXlsx(hoCur); };
/* ---------- salin petugas dari surat tugas ---------- */
const hsSel = new Set<string>();
function renderHs(): void {
  const toks = acNorm($("#hsQ").value.trim()).split(/\s+/).filter(Boolean), P = pegMap();
  const list = [...records].sort(byYearNo).reverse().filter(r => !toks.length || toks.every(t => acNorm(hayOf(r)).includes(t))).slice(0, 150);
  $("#hsTbl tbody").innerHTML = list.map(r => { const F = computeC(r);
    return `<tr data-hs="${esc(r._id)}" style="cursor:pointer" class="${hsSel.has(r._id ?? "") ? "on" : ""}"><td><input type="checkbox" ${hsSel.has(r._id ?? "") ? "checked" : ""}></td><td><b style="font-size:13px">${esc(F.MAKSUD__TUJUAN)}</b><div class="lsub">${esc(F.NOMOR_ST)}${F.kegiatan ? " · " + esc(F.kegiatan) : ""}</div></td><td style="font-size:13px">${esc(tglRange(r))}</td><td class="num">${personCodes(r, P).length}</td></tr>`; }).join("")
    || `<tr><td colspan="4" class="muted" style="text-align:center;padding:18px">Tidak ada surat tugas yang cocok.</td></tr>`;
  const nP = new Set([...hsSel].flatMap(id => { const r = records.find(x => x._id === id); return r ? personCodes(r, P) : []; })).size;
  $("#hsInfo").textContent = hsSel.size ? `${hsSel.size} surat dipilih · ${nP} petugas (nama ganda hanya dihitung sekali)` : "Centang satu atau beberapa surat tugas — semua pelaksana & anggota timnya ditambahkan.";
}
$("#hoFromSt").onclick = () => { hsSel.clear(); $("#hsQ").value = ""; renderHs(); $<HTMLDialogElement>("#dHoSt").showModal(); $("#hsQ").focus(); };
$("#hsQ").addEventListener("input", debounce(() => renderHs(), 150));
$("#hsTbl").addEventListener("click", e => { const tr = tg(e).closest<HTMLInputElement>("tr[data-hs]"); if (!tr) return; const id = tr.dataset.hs ?? ""; hsSel.has(id) ? hsSel.delete(id) : hsSel.add(id); renderHs(); });
$("#hsCancel").onclick = () => $<HTMLDialogElement>("#dHoSt").close();
$("#hsGo").onclick = () => {
  if (!hsSel.size) return toast("Centang surat tugas dulu."); if (!hoCur) return; const cur = hoCur;
  const P = pegMap(), have = new Set(cur.rows.map(x => x.c).filter(Boolean)); let n = 0;
  for (const id of hsSel){ const r = records.find(x => x._id === id); if (!r) continue;
    for (const c of personCodes(r, P)){ if (have.has(c)) continue; have.add(c);
      cur.rows.push({ nama: P[c].nama, c, rek: rekMap[c] || "", dok: "", jab: cur.defJab || "Petugas Lapangan", sat: cur.defSat === "" || cur.defSat == null ? "" : num(cur.defSat), unit: cur.defUnit || "Dokumen", pph: pphAuto({ c, dok: 0, sat: cur.defSat }) }); n++; } }
  $<HTMLDialogElement>("#dHoSt").close(); renderHoRows(); toast(n ? `${n} petugas ditambahkan dari ${hsSel.size} surat tugas — isi banyak dokumen & satuan.` : "Semua petugas itu sudah ada di daftar.");
};
/* ---------- template & impor petugas ---------- */
const HO_HDR = ["Nama", "No Rekening", "Volume", "Satuan Volume", "Jabatan", "Satuan (Rp)", "PPh 21 (%)"];
const hoTemplate = () => {
  const mit = pegawai.filter(isMitra).slice(0, 3);
  const ws = XLSX.utils.aoa_to_sheet([HO_HDR, ...mit.map((p, i) => [p.nama, rekMap[p.kode] || "-", 10 + i * 5, HO_UNITS[i % HO_UNITS.length], "Petugas Lapangan", 69000, pphAuto({ c: p.kode, dok: 10 + i * 5, sat: 69000 })])]);
  ws["!cols"] = [34, 20, 10, 14, 22, 14, 12].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Petugas"); XLSX.writeFile(wb, "Template Honor Petugas.xlsx");
  toast("Template diunduh — satu baris per petugas, lalu Impor petugas.");
};
$("#hoTpl").onclick = hoTemplate; $("#hoTpl2").onclick = hoTemplate;
$("#hoImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f || !hoCur) return; const cur = hoCur;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
    let rows: unknown[][] | null = null, H: string[] = [];
    for (const sn of wb.SheetNames){ const a = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: true }); const hi = a.findIndex(r => r.some(c => /^nama$/i.test(String(c).trim()))); if (hi >= 0){ H = a[hi].map(c => String(c).trim().toLowerCase()); rows = a.slice(hi + 1); break; } }
    if (!rows) return toast("Kolom 'Nama' tidak ditemukan. Pakai template.");
    const ix = (re: RegExp) => H.findIndex(h => re.test(h)), cN = ix(/^nama$/), cR = ix(/rekening/), cD = ix(/dokumen|^volume|jumlah dok/), cJ = ix(/^jabatan/), cS = ix(/^satuan \(rp|^harga|^tarif|^satuan$/), cU = ix(/^satuan volume|^unit/), cP = ix(/pph/);
    let n = 0, unk = 0;
    for (const r of rows){
      const nm = String(r[cN] ?? "").trim(); if (!nm || /^jumlah$/i.test(nm)) continue;
      const c = resolvePeg(nm); if (!c) unk++;
      cur.rows.push({ nama: c ? pegMap()[c].nama : nm, c: c || "", rek: String(cR < 0 ? "" : r[cR] ?? "").trim() || (c && rekMap[c]) || "", dok: cD < 0 ? "" : num(r[cD]), jab: String(cJ < 0 ? "" : r[cJ] ?? "").trim() || cur.defJab || "Petugas Lapangan",
        sat: cS < 0 ? (cur.defSat === "" ? "" : num(cur.defSat)) : num(r[cS]), unit: ((u: string) => u ? (HO_UNITS.find(x => x.toLowerCase() === u.toLowerCase()) || u) : (cur.defUnit || "Dokumen"))(String(cU < 0 ? "" : r[cU] ?? "").trim()),
        pph: cP < 0 ? pphAuto({ c, dok: cD < 0 ? 0 : num(r[cD]), sat: cS < 0 ? num(cur.defSat) : num(r[cS]) }) : ((v: number) => /%/.test(H[cP]) || v <= 100 ? v : (num(r[cD]) * num(r[cS]) ? Math.round(v / (num(r[cD]) * num(r[cS])) * 10000) / 100 : 0))(num(r[cP])) });
      n++;
    }
    renderHoRows(); toast(`${n} petugas diimpor` + (unk ? ` — ${unk} nama belum ada di Pegawai & Mitra (tetap dipakai apa adanya).` : "."));
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
});
/* ---------- ekspor Excel seperti draf Honor ---------- */
async function honorXlsx(h: Honor): Promise<void> {
  const P = pegMap(), t = hoTot(h), rows = (h.rows || []).filter(x => hoName(x)), C = 12;
  if (!rows.length) return toast("Belum ada petugas di daftar ini.");
  const sh = xSheet(h.judul2 || "Honor", [5, 27, 17, 8, 10, 18, 12, 14, 12, 15, 12, 12], { portrait: false });
  sh.set(1, 1, h.judul1 || "DAFTAR PEMBAYARAN HONOR", XS.title).merge(1, 1, 1, C);
  sh.set(2, 1, String(h.judul2 || "").toUpperCase(), XS.title).merge(2, 1, 2, C);
  let y = 4;
  const lines = makLines(h.MAK).filter(([k]) => k !== "Sub-Komponen").map(([k, v]) => [k === "Akun/Detil" ? "Akun" : k, v]);
  for (const [k, v] of [...lines, ["Unit Kerja", h.unit || "BPS Kabupaten Maybrat (690691)"], ["Nomor SK", skOf(h)[0] || ""], ["Tanggal SK", skOf(h)[1] || ""]]){
    sh.set(y, 1, k, XS.wrap).merge(y, 1, y, 2).set(y, 3, ": " + v, XS.wrap).merge(y, 3, y, C); if (String(v).length > 100) sh.h(y, 27); y++; }
  y++;
  const H = ["No", "Nama", "No Rekening", "Volume", "Satuan", "Jabatan", "Harga Satuan (Rp)", "Jumlah Bruto (Rp)", "PPh 21 (Rp)", "Jumlah yang Diterima (Rp)", "Tanda Tangan"];
  H.forEach((x, i) => sh.set(y, i + 1, x, XS.th)); sh.merge(y, 11, y, 12, XS.th); sh.h(y, 32); y++;
  H.forEach((_, i) => sh.set(y, i + 1, `(${i + 1})`, XS.thn)); sh.merge(y, 11, y, 12, XS.thn); y++;
  const d0 = y;
  rows.forEach((x, i) => { const b = hoBruto(x);
    sh.set(y, 1, i + 1, XS.td).set(y, 2, hoName(x), XS.tdl).set(y, 3, x.rek || "-", XS.td).set(y, 4, num(x.dok), XS.td).set(y, 5, x.unit || "Dokumen", XS.td).set(y, 6, x.jab || "", XS.tdl).set(y, 7, num(x.sat), XS.num)
      .set(y, 8, b, XS.num, `D${y}*G${y}`).set(y, 9, pphAmt(x), XS.num, `ROUND(H${y}*${num(x.pph)}/100,0)`).set(y, 10, b - pphAmt(x), XS.num, `H${y}-I${y}`)
      .set(y, 11, i % 2 ? "" : `${i + 1}  …………`, XS.tdl).set(y, 12, i % 2 ? `${i + 1}  …………` : "", XS.tdl); sh.h(y, 24); y++; });
  sh.set(y, 1, "Jumlah", XS.tdb).merge(y, 1, y, 7, XS.tdb);
  sh.set(y, 8, t.bruto, XS.numb, `SUM(H${d0}:H${y - 1})`).set(y, 9, t.pph, XS.numb, `SUM(I${d0}:I${y - 1})`).set(y, 10, t.net, XS.numb, `SUM(J${d0}:J${y - 1})`).merge(y, 11, y, 12, XS.td); sh.h(y, 20); y += 2;
  sh.set(y, 1, "Terbilang", XS.it).merge(y, 1, y, 2).set(y, 3, ": " + capFirst(terbilang(t.net)) + " Rupiah", XS.it).merge(y, 3, y, C); y += 2;
  sh.set(y, 1, "Lunas pada tanggal", XS.n).merge(y, 1, y, 3); y += 2;
  const bend = P[h.bend], ppk = P[h.ppk], pb = P[h.pembuat];
  sh.set(y, 6, "Setuju dibayar,", XS.n).set(y, 10, `${h.tempat || "Maybrat"}, ${h.tglDaftar || ""}`, XS.n); y++;
  sh.set(y, 1, "Bendahara Pengeluaran", XS.n).merge(y, 1, y, 3).set(y, 6, "Pejabat Pembuat Komitmen", XS.n).set(y, 10, "Pembuat Daftar", XS.n); y += 5;
  sh.set(y, 1, bend?.nama || "", XS.b).merge(y, 1, y, 3).set(y, 6, ppk?.nama || "", XS.b).set(y, 10, pb?.nama || "", XS.b); y++;
  sh.set(y, 1, nipText(bend), XS.n).merge(y, 1, y, 3).set(y, 6, nipText(ppk), XS.n).set(y, 10, nipText(pb), XS.n);
  await xlsxSave([sh], `Honor ${(h.judul2 || "Petugas").replace(/[\\/:*?"<>|]+/g, " ").slice(0, 80)}.xlsx`);
  toast(`Daftar honor ${rows.length} petugas diunduh (Rp ${rupiah(t.net)}).`);
}

