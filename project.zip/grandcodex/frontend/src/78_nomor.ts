/* ================= NOMOR SURAT (register tersendiri, urut per jenis & tahun) ================= */
const NS_JENIS = ["Surat Keputusan", "Surat Keluar", "Kontrak", "Kuitansi", "Surat Penghargaan"];
const NS_FMT0 = Object.fromEntries(["Surat Keputusan", "Surat Keluar", "Kontrak", "Kuitansi", "Surat Penghargaan"].map(j => [j, "{SIFAT}-{NO}/9204/{KODE}/{TAHUN}"]));
/** satu nomor surat di register */
interface Surat { _id: string; jenis: string; sifat?: string | null; no: number; tgl: string; tahun?: number; kode: string; kodeLain?: boolean; perihal: string; tujuan?: string; ket?: string; batch?: string }
/** isian formulir nomor surat ([data-ns]) */
type NsForm = Record<"jenis" | "sifat" | "tgl" | "kode" | "no" | "noEnd" | "perihal", string>;
/** cukup untuk menyusun nomor: surat tersimpan atau isian formulir */
interface NsLike { jenis: string; sifat?: string | null; no?: number | string; tgl: string; kode: string; tahun?: number }
var suratDB = LS.get<Surat[]>("st.surat", []), nsFmt: Record<string, string> = { ...NS_FMT0, ...LS.get<Record<string, string>>("st.suratFmt", {}) }, nsEdit: string | null = null, nsYear: string = "";
for (const x of suratDB) if (x.kode) x.kode = String(x.kode).toUpperCase();
for (const j in nsFmt) nsFmt[j] = String(nsFmt[j]).replace(/^B-\{NO\}/, "{SIFAT}-{NO}");
const persistSurat = () => { LS.set("st.surat", suratDB); LS.set("st.suratFmt", nsFmt); };
const nsYearOf = (x: { tgl?: string; tahun?: number }): number | null => yrOf(x.tgl) || x.tahun || null;
{ const sig = (x: Surat) => [nsYearOf(x), x.jenis, x.sifat, x.tgl, x.kode, x.perihal].join("|"), srt = suratDB.filter(x => !x.batch).sort((a, b) => sig(a).localeCompare(sig(b)) || a.no - b.no);
  for (let i = 0; i < srt.length;){ let j = i; while (j + 1 < srt.length && sig(srt[j + 1]) === sig(srt[i]) && srt[j + 1].no === srt[j].no + 1) j++;
    if (j - i >= 2){ const b = "m" + srt[i]._id; for (let k = i; k <= j; k++) srt[k].batch = b; } i = j + 1; } }
const nsBULAN_ROM = ["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];
function nsNomor(x: NsLike): string {
  const d = parseTgl(x.tgl), y = nsYearOf(x) || "", f = nsFmt[x.jenis] || NS_FMT0["Surat Keluar"];
  const sf = x.sifat == null ? "B" : String(x.sifat);
  return (sf ? f : f.replace(/\{SIFAT\}[-/.]?/g, "")).replace(/\{SIFAT\}/g, sf).replace(/\{NO\}/g, pad3(x.no || "")).replace(/\{KODE\}/g, String(x.kode || "…").toUpperCase()).replace(/\{TAHUN\}/g, String(y)).replace(/\{BULAN\}/g, d ? nsBULAN_ROM[d.getMonth()] : "").replace(/\{BLN\}/g, d ? String(d.getMonth() + 1).padStart(2, "0") : "");
}
const nsNext = (jenis: string | null, y: number | null, exceptId?: string | null): number => 1 + suratDB.filter(x => nsYearOf(x) === y && x._id !== exceptId).reduce((m, x) => Math.max(m, parseInt(String(x.no), 10) || 0), 0);   // urutan bersama semua jenis surat
const nsIn = (k: keyof NsForm) => $(`#nsForm [data-ns="${k}"]`);
function nsRead(): NsForm {
  const o: Record<string, string> = { jenis: "", sifat: "", tgl: "", kode: "", no: "", noEnd: "", perihal: "" };
  $$("#nsForm [data-ns]").forEach(e => { if (e.dataset.ns) o[e.dataset.ns] = e.value.trim(); }); return o as NsForm;
}
function nsReset(keep?: Partial<NsForm>): void {
  nsEdit = null; nsEditBatch = null; $("#nsEndWrap").hidden = false; nsIn("no").readOnly = nsIn("noEnd").readOnly = false;
  const j = keep?.jenis || nsIn("jenis").value || NS_JENIS[1];
  for (const e of $$("#nsForm [data-ns]")) e.value = "";
  nsIn("jenis").value = j; nsIn("sifat").value = keep?.sifat || "B"; nsKodeMode(false); nsIn("tgl").value = keep?.tgl || today(); if (keep?.kode) nsIn("kode").value = keep.kode;
  nsAutoNo(true); $("#nsSave").textContent = "Simpan nomor"; $("#nsCancel").hidden = true; $("#nsFlag").hidden = true; nsPreview();
}
let _nsAutoNo = true;
function nsAutoNo(force?: boolean): void {
  const f = nsRead(), y = yrOf(f.tgl) || new Date().getFullYear(), nx = nsNext(f.jenis, y, nsEdit);
  if (force || _nsAutoNo) nsIn("no").value = String(nx);
  _nsAutoNo = true;
}
function nsCheck(f: NsForm): string | null {
  if (!f.perihal) return "Perihal surat wajib diisi.";
  const d = parseTgl(f.tgl); if (!d) return "Tanggal tidak terbaca — tulis mis. 7 November 2026.";
  if (!f.kode) return "Kode klasifikasi arsip wajib diisi.";
  if (!$("#nsKodeLain").checked && !kodeMap()[f.kode.toUpperCase()]) return `Kode klasifikasi "${f.kode}" tidak ada di daftar — pilih dari daftar atau centang "Lainnya".`;
  const n = parseInt(String(f.no), 10), y = d.getFullYear(); if (!n || n < 1) return "No. urut tidak valid.";
  { const dup = suratDB.find(x => x._id !== nsEdit && nsYearOf(x) === y && parseInt(String(x.no), 10) === n); if (dup) return `No. ${pad3(n)} tahun ${y} sudah dipakai oleh ${dup.jenis}: ${nsNomor(dup)}.`; }
  const old = nsEdit ? suratDB.find(x => x._id === nsEdit) : undefined, nx = nsNext(f.jenis, y, nsEdit);
  if ((!old || parseInt(String(old.no), 10) !== n || nsYearOf(old) !== y) && n > nx) return `Nomor harus berurutan: nomor surat tahun ${y} berikutnya No. ${pad3(nx)} (tidak boleh langsung ${pad3(n)}).`;
  const e = parseInt(f.noEnd, 10);
  if (!nsEdit && f.noEnd !== "" && f.noEnd != null){
    if (!e || e < n) return `"Sampai No." harus sama atau lebih besar dari No. urut (${pad3(n)}).`;
    if (e - n + 1 > 1000) return "Maksimal 1.000 nomor sekali catat.";
    const used = suratDB.filter(x => nsYearOf(x) === y && parseInt(String(x.no), 10) >= n && parseInt(String(x.no), 10) <= e).map(x => pad3(x.no));
    if (used.length) return `No. ${used.slice(0, 5).join(", ")}${used.length > 5 ? "…" : ""} tahun ${y} sudah dipakai — rentang massal tidak boleh menimpa nomor lain.`;
  }
  return null;
}
const nsRange = (f: NsForm): [number, number] | null => { const n = parseInt(String(f.no), 10), e = parseInt(f.noEnd, 10); return !nsEdit && e && n && e > n ? [n, e] : null; };
function nsKodeMode(lain: unknown): void {
  const inp = nsIn("kode"); $("#nsKodeLain").checked = !!lain;
  if (lain){ delete inp.dataset.ac; inp.placeholder = "Tulis kode sendiri, mis. KU.010 atau 001"; } else { inp.dataset.ac = "kode"; inp.placeholder = "Cari kode / kata, mis. KP.200 atau keputusan"; }
}
$("#nsKodeLain").addEventListener("change", e => { nsKodeMode(tg(e).checked); if (!tg(e).checked){ const c = kodeMap()[nsIn("kode").value.trim().toUpperCase()]; if (!c) nsIn("kode").value = ""; } nsIn("kode").focus(); nsPreview(); });
function nsPreview(): void {
  const f = nsRead(), y = yrOf(f.tgl) || new Date().getFullYear(), x = { ...f, no: f.no };
  const kc = kodeMap()[f.kode.toUpperCase()];
  $("#nsKodeInfo").innerHTML = $("#nsKodeLain").checked ? `<span class="muted">Kode lainnya — diisi manual${kc ? ` (ada di daftar: ${esc(kc.d)})` : ""}</span>` : f.kode ? (kc ? `${esc(kc.d)} · ${esc(kodeGroup(kc.k))}` : `<span class="bad">Kode tidak dikenal — pilih dari daftar atau centang "Lainnya"</span>`) : "";
  { const rg = nsRange(f) || (nsEditBatch ? [parseInt(String(f.no), 10), parseInt(f.noEnd, 10)] as [number, number] : null); $("#nsNo").textContent = rg ? `${nsNomor({ ...x, no: rg[0] })}  s.d.  ${nsNomor({ ...x, no: rg[1] })}` : nsNomor(x);
    $("#nsSave").textContent = nsEdit ? (nsEditBatch && rg ? `Simpan perubahan (${rg[1] - rg[0] + 1} nomor)` : "Simpan perubahan") : rg ? `Simpan ${rg[1] - rg[0] + 1} nomor` : "Simpan nomor"; }
  $("#nsYearInfo").textContent = `Tahun ${y} · nomor surat berikutnya (semua jenis): ${pad3(nsNext(f.jenis, y, nsEdit))}`;
  const err = nsCheck(f); $("#nsErr").innerHTML = err && (f.perihal || f.kode) ? `<span class="bad">${esc(err)}</span>` : "";
}
$("#nsForm").addEventListener("input", e => {
  const k = tg(e).dataset.ns, t0 = tg(e);
  if (k === "no") _nsAutoNo = false;
  if (k === "sifat"){ const v = tg(e).value.toUpperCase().replace(/[^A-Z]/g, ""); if (v !== tg(e).value) tg(e).value = v; }
  if (k === "jenis" || k === "tgl"){ if (!nsEdit) nsAutoNo(true); }
  if (k === "kode"){ const t = tg(e), up = t.value.toUpperCase(); if (up !== t.value){ const c = t.selectionStart; t.value = up; t.setSelectionRange(c, c); } }
  if (k === "kode" && !$("#nsKodeLain").checked){ const c = kodeMap()[tg(e).value.trim().toUpperCase()]; if (c) tg(e).value = c.k; }
  nsPreview();
});
$("#nsForm").addEventListener("change", e => {
  if (tg(e).dataset.nsfor && tg(e).value){ nsIn("tgl").value = fmtTgl(tg(e).value); if (!nsEdit) nsAutoNo(true); }
  if (tg(e).dataset.ns === "kode" && !$("#nsKodeLain").checked){ const { c, n } = lookupKode(tg(e).value); if (c) tg(e).value = c.k; else if (n > 1) toast(`${n} kode cocok — pilih dari daftar.`); }
  nsPreview();
});
$("#nsSave").onclick = async () => {
  const f = nsRead(); f.kode = f.kode.toUpperCase();
  const err = nsCheck(f); if (err) return toast(err);
  if (nsEdit && nsEditBatch){
    const g = suratDB.filter(x => x.batch === nsEditBatch && nsYearOf(x) === nsYearOf(suratDB.find(y => y._id === nsEdit) || { tgl: "" })), d = parseTgl(f.tgl)!;
    if (d.getFullYear() !== nsYearOf(g[0])) return toast("Tahun nomor massal tidak bisa diubah — hapus lalu catat ulang di tahun yang baru.");
    for (const x of g) Object.assign(x, { jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), tgl: fmtDate(d), kode: f.kode, perihal: f.perihal, kodeLain: $("#nsKodeLain").checked || undefined });
    persistSurat(); toast(`${g.length} nomor diperbarui: ${nsNomor(g[0])} s.d. ${nsNomor(g[g.length - 1])}`); nsReset({ jenis: f.jenis, tgl: fmtDate(d) }); renderSurat(); return;
  }
  const rg = nsRange(f);
  if (rg){
    const d = parseTgl(f.tgl)!, base = { jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), tgl: fmtDate(d), tahun: d.getFullYear(), kode: f.kode, ...($("#nsKodeLain").checked ? { kodeLain: true } : {}), perihal: f.perihal };
    const cnt = rg[1] - rg[0] + 1; if (cnt > 20 && !confirm(`Catat ${cnt} nomor sekaligus (${pad3(rg[0])} s.d. ${pad3(rg[1])}) dengan perihal "${f.perihal}"?`)) return;
    const batch = newId();
    for (let n = rg[0]; n <= rg[1]; n++) suratDB.push({ _id: newId(), ...base, batch, no: n });
    persistSurat(); nsYear = String(base.tahun);
    const t = `${nsNomor({ ...base, no: rg[0] })} s.d. ${nsNomor({ ...base, no: rg[1] })}`; try{ await navigator.clipboard.writeText(t); }catch(e){}
    toast(`Tersimpan ${cnt} nomor: ${t}`);
    nsReset({ jenis: base.jenis, tgl: base.tgl }); renderSurat(); return;
  }
  const d = parseTgl(f.tgl)!, x: Surat = { _id: nsEdit || newId(), jenis: f.jenis, sifat: String(f.sifat || "").toUpperCase().replace(/[^A-Z]/g, ""), no: parseInt(String(f.no), 10), tgl: fmtDate(d), tahun: d.getFullYear(), kode: f.kode, ...($("#nsKodeLain").checked ? { kodeLain: true } : {}), perihal: f.perihal, tujuan: suratDB.find(s0 => s0._id === nsEdit)?.tujuan || "", ket: suratDB.find(s0 => s0._id === nsEdit)?.ket || "" };
  const i = suratDB.findIndex(s0 => s0._id === x._id);
  if (i >= 0) suratDB[i] = x; else suratDB.push(x);
  persistSurat(); nsYear = String(x.tahun);
  const nomor = nsNomor(x); try{ await navigator.clipboard.writeText(nomor); }catch(e){}
  toast(`${i >= 0 ? "Diperbarui" : "Tersimpan"}: ${nomor} (nomor disalin)`);
  nsReset({ jenis: x.jenis, tgl: x.tgl }); renderSurat();
};
$("#nsCancel").onclick = () => nsReset();
/* ---------- daftar ---------- */
function renderSurat(): void {
  const years = [...new Set(suratDB.map(nsYearOf).filter((y): y is number => !!y))].sort((a, b) => b - a), cy = new Date().getFullYear();
  const opts = [...new Set([String(cy), ...years.map(String)])].sort((a, b) => +b - +a).concat("semua");
  if (!opts.includes(nsYear)) nsYear = String(cy);
  $("#nsYear").innerHTML = opts.map(y => `<option value="${y}" ${y === nsYear ? "selected" : ""}>${y === "semua" ? "Semua tahun" : "Tahun " + y}</option>`).join("");
  const J = $<HTMLSelectElement>("#nsJenisF").value, toks = acNorm($("#nsQ").value.trim()).split(/\s+/).filter(Boolean);
  const inY = suratDB.filter(x => nsYear === "semua" || String(nsYearOf(x)) === nsYear);
  const cnt = Object.fromEntries(NS_JENIS.map(j => [j, inY.filter(x => x.jenis === j).length]));
  $("#nsStats").innerHTML = `<div class="nsst nsnext"><small>Nomor berikutnya ${nsYear === "semua" ? cy : nsYear}</small><b>${pad3(nsNext(null, nsYear === "semua" ? cy : +nsYear))}</b><span>${inY.length} surat · semua jenis</span></div>` + NS_JENIS.map(j => `<button type="button" class="nsst ${J === j ? "on" : ""}" data-nsj="${esc(j)}"><small>${esc(j)}</small><b>${cnt[j]}</b><span>${cnt[j] ? "terakhir " + pad3(Math.max(...inY.filter(x => x.jenis === j).map(x => parseInt(String(x.no), 10) || 0))) : "belum ada"}</span></button>`).join("");
  const list = inY.filter(x => (!J || x.jenis === J) && (!toks.length || toks.every(t => acNorm([nsNomor(x), x.perihal, x.tujuan, x.ket, x.kode, x.jenis, x.tgl].join(" ")).includes(t))));
  // nomor yang dicatat massal → satu baris
  nsGroups = new Map();
  for (const x of list){ const k = x.batch ? "b:" + nsYearOf(x) + ":" + x.batch : "s:" + x._id; const g0 = nsGroups.get(k); if (g0) g0.push(x); else nsGroups.set(k, [x]); }
  for (const g of nsGroups.values()) g.sort((a, b) => a.no - b.no);
  const groups = [...nsGroups.entries()].sort((a, b) => (nsYearOf(b[1][0]) || 0) - (nsYearOf(a[1][0]) || 0) || b[1][b[1].length - 1].no - a[1][a[1].length - 1].no);
  const KM = kodeMap();
  $("#nsTbl tbody").innerHTML = groups.map(([k, g]) => { const x = g[0], z = g[g.length - 1], many = g.length > 1, on = g.every(y => nsSel.has(y._id));
    return `<tr data-nsg="${esc(k)}" class="${on ? "on" : ""}"><td><input type="checkbox" class="nsck" ${on ? "checked" : ""}></td>
    <td class="no"><b>${many ? `${pad3(x.no)}–${pad3(z.no)}` : pad3(x.no)}</b><div class="lsub">${nsYearOf(x) || ""}${many ? ` · <b>${g.length} nomor</b>` : ""}</div></td>
    <td><span class="nsnum">${esc(nsNomor(x))}</span>${many ? `<div class="nsnum" style="font-weight:400"><span class="muted">s.d.</span> ${esc(nsNomor(z))}</div>` : ""}<div class="lsub">${esc(x.tgl)}</div></td>
    <td><span class="tag nsj-${NS_JENIS.indexOf(x.jenis)}">${esc(x.jenis)}</span>${many ? `<div class="lsub">dicatat massal</div>` : ""}</td>
    <td><div class="lt-title" data-nsa="edit">${esc(x.perihal)}</div></td>
    <td><b style="font-size:13px">${esc(x.kode)}</b><div class="lsub one" title="${esc(KM[x.kode]?.d || "")}">${esc(KM[x.kode]?.d || "")}</div></td>
    <td class="acts"><button class="btn sm" data-nsa="copy" title="Salin nomor">Salin</button> <button class="ib" data-nsa="edit" title="Edit">${IC.edit}</button><button class="ib" data-nsa="dup" title="Duplikat — pakai data ini untuk nomor baru">${IC.dup}</button><button class="ib del" data-nsa="del" title="Hapus">${IC.del}</button></td></tr>`; }).join("")
    || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">${suratDB.length ? "Tidak ada nomor surat yang cocok." : "Belum ada nomor surat. Isi formulir di atas lalu Simpan nomor."}</td></tr>`;
  const seen: Record<string, 1> = {}, dups = new Set(); for (const x of inY){ const k = nsYearOf(x) + "|" + parseInt(String(x.no), 10); if (seen[k]) dups.add(k); seen[k] = 1; }
  $("#nsInfo").innerHTML = (list.length ? `${groups.length} baris · ${list.length} nomor surat ditampilkan` : "") + (dups.size ? ` · <span class="bad">${dups.size} nomor urut dipakai lebih dari satu surat — ubah salah satunya</span>` : "");
  nsSelUI();
}
var nsGroups = new Map<string, Surat[]>(), nsSel = new Set<string>(), nsEditBatch: string | null = null;
function nsSelUI(): void {
  for (const id of [...nsSel]) if (!suratDB.some(x => x._id === id)) nsSel.delete(id);
  const b = $("#nsDelSel"); b.hidden = !nsSel.size; b.textContent = `Hapus terpilih (${nsSel.size} nomor)`;
  const all = [...nsGroups.values()].flat(); $("#nsAll").checked = all.length > 0 && all.every(x => nsSel.has(x._id));
}
$("#nsAll").addEventListener("change", e => { for (const x of [...nsGroups.values()].flat()) tg(e).checked ? nsSel.add(x._id) : nsSel.delete(x._id); renderSurat(); });
$("#nsDelSel").onclick = () => {
  const xs = suratDB.filter(x => nsSel.has(x._id)); if (!xs.length) return;
  if (!confirm(`Hapus ${xs.length} nomor surat terpilih?\n\n${xs.slice(0, 6).map(nsNomor).join("\n")}${xs.length > 6 ? "\n…" : ""}\n\nNomor yang dihapus akan kosong di urutan bila bukan nomor terakhir.`)) return;
  suratDB = suratDB.filter(x => !nsSel.has(x._id)); if (nsEdit && nsSel.has(nsEdit)) nsReset(); nsSel.clear();
  persistSurat(); renderSurat(); nsAutoNo(true); nsPreview(); toast(`${xs.length} nomor surat dihapus.`);
};
$("#nsQ").addEventListener("input", debounce(() => renderSurat(), 150));
$("#nsYear").addEventListener("change", e => { nsYear = tg(e).value; renderSurat(); });
$("#nsJenisF").addEventListener("change", () => renderSurat());
$("#nsStats").addEventListener("click", e => { const b = tg(e).closest<HTMLInputElement>("[data-nsj]"); if (!b) return; $("#nsJenisF").value = $("#nsJenisF").value === b.dataset.nsj ? "" : b.dataset.nsj ?? ""; renderSurat(); });
$("#nsTbl").addEventListener("click", async e => {
  const tr = tg(e).closest<HTMLInputElement>("tr[data-nsg]"); if (!tr) return;
  const g = nsGroups.get(tr.dataset.nsg ?? ""); if (!g) return;
  const x = g[0], z = g[g.length - 1], many = g.length > 1, rangeTxt = many ? `${nsNomor(x)} s.d. ${nsNomor(z)}` : nsNomor(x);
  if (tg(e).classList.contains("nsck")){ g.forEach(y => tg(e).checked ? nsSel.add(y._id) : nsSel.delete(y._id)); tr.classList.toggle("on", tg(e).checked); nsSelUI(); return; }
  const a = tg(e).closest<HTMLInputElement>("[data-nsa]")?.dataset.nsa; if (!a) return;
  if (a === "copy"){ try{ await navigator.clipboard.writeText(rangeTxt); toast("Disalin: " + rangeTxt); }catch(err){ toast(rangeTxt); } }
  if (a === "edit"){
    nsEdit = x._id; nsEditBatch = many ? x.batch ?? null : null;
    nsIn("jenis").value = x.jenis; nsIn("sifat").value = x.sifat == null ? "B" : x.sifat; nsIn("tgl").value = x.tgl; nsIn("kode").value = x.kode; nsKodeMode(x.kodeLain || !kodeMap()[x.kode]);
    nsIn("no").value = String(x.no); nsIn("perihal").value = x.perihal;
    $("#nsEndWrap").hidden = !many; nsIn("noEnd").value = many ? String(z.no) : ""; nsIn("no").readOnly = nsIn("noEnd").readOnly = many;
    _nsAutoNo = false; $("#nsSave").textContent = many ? `Simpan perubahan (${g.length} nomor)` : "Simpan perubahan"; $("#nsCancel").hidden = false; $("#nsFlag").hidden = false; $("#nsFlag").textContent = "Mengubah " + rangeTxt; nsPreview(); window.scrollTo({ top: 0, behavior: "smooth" }); }
  if (a === "dup"){
    nsReset(); nsIn("jenis").value = x.jenis; nsIn("sifat").value = x.sifat == null ? "B" : x.sifat; nsIn("kode").value = x.kode; nsKodeMode(x.kodeLain || !kodeMap()[x.kode]);
    nsIn("perihal").value = x.perihal; nsAutoNo(true); if (many) nsIn("noEnd").value = String(parseInt(nsIn("no").value, 10) + g.length - 1);
    $("#nsCancel").hidden = false; $("#nsFlag").hidden = false; $("#nsFlag").textContent = "Salinan dari " + rangeTxt;
    nsPreview(); window.scrollTo({ top: 0, behavior: "smooth" }); nsIn("perihal").focus(); nsIn("perihal").select();
    toast(`Salinan dibuat dengan nomor baru${many ? ` (${g.length} nomor)` : ""} — ubah perihal lalu simpan.`);
  }
  if (a === "del"){
    const last = nsNext(null, nsYearOf(z)) - 1 === parseInt(String(z.no), 10);
    if (!confirm(`Hapus ${many ? `${g.length} nomor (${rangeTxt})` : "nomor " + rangeTxt}?` + (last ? "" : "\n\nBukan nomor terakhir — akan ada nomor kosong di urutan."))) return;
    const del = new Set(g.map(y => y._id)); suratDB = suratDB.filter(s0 => !del.has(s0._id)); g.forEach(y => nsSel.delete(y._id));
    persistSurat(); if (nsEdit && del.has(nsEdit)) nsReset(); renderSurat(); nsAutoNo(true); nsPreview();
  }
});
/* ---------- format nomor ---------- */
function renderNsFmt(): void {
  $("#nsFmtRows").innerHTML = NS_JENIS.map(j => `<div class="c6"><label>${esc(j)}</label><input data-nsf="${esc(j)}" value="${esc(nsFmt[j])}"></div>`).join("");
}
$("#nsFmtRows").addEventListener("input", e => { const j = tg(e).dataset.nsf; if (!j) return; nsFmt[j] = tg(e).value.trim() || NS_FMT0[j]; persistSurat(); nsPreview(); renderSurat(); });
$("#nsFmtReset").onclick = () => { nsFmt = { ...NS_FMT0 }; persistSurat(); renderNsFmt(); nsPreview(); renderSurat(); toast("Format nomor kembali ke bawaan."); };
/* ---------- ekspor & impor Excel ---------- */
const NS_HDR = ["Jenis Surat", "Sifat", "No Urut", "Nomor Surat", "Tanggal", "Tahun", "Kode Klasifikasi", "Uraian Kode", "Perihal"];
$("#nsExp").onclick = () => {
  const list = suratDB.filter(x => nsYear === "semua" || String(nsYearOf(x)) === nsYear).sort((a, b) => (nsYearOf(a) || 0) - (nsYearOf(b) || 0) || a.no - b.no);
  if (!list.length) return toast("Belum ada nomor surat untuk diekspor.");
  const KM = kodeMap(), ws = XLSX.utils.aoa_to_sheet([NS_HDR, ...list.map(x => [x.jenis, x.sifat == null ? "B" : x.sifat, x.no, nsNomor(x), x.tgl, nsYearOf(x), x.kode, KM[x.kode]?.d || "", x.perihal])]);
  ws["!cols"] = [18, 6, 8, 30, 18, 7, 12, 34, 60].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Nomor Surat");
  XLSX.writeFile(wb, `Nomor Surat ${nsYear === "semua" ? "semua tahun" : nsYear} (${list.length}).xlsx`); toast(`${list.length} nomor surat diekspor.`);
};
$("#nsImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{
    const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true });
    let rows: unknown[][] | null = null, H: string[] = [];
    for (const sn of wb.SheetNames){ const a = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sn], { header: 1, defval: "", raw: true }); const hi = a.findIndex(r => r.some(c => /^perihal/i.test(String(c).trim()))); if (hi >= 0){ H = a[hi].map(c => String(c).trim().toLowerCase()); rows = a.slice(hi + 1); break; } }
    if (!rows) return toast("Kolom 'Perihal' tidak ditemukan. Pakai file hasil Ekspor.");
    const ix = (re: RegExp) => H.findIndex(h => re.test(h)), cJ = ix(/^jenis/), cN = ix(/^no urut/), cNs = ix(/^nomor surat/), cT = ix(/^tanggal/), cK = ix(/^kode/), cP = ix(/^perihal/), cU = ix(/^tujuan|penerima/), cX = ix(/^keterangan/), cS = ix(/^sifat/);
    const cell = (r: unknown[], i: number): string => { const v = i < 0 ? "" : r[i]; return v instanceof Date ? fmtDate(new Date(v.getTime() + 12 * 36e5)) : String(v ?? "").trim(); };
    let add = 0, upd = 0, bad = 0;
    for (const r of rows){
      const per = cell(r, cP); if (!per) continue;
      const jr = cell(r, cJ), jenis = NS_JENIS.find(j => acNorm(j) === acNorm(jr)) || NS_JENIS.find(j => acNorm(jr) && acNorm(j).includes(acNorm(jr))) || "Surat Keluar";
      let no = parseInt(cell(r, cN), 10); if (!no){ const m = cell(r, cNs).match(/\d+/); no = m ? +m[0] : 0; }
      const d = parseTgl(cell(r, cT)); if (!no || !d){ bad++; continue; }
      const sf = (cS >= 0 ? cell(r, cS) : (cell(r, cNs).match(/^([A-Z]{1,4})-/) || [])[1] || (cell(r, cNs) && /^\d/.test(cell(r, cNs)) ? "" : "B")).toUpperCase();
      const x: Surat = { _id: newId(), jenis, sifat: sf.replace(/[^A-Z]/g, "").slice(0, 4), no, tgl: fmtDate(d), tahun: d.getFullYear(), kode: cell(r, cK).toUpperCase(), perihal: per, tujuan: cell(r, cU), ket: cell(r, cX) };
      const i = suratDB.findIndex(s0 => nsYearOf(s0) === x.tahun && parseInt(String(s0.no), 10) === x.no);
      if (i >= 0){ x._id = suratDB[i]._id; suratDB[i] = x; upd++; } else { suratDB.push(x); add++; }
    }
    persistSurat(); renderSurat(); nsAutoNo(true); nsPreview();
    toast(`Impor selesai: ${add} ditambahkan, ${upd} diperbarui` + (bad ? `, ${bad} baris dilewati (nomor/tanggal kosong)` : "") + ".");
  }catch(err){ console.error(err); toast("Gagal membaca file: " + (err as Error).message); }
});

