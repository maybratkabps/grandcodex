/* ================= ANGGARAN: RPD · CATAT TUP · PERMINTAAN REVISI (dari detil POK) ================= */
/* RPD, TUP & Revisi disimpan per tahun anggaran (st.<nama>.<tahun>); tahun dipilih sendiri, terpisah dari POK aktif */
var rpdDB: RpdDB = {}, tupDB: TupDB = {}, upDB: TupDB = {}, revDB: Revisi[] = [], rpdKet: RpdKetDB = {}, rabDB: RabDoc[] = [], rpdFinDB: RpdFinDB = {}, rpdSup: RpdSupDB = {};
const ANG_N = ["rpd", "rpdKet", "tup", "revisi", "rab", "rpdFin", "up", "rpdSup"] as const;
type AngName = typeof ANG_N[number];
const angK = (n: AngName, y: string): string => `st.${n}.${y}`;
{ const y0 = String(pokDB.meta?.tahun || pokYear);   // migrasi data lama (tanpa tahun)
  for (const n of ANG_N){ const old = LS.get<unknown>("st." + n, null); if (old != null){ if (LS.get<unknown>(angK(n, y0), null) == null) LS.set(angK(n, y0), old); LS.del("st." + n); } } }
let angYear = String(LS.get("st.angYear", "") || pokYear);
function angLoad(y: string): void { rpdDB = LS.get<RpdDB>(angK("rpd", y), {}); rpdKet = LS.get<RpdKetDB>(angK("rpdKet", y), {}); tupDB = LS.get<TupDB>(angK("tup", y), {}); upDB = LS.get<TupDB>(angK("up", y), {}); rpdSup = LS.get<RpdSupDB>(angK("rpdSup", y), {}); if (rpdSupMigrate()) LS.set(angK("rpdSup", y), rpdSup); revDB = LS.get<Revisi[]>(angK("revisi", y), []); rabDB = LS.get<RabDoc[]>(angK("rab", y), []); rpdFinDB = LS.get<RpdFinDB>(angK("rpdFin", y), {}); }
angLoad(angYear);
const persistAng = (): void => { LS.set(angK("rpd", angYear), rpdDB); LS.set(angK("rpdKet", angYear), rpdKet); LS.set(angK("tup", angYear), tupDB); LS.set(angK("up", angYear), upDB); LS.set(angK("rpdSup", angYear), rpdSup); LS.set(angK("revisi", angYear), revDB); LS.set(angK("rab", angYear), rabDB); LS.set(angK("rpdFin", angYear), rpdFinDB); };
const angPok = (): Pok => pokGet(angYear) || { meta: { tahun: angYear }, akun: [] };
const angYearsOpt = (): string[] => { const cy = new Date().getFullYear(); return [...new Set([...pokYears(), angYear, String(cy), String(cy + 1)])].sort(); };
function angRefresh(): void { angYearUI(); const v = document.querySelector(".view.on")?.id; if (v === "v-rpd") renderRpd(); if (v === "v-tup") renderTup(); if (v === "v-revisi") renderRev(); if (v === "v-rab") renderRab(); if (v === "v-rablist") renderRabList(); }
function angSetYear(y0: string | number, quiet?: boolean): void { const y = String(y0); if (y === angYear) return; angYear = y; LS.set("st.angYear", y); angLoad(y); _detC = null; rpdOpen.clear(); angRefresh(); if (!quiet) toast(`Tahun anggaran RPD/TUP/Revisi: ${y}`); }
function angYearUI(): void {
  const opts = angYearsOpt().map(y => `<option value="${y}" ${y === angYear ? "selected" : ""}>T.A. ${y}${pokGet(y) ? (pokGet(y)?.meta?.draft ? " (POK rancangan)" : "") : " (POK belum ada)"}${y === pokYear ? " · POK aktif" : ""}</option>`).join("");
  $$(".angYear").forEach(el => el.innerHTML = opts);
  const no = !pokGet(angYear), base = pokYears().filter(y => y !== angYear).at(-1);
  $$(".angNoPok").forEach(el => { el.hidden = !no; el.innerHTML = no ? `⚠ <b>POK T.A. ${angYear} belum ada.</b> Unggah POK ${angYear} di menu Database › POK (POK aktif tidak berubah)${base ? `, atau mulai dulu dengan salinan POK ${base} sebagai rancangan. <button class="btn sm" type="button" data-angcopy="${base}">Pakai POK ${base} sebagai rancangan ${angYear}</button>` : "."} <button class="btn sm" type="button" data-anggo="1">Buka Database POK</button>` : ""; });
}
document.addEventListener("change", e => { if (tg(e).classList?.contains("angYear")) angSetYear(tg(e).value); });
document.addEventListener("click", e => {
  const c = tg(e).closest<HTMLInputElement>("[data-angcopy]")?.dataset.angcopy;
  if (c){ const src = pokGet(c); if (!src) return; const d = clone(src); d.meta = { ...(d.meta || {}), tahun: angYear, tanggal: "", draft: true, dasar: c }; pokSave(angYear, d); _dataVer++; angRefresh(); toast(`POK ${c} disalin sebagai rancangan T.A. ${angYear}. Ganti dengan POK ${angYear} asli saat sudah terbit.`); return; }
  if (tg(e).closest<HTMLInputElement>("[data-anggo]")) show("pok");
});
const BLN_S = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"], TWN = ["TW I", "TW II", "TW III", "TW IV"];
/* semua detil POK: kunci = MAK + nama detil (tetap walau POK diimpor ulang) */
let _detC: Detil[] | null = null, _detV = -1, _detY: string | null = null;
/* kunci detil (MAK + nama) untuk sebuah POK — sama dengan pokDetil() */
interface DetKey { mak: string; i: number; j: number; key: string }
function detKeysOf(pok: Pok | null): DetKey[] {
  const out: DetKey[] = [], seen: Record<string, number> = {};
  for (const a of (pok && pok.akun) || []) a.items.forEach((it, i) => { const u = String(it.u || "").trim() || a.kompNama; let key = a.mak + "#" + acNorm(u); seen[key] = (seen[key] || 0) + 1; if (seen[key] > 1) key += "#" + seen[key]; out.push({ mak: a.mak, i, j: num(it.j), key }); });
  return out;
}
/* POK tahun y diganti (impor ulang): pindahkan isian RPD/TUP/Revisi dari kunci lama ke kunci baru
   (detil dipasangkan per MAK menurut urutan bila jumlahnya sama, selain itu menurut nilai) */
function angRemap(y: string, oldP: Pok | null, newP: Pok | null): number {
  if (!oldP || !newP) return 0;
  const O = detKeysOf(oldP), N = detKeysOf(newP), byMak = (m: string) => N.filter(x => x.mak === m), map: Record<string, string> = {};
  for (const mk of [...new Set(O.map(x => x.mak))]){
    const os = O.filter(x => x.mak === mk), ns = byMak(mk); if (!ns.length) continue;
    if (os.length === ns.length) os.forEach((o, i) => { if (o.key !== ns[i].key) map[o.key] = ns[i].key; });
    else { const used = new Set<string>(); for (const o of os){ if (ns.some(n => n.key === o.key)){ used.add(o.key); continue; } const n = ns.find(n => !used.has(n.key) && n.j === o.j && !os.some(x => x.key === n.key)); if (n){ used.add(n.key); map[o.key] = n.key; } } }
  }
  const ks = Object.keys(map); if (!ks.length) return 0;
  const mv = <T extends Record<string, unknown>>(obj: T | null | undefined): T | null | undefined => { if (!obj) return obj; const o: Record<string, unknown> = obj; for (const k of ks) if (k in o && !(map[k] in o)){ o[map[k]] = o[k]; delete o[k]; } return obj; };
  const rpd = mv(LS.get<RpdDB | null>(angK("rpd", y), null)), ket = mv(LS.get<RpdKetDB | null>(angK("rpdKet", y), null)), tup = LS.get<TupDB | null>(angK("tup", y), null), rev = LS.get<Revisi[] | null>(angK("revisi", y), null);
  if (tup) for (const t of Object.values(tup)){ mv(t.val); mv(t.nama); mv(t.kt); if (t.add) t.add = t.add.map((k: string) => map[k] || k); if (t.excl) t.excl = t.excl.map((k: string) => map[k] || k); }
  if (Array.isArray(rev)) rev.forEach(x => { if (map[x.key]) x.key = map[x.key]; });
  const rab = LS.get<RabDoc[] | null>(angK("rab", y), null);
  if (Array.isArray(rab)){ for (const d of rab){ for (const l of d.items || []) if (map[l.key]) l.key = map[l.key]; for (const t of d.trips || []) if (map[t.key]) t.key = map[t.key]; for (const r of d.rpdIn || []) if (map[r.key]) r.key = map[r.key]; } LS.set(angK("rab", y), rab); }
  if (rpd) LS.set(angK("rpd", y), rpd); if (ket) LS.set(angK("rpdKet", y), ket); if (tup) LS.set(angK("tup", y), tup); if (rev) LS.set(angK("revisi", y), rev);
  if (y === angYear) angLoad(y);
  return ks.length;
}
function pokDetil(): Detil[] {
  if (_detC && _detV === _dataVer && _detY === angYear) return _detC;
  const out: Detil[] = [], seen: Record<string, number> = {};
  for (const a of angPok().akun) a.items.forEach(it => { const u = String(it.u || "").trim() || a.kompNama; let key = a.mak + "#" + acNorm(u); seen[key] = (seen[key] || 0) + 1; if (seen[key] > 1) key += "#" + seen[key];
    out.push({ key, a, u, j: num(it.j), blokir: !!it.b, v: it.v, s: it.s, h: it.h }); });
  _detC = out; _detV = _dataVer; _detY = angYear; return out;
}
const detMap = (): Record<string, Detil> => Object.fromEntries(pokDetil().map(d => [d.key, d]));
const detLabel = (d: Detil): string => `${d.u} — ${d.a.mak}`;
const rpdOf = (k: string): number[] => rpdDB[k] || (rpdDB[k] = Array<number>(12).fill(0));
const rpdSum = (k: string, from = 0, to = 12): number => (rpdDB[k] || []).slice(from, to).reduce((s, v) => s + num(v), 0);
const tw = (k: string, t: number): number => rpdSum(k, t * 3, t * 3 + 3);
function detilAc(q: string): AcItem[] {   // sumber autocomplete "detil"
  const toks: string[] = acNorm(q).split(/\s+/).filter(Boolean), res: AcItem[] = [];
  const noAk51 = !!AC.el?.closest("#tupTbl");
  for (const d of pokDetil()){ if (noAk51 && /^51/.test(String(d.a.akun))) continue; const h = acNorm(d.u + " " + d.a.mak + " " + d.a.roNama + " " + d.a.kompNama + " " + d.a.nama);
    if (toks.length && !toks.every(t => h.includes(t))) continue;
    res.push({ v: detLabel(d), key: d.key, html: `<span class="d"><b>${acHi(d.u, toks)}</b><small>${esc(d.a.mak)} · ${esc(d.a.nama)} · pagu Rp ${rupiah(d.j)}</small></span>`, score: 0 });
    if (res.length > 150) break; }
  return res;
}
const keyFromInput = (el: HTMLInputElement): string | null => { const k0 = el.dataset.key; if (k0 && detMap()[k0] && detLabel(detMap()[k0]) === el.value) return k0; const d = pokDetil().find(x => detLabel(x) === el.value.trim()); return d ? d.key : null; };

/* ================= RPD ================= */
let rpdOpen = new Set<string>(), rpdBlk = new Set<string>(), rpdTw: number = LS.get("st.rpdTw", Math.floor(new Date().getMonth() / 3)), rpdRoSel: string = LS.get("st.rpdRo", "");
// rpdKet: keterangan per detil per triwulan { key: ["", "", "", ""] } — dimuat per tahun oleh angLoad()
const rpdKetOf = (k: string): string[] => rpdKet[k] || (rpdKet[k] = ["", "", "", ""]);
/* supplier RPD: per detil per BULAN; dipilih lewat pop-up — boleh beberapa supplier, RAB dan Surat Tugas sekaligus.
   Surat tugas tertaut dicatat sebagai nama petugasnya, tiap nama satu kali. Data lama (per triwulan) disalin ke tiga bulan triwulannya. */
const rpdSupRefs = (x?: RpdSup): string[] => !x ? [] : x.refs ? x.refs : x.ref ? [x.ref] : [];
function rpdSupMigrate(): boolean {
  let ch = false;
  for (const k of Object.keys(rpdSup)){ const a = rpdSup[k]; if (!Array.isArray(a) || a.length > 4) continue;
    // (dipanggil dari angLoad saat modul dimuat → tidak boleh memakai const yang dideklarasikan di bawahnya)
    const n: RpdSup[] = []; for (let m = 0; m < 12; m++){ const o = a[Math.floor(m / 3)], refs = o ? (o.refs || (o.ref ? [o.ref] : [])) : []; n.push(o && o.t ? (refs.length ? { t: o.t, refs: refs.slice() } : { t: o.t, s: [o.t] }) : { t: "" }); }
    rpdSup[k] = n; ch = true; }
  return ch;
}
const rpdSupOf = (k: string): RpdSup[] => { const a = rpdSup[k] || (rpdSup[k] = []); for (let i = 0; i < 12; i++) a[i] ||= { t: "" }; return a; };
const rpdSupGet = (k: string, m: number): RpdSup | undefined => { const x = (rpdSup[k] || [])[m]; return x && x.t ? x : undefined; };
const uniqNames = (xs: string[]): string[] => { const seen = new Set<string>(), out: string[] = []; for (const x of xs){ const t = String(x || "").trim(), key = acNorm(t); if (!t || seen.has(key)) continue; seen.add(key); out.push(t); } return out; };
/** supplier satu triwulan (gabungan tiga bulannya, tanpa duplikat) */
const rpdSupTw = (k: string, t: number): string => uniqNames([0, 1, 2].flatMap(j => (rpdSupGet(k, t * 3 + j)?.t || "").split(/\s*,\s*/))).join(", ");
/** nama petugas surat tugas (pelaksana + anggota), tanpa gelar */
const stNames = (r: StRecord): string[] => { const P = pegMap(); return personCodes(r, P).map(c => String(P[c]?.nama || "").split(",")[0].trim()).filter(Boolean); };
function rpdSupText(sup: string[], refs: string[]): string {
  const rab = refs.filter(x => x.startsWith("rab:")).map(x => rabDB.find(d => d._id === x.slice(4))?.nama || "");
  const st = refs.filter(x => x.startsWith("st:")).flatMap(x => { const r = records.find(y => y._id === x.slice(3)); return r ? stNames(r) : []; });
  return uniqNames([...sup, ...rab, ...st]).join(", ");
}
function rpdSupGo(ref?: string): void { if (!ref) return; const [ty, id] = ref.split(":");
  if (ty === "rab"){ if (!rabDB.some(x => x._id === id)) return toast("RAB yang ditautkan sudah tidak ada.", "warn"); rabCur = id; LS.set("st.rabCur", id); $("#rabHead").dataset.new = ""; show("rab"); return; }
  if (ty === "st"){ const r = records.find(x => x._id === id); if (!r) return toast("Surat tugas yang ditautkan sudah tidak ada.", "warn"); openPreview([r], `Surat tugas ${compute(r).NOMOR_ST} (tautan supplier RPD) — hanya lihat`); } }
/* supplier hanya berisi NAMA: tautan surat tugas dicatat sebagai nama petugasnya, bukan nomor surat.
   Isian lama ("ST B-…/2026 — Nama") dirapikan saat RPD dibuka. */
const rpdSupNoSt = (t: string): string => uniqNames(String(t || "").split(/\s*,\s*/).map(x => x.replace(/^ST\s+\S+\s*[—–-]\s*/i, "").replace(/^ST\s+B-\S+$/i, ""))).join(", ");
function rpdSupNamesOnly(): void {
  let ch = false;
  for (const a of Object.values(rpdSup)) for (const x of a || []){ if (!x || !x.t) continue;
    const refs = rpdSupRefs(x), want = refs.some(r => r.startsWith("st:")) ? (rpdSupText(x.s || [], refs) || rpdSupNoSt(x.t)) : rpdSupNoSt(x.t);
    if (want !== x.t){ x.t = want; if (x.ref){ x.refs = refs; delete x.ref; } ch = true; } }
  if (ch) persistAng();
}
/** buka semua surat tugas yang tertaut ke supplier bulan ini */
function rpdSupGoSt(x?: RpdSup): void { const rs = rpdSupRefs(x).filter(r => r.startsWith("st:")).map(r => records.find(y => y._id === r.slice(3))).filter((r): r is StRecord => !!r);
  if (!rs.length) return toast("Surat tugas yang ditautkan sudah tidak ada.", "warn"); openPreview(rs, `${rs.length} surat tugas (tautan supplier RPD) — hanya lihat`); }
/** supplier yang pernah dicatat (RPD, Catat TUP, Catat UP) — pilihan di pop-up */
function rpdSupKnown(): string[] {
  const xs: string[] = [];
  for (const a of Object.values(rpdSup)) for (const x of a || []) if (x) xs.push(...(x.s || (rpdSupRefs(x).length ? [] : [x.t])));
  for (const db of [tupDB, upDB]) for (const mo of Object.values(db)) for (const f of Object.values(mo?.f || {})) if (f && typeof f.sup === "string") xs.push(f.sup);
  return uniqNames(xs).sort((a, b) => a.localeCompare(b));
}
/* ---- pop-up pilih supplier & tautan (multi-pilih) ---- */
let rsu: { k: string; m: number; st: Set<string>; rab: Set<string>; sup: string[]; extra: string[] } | null = null;
function rpdSupOpen(k: string, m: number): void {
  const x = (rpdSup[k] || [])[m], refs = rpdSupRefs(x), d = detMap()[k];
  rsu = { k, m, st: new Set(refs.filter(r => r.startsWith("st:")).map(r => r.slice(3))), rab: new Set(refs.filter(r => r.startsWith("rab:")).map(r => r.slice(4))), sup: (x?.s || (x?.t && !refs.length ? [x.t] : [])).slice(), extra: [] };
  $("#rsuH").innerHTML = `Supplier &amp; tautan · ${esc(BULAN[m])} ${esc(angYear)} <span class="muted" style="font-weight:400;font-size:13px">— ${esc(String(d?.u || "").slice(0, 70))}</span>`;
  $("#rsuQ").value = ""; $("#rsuNew").value = ""; rpdSupRender(); $<HTMLDialogElement>("#dRpdSup").showModal(); $("#rsuQ").focus();
}
function rpdSupRender(): void {
  if (!rsu) return; const R = rsu, toks = acNorm($("#rsuQ").value.trim()).split(/\s+/).filter(Boolean), hit = (h: string): boolean => !toks.length || toks.every(t => acNorm(h).includes(t));
  const mak = normMak(detMap()[R.k]?.a.mak || ""), same = (r: StRecord): boolean => !!mak && normMak(r.MAK) === mak;
  const rs = [...records].sort(byYearNo).reverse().filter(r => R.st.has(r._id ?? "") || (toks.length ? toks.every(t => hayOf(r).includes(t)) : true))
    .sort((a, b) => +R.st.has(b._id ?? "") - +R.st.has(a._id ?? "") || +same(b) - +same(a));
  $("#rsuSt").innerHTML = rs.slice(0, 150).map(r => { const F = computeC(r), on = R.st.has(r._id ?? "");
    return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="st" value="${esc(r._id)}" ${on ? "checked" : ""}><span><b>${esc(stNames(r).join(", ") || "(tanpa petugas)")}</b>${same(r) ? ` <span class="tag ok">MAK sama</span>` : ""}<small>${esc(String(F.MAKSUD__TUJUAN || "").slice(0, 70))} · ${esc(F.TGL_PERGI || "")} · ${esc(F.NOMOR_ST)}</small></span></label>`; }).join("")
    + (rs.length > 150 ? `<div class="muted" style="font-size:12px;padding:6px">${rs.length - 150} surat lain — persempit dengan kolom cari.</div>` : "") || `<div class="muted" style="padding:10px;font-size:12.5px">Tidak ada surat tugas yang cocok.</div>`;
  const sups = uniqNames([...R.sup, ...R.extra, ...rpdSupKnown()]), selSup = new Set(R.sup.map(acNorm));
  $("#rsuSup").innerHTML = [...rabDB].reverse().filter(d => R.rab.has(d._id) || hit(d.nama + " " + d.ro + " rab")).map(d => { const on = R.rab.has(d._id);
      return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="rab" value="${esc(d._id)}" ${on ? "checked" : ""}><span><b><span class="tag">RAB</span> ${esc(d.nama)}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></span></label>`; }).join("")
    + sups.filter(n => selSup.has(acNorm(n)) || hit(n)).map(n => { const on = selSup.has(acNorm(n)); return `<label class="rsu-it${on ? " on" : ""}"><input type="checkbox" data-rsu="sup" value="${esc(n)}" ${on ? "checked" : ""}><span><b>${esc(n)}</b></span></label>`; }).join("")
    || `<div class="muted" style="padding:10px;font-size:12.5px">Belum ada supplier — ketik nama di bawah lalu Tambah.</div>`;
  $("#rsuNSt").textContent = R.st.size + " dipilih"; $("#rsuNSup").textContent = (R.sup.length + R.rab.size) + " dipilih";
  const refs = [...[...R.rab].map(i => "rab:" + i), ...[...R.st].map(i => "st:" + i)], t = rpdSupText(R.sup, refs);
  $("#rsuOut").innerHTML = t ? `Tercatat sebagai: <b>${esc(t)}</b>${R.st.size ? ` <span class="muted">— nama petugas dari ${R.st.size} surat tugas, tiap nama satu kali</span>` : ""}` : `<span class="muted">Belum ada yang dipilih.</span>`;
}
$("#dRpdSup").addEventListener("change", e => { const t = tg(e), ty = t.dataset.rsu; if (!rsu || !ty) return;
  if (ty === "st") t.checked ? rsu.st.add(t.value) : rsu.st.delete(t.value);
  else if (ty === "rab") t.checked ? rsu.rab.add(t.value) : rsu.rab.delete(t.value);
  else { rsu.sup = rsu.sup.filter(n => acNorm(n) !== acNorm(t.value)); if (t.checked) rsu.sup.push(t.value); }
  rpdSupRender(); });
$("#rsuQ").addEventListener("input", debounce(() => rpdSupRender(), 120));
const rsuAddNew = (): void => { const v = $("#rsuNew").value.trim(); if (!rsu || !v) return; if (!rsu.sup.some(n => acNorm(n) === acNorm(v))) rsu.sup.push(v); rsu.extra.push(v); $("#rsuNew").value = ""; rpdSupRender(); $("#rsuNew").focus(); };
$("#rsuAdd").onclick = rsuAddNew;
$("#rsuNew").addEventListener("keydown", (e: KeyboardEvent) => { if (e.key === "Enter"){ e.preventDefault(); rsuAddNew(); } });
$("#rsuCancel").onclick = () => { rsu = null; $<HTMLDialogElement>("#dRpdSup").close(); };
$("#rsuClr").onclick = () => { if (!rsu) return; rsu.st.clear(); rsu.rab.clear(); rsu.sup = []; rpdSupRender(); };
$("#rsuOk").onclick = () => { if (!rsu) return; const R = rsu, x = rpdSupOf(R.k)[R.m], refs = [...[...R.rab].map(i => "rab:" + i), ...[...R.st].map(i => "st:" + i)];
  x.t = rpdSupText(R.sup, refs); delete x.ref; if (refs.length) x.refs = refs; else delete x.refs; if (R.sup.length) x.s = R.sup.slice(); else delete x.s;
  persistAng(); rsu = null; $<HTMLDialogElement>("#dRpdSup").close(); renderRpd(); toast(x.t ? `Supplier ${BULAN[R.m]} dicatat: ${x.t.slice(0, 80)}${x.t.length > 80 ? "…" : ""}` : `Supplier ${BULAN[R.m]} dikosongkan.`, "ok"); };
/* triwulan yang sudah lewat (menurut tanggal komputer) tidak bisa diisi lagi */
const rpdYear = (): number => +angYear || new Date().getFullYear();
function rpdLockTw(t: number): boolean { const now = new Date(), y = rpdYear(); return y < now.getFullYear() || (y === now.getFullYear() && t < Math.floor(now.getMonth() / 3)); }
const rpdFinM = (m: number): boolean => !!tupDB[m]?.fin || !!upDB[m]?.fin;
/** detil dasar TUP (tanpa akun 51) */
const rpdTupDet = (): Detil[] => pokDetil().filter(d => !/^51/.test(String(d.a.akun)));
/** Total Permintaan RPD Awal bulan m: nilai yang dikunci di RPD; bila belum dikunci → RPD sebelum finalisasi TUP (atau RPD saat ini) */
function rpdAwal(m: number): { total: number; locked: boolean; tgl: string } {
  const L = rpdFinDB[m]; if (L) return { total: L.total, locked: true, tgl: L.tgl };
  const prev = tupDB[m]?.fin?.prev || {}; let s = 0;
  for (const d of rpdTupDet()) s += d.key in prev ? num(prev[d.key]) : num((rpdDB[d.key] || [])[m]);
  return { total: s, locked: false, tgl: "" };
}
/* ---------- Finalisasi RPD: kunci / buka kunci Total Permintaan RPD Awal, per bulan ---------- */
const rpdCurTot = (m: number): number => rpdTupDet().reduce((s0, d) => s0 + num((rpdDB[d.key] || [])[m]), 0);
let rfSel = new Set<number>();
function rpdFinOpen(m0?: number): void {
  rfSel = new Set(m0 != null ? [m0] : [Math.min(11, Math.max(0, rpdTw * 3 + (new Date().getFullYear() === rpdYear() ? new Date().getMonth() % 3 : 0)))]);
  rpdFinRender(); $<HTMLDialogElement>("#dRpdFin").showModal();
}
function rpdFinRender(): void {
  $("#rfMonths").innerHTML = BULAN.map((b, m) => { const L = rpdFinDB[m], cur = rpdCurTot(m), on = rfSel.has(m);
    return `<button type="button" class="rfm ${L ? "lk" : ""} ${on ? "sel" : ""}" data-rfm="${m}" aria-pressed="${on}" title="Klik untuk memilih / batal memilih ${b}"><small>${on ? "☑" : "☐"} ${BLN_S[m]}</small><b>${rpShort(L ? L.total : cur).replace("Rp ", "")}</b><span>${L ? `🔒 dikunci ${esc(L.tgl)}` : "🔓 belum dikunci"}</span>${L && L.total !== cur ? `<span class="muted">RPD sekarang ${rpShort(cur).replace("Rp ", "")}</span>` : ""}</button>`; }).join("");
  const sel = [...rfSel].sort((a, b) => a - b), nL = sel.filter(m => rpdFinDB[m]).length, nU = sel.length - nL;
  $("#rfInfo").textContent = sel.length ? `Dipilih: ${sel.map(m => BLN_S[m]).join(", ")} — ${nU} belum dikunci, ${nL} sudah dikunci` : "Pilih bulan dulu (klik kotak bulan).";
  $<HTMLButtonElement>("#rfLock").disabled = !nU; $<HTMLButtonElement>("#rfUnlock").disabled = !nL;
  $("#rfLock").textContent = `🔒 Kunci ${nU || ""} bulan terpilih`.replace("  ", " "); $("#rfUnlock").textContent = `🔓 Buka kunci ${nL || ""} bulan terpilih`.replace("  ", " ");
}
/** kunci (lock=true) atau buka kunci bulan-bulan ms; satu konfirmasi */
function rpdFinSet(ms: number[], lock: boolean): boolean {
  const list = ms.filter(m => lock ? !rpdFinDB[m] : !!rpdFinDB[m]).sort((a, b) => a - b); if (!list.length) return false;
  const txt = list.map(m => `• ${BULAN[m]}: Rp ${rupiah(lock ? rpdCurTot(m) : rpdFinDB[m].total)}`).join("\n");
  if (!confirm(lock ? `Finalisasi RPD ${angYear} — kunci Total Permintaan RPD Awal (tanpa akun 51):\n\n${txt}\n\nIsian RPD tetap bisa diubah; yang dikunci hanya nilai total awal sebagai pembanding Catat TUP.` : `Buka kunci RPD awal ${angYear}:\n\n${txt}`)) return false;
  for (const m of list){
    if (!lock){ delete rpdFinDB[m]; continue; }
    const val: Record<string, number> = {}; let tot = 0; for (const d of rpdTupDet()){ const v = num((rpdDB[d.key] || [])[m]); if (v){ val[d.key] = v; tot += v; } }
    rpdFinDB[m] = { tgl: today(), total: tot, val };
  }
  persistAng(); toast(`${lock ? "RPD awal dikunci" : "Kunci RPD awal dibuka"}: ${list.map(m => BULAN[m]).join(", ")}.`, lock ? "ok" : "info"); return true;
}
$("#rpdFinBtn").onclick = () => rpdFinOpen();
$("#rfClose").onclick = () => { $<HTMLDialogElement>("#dRpdFin").close(); renderRpd(); };
$("#rfMonths").addEventListener("click", e => { const m = Number(tg(e).closest<HTMLElement>("[data-rfm]")?.dataset.rfm ?? -1); if (m < 0) return; rfSel.has(m) ? rfSel.delete(m) : rfSel.add(m); rpdFinRender(); });
$("#rfAll").onclick = () => { rfSel = rfSel.size === 12 ? new Set() : new Set([...Array(12).keys()]); rpdFinRender(); };
$("#rfLock").onclick = () => { if (rpdFinSet([...rfSel], true)) rpdFinRender(); };
$("#rfUnlock").onclick = () => { if (rpdFinSet([...rfSel], false)) rpdFinRender(); };
/* gembok di judul kolom bulan RPD: kunci / buka kunci bulan itu langsung */
$("#rpdTbl").addEventListener("click", e => { const b = tg(e).closest<HTMLElement>("[data-rfh]"); if (!b) return; e.stopPropagation(); const m = Number(b.dataset.rfh); if (rpdFinSet([m], !rpdFinDB[m])) renderRpd(); });
const rpdLockM = (m: number): boolean => rpdLockTw(Math.floor(m / 3)) || rpdFinM(m);
const rpdOpenM = (): number[] => [...Array(12).keys()].filter(m => !rpdLockM(m));
const roOf = (d: Detil): string => d.a.ro;
const roTitle = (n: string): string => cleanRoNama(n);
const fmtVol = (v: number | null | undefined): string => v == null ? "" : Number.isInteger(+v) ? (+v).toFixed(1) : String(v);
const volTxt = (d: { v?: number; s?: string; h?: number }): string => d.h != null && d.v != null ? `(${fmtVol(d.v)} ${esc(d.s || "")} @ ${rupiah(d.h)})` : "";
let rpdAkOpen = new Set<string>(), rpdAkAll = false, rpdHide0 = !!LS.get("st.rpdHide0", false);
function rpdScope(): Detil[] {   // detil dalam RO terpilih (termasuk blokir)
  const D = pokDetil(); return rpdRoSel === "*" || !rpdRoSel ? D : D.filter(d => roOf(d) === rpdRoSel);
}
function rpdKpi(): void {
  const S = rpdScope(), A = S.filter(d => !d.blokir), B = S.filter(d => d.blokir), t = rpdTw, m0 = t * 3;
  const pagu = A.reduce((s, d) => s + d.j, 0), tot = A.reduce((s, d) => s + rpdSum(d.key), 0), twv = A.reduce((s, d) => s + tw(d.key, t), 0);
  const scope = rpdRoSel && rpdRoSel !== "*" ? rpdRoSel : "semua RO";
  $("#rpdSum").innerHTML = ([
    ["Pagu (tanpa blokir)", rpShort(pagu), `${A.length} detil · ${scope}`],
    [`RPD ${TWN[t]}${rpdLockTw(t) ? " 🔒" : ""}`, rpShort(twv), [0, 1, 2].map(j => `${BLN_S[m0 + j]} ${rpShort(A.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0))}`).join(" · ")],
    ["Total RPD setahun", rpShort(tot), pagu ? Math.round(tot / pagu * 100) + "% dari pagu" : ""],
    ["Belum direncanakan", rpShort(pagu - tot), `${A.filter(d => !rpdSum(d.key)).length} detil kosong`, pagu - tot < 0],
    ["Detil blokir", B.length, B.length ? `Rp ${rupiah(B.reduce((s, d) => s + d.j, 0))} · disembunyikan` : "tidak ada"]] as [string, string | number, string, boolean?][])
    .map(([k, v, sub, bad]) => `<div class="kpi ${bad ? "bad" : ""}"><small>${k}</small><b>${v}</b><span class="sub">${sub}</span></div>`).join("");
  const OV = A.filter(d => rpdSum(d.key) > d.j);
  $("#rpdWarn").hidden = !OV.length;
  $("#rpdWarn").innerHTML = OV.length ? `⚠ <b>${OV.length} detil RPD melebihi pagu</b> (lebih Rp ${rupiah(OV.reduce((s, d) => s + rpdSum(d.key) - d.j, 0))})${rpdRoSel && rpdRoSel !== "*" ? "" : " di semua RO"}. Detil tersebut <b>tidak dimunculkan di Catat TUP</b> sampai RPD-nya diperbaiki. <button class="btn sm" type="button" id="rpdWarnGo">Tampilkan detilnya</button>` : "";
  $("#rpdTwChips").innerHTML = TWN.map((n, i) => { const v = A.reduce((s, d) => s + tw(d.key, i), 0), lk = rpdLockTw(i);
    return `<button type="button" class="twchip ${i === t ? "on" : ""} ${lk ? "lock" : ""}" data-twc="${i}" title="${lk ? "Triwulan sudah lewat — hanya bisa dilihat" : ""}"><b>${n}${lk ? " 🔒" : ""}</b><span>${BLN_S[i * 3]} – ${BLN_S[i * 3 + 2]}${lk ? " · sudah lewat" : ""}</span><small>${v ? "Rp " + rupiah(v) : "belum diisi"}</small></button>`; }).join("");
}
function renderRpd(): void {
  rpdSupNamesOnly();
  angYearUI();
  const D = pokDetil(), q = acNorm($("#rpdQ").value.trim()).split(/\s+/).filter(Boolean), st = $("#rpdSt").value, t = rpdTw, m0 = t * 3, lock = rpdLockTw(t);
  const ros = [...new Map(angPok().akun.map((a): [string, string] => [a.ro, a.roNama])).entries()].sort((a, b) => a[0].localeCompare(b[0]));
  if (rpdRoSel && rpdRoSel !== "*" && !ros.some(r => r[0] === rpdRoSel)) rpdRoSel = "";
  $("#rpdRo").innerHTML = `<option value="">— Pilih MAK / RO —</option><option value="*">Semua RO</option>` + ros.map(([k, n]) => `<option value="${esc(k)}">${esc(k)} ${esc(roTitle(n).slice(0, 70))}</option>`).join("");
  $("#rpdRo").value = rpdRoSel;
  $("#rpdBack").hidden = !rpdRoSel;
  $("#rpdAkAll").hidden = !rpdRoSel && !q.length; $("#rpdAkAll").textContent = rpdAkAll || rpdAkOpen.size ? "Tutup semua akun" : "Buka semua akun";
  const now = new Date();
  const finM = [0, 1, 2].map(j => m0 + j).filter(rpdFinM);
  $("#rpdLock").hidden = !lock && !finM.length;
  $("#rpdLock").innerHTML = lock ? `🔒 <b>${TWN[t]} ${rpdYear()} sudah lewat</b> (tanggal komputer ${now.getDate()} ${BULAN[now.getMonth()]} ${now.getFullYear()}). Isian dan keterangan hanya bisa dilihat, tidak bisa diubah.`
    : finM.length ? `🔒 <b>${finM.map(m => BULAN[m]).join(", ")} terkunci</b> — TUP bulan itu sudah difinalisasi, nilai RPD mengikuti Catat TUP. Untuk mengubah, batalkan finalisasi di Catat TUP.` : "";
  $("#rpdTbl thead").innerHTML = `<tr><th style="width:26px"></th><th>${rpdRoSel || q.length ? "Detil POK" : "MAK / RO"}</th><th class="num" style="width:108px">Pagu</th>${[0, 1, 2].map(j => `<th class="num c-m" style="width:88px">${BULAN[m0 + j]} <button type="button" class="rfh ${rpdFinDB[m0 + j] ? "on" : ""}" data-rfh="${m0 + j}" title="${rpdFinDB[m0 + j] ? `RPD awal ${BULAN[m0 + j]} dikunci ${esc(rpdFinDB[m0 + j].tgl)} (Rp ${rupiah(rpdFinDB[m0 + j].total)}) — klik untuk membuka kunci` : `Klik untuk mengunci RPD awal ${BULAN[m0 + j]}`}">${rpdFinDB[m0 + j] ? "🔒" : "🔓"}</button>${tupDB[m0 + j]?.fin ? ` <span class="tag ok" title="TUP ${BULAN[m0 + j]} sudah difinalisasi — RPD bulan ini = realisasi TUP">final TUP</span>` : ""}${upDB[m0 + j]?.fin ? ` <span class="tag ok" title="UP ${BULAN[m0 + j]} sudah difinalisasi — RPD detil UP = realisasi UP">final UP</span>` : ""}</th>`).join("")}<th class="c-k" style="width:210px">Keterangan</th><th class="num" style="width:112px">Sisa pagu</th></tr>`;
  rpdKpi();
  // langkah 1: belum pilih RO → daftar RO untuk dipilih
  if (!rpdRoSel && !q.length){
    const html = ros.map(([r, n]) => { const ds = D.filter(d => roOf(d) === r && !d.blokir), nb = D.filter(d => roOf(d) === r && d.blokir).length, pg = ds.reduce((s, d) => s + d.j, 0), tt = ds.reduce((s, d) => s + rpdSum(d.key), 0), nk = ds.filter(d => (rpdKet[d.key] || [])[t]).length;
      if (rpdHide0 && pg - tt === 0) return "";
      return `<tr class="rpd-pick" data-ro="${esc(r)}"><td class="chev">▸</td><td><div class="lt-title"><span class="rocode">${esc(r)}</span> ${esc(roTitle(n))}</div><div class="lsub one">${ds.length} detil${nb ? ` · ${nb} blokir` : ""}${ds.some(d => rpdSum(d.key) > d.j) ? ` · <span class="bad">⚠ ${ds.filter(d => rpdSum(d.key) > d.j).length} melebihi pagu</span>` : ""}</div></td><td class="num">${rupiah(pg)}</td>${[0, 1, 2].map(j => { const v = ds.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0); return `<td class="num">${v ? rupiah(v) : `<span class="muted">–</span>`}</td>`; }).join("")}<td class="muted" style="font-size:12px">${nk ? nk + " keterangan" : ""}</td><td class="num ${pg - tt < 0 ? "bad" : ""}">${rupiah(pg - tt)}</td></tr>`; }).join("");
    $("#rpdTbl tbody").innerHTML = html || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">POK T.A. ${angYear} belum ada.</td></tr>`;
    $("#rpdInfo").textContent = `${ros.length} MAK/RO · pilih salah satu untuk ${lock ? "melihat" : "mengisi"} RPD ${TWN[t]}`; return;
  }
  const fit = (d: Detil): boolean => (!q.length || q.every(x => acNorm(d.u + " " + d.a.mak + " " + d.a.nama + " " + d.a.roNama + " " + (rpdKet[d.key] || []).join(" ")).includes(x)))
    && (!st || (st === "isi" ? rpdSum(d.key) > 0 : st === "kosong" ? rpdSum(d.key) === 0 : st === "twkosong" ? tw(d.key, t) === 0 : rpdSum(d.key) > d.j))
    && (!rpdHide0 || d.j - rpdSum(d.key) !== 0);
  const list = (rpdRoSel && rpdRoSel !== "*" ? D.filter(d => roOf(d) === rpdRoSel) : D).filter(fit);
  const byRo = new Map<string, Detil[]>(); for (const d of list){ const r = roOf(d); byRo.set(r, [...(byRo.get(r) || []), d]); }
  const dis = lock ? "disabled" : "", nLock = 12 - rpdOpenM().length;
  const row = (d: Detil): string => { const k = d.key, tt = rpdSum(k), op = rpdOpen.has(k), sisa = d.j - tt, r = rpdDB[k] || [];
    let h = `<tr class="rpd-row ${op ? "open" : ""} ${d.blokir ? "blk" : ""} ${lock ? "lock" : ""}" data-k="${esc(k)}"><td class="chev">${op ? "▾" : "▸"}</td><td class="rpd-det"><div class="lt-title">• ${esc(d.u)}</div><div class="lsub">${(() => { const s0 = rpdSupTw(k, t); return s0 ? `<span class="supchip" title="Supplier ${TWN[t]}: ${esc(s0)}">🏷 ${esc(s0.slice(0, 40))}${s0.length > 40 ? "…" : ""}</span> ` : ""; })()}${volTxt(d)}${d.blokir ? ` <span class="bad">· blokir</span>` : ""}${rpdRoSel === "*" || q.length ? ` <span class="muted">· ${esc(d.a.mak)}</span>` : ""}</div><div class="rpd-over" data-over ${sisa < 0 ? "" : "hidden"}>⚠ RPD melebihi pagu Rp <span>${rupiah(-sisa)}</span> — tidak muncul di Catat TUP</div></td><td class="num">${rupiah(d.j)}</td>
      ${[0, 1, 2].map(j => `<td class="c-m"><input type="number" min="0" step="1000" data-m="${m0 + j}" value="${num(r[m0 + j]) || ""}" placeholder="0" aria-label="${BULAN[m0 + j]}" ${dis || (rpdFinM(m0 + j) ? `disabled title="Terkunci: TUP / UP ${BULAN[m0 + j]} sudah difinalisasi — nilai mengikuti Catat TUP / Catat UP"` : "")}></td>`).join("")}
      <td class="c-k"><input type="text" data-ket="${t}" value="${esc((rpdKet[k] || [])[t] || "")}" placeholder="${lock ? "" : "Keterangan…"}" aria-label="Keterangan ${TWN[t]}" title="${esc((rpdKet[k] || [])[t] || "")}" ${dis}></td>
      <td class="num ${sisa < 0 ? "bad" : ""}" data-sisa>${rupiah(sisa)}</td></tr>`;
    if (op) h += `<tr class="rpd-edit" data-k="${esc(k)}"><td></td><td colspan="7"><div class="rpd-mini">${TWN.map((n, i) => `<span class="${i === t ? "on" : ""}" data-twm="${i}">${n}${rpdLockTw(i) ? " 🔒" : ""}: <b>Rp ${rupiah(tw(k, i))}</b>${(rpdKet[k] || [])[i] ? ` <i>(${esc(rpdKet[k][i])})</i>` : ""}</span>`).join("")}<span>Setahun: <b data-tot>Rp ${rupiah(tt)}</b></span></div>
      <div class="rpd-sup">${[0, 1, 2].map(j => { const m = m0 + j, s0 = (rpdSup[k] || [])[m], refs = rpdSupRefs(s0), nSt = refs.filter(x => x.startsWith("st:")).length, rabs = refs.filter(x => x.startsWith("rab:"));
        return `<div class="rs-m"><span>Supplier ${BULAN[m]}${nSt ? ` <button type="button" class="lnk" data-supgo="${m}:st" title="Lihat surat tugas yang ditautkan">↗ ${nSt} surat tugas</button>` : ""}${rabs.map(x => `<button type="button" class="lnk" data-supgo="${m}:${esc(x)}" title="Buka RAB">↗ RAB</button>`).join("")}</span>
          <button type="button" class="rs-pick${s0?.t ? "" : " empty"}" data-suppick="${m}" title="${esc(s0?.t || "")}" ${rpdLockTw(t) ? "disabled" : ""}>${esc(s0?.t || "Pilih supplier / surat tugas…")}</button></div>`; }).join("")}</div>
      <div class="actions" style="margin-top:8px">${lock ? "" : `<button class="btn sm" type="button" data-rpda="sisa">Isi sisa pagu ke ${BULAN[m0 + 2]}</button>`}${nLock < 12 ? `<button class="btn sm" type="button" data-rpda="rata">${nLock ? `Bagi rata sisa ke ${12 - nLock} bulan terbuka` : "Bagi rata 12 bulan"}</button><button class="btn sm" type="button" data-rpda="tw">Bagi rata per triwulan${nLock ? " terbuka" : ""} (akhir TW)</button><button class="btn sm del" type="button" data-rpda="clr" title="${nLock ? "Hapus isian bulan yang masih terbuka (triwulan yang sudah lewat tidak berubah)" : "Hapus semua isian RPD detil ini"}">Bersihkan</button>` : `<span class="muted" style="font-size:12px">Semua triwulan tahun ${rpdYear()} sudah lewat.</span>`}<span class="muted" style="font-size:12px" data-info></span></div></td></tr>`;
    return h; };
  let html = "";
  for (const [r, ds] of byRo){
    const A = ds.filter(d => !d.blokir), B = ds.filter(d => d.blokir), pg = A.reduce((s, d) => s + d.j, 0), tt = A.reduce((s, d) => s + rpdSum(d.key), 0);
    html += `<tr class="rpd-ro" data-ro="${esc(r)}"><td colspan="2"><b><span class="rocode">${esc(r)}</span> ${esc(roTitle(ds[0].a.roNama))}</b></td><td class="num">${rupiah(pg)}</td>${[0, 1, 2].map(j => `<td class="num" data-rom="${j}">${rupiah(A.reduce((s, d) => s + num((rpdDB[d.key] || [])[m0 + j]), 0))}</td>`).join("")}<td></td><td class="num ${pg - tt < 0 ? "bad" : ""}" data-rosisa>${rupiah(pg - tt)}</td></tr>`;
    const showB = rpdBlk.has(r), byAk = new Map<string, Detil[]>();
    for (const d of ds){ if (d.blokir && !showB) continue; byAk.set(d.a.mak, [...(byAk.get(d.a.mak) || []), d]); }
    for (const [mk, xs] of byAk){
      const a0 = xs[0].a, XA = xs.filter(d => !d.blokir), apg = XA.reduce((s0, d) => s0 + d.j, 0), att = XA.reduce((s0, d) => s0 + rpdSum(d.key), 0), aop = rpdAkAll || q.length > 0 || !!st || rpdAkOpen.has(mk);
      const nOv = XA.filter(d => rpdSum(d.key) > d.j).length;
      html += `<tr class="rpd-ak ${aop ? "open" : ""}" data-mak="${esc(mk)}"><td class="chev">${aop ? "▾" : "▸"}</td><td><div class="ak-t"><b>${esc(a0.akun)}</b> ${esc(a0.nama)}</div><div class="lsub one">${esc(a0.komp)} ${esc(a0.kompNama || "")} · ${xs.length} detil${nOv ? ` · <span class="bad">⚠ ${nOv} melebihi pagu</span>` : ""}</div></td><td class="num">${rupiah(apg)}</td>${[0, 1, 2].map(j => `<td class="num" data-akm="${j}">${rupiah(XA.reduce((s0, d) => s0 + num((rpdDB[d.key] || [])[m0 + j]), 0)) || "0"}</td>`).join("")}<td></td><td class="num ${apg - att < 0 ? "bad" : ""}" data-aksisa>${rupiah(apg - att)}</td></tr>`;
      if (aop) html += xs.map(row).join("");
    }
    if (B.length){ const on = showB;
      html += `<tr class="rpd-blk" data-blk="${esc(r)}"><td class="chev">${on ? "▾" : "▸"}</td><td colspan="7">${on ? "Sembunyikan" : "Tampilkan"} <b>${B.length} detil blokir</b> <span class="muted">· pagu Rp ${rupiah(B.reduce((s, d) => s + d.j, 0))} (tidak dihitung dalam total)</span></td></tr>`; }
  }
  $("#rpdTbl tbody").innerHTML = html || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">Tidak ada detil yang cocok.</td></tr>`;
  const nA = list.filter(d => !d.blokir).length;
  $("#rpdInfo").textContent = `${nA} detil ditampilkan${list.length > nA ? ` · ${list.length - nA} blokir disembunyikan` : ""} · ${lock ? `${TWN[t]} terkunci (sudah lewat)` : `isi langsung kolom ${BLN_S.slice(m0, m0 + 3).join(", ")} dan keterangannya`} · klik ▸ untuk rincian`;
}
/** cari elemen di dalam baris (markup buatan sendiri → selalu ada) */
const q1 = (root: ParentNode, sel: string): HTMLElement => root.querySelector<HTMLElement>(sel)!;
function rpdRowRefresh(k: string): void {
  const d = detMap()[k], tr = document.querySelector<HTMLElement>(`#rpdTbl tr.rpd-row[data-k="${CSS.escape(k)}"]`), ed = document.querySelector<HTMLElement>(`#rpdTbl tr.rpd-edit[data-k="${CSS.escape(k)}"]`); if (!d || !tr) return;
  const t = rpdTw, tt = rpdSum(k), sc = q1(tr, "[data-sisa]");
  sc.textContent = rupiah(d.j - tt); sc.classList.toggle("bad", d.j - tt < 0); const ov = q1(tr, "[data-over]"); ov.hidden = !(tt > d.j); q1(ov, "span").textContent = rupiah(tt - d.j);
  if (ed){ for (let i = 0; i < 4; i++) q1(ed, `[data-twm="${i}"] b`).textContent = "Rp " + rupiah(tw(k, i)); q1(ed, "[data-tot]").textContent = "Rp " + rupiah(tt);
    q1(ed, "[data-info]").innerHTML = tt > d.j ? `<span class="bad">RPD melebihi pagu Rp ${rupiah(tt - d.j)}</span>` : tt === d.j ? "RPD sama dengan pagu ✓" : `Belum direncanakan Rp ${rupiah(d.j - tt)}`; }
  // subtotal RO + ringkasan
  const r = roOf(d), gr = document.querySelector<HTMLElement>(`#rpdTbl tr.rpd-ro[data-ro="${CSS.escape(r)}"]`);
  if (gr){ const A = pokDetil().filter(x => roOf(x) === r && !x.blokir), pg = A.reduce((s, x) => s + x.j, 0), T = A.reduce((s, x) => s + rpdSum(x.key), 0);
    for (let j = 0; j < 3; j++) q1(gr, `[data-rom="${j}"]`).textContent = rupiah(A.reduce((s, x) => s + num((rpdDB[x.key] || [])[t * 3 + j]), 0));
    const rs = q1(gr, "[data-rosisa]"); rs.textContent = rupiah(pg - T); rs.classList.toggle("bad", pg - T < 0); }
  const ar = document.querySelector<HTMLElement>(`#rpdTbl tr.rpd-ak[data-mak="${CSS.escape(d.a.mak)}"]`);
  if (ar){ const XA = pokDetil().filter(x => x.a.mak === d.a.mak && !x.blokir), apg = XA.reduce((s0, x) => s0 + x.j, 0), att = XA.reduce((s0, x) => s0 + rpdSum(x.key), 0);
    for (let j = 0; j < 3; j++) q1(ar, `[data-akm="${j}"]`).textContent = rupiah(XA.reduce((s0, x) => s0 + num((rpdDB[x.key] || [])[t * 3 + j]), 0)) || "0";
    const as = q1(ar, "[data-aksisa]"); as.textContent = rupiah(apg - att); as.classList.toggle("bad", apg - att < 0); }
  rpdKpi();
}
const rpdSetRo = (v: string): void => { rpdRoSel = v; LS.set("st.rpdRo", v); rpdOpen.clear(); rpdAkOpen.clear(); rpdAkAll = false; renderRpd(); const wr = $("#rpdTbl").closest<HTMLElement>(".tblwrap"); if (wr) wr.scrollTop = 0; };
$("#rpdTwChips").addEventListener("click", e => { const b = tg(e).closest<HTMLInputElement>("[data-twc]"); if (!b) return; rpdTw = Number(b.dataset.twc); LS.set("st.rpdTw", rpdTw); renderRpd(); });
$("#rpdRo").addEventListener("change", e => rpdSetRo(tg(e).value));
$("#rpdBack").onclick = () => { $("#rpdQ").value = ""; rpdSetRo(""); };
$("#rpdTbl").addEventListener("click", e => {
  const pk = tg(e).closest<HTMLInputElement>("tr.rpd-pick"); if (pk) return rpdSetRo(pk.dataset.ro ?? "");
  const ak = tg(e).closest<HTMLInputElement>("tr.rpd-ak"); if (ak){ const mk = ak.dataset.mak ?? ""; if (rpdAkAll){ rpdAkAll = false; pokDetil().forEach(x => rpdAkOpen.add(x.a.mak)); } rpdAkOpen.has(mk) ? rpdAkOpen.delete(mk) : rpdAkOpen.add(mk); return renderRpd(); }
  const bk = tg(e).closest<HTMLInputElement>("tr.rpd-blk"); if (bk){ const r = bk.dataset.blk ?? ""; rpdBlk.has(r) ? rpdBlk.delete(r) : rpdBlk.add(r); return renderRpd(); }
  if (tg(e).closest<HTMLInputElement>("input")) return;
  const a = tg(e).closest<HTMLInputElement>("[data-rpda]")?.dataset.rpda, row = tg(e).closest<HTMLInputElement>("tr[data-k]"); if (!row) return; const k = row.dataset.k ?? "", d = detMap()[k];
  if (a){ const r = rpdOf(k), open = rpdOpenM(); if (!open.length) return toast("Semua triwulan sudah lewat.");
    const base = d.j - [...Array(12).keys()].filter(rpdLockM).reduce((s, m) => s + num(r[m]), 0);   // pagu dikurangi bulan terkunci
    if (a === "rata"){ const v = Math.max(0, Math.floor(base / open.length / 1000) * 1000); open.forEach(m => r[m] = v); r[open[open.length - 1]] += Math.max(0, base) - v * open.length; }
    if (a === "tw"){ const ends = [2, 5, 8, 11].filter(m => !rpdLockM(m)), v = Math.max(0, Math.floor(base / ends.length / 1000) * 1000); open.forEach(m => r[m] = 0); ends.forEach(m => r[m] = v); r[ends[ends.length - 1]] += Math.max(0, base) - v * ends.length; }
    if (a === "sisa"){ if (rpdLockM(rpdTw * 3 + 2)) return toast(`${BULAN[rpdTw * 3 + 2]} terkunci (TUP sudah difinalisasi / triwulan lewat).`, "warn"); const s0 = d.j - rpdSum(k); if (s0 <= 0) return toast("Tidak ada sisa pagu."); r[rpdTw * 3 + 2] = num(r[rpdTw * 3 + 2]) + s0; }
    if (a === "clr"){ if (!open.some(m => num(r[m]))) return toast("Tidak ada isian untuk dibersihkan."); if (!confirm(`Bersihkan isian RPD "${d.u}"${rpdOpenM().length < 12 ? " pada bulan yang masih terbuka" : ""}?`)) return; open.forEach(m => r[m] = 0); toast("Isian RPD dibersihkan."); }
    persistAng(); renderRpd(); return; }
  if (row.classList.contains("rpd-row")){ rpdOpen.has(k) ? rpdOpen.delete(k) : rpdOpen.add(k); renderRpd(); }
});
$("#rpdTbl").addEventListener("input", e => { const row = tg(e).closest<HTMLInputElement>("tr[data-k]"); if (!row) return; const m = tg(e).dataset.m, kt = tg(e).dataset.ket, k = row.dataset.k ?? "";
  if (kt != null){ if (rpdLockTw(+kt)) return; rpdKetOf(k)[+kt] = tg(e).value; tg(e).title = tg(e).value; persistAng(); return; }
  if (m == null || rpdLockM(+m)) return; rpdOf(k)[+m] = num(tg(e).value); persistAng(); rpdRowRefresh(k); });
$("#rpdQ").addEventListener("input", debounce(() => renderRpd(), 150));
$("#rpdSt").addEventListener("change", renderRpd);
$("#rpdHide0").checked = rpdHide0;
$("#rpdHide0").addEventListener("change", e => { rpdHide0 = tg(e).checked; LS.set("st.rpdHide0", rpdHide0); renderRpd(); });
$("#rpdAkAll").onclick = () => { const open = rpdAkAll || rpdAkOpen.size > 0; rpdAkAll = !open; rpdAkOpen.clear(); renderRpd(); };
$("#rpdWarn").addEventListener("click", e => { if (!tg(e).closest<HTMLInputElement>("#rpdWarnGo")) return; $("#rpdSt").value = "lebih"; if (!rpdRoSel) rpdRoSel = "*"; renderRpd(); });
$("#rpdExp").onclick = () => {
  $("#reTw").innerHTML = [...TWN.map((n, i) => `<label class="twchip ${i === rpdTw ? "on" : ""}"><input type="radio" name="reTw" value="${i}" ${i === rpdTw ? "checked" : ""} hidden><b>${n}</b><span>${BLN_S[i * 3]} – ${BLN_S[i * 3 + 2]}</span></label>`),
    `<label class="twchip"><input type="radio" name="reTw" value="all" hidden><b>Setahun</b><span>Jan – Des</span></label>`].join("");
  $("#reRoWrap").hidden = !rpdRoSel || rpdRoSel === "*"; $("#reRoTxt").textContent = rpdRoSel && rpdRoSel !== "*" ? rpdRoSel : "";
  $<HTMLDialogElement>("#dRpdExp").showModal();
};
$("#reTw").addEventListener("change", () => $$("#reTw .twchip").forEach(l => l.classList.toggle("on", !!l.querySelector<HTMLInputElement>("input")?.checked)));
$("#reCancel").onclick = () => $<HTMLDialogElement>("#dRpdExp").close();
$("#reGo").onclick = () => {
  const v = document.querySelector<HTMLInputElement>('#reTw input:checked')?.value ?? "all", hide0 = $("#reHide0").checked, onlyRo = !$("#reRoWrap").hidden && $("#reRo").checked;
  const D0 = pokDetil().filter(d => !onlyRo || d.a.ro === rpdRoSel);
  if (v !== "all"){
    const t = +v, D = D0.filter(d => !hide0 || tw(d.key, t) > 0);
    if (!D.length) return toast(`Tidak ada detil ber-RPD di ${TWN[t]} ${angYear}.`, "warn");
    const H = ["RO", "MAK", "Akun", "Detil", "Pagu", ...BULAN.slice(t * 3, t * 3 + 3), "Jumlah " + TWN[t], "Keterangan " + TWN[t], "Total RPD setahun", "Sisa pagu", "Status", "Supplier " + TWN[t]];
    const rows = D.map(d => { const r = rpdDB[d.key] || Array<number>(12).fill(0); return [d.a.ro, d.a.mak, d.a.nama, d.u, d.j, ...r.slice(t * 3, t * 3 + 3).map(num), tw(d.key, t), (rpdKet[d.key] || [])[t] || "", rpdSum(d.key), d.j - rpdSum(d.key), d.blokir ? "Blokir" : "", rpdSupTw(d.key, t)]; });
    const tot = ["", "", "", "Jumlah", D.reduce((s, d) => s + d.j, 0), ...[0, 1, 2].map(j => D.reduce((s, d) => s + num((rpdDB[d.key] || [])[t * 3 + j]), 0)), D.reduce((s, d) => s + tw(d.key, t), 0), "", D.reduce((s, d) => s + rpdSum(d.key), 0), D.reduce((s, d) => s + d.j - rpdSum(d.key), 0), ""];
    const ws = XLSX.utils.aoa_to_sheet([H, ...rows, tot]); ws["!cols"] = [14, 28, 28, 46, 14, 13, 13, 13, 15, 34, 15, 14, 9, 30].map(w => ({ wch: w }));
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, `RPD ${TWN[t]} ${angYear}`);
    XLSX.writeFile(wb, `RPD ${TWN[t]} ${angYear}${onlyRo ? " " + rpdRoSel : ""} (${D.length} detil).xlsx`);
    $<HTMLDialogElement>("#dRpdExp").close(); return toast(`RPD ${TWN[t]} diekspor (${D.length} detil).`, "ok");
  }
  const D = D0.filter(d => !hide0 || rpdSum(d.key) > 0);
  if (!D.length) return toast(`Belum ada detil ber-RPD di ${angYear}.`, "warn");
  $<HTMLDialogElement>("#dRpdExp").close();
  const rows = D.map(d => { const r = rpdDB[d.key] || Array<number>(12).fill(0); return [d.a.ro, d.a.mak, d.a.nama, d.u, d.j, ...[0, 1, 2, 3].flatMap(t => [...r.slice(t * 3, t * 3 + 3).map(num), tw(d.key, t), (rpdKet[d.key] || [])[t] || ""]), rpdSum(d.key), d.j - rpdSum(d.key), d.blokir ? "Blokir" : ""]; });
  const H = ["RO", "MAK", "Akun", "Detil", "Pagu", ...[0, 1, 2, 3].flatMap(t => [...BULAN.slice(t * 3, t * 3 + 3), TWN[t], "Keterangan " + TWN[t]]), "Total RPD", "Sisa", "Status"];
  const ws = XLSX.utils.aoa_to_sheet([H, ...rows]); ws["!cols"] = [14, 28, 28, 46, 14, ...[0, 1, 2, 3].flatMap(() => [12, 12, 12, 13, 30]), 14, 14, 9].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "RPD " + angYear); XLSX.writeFile(wb, `RPD setahun ${angYear}${onlyRo ? " " + rpdRoSel : ""} (${D.length} detil).xlsx`); toast(`RPD setahun diekspor (${D.length} detil).`, "ok");
};
$("#rpdImp").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; tg(e).value = ""; if (!f) return;
  try{ const wb = XLSX.read(await f.arrayBuffer(), { type: "array" }), a = XLSX.utils.sheet_to_json<XCell[]>(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: "" }), H = a[0].map(x => String(x).trim());
    const iM = H.indexOf("MAK"), iD = H.indexOf("Detil"), mi = BULAN.map(b => H.indexOf(b)); if (iM < 0 || iD < 0 || mi.every(i => i < 0)) return toast("Pakai file hasil Ekspor RPD.");
    const ki = TWN.map(t0 => H.indexOf("Keterangan " + t0)); let n = 0, nl = 0;
    for (const r of a.slice(1)){ const d = pokDetil().find(x => x.a.mak === String(r[iM]).trim() && acNorm(x.u) === acNorm(r[iD])); if (!d) continue; const old = rpdDB[d.key] || Array<number>(12).fill(0);
      rpdDB[d.key] = mi.map((i, m) => { if (i < 0) return num(old[m]); if (rpdLockM(m)){ if (num(r[i]) !== num(old[m])) nl++; return num(old[m]); } return num(r[i]); });
      ki.forEach((i, t0) => { if (i >= 0 && !rpdLockTw(t0)) rpdKetOf(d.key)[t0] = String(r[i] ?? "").trim(); }); n++; }
    persistAng(); renderRpd(); toast(`RPD ${n} detil diimpor.` + (nl ? ` ${nl} isian di triwulan yang sudah lewat diabaikan.` : "")); }catch(err){ toast("Gagal membaca file: " + (err as Error).message); }
});


$("#rpdTbl").addEventListener("click", e => { const b = tg(e).closest<HTMLElement>("[data-supgo],[data-suppick]"); if (!b) return; e.stopPropagation();
  const k = b.closest<HTMLElement>("tr[data-k]")?.dataset.k || "";
  if (b.dataset.suppick != null) return rpdSupOpen(k, +b.dataset.suppick);
  const [m, ...rest] = (b.dataset.supgo || "").split(":"), ref = rest.join(":"), x = (rpdSup[k] || [])[+m];
  if (ref === "st") rpdSupGoSt(x); else rpdSupGo(ref); }, true);
