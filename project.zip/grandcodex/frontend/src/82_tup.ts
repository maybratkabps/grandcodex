/* ================= CATAT TUP & CATAT UP (satu modul, dua mode) ================= */
let tupM = new Date().getMonth();
/** "tup" = Catat TUP (baris dari RPD, batas = Total Permintaan RPD Awal); "up" = Catat UP (baris ditambah sendiri, batas = Total UP baku setahun dari Pengaturan) */
let tupMode: "tup" | "up" = "tup";
const TD = (): TupDB => tupMode === "up" ? upDB : tupDB;
/** bulan sudah difinalisasi → seluruh rincian terkunci; harus "Batalkan finalisasi" dulu untuk mengubah */
const tupFinOn = (m: number = tupM): boolean => !!TD()[m]?.fin;
const tupFinMsg = (): string => `${tupMode === "up" ? "UP" : "TUP"} ${BULAN[tupM]} sudah difinalisasi — rincian terkunci. Klik "Batalkan finalisasi" dulu untuk mengubah.`;
const TL = (): string => tupMode === "up" ? "UP" : "TUP";
/** Total UP setahun per tahun anggaran (Pengaturan) */
const upTotalAll = (): Record<string, number> => LS.get<Record<string, number>>("st.upTotal", {});
const upTotal = (y: string = angYear): number => num(upTotalAll()[y]);
function withMode<T>(md: "tup" | "up", fn: () => T): T { const o = tupMode; tupMode = md; try { return fn(); } finally { tupMode = o; } }
const otherMode = (): "tup" | "up" => tupMode === "up" ? "tup" : "up";
/** batas pembanding bulan ini: TUP → Total Permintaan RPD Awal; UP → Total UP */
const capLbl = (): string => tupMode === "up" ? `Total UP ${angYear}` : "Total Permintaan RPD Awal";
/** TUP bulan m — data lama dilengkapi bagian yang belum ada */
const tupOf = (m: number): TupMonth => { const t = TD()[m] || (TD()[m] = { val: {}, add: [], excl: [], tgl: "", ket: "" }); t.val ||= {}; t.add ||= []; t.excl ||= []; t.tgl ??= ""; t.ket ??= ""; t.nama ||= {}; t.kt ||= {}; t.f ||= {}; t.dup ||= []; return t as TupMonth; };
const tupAkMap = (): Record<string, PokAkun> => Object.fromEntries(angPok().akun.map(a => [a.mak, a]));
const isoTgl = (v: string | undefined): string => isoToDmy(v) || v || "";
const tupAkun51 = (d: Detil): boolean => /^51/.test(String(d.a.akun || "").trim());   // belanja pegawai: tidak lewat TUP
const tupOver = (d: Detil): boolean => rpdSum(d.key) > d.j;                            // RPD melebihi pagu
const rpdKetM = (k: string, m: number): string => (rpdKet[k] || [])[Math.floor(m / 3)] || "";
/** satu baris Catat TUP */
interface TupRow {
  k: string; d: Detil; a: PokAkun; dup: boolean; rpd: number; tup: number; edited: boolean; added: boolean;
  nama: string; namaEd: boolean; ket: string; ketEd: boolean; rpdKet: string; f: TupFields;
}
/** detil POK yang menerima realisasi baris: detil asal, atau — bila MAK diganti — detil di MAK baru (pilihan, nama sama, atau detil pertama tanpa blokir) */
function tupKey(x: TupRow): string { return x.d.key; }   // MAK di Catat TUP terkunci: realisasi selalu ke detil asal
function tupRows(m: number): TupRow[] {
  const t: Partial<TupMonth> = TD()[m] || {}, M = detMap();
  const keys = [...new Set([...(tupMode === "up" ? [] : t.fin ? Object.entries(t.fin.prev).filter(([, v]) => num(v) > 0).map(([k]) => k) : pokDetil().filter(d => num((rpdDB[d.key] || [])[m]) > 0).map(d => d.key)), ...(t.add || [])])].filter(k => M[k] && !(t.excl || []).includes(k) && !tupAkun51(M[k]) && (t.fin ? true : !tupOver(M[k])));
  const AK = tupAkMap();
  /* k = kunci baris (detil, atau "dup:…" untuk baris duplikat); a = akun/MAK yang dipakai (bisa dipilih lain) */
  const mkRow = (k: string, d: Detil, dup: boolean): TupRow => { const rk = rpdKetM(d.key, m), f = (t.f || {})[k] || {}, rpd = dup ? 0 : num((rpdDB[d.key] || [])[m]);
    void AK; return { k, d, a: d.a, dup, rpd, tup: t.val && t.val[k] != null ? num(t.val[k]) : rpd, edited: !!(t.val && t.val[k] != null), added: !dup && (t.add || []).includes(k),
      nama: t.nama && t.nama[k] != null ? t.nama[k] : d.u, namaEd: !!(t.nama && t.nama[k] != null), ket: t.kt && t.kt[k] != null ? t.kt[k] : rk, ketEd: !!(t.kt && t.kt[k] != null), rpdKet: rk, f }; };
  const out: TupRow[] = [];
  for (const k of keys){ out.push(mkRow(k, M[k], false)); for (const dp of (t.dup || []).filter(x => x.src === k)) out.push(mkRow(dp.id, M[k], true)); }
  return out;
}
function tupHidden(m: number): { a51: Detil[]; over: Detil[] } {   // detil ber-RPD bulan ini yang tidak dimunculkan
  const D = pokDetil().filter(d => num((rpdDB[d.key] || [])[m]) > 0);
  return { a51: D.filter(tupAkun51), over: D.filter(d => !tupAkun51(d) && tupOver(d)) };
}
/* ---------- tampilan Catat TUP: daftar ringkas, klik baris untuk mengisi; pajak lewat pop-up ---------- */
let tupOpen = new Set<string>(), tupFlt = "", tupPjKey = "";
const IC_CP = `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>`;
const tglSalin = (v: string | undefined): string => { if (!v) return ""; const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}` : v; };   // format isian SAKTI: dd/mm/yyyy
async function salin(txt0: unknown, lbl?: string): Promise<void> {
  const txt = String(txt0 ?? "").trim(); if (!txt) return toast(`${lbl || "Isian"} masih kosong.`);
  let ok = false; try{ await navigator.clipboard.writeText(txt); ok = true; }catch(e){}
  if (!ok){ const ta = document.createElement("textarea"); ta.value = txt; ta.style.cssText = "position:fixed;opacity:0;left:-9999px"; document.body.appendChild(ta); ta.select(); try{ ok = document.execCommand("copy"); }catch(e){} ta.remove(); }
  toast(ok ? `Disalin${lbl ? " " + (lbl === "MAK" ? "MAK" : lbl.replace(/SAKTI/, "\x00").toLowerCase().replace("\x00", "SAKTI").replace("spby", "SPBY")) : ""}: ${txt.length > 70 ? txt.slice(0, 70) + "…" : txt}` : "Gagal menyalin — pilih teks lalu tekan Ctrl+C.");
}
const cpBtn = (val: string, lbl: string): string => `<button type="button" class="cpb" data-cp="${esc(val)}" data-cpl="${esc(lbl)}" data-stop title="Salin ${esc(lbl.toLowerCase())}" aria-label="Salin ${esc(lbl.toLowerCase())}">${IC_CP}</button>`;
const PPH_J: [string, number][] = [["PPh 22", 1.5], ["PPh 23", 2], ["PPh 21", 5], ["PPh 4 ayat 2", 10], ["Lainnya", 0]];
const tglS = (v: string): string => isoToDmy(v) || v || "";
const tupPj = (f: TupFields): { ppn: number; pph: number } => f.pajak && f.pj ? { ppn: num(f.pj.ppn), pph: num(f.pj.pph) } : { ppn: 0, pph: 0 };
const tupVis = (rows: TupRow[]): TupRow[] => rows.filter(x => !tupFlt || (tupFlt === "belum" ? !x.f.catat : tupFlt === "sudah" ? x.f.catat : tupFlt === "pajak" ? x.f.pajak : !x.f.pajak));
const tupSel = (x: TupRow): string => x.dup ? "baris duplikat · tidak dihitung dari RPD" : x.rpd || x.tup ? (x.tup - x.rpd ? `RPD ${rupiah(x.rpd)} · <span class="${x.tup > x.rpd ? "bad" : "ok"}">${x.tup > x.rpd ? "+" : "−"}${rupiah(Math.abs(x.tup - x.rpd))}</span>` : `sesuai RPD`) : (x.added ? "ditambahkan" : "");
/* ---------- syarat "Selesai": isian lengkap & pagu detil cukup ---------- */
/** sisa pagu detil per kunci untuk bulan m: pagu − realisasi (baris selesai) bulan lain − semua baris detil itu di bulan m */
let tupSisa: Record<string, number> = {};
function tupCalcSisa(m: number): Record<string, number> {
  const used: Record<string, number> = {};
  for (let mm = 0; mm < 12; mm++) for (const x of tupRows(mm)) if (mm === m || x.f.catat){ const kk = tupKey(x); used[kk] = (used[kk] || 0) + x.tup; }
  for (let mm = 0; mm < 12; mm++) for (const x of withMode(otherMode(), () => tupRows(mm))) if (x.f.catat){ const kk = tupKey(x); used[kk] = (used[kk] || 0) + x.tup; }   // Catat TUP + Catat UP memakai pagu yang sama
  const o: Record<string, number> = {}; for (const d of pokDetil()) if (used[d.key] != null) o[d.key] = (d.blokir ? 0 : d.j) - used[d.key];
  return (tupSisa = o);
}
/** isian yang belum diisi (nama kolom untuk pesan) */
function tupMissing(x: TupRow): string[] {
  const f = x.f, out: string[] = [];
  if (!f.nota) out.push("tanggal nota"); if (!f.spby) out.push("tanggal SPBY"); if (!f.kui) out.push("tanggal kuitansi SAKTI");
  if (!String(x.nama || "").trim()) out.push("uraian"); if (!String(f.sup || "").trim()) out.push("supplier"); if (!(x.tup > 0)) out.push("jumlah");
  if (f.pajak && !(f.pj && num(f.pj.dpp) > 0)) out.push("rincian pajak (DPP)");
  return out;
}
const tupMinus = (x: TupRow): number => Math.min(0, tupSisa[tupKey(x)] ?? 0);
const tupOk = (x: TupRow): boolean => !tupMissing(x).length && tupMinus(x) >= 0;
function tupMain(x: TupRow, i: number): string {
  const f = x.f, a = x.a, op = tupOpen.has(x.k), pj = tupPj(f);
  const dates = ([["Nota", f.nota, "Tanggal nota"], ["SPBY", f.spby, "Tanggal SPBY"], ["Kuitansi", f.kui, "Tanggal kuitansi SAKTI"]] as [string, string | undefined, string][]).map(([l, v, n]) => v
    ? `<span class="tchip on" title="${esc(n)}">${l} ${tglS(v)}</span>`
    : `<span class="tchip">${l} —</span>`).join("");
  return `<label class="tck" title="Tandai selesai (sudah dicatat)" data-stop><input type="checkbox" data-tc="catat" ${f.catat ? "checked" : ""} ${tupFinOn() ? "disabled" : ""} aria-label="Selesai dicatat"><span class="no">${i + 1}</span></label>
    <div class="tr-t"><div class="tr-u">${x.dup ? `<span class="tdup">duplikat</span> ` : ""}${esc(x.nama)} ${cpBtn(x.nama, "Uraian")}</div>
      <div class="tr-mak"><span class="mk">MAK</span><code>${esc(a.mak)}</code>${cpBtn(a.mak, "MAK")}<span class="tr-s">${esc(a.nama)} · ${esc(roTitle(a.roNama))}</span><span class="tr-s tr-det" title="Detil POK: ${esc(x.d.u)}">detil: ${esc(x.d.u.slice(0, 70))}</span></div>
      <div class="tr-c">${dates}${f.sup ? `<span class="tchip sup" title="Supplier">${esc(f.sup)}</span>` : ""}${x.ket ? `<span class="tchip ket" title="${esc(x.ket)}">${esc(x.ket)}</span>` : ""}</div></div>
    <div class="tr-j"><b>Rp ${rupiah(x.tup)}</b><small>${tupSel(x)}</small>${(() => { const s = tupSisa[tupKey(x)] ?? 0, ms = tupMissing(x);
      return `<small class="tr-pg ${s < 0 ? "bad" : ""}" title="Pagu detil dikurangi realisasi ${TL()} bulan lain & semua baris detil ini bulan ini">${s < 0 ? `⚠ pagu kurang Rp ${rupiah(-s)}` : `sisa pagu Rp ${rupiah(s)}`}</small>${f.catat && (ms.length || s < 0) ? `<small class="bad">⚠ ${ms.length ? "belum lengkap" : "melebihi pagu"} — tidak bisa difinalisasi</small>` : !f.catat && ms.length ? `<small class="muted tr-ms" title="Wajib diisi sebelum Selesai: ${esc(ms.join(", "))}">belum diisi: ${esc(ms.slice(0, 2).join(", "))}${ms.length > 2 ? ` +${ms.length - 2}` : ""}</small>` : ""}`; })()}</div>
    <button type="button" class="tpj ${f.pajak ? "on" : ""}" data-tpj data-stop ${f.catat || tupFinOn() ? "disabled" : ""} title="${f.catat ? "Baris selesai — terkunci. " : ""}${f.pajak ? "Ubah rincian pajak" : "Tandai ada pajak & isi DPP, PPN, PPh"}">${f.pajak ? `<b>Pajak</b><small>${f.pj ? `PPN ${rupiah(pj.ppn)} · ${esc(f.pj.pphJ || "PPh")} ${rupiah(pj.pph)}` : "isi rincian"}</small>` : `<span>+ Pajak</span>`}</button>
    <span class="tr-tools"><button type="button" class="cpb tdupb" data-tdup data-stop ${f.catat || tupFinOn() ? "disabled" : ""} title="Duplikat baris (mis. satu detil dibayar beberapa nota)" aria-label="Duplikat baris">${IC.dup}</button><span class="tr-chev" aria-hidden="true">${op ? "▾" : "▸"}</span></span>`;
}
/** pilihan MAK berisi judul detil: dikelompokkan per MAK (optgroup), nilai = kunci detil */
function tupDetOpts(cur: string): string {
  const byMak = new Map<string, Detil[]>(); for (const d of pokDetil()) if (!tupAkun51(d)){ const g = byMak.get(d.a.mak); if (g) g.push(d); else byMak.set(d.a.mak, [d]); }
  return [...byMak.entries()].map(([mak, ds]) => `<optgroup label="${esc(mak)} — ${esc(ds[0].a.nama)}">${ds.map(d => `<option value="${esc(d.key)}" ${d.key === cur ? "selected" : ""}>${esc(d.u.slice(0, 80))} · pagu ${rupiah(d.blokir ? 0 : d.j)}${d.blokir ? " (blokir)" : ""}</option>`).join("")}</optgroup>`).join("");
}
function tupEditor(x: TupRow): string {
  const f = x.f, L = f.catat || tupFinOn() ? "disabled" : "";
  return `<div class="tr-ed ${f.catat || tupFinOn() ? "locked" : ""}">${tupFinOn() ? `<div class="w4 tr-lock">🔒 ${tupMode === "up" ? "UP" : "TUP"} ${BULAN[tupM]} sudah <b>difinalisasi</b> — rincian terkunci. Klik <b>Batalkan finalisasi</b> untuk mengubah.</div>` : f.catat ? `<div class="w4 tr-lock">🔒 Baris sudah <b>Selesai</b> — semua isian terkunci. Hapus centang ✓ Selesai untuk mengubah lagi.</div>` : ""}
    <div class="w4 trmk"><span class="lh"><span><span class="mk">MAK</span> &amp; detil POK <span class="muted">(terkunci — sesuai POK / RPD)</span></span><button type="button" class="cpb" data-cp="${esc(x.a.mak)}" data-cpl="MAK" title="Salin MAK">${IC_CP}</button></span>
      <div class="trmk-v" title="MAK tidak bisa diubah di Catat ${TL()}"><span class="lk" aria-hidden="true">🔒</span><code>${esc(x.a.mak)}</code><b>${esc(x.d.u)}</b></div>
      <span class="muted" style="font-size:11.5px">${esc(x.a.nama)} · ${esc(x.a.ro)} ${esc(roTitle(x.a.roNama))} · pagu detil Rp ${rupiah(x.d.blokir ? 0 : x.d.j)}</span></div>
    <label><span class="lh">Tanggal nota</span><input type="date" data-tf="nota" value="${esc(f.nota || "")}" ${L}></label>
    <label><span class="lh">Tanggal SPBY</span><input type="date" data-tf="spby" value="${esc(f.spby || "")}" ${L}></label>
    <label><span class="lh">Tanggal kuitansi SAKTI</span><input type="date" data-tf="kui" value="${esc(f.kui || "")}" ${L}></label>
    <label><span class="lh">Jumlah (Rp)</span><input type="number" min="0" step="1000" data-tv value="${x.tup || ""}" ${L} class="${x.edited ? "edited" : ""}"></label>
    <label class="w2"><span class="lh">Uraian<button type="button" class="cpb" data-cpf="tn" data-cpl="Uraian" title="Salin uraian">${IC_CP}</button></span><input type="text" data-tn value="${esc(x.nama)}" ${L} class="${x.namaEd ? "edited" : ""}" title="${x.namaEd ? "Nama di POK: " + esc(x.d.u) : "Bisa diubah — POK tidak berubah"}"></label>
    <label class="w2"><span class="lh">Supplier</span><input type="text" data-tf="sup" value="${esc(f.sup || "")}" ${L} placeholder="${esc(rpdSupGet(x.d.key, tupM)?.t ? "Supplier di RPD: " + rpdSupGet(x.d.key, tupM)!.t : "Nama toko / penyedia")}">${!f.sup && rpdSupGet(x.d.key, tupM) && !f.catat ? `<button type="button" class="lnk" data-supuse title="Isi supplier dari RPD">Pakai supplier RPD</button>` : ""}</label>
    <label class="w4">Keterangan<input type="text" data-tk value="${esc(x.ket)}" ${L} placeholder="Keterangan…" class="${x.ketEd ? "edited" : ""}" title="${x.rpdKet ? "Keterangan RPD: " + esc(x.rpdKet) : ""}"></label>
    <div class="w4 tr-act"><span class="muted">${x.dup ? "Baris duplikat — ubah uraian supaya berbeda sebelum ditandai selesai." : x.namaEd ? `Nama di POK: ${esc(x.d.u)}` : ""}</span><span style="display:flex;gap:6px"><button class="btn sm" type="button" data-tdup ${L}>Duplikat baris</button><button class="btn sm del" type="button" data-tx ${L}>${x.dup ? "Hapus duplikat" : "Keluarkan dari bulan ini"}</button></span></div></div>`;
}
function tupSummary(rows: TupRow[]): void {
  const tot = rows.reduce((s0, x) => s0 + x.tup, 0), nC = rows.filter(x => x.f.catat).length, nP = rows.filter(x => x.f.pajak).length;
  const ppn = rows.reduce((s0, x) => s0 + tupPj(x.f).ppn, 0), pph = rows.reduce((s0, x) => s0 + tupPj(x.f).pph, 0);
  $("#tupSum").innerHTML = `<div class="ts"><small>Total ${TL()}</small><b>Rp ${rupiah(tot)}</b><span>${rows.length} baris</span></div>
    <div class="ts"><small>Selesai dicatat</small><b>${nC} / ${rows.length}</b><span class="tbar"><i style="width:${rows.length ? Math.round(nC / rows.length * 100) : 0}%"></i></span></div>
    <div class="ts"><small>Ada pajak</small><b>${nP} baris</b><span>PPN Rp ${rupiah(ppn)} · PPh Rp ${rupiah(pph)}</span></div>`;
  tupFinUI(rows);
  $$("#tupSeg [data-flt]").forEach(b => { b.classList.toggle("on", b.dataset.flt === tupFlt); const c = b.dataset.flt === "" ? rows.length : b.dataset.flt === "belum" ? rows.length - nC : b.dataset.flt === "sudah" ? nC : nP; b.querySelector("i")!.textContent = String(c); });
}
/* ---------- finalisasi TUP: semua baris selesai → RPD bulan itu diganti realisasi TUP (bisa dibatalkan) ---------- */
/** realisasi TUP per detil (baris duplikat ikut dijumlahkan ke detilnya) */
const tupReal = (rows: TupRow[]): Record<string, number> => { const o: Record<string, number> = {}; for (const x of rows){ const kk = tupKey(x); o[kk] = (o[kk] || 0) + x.tup; } return o; };
/** selisih RPD awal − total Catat TUP (minus = TUP melebihi RPD awal) */
function tupCmp(rows: TupRow[]): { awal: number; tot: number; sel: number; locked: boolean; tgl: string } {
  const tot = rows.reduce((s0, x) => s0 + x.tup, 0);
  if (tupMode === "up"){ const u = upTotal(); return { awal: u, tot, sel: u - tot, locked: u > 0, tgl: "" }; }
  const a = rpdAwal(tupM); return { awal: a.total, tot, sel: a.total - tot, locked: a.locked, tgl: a.tgl };
}
function tupCmpUI(rows: TupRow[]): void {
  const c = tupCmp(rows), el = $("#tupCmp");
  if (tupMode === "up"){ el.innerHTML = `<span>${capLbl()} (baku setahun): <b>Rp ${rupiah(c.awal)}</b> ${c.awal ? "" : `<span class="bad">— belum diisi di Pengaturan</span>`}</span>
    <span>Total Catat UP ${BULAN[tupM]}: <b>Rp ${rupiah(c.tot)}</b></span>
    <span>Selisih: <b class="sel ${c.sel < 0 ? "bad" : c.sel > 0 ? "" : "ok"}">${c.sel < 0 ? "−" : c.sel > 0 ? "+" : ""}Rp ${rupiah(Math.abs(c.sel))}</b></span>
    <span class="msg ${c.sel < 0 ? "bad" : ""}">${!c.awal ? `Isi <b>Total UP</b> di Pengaturan → Tarif bawaan.` : c.sel < 0 ? `⚠ Total Catat UP melebihi Total UP Rp ${rupiah(-c.sel)} — <b>UP tidak bisa difinalisasi</b>. Kurangi nominal UP.` : c.tot ? `Sisa UP Rp ${rupiah(c.sel)}.` : ""}</span>`; return; }
  el.innerHTML = `<span>Total Permintaan RPD Awal ${BLN_S[tupM]}: <b>Rp ${rupiah(c.awal)}</b> ${c.locked ? `<span class="tag" title="Dikunci di RPD ${esc(c.tgl)}">🔒 dikunci</span>` : `<span class="muted" title="Kunci lewat tombol Finalisasi RPD di halaman RPD">(belum dikunci)</span>`}</span>
    <span>Total Catat ${TL()}: <b>Rp ${rupiah(c.tot)}</b></span>
    <span>Selisih: <b class="sel ${c.sel < 0 ? "bad" : c.sel > 0 ? "" : "ok"}">${c.sel < 0 ? "−" : c.sel > 0 ? "+" : ""}Rp ${rupiah(Math.abs(c.sel))}</b></span>
    <span class="msg ${c.sel < 0 ? "bad" : ""}">${c.sel < 0 ? `⚠ Total Catat ${TL()} melebihi RPD awal Rp ${rupiah(-c.sel)} — <b>${TL()} tidak bisa difinalisasi</b>. Kurangi nominal ${TL()}.` : c.sel > 0 && c.tot ? `↩ Sisa Rp ${rupiah(c.sel)} dari RPD awal tidak terpakai — <b>harus dilakukan pengembalian</b>.` : c.tot ? "✓ Total Catat ${TL()} sama dengan RPD awal." : ""}</span>`;
}
function tupFinUI(rows: TupRow[]): void {
  tupCmpUI(rows); const cmp = tupCmp(rows);
  const el = $("#tupFin"), t: Partial<TupMonth> = TD()[tupM] || {}, fin = t.fin, nOk = rows.filter(x => x.f.catat && tupOk(x)).length, done = rows.length > 0 && nOk === rows.length, tot = rows.reduce((s0, x) => s0 + x.tup, 0);
  const diff = fin ? Object.entries(tupReal(rows)).some(([k, v]) => num((rpdDB[k] || [])[tupM]) !== v) : false;
  el.hidden = !fin && !rows.length;
  el.className = "tup-fin" + (fin ? (done && !diff ? " ok" : " warn") : done ? "" : " wait");
  if (!fin && done && cmp.sel < 0){ el.className = "tup-fin warn"; el.innerHTML = `<div><b>⚠ ${TL()} ${BULAN[tupM]} tidak bisa difinalisasi</b><br><small>Total Catat ${TL()} (Rp ${rupiah(cmp.tot)}) melebihi ${capLbl()} (Rp ${rupiah(cmp.awal)}) sebesar Rp ${rupiah(-cmp.sel)}. Kurangi nominal ${TL()} terlebih dahulu.</small></div>
       <div class="tf-act"><button type="button" class="btn sm" disabled>Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`; return; }
  if (!fin && !done){ el.innerHTML = `<div><b>Finalisasi ${TL()} ${BULAN[tupM]}</b> <span class="muted">— ${nOk} dari ${rows.length} baris selesai</span><br><small>Tersedia setelah semua baris dicentang <b>Selesai</b> (isian lengkap & pagu cukup). Finalisasi mengganti RPD ${BULAN[tupM]} dengan realisasi ${TL()}.</small><span class="tbar"><i style="width:${Math.round(nOk / rows.length * 100)}%"></i></span></div>
       <div class="tf-act"><button type="button" class="btn sm" disabled title="Selesaikan semua baris dulu">Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`; return; }
  el.innerHTML = fin
    ? `<div><b>✓ ${TL()} ${BULAN[tupM]} sudah difinalisasi</b> <span class="muted">(${esc(fin.tgl)})</span><br><small>RPD ${BULAN[tupM]} ${esc(angYear)} otomatis = hasil Catat ${TL()}: <b>Rp ${rupiah(fin.total)}</b>${diff ? "" : " ✓ sesuai"}. 🔒 Rincian Catat ${TL()} dan kolom RPD ${BULAN[tupM]} terkunci — klik <b>Batalkan finalisasi</b> untuk mengubah.${!done ? " ⚠ Ada baris yang belum selesai / melebihi pagu." : ""}</small></div>
       <div class="tf-act"><button type="button" class="btn sm" data-tgo-rpd>Lihat RPD</button><button type="button" class="btn sm" data-tfin="undo">Batalkan finalisasi</button></div>`
    : `<div><b>Semua ${rows.length} baris sudah selesai dicatat.</b><br><small>Finalisasi mengganti nilai RPD ${BULAN[tupM]} ${esc(angYear)} dengan realisasi ${TL()} (Rp ${rupiah(tot)}). Nilai RPD lama disimpan dan bisa dikembalikan.</small></div>
       <div class="tf-act"><button type="button" class="btn sm pri" data-tfin="go">Finalisasi ${TL()} ${BULAN[tupM]}</button></div>`;
}
/** detil yang ikut TUP (bukan akun 51) dan punya RPD di bulan m */
const tupRpdKeys = (m: number): string[] => (TD()[m]?.excl || []).filter(k => num((rpdDB[k] || [])[m]) > 0);
/* RPD bulan m := hasil Catat TUP. Detil ber-RPD yang tidak dicatat di TUP (dikeluarkan / tidak ada baris) menjadi 0.
   Akun 51 tidak disentuh (tidak lewat TUP). Nilai RPD sebelum finalisasi disimpan di prev (sekali) agar bisa dibatalkan. */
/* RPD bulan m = gabungan: TUP terfinalisasi → realisasi TUP (+ realisasi UP terfinalisasi), detil lain 0;
   hanya UP terfinalisasi → detil UP = realisasi UP, detil lain tetap. Nilai asli disimpan di prev (TUP / UP) agar bisa dibatalkan. */
function finRecalc(m: number, prev: Record<string, number>): number {
  const tf = tupDB[m]?.fin, uf = upDB[m]?.fin, tP = tf?.prev || {}, uP = uf?.prev || {};
  const tr = tf ? withMode("tup", () => tupReal(tupRows(m))) : {}, ur = uf ? withMode("up", () => tupReal(tupRows(m))) : {};
  const orig = (k: string): number => k in uP ? num(uP[k]) : k in tP ? num(tP[k]) : num((rpdDB[k] || [])[m]);
  const keys = new Set<string>([...Object.keys(tP), ...Object.keys(uP), ...Object.keys(prev), ...Object.keys(tr), ...Object.keys(ur), ...(tf ? withMode("tup", () => tupRpdKeys(m)) : [])]);
  let chg = 0;
  for (const k of keys){ const v = tf ? num(tr[k]) + num(ur[k]) : uf && k in ur ? num(ur[k]) : orig(k), cur = num((rpdDB[k] || [])[m]);
    if (cur === v) continue; if (!(k in tP) && !(k in uP) && !(k in prev)) prev[k] = cur; rpdOf(k)[m] = v; chg++; }
  return chg;
}
function tupApplyFin(m: number, prev: Record<string, number>): { chg: number; tot: number } {
  const rows = tupRows(m); return { chg: finRecalc(m, prev), tot: rows.reduce((s0, x) => s0 + x.tup, 0) };
}
/** bulan yang sudah difinalisasi: RPD selalu mengikuti perubahan Catat TUP */
function tupFinSync(m: number): number {
  const t = TD()[m]; if (!t?.fin) return 0;
  const r = tupApplyFin(m, t.fin.prev); t.fin.total = r.tot;
  if (r.chg) persistAng(); return r.chg;
}
function tupFinalize(m: number): void {
  const rows = tupRows(m), t = tupOf(m); if (!rows.length) return;
  tupCalcSisa(m); if (!rows.every(x => x.f.catat && tupOk(x))) return toast("Semua baris harus selesai, lengkap, dan tidak melebihi pagu sebelum finalisasi.", "warn");
  const cmp = (() => { const tt = rows.reduce((s0, x) => s0 + x.tup, 0), aw = tupMode === "up" ? upTotal() : rpdAwal(m).total; return { awal: aw, tot: tt, sel: aw - tt }; })();
  if (cmp.sel < 0) return toast(`${TL()} tidak bisa difinalisasi: Total Catat ${TL()} melebihi ${tupMode === "up" ? "Total UP" : "RPD awal"} Rp ${rupiah(-cmp.sel)}.`, "err");
  if (tupMode === "up" && !upTotal()) return toast("Isi Total UP tahun ini di Pengaturan sebelum finalisasi Catat UP.", "warn");
  const real = tupReal(rows), M = detMap(), prev: Record<string, number> = { ...(t.fin?.prev || {}) };
  const zero = tupRpdKeys(m).filter(k => !(k in real)), chg = [...Object.entries(real).filter(([k, v]) => num((rpdDB[k] || [])[m]) !== v).map(([k]) => k), ...zero], tot = rows.reduce((s0, x) => s0 + x.tup, 0);
  const over = Object.entries(real).filter(([k, v]) => M[k] && rpdSum(k) - num((rpdDB[k] || [])[m]) + v > M[k].j).length;
  if (!confirm(`Finalisasi ${TL()} ${BULAN[m]} ${angYear}?

• ${rows.length} baris, realisasi Rp ${rupiah(tot)}
• RPD ${BULAN[m]} otomatis diisi sesuai hasil Catat ${TL()} (${chg.length} detil berubah${zero.length ? `, ${zero.length} detil yang dikeluarkan dari ${TL()} menjadi 0` : ""})
• Kolom RPD ${BULAN[m]} dikunci (tidak bisa diisi manual) selama terfinalisasi
• Rincian Catat ${TL()} bulan ini terkunci — untuk mengubah, batalkan finalisasi dulu
• ${capLbl()} Rp ${rupiah(cmp.awal)} · selisih ${cmp.sel ? `Rp ${rupiah(cmp.sel)}${tupMode === "up" ? " (sisa UP)" : " → HARUS DILAKUKAN PENGEMBALIAN"}` : "Rp 0"}
• Nilai RPD lama disimpan — bisa dibatalkan kapan saja${over ? `

⚠ ${over} detil akan melebihi pagu setahun di RPD.` : ""}`)) return;
  for (const x of rows) if (!x.dup){ if (!(t.val && x.k in t.val)) t.val[x.k] = x.tup; if (!t.add.includes(x.k)) t.add.push(x.k); }   // jumlah & baris tetap walau RPD berubah
  if (tupMode === "tup" && !rpdFinDB[m]){ const val: Record<string, number> = {}; let s0 = 0; for (const d of rpdTupDet()){ const v = num((rpdDB[d.key] || [])[m]); if (v){ val[d.key] = v; s0 += v; } } rpdFinDB[m] = { tgl: today(), total: s0, val }; }
  void real; t.fin = { tgl: today(), prev, total: tot }; tupApplyFin(m, prev);
  persistAng(); renderTup(); toast(`${TL()} ${BULAN[m]} difinalisasi — RPD ${BULAN[m]} sekarang sama dengan hasil Catat ${TL()} (Rp ${rupiah(tot)}).${cmp.sel > 0 ? (tupMode === "up" ? ` Sisa UP Rp ${rupiah(cmp.sel)}.` : ` Sisa Rp ${rupiah(cmp.sel)} harus dikembalikan.`) : ""}`, cmp.sel > 0 && tupMode === "tup" ? "warn" : "ok");
}
function tupUnfinal(m: number): void {
  const t = tupOf(m), fin = t.fin; if (!fin) return;
  if (!confirm(`Batalkan finalisasi ${TL()} ${BULAN[m]}? Nilai RPD ${BULAN[m]} dikembalikan seperti sebelum finalisasi.`)) return;
  const of = withMode(otherMode(), () => TD()[m]?.fin);
  delete t.fin;
  if (of){ for (const [k, v] of Object.entries(fin.prev)) if (!(k in of.prev)) of.prev[k] = v; finRecalc(m, of.prev); }
  else for (const [k, v] of Object.entries(fin.prev)) rpdOf(k)[m] = v; persistAng(); renderTup(); toast(`Finalisasi ${TL()} ${BULAN[m]} dibatalkan — RPD dikembalikan.`);
}
$("#tupFin").addEventListener("click", e => { if (tg(e).closest("[data-tgo-rpd]")){ rpdTw = Math.floor(tupM / 3); show("rpd"); return; } const a = tg(e).closest<HTMLElement>("[data-tfin]")?.dataset.tfin; if (a === "go") tupFinalize(tupM); else if (a === "undo") tupUnfinal(tupM); });
function renderTup(): void {
  rpdSupNamesOnly();
  $("#tupMonths").innerHTML = BULAN.map((b, m) => { const tot = tupRows(m).reduce((s0, x) => s0 + x.tup, 0);
    return `<button type="button" class="tupm ${m === tupM ? "on" : ""}" data-tm="${m}"><small>${BLN3[m]}</small><b>${tot ? rpShort(tot).replace("Rp ", "") : "–"}</b></button>`; }).join("");
  tupFinSync(tupM);
  const rows = tupRows(tupM), t = tupOf(tupM); tupCalcSisa(tupM);
  { const fin = tupFinOn(); for (const id of ["#tupAdd", "#tupAddBtn", "#tupReset", "#tupTgl", "#tupKet"]){ const el = $<HTMLInputElement>(id); el.disabled = fin; if (el._dmy) el._dmy.disabled = fin; } $("#tupTbl").classList.toggle("finlock", fin); }
  angYearUI(); $("#tupTitle").textContent = `${TL()} ${BULAN[tupM]} ${angYear}`;
  $("#tupSubT").innerHTML = tupMode === "up" ? `Detil ditambahkan sendiri (tanpa akun 51) · batas: <b>Total UP ${esc(angYear)} Rp ${rupiah(upTotal())}</b> (baku setahun, ubah di Pengaturan) · finalisasi mengubah RPD` : "Otomatis dari RPD (tanpa akun 51) · jumlah, uraian &amp; keterangan bisa diubah tanpa mengubah RPD/POK";
  $("#tupReset").hidden = tupMode === "up"; $("#tupKet").placeholder = tupMode === "up" ? "mis. Belanja UP kegiatan survei" : "mis. Pengajuan TUP kegiatan survei";
  $("#tupAdd").placeholder = tupMode === "up" ? "+ Tambah detil POK yang dibayar dengan UP…" : "+ Tambah detil POK lain ke bulan ini…";
  $("#tupTgl").value = t.tgl || ""; $("#tupKet").value = t.ket || "";
  tupSummary(rows);
  const vis = tupVis(rows);
  $("#tupTbl").innerHTML = (vis.length ? `<div class="tlist-h" aria-hidden="true"><span title="Centang bila sudah selesai dicatat">✓ Selesai</span><span>Uraian · MAK · tanggal</span><span>Jumlah</span><span>Pajak</span><span></span></div>` : "") + vis.map(x => `<div class="trow ${x.f.catat ? "tcat" : ""} ${tupOpen.has(x.k) ? "open" : ""}" data-k="${esc(x.k)}"><div class="tr-main" data-ttog tabindex="0" role="button" aria-label="Buka / tutup isian baris">${tupMain(x, rows.indexOf(x))}</div>${tupOpen.has(x.k) ? tupEditor(x) : ""}</div>`).join("")
    || `<div class="tempty">${rows.length ? "Tidak ada baris yang cocok dengan saringan." : (tupMode === "up" ? `Belum ada detil UP di bulan ${BULAN[tupM]}. Tambahkan detil POK yang dibayar dengan UP di bawah.` : `Belum ada detil dengan RPD di bulan ${BULAN[tupM]}. Isi RPD dulu, atau tambahkan detil di bawah.`)}</div>`;
  const hd = tupHidden(tupM);
  $("#tupHid").hidden = tupMode === "up" || !(hd.a51.length || hd.over.length);
  $("#tupHid").innerHTML = [hd.over.length ? `⚠ <b>${hd.over.length} detil tidak dimunculkan karena RPD melebihi pagu</b> (sisa minus): ${hd.over.slice(0, 4).map(d => esc(d.u.slice(0, 40))).join(", ")}${hd.over.length > 4 ? ", …" : ""}. Perbaiki di tab RPD.` : "",
    hd.a51.length ? `ℹ️ ${hd.a51.length} detil akun 51 (belanja pegawai) tidak dicatat di ${TL()}.` : ""].filter(Boolean).join("<br>");
  const ex = (t.excl || []).map(k => detMap()[k]).filter((d): d is Detil => !!d);
  $("#tupExcl").innerHTML = ex.length ? `Dikeluarkan dari ${TL()} ${BULAN[tupM]}: ${ex.map(d => `<span class="chip">${esc(d.u.slice(0, 50))}<button type="button" class="x" data-tback="${esc(d.key)}" title="Masukkan lagi">↺</button></span>`).join(" ")}` : "";
}
/* perbarui satu baris (bagian ringkas) & ringkasan tanpa menyentuh kolom yang sedang diisi */
function tupRefreshRow(k: string): void {
  if (tupFinSync(tupM)){ const mb = document.querySelector<HTMLElement>(`#tupMonths [data-tm="${tupM}"]`); if (mb) mb.title = "RPD ikut diperbarui (bulan terfinalisasi)"; }
  const rows = tupRows(tupM), x = rows.find(y => y.k === k), el = document.querySelector<HTMLElement>(`#tupTbl .trow[data-k="${CSS.escape(k)}"]`); if (!x || !el) return;
  tupCalcSisa(tupM);
  for (const y of rows) if (y.k !== k && (y.d.key === x.d.key || tupKey(y) === tupKey(x))){ const o = document.querySelector<HTMLElement>(`#tupTbl .trow[data-k="${CSS.escape(y.k)}"] .tr-main`); if (o) o.innerHTML = tupMain(y, rows.indexOf(y)); }   // detil sama → sisa pagu ikut berubah
  el.querySelector(".tr-main")!.innerHTML = tupMain(x, rows.indexOf(x)); el.classList.toggle("tcat", !!x.f.catat); tupSummary(rows);
  const mb = document.querySelector<HTMLElement>(`#tupMonths [data-tm="${tupM}"] b`); if (mb){ const tot = rows.reduce((s0, y) => s0 + y.tup, 0); mb.textContent = tot ? rpShort(tot).replace("Rp ", "") : "–"; }
}
$("#tupMonths").addEventListener("click", e => { const b = tg(e).closest<HTMLInputElement>("[data-tm]"); if (!b) return; tupM = Number(b.dataset.tm); tupOpen.clear(); renderTup(); });
$("#tupSeg").addEventListener("click", e => { const b = tg(e).closest<HTMLInputElement>("[data-flt]"); if (!b) return; tupFlt = b.dataset.flt ?? ""; renderTup(); });
$("#tupTbl").addEventListener("input", e => { const row = tg(e).closest<HTMLInputElement>("[data-k]"); if (!row) return;
  if (tupFinOn()){ toast(tupFinMsg(), "warn"); renderTup(); return; }
  const k0 = row.dataset.k ?? "", d0 = tupRows(tupM).find(y => y.k === k0)?.d, t0 = tupOf(tupM), el = tg(e);
  if (el.hasAttribute("data-tn")){ const v = el.value; if (!v.trim() || v.trim() === d0?.u) delete t0.nama[k0]; else t0.nama[k0] = v; el.classList.toggle("edited", k0 in t0.nama); }
  else if (el.hasAttribute("data-tk")){ const v = el.value; if (v === rpdKetM(k0, tupM)) delete t0.kt[k0]; else t0.kt[k0] = v; el.classList.toggle("edited", k0 in t0.kt); }
  else if (el.dataset.tf === "mak"){ const o = t0.f[k0] ||= {}; if (el.value === d0?.a.mak) delete o.mak; else o.mak = el.value; delete o.det; persistAng(); renderTup();
    const xx = tupRows(tupM).find(y => y.k === k0), dk = xx ? detMap()[tupKey(xx)] : undefined;
    toast(`MAK baris diubah ke ${el.value}${dk && xx && dk.key !== xx.d.key ? ` — realisasi dibebankan ke detil "${dk.u.slice(0, 50)}"` : ""}.`); return; }
  else if (el.dataset.tf === "det"){ const o = t0.f[k0] ||= {}, nk = keyFromInput(el), nd = nk ? detMap()[nk] : undefined; if (!nd || !d0) return;
    if (tupAkun51(nd)){ toast(`Akun 51 (belanja pegawai) tidak dicatat di ${TL()} — pilih detil lain.`, "warn"); return; }
    if (nd.a.mak === d0.a.mak) delete o.mak; else o.mak = nd.a.mak;
    if (nd.key === d0.key) delete o.det; else o.det = nd.key;
    persistAng(); renderTup(); toast(nd.key === d0.key ? "Kembali ke detil & MAK asal." : `Dibebankan ke ${nd.a.mak} — "${nd.u.slice(0, 50)}".`); return; }
  else if (el.dataset.tf){ const o = t0.f[k0] ||= {}, fk = el.dataset.tf; o[fk] = el.value.trim(); if (!o[fk]) delete o[fk]; }
  else if (el.hasAttribute("data-tv")){ t0.val[k0] = num(el.value); el.classList.add("edited"); }
  else return;
  persistAng(); tupRefreshRow(k0); });
$("#tupTbl").addEventListener("input", e => { const el = tg(e); if (el.classList.contains("need") && el.value){ el.classList.remove("need"); el._dmy?.classList.remove("need"); } }, true);
$("#tupTbl").addEventListener("change", e => { const el0 = tg(e); if (el0.classList.contains("need") && el0.value){ el0.classList.remove("need"); el0._dmy?.classList.remove("need"); } if (tg(e).dataset.tc !== "catat") return; const row = tg(e).closest<HTMLInputElement>("[data-k]"); if (!row) return;
  if (tupFinOn()){ tg(e).checked = !tg(e).checked; return toast(tupFinMsg(), "warn"); }
  const k = row.dataset.k ?? "", o = tupOf(tupM).f[k] ||= {};
  if (tg(e).checked){ const rs = tupRows(tupM), me0 = rs.find(y => y.k === k);
    if (me0){ tupCalcSisa(tupM); const ms = tupMissing(me0), mn = tupMinus(me0);
      if (ms.length || mn < 0){ tg(e).checked = false; tupOpen.add(k); renderTup();
        if (ms.length){ const map: Record<string, string> = { "tanggal nota": '[data-tf="nota"]', "tanggal SPBY": '[data-tf="spby"]', "tanggal kuitansi SAKTI": '[data-tf="kui"]', uraian: "[data-tn]", supplier: '[data-tf="sup"]', jumlah: "[data-tv]" };
          setTimeout(() => { for (const m0 of ms){ const sel = map[m0]; const inp = sel && document.querySelector<HTMLInputElement>(`#tupTbl .trow[data-k="${CSS.escape(k)}"] ${sel}`); if (inp){ inp.classList.add("need"); inp._dmy?.classList.add("need"); } } }, 0);
          if (ms.includes("rincian pajak (DPP)") && ms.length === 1) openPajak(k);
          return toast(`Belum bisa ditandai selesai — lengkapi dulu: ${ms.join(", ")}.`, "warn"); }
        return toast(`Belum bisa ditandai selesai — dana pagu detil tidak cukup (kurang Rp ${rupiah(-mn)}). Kurangi jumlah atau ajukan revisi.`, "err"); } }
    const me = me0, nrm = (v: unknown) => String(v || "").trim().toLowerCase().replace(/\s+/g, " ");
    const same = rs.filter(y => y.k !== k && nrm(y.nama) === nrm(me?.nama));
    if (same.length){ tg(e).checked = false; tupOpen.add(k); renderTup(); const el = document.querySelector<HTMLInputElement>(`#tupTbl .trow[data-k="${CSS.escape(k)}"] [data-tn]`); el?.focus(); el?.select();
      return toast(`Uraian sama dengan baris ${same.map(y => rs.indexOf(y) + 1).join(", ")}. Ubah uraian dulu sebelum menandai selesai.`, "warn"); } }
  if (tg(e).checked) o.catat = true; else delete o.catat; persistAng(); toast(tg(e).checked ? "Ditandai selesai dicatat — semua isian baris ini terkunci." : "Tanda selesai dihapus — isian bisa diubah lagi.");
  if (tupFlt || tupOpen.has(k)) renderTup(); else tupRefreshRow(k); });
$("#tupTbl").addEventListener("click", e => {
  const row = tg(e).closest<HTMLInputElement>("[data-k]"); if (!row) return; const k = row.dataset.k ?? "";
  const cp = tg(e).closest<HTMLInputElement>("[data-cp]"); if (cp){ e.preventDefault(); return salin(cp.dataset.cp, cp.dataset.cpl); }
  const cpf = tg(e).closest<HTMLInputElement>("[data-cpf]"); if (cpf){ e.preventDefault(); const f0 = cpf.dataset.cpf ?? "", inp = row.querySelector<HTMLInputElement>(f0 === "tn" ? "[data-tn]" : f0 === "tv" ? "[data-tv]" : `[data-tf="${f0}"]`); return salin(/^(nota|spby|kui)$/.test(f0) ? tglSalin(inp?.value) : inp?.value, cpf.dataset.cpl); }
  const locked = !!TD()[tupM]?.f?.[k]?.catat || tupFinOn();
  if (tupFinOn() && tg(e).closest("[data-tpj],[data-tdup],[data-tx],[data-supuse]")) return toast(tupFinMsg(), "warn");
  if (tg(e).closest("[data-supuse]")){ const x = tupRows(tupM).find(y => y.k === k), s0 = x ? rpdSupGet(x.d.key, tupM) : undefined; if (!s0 || locked) return;
    const o = TD()[tupM]!.f![k] ||= {}; o.sup = s0.t; persistAng(); renderTup(); return toast(`Supplier diisi dari RPD: ${s0.t}`); }
  if (locked && tg(e).closest("[data-tpj],[data-tdup],[data-tx]")) return toast("Baris sudah Selesai — terkunci. Hapus centang ✓ Selesai untuk mengubah.", "warn");
  if (tg(e).closest<HTMLInputElement>("[data-tpj]")) return openPajak(k);
  if (tg(e).closest<HTMLInputElement>("[data-tdup]")){ const t = tupOf(tupM), x = tupRows(tupM).find(y => y.k === k); if (!x) return;
    const id = "dup:" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); t.dup.push({ id, src: x.d.key });
    t.val[id] = x.tup; t.nama[id] = x.nama; if (x.ket) t.kt[id] = x.ket; const f: TupFields = { ...x.f }; delete f.catat; delete f.pajak; delete f.pj; if (Object.keys(f).length) t.f[id] = f;
    tupOpen.add(id); persistAng(); renderTup(); const el = document.querySelector<HTMLInputElement>(`#tupTbl .trow[data-k="${CSS.escape(id)}"] [data-tn]`); el?.focus(); el?.select();
    return toast("Baris diduplikat. Ubah uraian & jumlahnya; uraian harus berbeda sebelum ditandai selesai."); }
  if (tg(e).closest<HTMLInputElement>("[data-tx]")){ const t = tupOf(tupM);
    if (Object.keys(t.f[k] || {}).length && !confirm(`Baris ini sudah berisi tanggal / supplier / pajak / tanda. Tetap keluarkan dari ${TL()} bulan ini?`)) return;
    if (k.startsWith("dup:")){ t.dup = t.dup.filter(x => x.id !== k); delete t.val[k]; delete t.nama[k]; delete t.kt[k]; delete t.f[k]; tupOpen.delete(k); persistAng(); renderTup(); return toast("Baris duplikat dihapus."); }
    if (t.dup.some(x => x.src === k) && !confirm("Detil ini punya baris duplikat. Keluarkan juga semua duplikatnya?")) return;
    for (const dp of t.dup.filter(x => x.src === k)){ delete t.val[dp.id]; delete t.nama[dp.id]; delete t.kt[dp.id]; delete t.f[dp.id]; } t.dup = t.dup.filter(x => x.src !== k);
    t.add = t.add.filter(x => x !== k); if (tupMode === "tup" && num((rpdDB[k] || [])[tupM]) > 0 && !t.excl.includes(k)) t.excl.push(k); delete t.val[k]; delete t.nama[k]; delete t.kt[k]; delete t.f[k]; tupOpen.delete(k); persistAng(); renderTup(); toast(`Detil dikeluarkan dari ${TL()} bulan ini.`); return; }
  if (tg(e).closest<HTMLInputElement>("[data-stop]") || !tg(e).closest<HTMLInputElement>("[data-ttog]")) return;
  tupOpen.has(k) ? tupOpen.delete(k) : tupOpen.add(k); renderTup();
  if (tupOpen.has(k)) document.querySelector<HTMLInputElement>(`#tupTbl .trow[data-k="${CSS.escape(k)}"] [data-tf="nota"]`)?.focus();
});
$("#tupTbl").addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && tg(e).matches(".tr-main")){ e.preventDefault(); tg(e).click(); } });
$("#tupExcl").addEventListener("click", e => { const k = tg(e).closest<HTMLInputElement>("[data-tback]")?.dataset.tback; if (!k) return; if (tupFinOn()) return toast(tupFinMsg(), "warn"); const t = tupOf(tupM); t.excl = t.excl.filter(x => x !== k); persistAng(); renderTup(); });
$("#tupAddBtn").onclick = () => { if (tupFinOn()) return toast(tupFinMsg(), "warn"); const el = $("#tupAdd"), k = keyFromInput(el); if (!k) return toast("Pilih detil dari daftar."); const t = tupOf(tupM), dd = detMap()[k];
  if (tupAkun51(dd)) return toast(`Akun 51 (belanja pegawai) tidak dicatat di ${TL()}.`); if (tupOver(dd)) return toast("RPD detil ini melebihi pagu. Perbaiki dulu di tab RPD.");
  t.excl = t.excl.filter(x => x !== k); if (!t.add.includes(k) && (tupMode === "up" || !num((rpdDB[k] || [])[tupM]))) t.add.push(k); el.value = ""; tupOpen.add(k); persistAng(); renderTup(); toast(`Detil ditambahkan ke ${TL()} ` + BULAN[tupM] + "."); };
$("#tupAdd").addEventListener("keydown", e => { if (e.key === "Enter" && $("#acBox").hidden){ e.preventDefault(); $("#tupAddBtn").click(); } });
$("#tupTgl").addEventListener("input", e => { if (tupFinOn()) return; tupOf(tupM).tgl = tg(e).value.trim(); persistAng(); });
$("#tupKet").addEventListener("input", e => { if (tupFinOn()) return; tupOf(tupM).ket = tg(e).value.trim(); persistAng(); });
$("#tupReset").onclick = () => { if (tupFinOn()) return toast(tupFinMsg(), "warn"); if (!confirm(`Kembalikan nilai ${TL()} ${BULAN[tupM]} sesuai RPD? Perubahan jumlah, uraian, keterangan, detil tambahan & yang dikeluarkan dihapus (tanggal, supplier, pajak & tanda tetap).`)) return; const t = tupOf(tupM); t.val = {}; t.add = []; t.excl = []; t.nama = {}; t.kt = {}; persistAng(); renderTup(); toast("${TL()} dikembalikan sesuai RPD."); };
$("#tupExp").onclick = () => {
  const wb = XLSX.utils.book_new(), one = $<HTMLSelectElement>("#tupScope").value === "bulan";
  for (const m of one ? [tupM] : [...Array(12).keys()]){ const rows = tupRows(m); if (!rows.length && !one) continue; const t: Partial<TupMonth> = TD()[m] || {}, P = (x: TupRow) => tupPj(x.f);
    const ws = XLSX.utils.aoa_to_sheet([[`CATATAN ${TL()} ${BULAN[m].toUpperCase()} ${angYear}`], [t.tgl ? "Tanggal pengajuan: " + t.tgl : "", t.ket || ""], [],
      ["No", "Tanggal Nota", "Tanggal SPBY", "Tanggal Kuitansi SAKTI", "Uraian", "Supplier", "Jumlah", "Kegiatan", "Akun", "Keterangan", "Sudah Catat", "Ada Pajak", "DPP", "PPN", "Jenis PPh", "PPh", "MAK"],
      ...rows.map((x, i) => [i + 1, isoTgl(x.f.nota), isoTgl(x.f.spby), isoTgl(x.f.kui), x.nama, x.f.sup || "", x.tup, `${x.a.ro} ${roTitle(x.a.roNama)}`, `${x.a.akun} ${x.a.nama}`, x.ket, x.f.catat ? "Ya" : "Belum", x.f.pajak ? "Ya" : "Tidak",
        x.f.pajak && x.f.pj ? num(x.f.pj.dpp) : "", x.f.pajak && x.f.pj ? P(x).ppn : "", x.f.pajak && x.f.pj ? x.f.pj.pphJ || "" : "", x.f.pajak && x.f.pj ? P(x).pph : "", x.a.mak]),
      ["", "", "", "", "Jumlah", "", rows.reduce((s0, x) => s0 + x.tup, 0), "", "", "", `${rows.filter(x => x.f.catat).length} dari ${rows.length}`, `${rows.filter(x => x.f.pajak).length}`, "", rows.reduce((s0, x) => s0 + P(x).ppn, 0), "", rows.reduce((s0, x) => s0 + P(x).pph, 0), ""]]);
    ws["!cols"] = [5, 16, 16, 20, 46, 24, 14, 40, 34, 36, 11, 10, 14, 12, 12, 12, 28].map(w => ({ wch: w })); XLSX.utils.book_append_sheet(wb, ws, BULAN[m]); }
  if (!wb.SheetNames.length) return toast(`Belum ada ${TL()} untuk diekspor.`);
  XLSX.writeFile(wb, one ? `${TL()} ${BULAN[tupM]} ${angYear}.xlsx` : `${TL()} ${angYear} (${wb.SheetNames.length} bulan).xlsx`); toast(`${TL()} diekspor.`);
};
/* ---------- pop-up pajak: DPP, PPN, PPh ---------- */
function openPajak(k: string): void {
  const x = tupRows(tupM).find(y => y.k === k); if (!x) return; tupPjKey = k;
  const f = x.f, pj: Partial<TupPajak> = f.pj || {}, dppDef = Math.round(x.tup * 100 / 111);
  $("#pjU").textContent = x.nama; $("#pjJml").textContent = "Rp " + rupiah(x.tup); $("#pjDel").hidden = !f.pajak;
  $<HTMLSelectElement>("#pjPphJ").innerHTML = PPH_J.map(([n, r]) => `<option value="${n}" data-r="${r}">${n}${r ? ` (${String(r).replace(".", ",")}%)` : ""}</option>`).join("");
  $("#pjPpnOn").checked = pj.ppnOn ?? true; $("#pjDpp").value = String(pj.dpp ?? (($("#pjPpnOn").checked) ? dppDef : x.tup));
  $("#pjPpnT").value = String(pj.ppnT ?? 11); $<HTMLSelectElement>("#pjPphJ").value = pj.pphJ || "PPh 22"; $("#pjPphT").value = String(pj.pphT ?? 1.5);
  $("#pjPpn").value = String(pj.ppn ?? ""); $("#pjPph").value = String(pj.pph ?? ""); if (pj.ppn == null) pjCalc("ppn"); if (pj.pph == null) pjCalc("pph");
  pjCalc(); $<HTMLDialogElement>("#dPajak").showModal(); $("#pjDpp").focus(); $("#pjDpp").select();
}
function pjCalc(what?: "ppn" | "pph" | "all"): void {
  const dpp = num($("#pjDpp").value), on = $("#pjPpnOn").checked; $("#pjPpnBox").classList.toggle("off", !on);
  if (what === "ppn" || what === "all") $("#pjPpn").value = String(on ? Math.round(dpp * num($("#pjPpnT").value) / 100) : 0);
  if (what === "pph" || what === "all") $("#pjPph").value = String(Math.round(dpp * num($("#pjPphT").value) / 100));
  const x = tupRows(tupM).find(y => y.k === tupPjKey), ppn = on ? num($("#pjPpn").value) : 0, pph = num($("#pjPph").value);
  $("#pjTot").textContent = "Rp " + rupiah(ppn + pph); $("#pjNet").textContent = "Rp " + rupiah((x ? x.tup : 0) - ppn - pph);
}
$("#pjDpp").addEventListener("input", () => pjCalc("all"));
$("#pjPpnT").addEventListener("input", () => pjCalc("ppn"));
$("#pjPphT").addEventListener("input", () => pjCalc("pph"));
$("#pjPpnOn").addEventListener("change", () => pjCalc("ppn"));
$("#pjPphJ").addEventListener("change", e => { const r = (e.target as HTMLSelectElement).selectedOptions[0]?.dataset.r; if (r && +r) $("#pjPphT").value = r; pjCalc("pph"); });
$("#pjPpn").addEventListener("input", () => pjCalc()); $("#pjPph").addEventListener("input", () => pjCalc());
$("#pjFromJml").onclick = () => { const x = tupRows(tupM).find(y => y.k === tupPjKey); if (!x) return; $("#pjDpp").value = String($("#pjPpnOn").checked ? Math.round(x.tup * 100 / 111) : x.tup); pjCalc("all"); };
$("#pjCancel").onclick = () => $<HTMLDialogElement>("#dPajak").close();
$("#pjSave").onclick = () => { if (tupFinOn()) return toast(tupFinMsg(), "warn"); const o = tupOf(tupM).f[tupPjKey] ||= {};
  o.pajak = true; o.pj = { dpp: num($("#pjDpp").value), ppnOn: $("#pjPpnOn").checked, ppnT: num($("#pjPpnT").value), ppn: $("#pjPpnOn").checked ? num($("#pjPpn").value) : 0, pphJ: $<HTMLSelectElement>("#pjPphJ").value, pphT: num($("#pjPphT").value), pph: num($("#pjPph").value) };
  persistAng(); $<HTMLDialogElement>("#dPajak").close(); if (tupFlt) renderTup(); else tupRefreshRow(tupPjKey); toast("Rincian pajak disimpan."); };
$("#pjDel").onclick = () => { if (!confirm("Hapus tanda & rincian pajak baris ini?")) return; const o: TupFields = tupOf(tupM).f[tupPjKey] || {}; delete o.pajak; delete o.pj; persistAng(); $<HTMLDialogElement>("#dPajak").close(); if (tupFlt) renderTup(); else tupRefreshRow(tupPjKey); toast("Pajak dihapus dari baris ini."); };

