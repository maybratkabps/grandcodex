/* ================= SURAT PERMINTAAN TUP (Daftar Rencana Penggunaan TUP) dari isian RPD ================= */
/** isian kepala surat permintaan TUP */
interface TrHdr { sd?: string; dipa?: string; up?: number | string; tempat?: string; tglIso?: string; kpa?: string }
/** isian per baris (kegiatan|RO|akun) */
interface TrRowSet { tglA?: string; tglB?: string; nama?: string; off?: boolean; [k: string]: string | number | boolean | undefined }
interface TrDB { hdr: TrHdr; m: Record<number, Record<string, TrRowSet>> }
interface TrGroup {
  g: string; keg: string; out: string; ro: string; akun: string; akunNm: string; pagu: number; before: number; val: number; detil: string[];
  sisa: number; sesudah: number; tglA: string; tglB: string; tgl: string; namaDef: string; namaK: string; off: boolean;
}
const trKey = (): string => "st.tupReq." + angYear;
let trDB: TrDB = { hdr: {}, m: {} }, trM = new Date().getMonth();
const trLoad = (): TrDB => { trDB = LS.get<TrDB | null>(trKey(), null) || { hdr: {}, m: {} }; trDB.hdr ||= {}; trDB.m ||= {}; return trDB; };
const trSave = (): boolean => LS.set(trKey(), trDB);
const isoToday = (): string => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const isoD = (v: unknown): Date | null => { const m = String(v || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
/* rentang tanggal → "2 – 20 November 2026" · "28 Oktober – 3 November 2026" · "30 Desember 2026 – 2 Januari 2027" */
function fmtRange(a: string | undefined, b: string | undefined): string {
  const A = isoD(a); if (!A) return ""; const B = isoD(b) || A;
  if (+B === +A) return fmtDate(A);
  const [x, y] = B < A ? [B, A] : [A, B];
  if (x.getFullYear() !== y.getFullYear()) return `${fmtDate(x)} – ${fmtDate(y)}`;
  if (x.getMonth() !== y.getMonth()) return `${x.getDate()} ${BULAN[x.getMonth()]} – ${fmtDate(y)}`;
  return `${x.getDate()} – ${fmtDate(y)}`;
}
const joinDan = (xs0: string[]): string => { const xs = [...new Set(xs0.map(s => String(s).trim()).filter(Boolean))]; return xs.length < 2 ? (xs[0] || "") : xs.slice(0, -1).join(", ") + " dan " + xs[xs.length - 1]; };
const kpaList = (): Pegawai[] => roleHolders(["KEPALA"]);
const trHdr = (): Required<Pick<TrHdr, "sd" | "dipa" | "up" | "tempat" | "tglIso" | "kpa">> => { const h = trDB.hdr, k = kpaList();
  const kpa = h.kpa && k.some((p: Pegawai) => String(p.kode) === String(h.kpa)) ? String(h.kpa) : (k[0] ? String(k[0].kode) : "");
  return { sd: h.sd ?? "RM", dipa: h.dipa ?? `DIPA-054.01.2.690691/${angYear}`, up: h.up ?? "", tempat: h.tempat ?? "Maybrat", tglIso: h.tglIso || trDefTgl(), kpa }; };
const trDefTgl = (): string => { const t = isoToday(), mo = `${angYear}-${String(trM + 1).padStart(2, "0")}`; return t.startsWith(mo) ? t : `${mo}-01`; };
const isoDt = (d: Date): string => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
/* rentang sah tanggal kegiatan: tanggal surat permintaan TUP s.d. 30 hari sesudahnya */
const TR_MAXD = 30;
function trWin(): { a: string; b: string; A: Date; B: Date; txt: string } { const d0 = isoD(trHdr().tglIso) || new Date(), d1 = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + TR_MAXD); return { a: isoDt(d0), b: isoDt(d1), A: d0, B: d1, txt: `${fmtDate(d0)} – ${fmtDate(d1)}` }; }
function trSuratErr(): string { const d = isoD(trHdr().tglIso); if (!d) return "Pilih tanggal surat."; if (String(d.getFullYear()) !== String(angYear)) return `Tanggal surat harus di tahun anggaran ${angYear} (terpilih tahun ${d.getFullYear()}).`; return ""; }
function trTglErr(a: string, b: string): string {
  if (!a) return ""; const w = trWin(), A = isoD(a); if (!A) return "Tanggal tidak valid."; const B = isoD(b) || A;
  if (String(A.getFullYear()) !== String(angYear) || String(B.getFullYear()) !== String(angYear)) return `Tahun salah: TUP ${angYear}, terpilih tahun ${(String(A.getFullYear()) !== String(angYear) ? A : B).getFullYear()}.`;
  if (a < w.a) return `Tidak boleh sebelum tanggal surat (${fmtDate(w.A)}).`;
  if ((b || a) > w.b) return `Maksimal ${TR_MAXD} hari dari tanggal surat (s.d. ${fmtDate(w.B)}).`;
  return "";
}
/* baris = kegiatan + output (KRO.RO) + akun; nilai dari RPD bulan m */
function trGroups(m: number): TrGroup[] {
  type G0 = Pick<TrGroup, "g" | "keg" | "out" | "ro" | "akun" | "akunNm" | "pagu" | "before" | "val" | "detil">;
  const G = new Map<string, G0>();
  for (const d of pokDetil()){
    if (d.blokir || tupAkun51(d)) continue;
    const a = d.a, g = `${a.keg}|${a.ro}|${a.akun}`, r = rpdDB[d.key] || [];
    const o: G0 = G.get(g) || { g, keg: a.keg, out: a.ro.split(".").slice(1).join("."), ro: a.ro, akun: a.akun, akunNm: a.nama, pagu: 0, before: 0, val: 0, detil: [] };
    o.pagu += d.j; for (let i = 0; i < m; i++) o.before += num(r[i]);
    const v = num(r[m]); if (v > 0 && !tupOver(d)){ o.val += v; o.detil.push(d.u); }
    G.set(g, o);
  }
  const ov = (trDB.m[m] || {});
  return [...G.values()].filter(o => o.val > 0).map((o): TrGroup => { const s: TrRowSet = ov[o.g] || {}, sis = o.pagu - o.before, val = o.val;   // sesuai RPD — tidak bisa diubah di sini
    return { ...o, sisa: sis, val, sesudah: sis - val, tglA: s.tglA || "", tglB: s.tglB || "", tgl: fmtRange(s.tglA, s.tglB), namaDef: joinDan(o.detil), namaK: s.nama ?? joinDan(o.detil), off: !!s.off }; })
    .sort((x, y) => x.keg.localeCompare(y.keg) || x.ro.localeCompare(y.ro) || x.akun.localeCompare(y.akun));
}
function trRender(): void {
  const h = trHdr(), rows = trGroups(trM), on = rows.filter(x => !x.off);
  $<HTMLSelectElement>("#trMonth").innerHTML = BULAN.map((b, i) => `<option value="${i}" ${i === trM ? "selected" : ""}>${b} ${angYear}</option>`).join("");
  for (const [id, k] of [["#trSd", "sd"], ["#trDipa", "dipa"], ["#trUp", "up"], ["#trTempat", "tempat"], ["#trTgl", "tglIso"]] as [string, keyof ReturnType<typeof trHdr>][]) if (document.activeElement !== $(id)) $(id).value = String(h[k]);
  $("#trTglTxt").textContent = fmtDate(isoD(h.tglIso) || new Date());
  const k = kpaList();
  $<HTMLSelectElement>("#trKpa").innerHTML = k.length ? k.map((p: Pegawai) => `<option value="${esc(p.kode)}" ${String(p.kode) === h.kpa ? "selected" : ""}>${esc(p.nama)}</option>`).join("") : `<option value="">— belum ada pegawai berperan Kepala Kantor —</option>`;
  $("#trKpaHint").hidden = !!k.length;
  const W0 = trWin(); $("#trWin").textContent = `Rentang sah: ${W0.txt} (maks. ${TR_MAXD} hari dari tanggal surat)`;
  { const se = trSuratErr(); $("#trTglErr").textContent = se; $("#trTglErr").hidden = !se; $("#trTgl").classList.toggle("err", !!se); }
  $("#trRows").innerHTML = on.length ? on.map((x, i) => `<tr data-g="${esc(x.g)}" class="${x.tglA ? "" : "need"} ${x.sesudah < 0 ? "neg" : ""} ${trTglErr(x.tglA, x.tglB) ? "tglerr" : ""}"><td class="muted">${i + 1}</td>
      <td><div class="trk"><b>${esc(x.keg)}</b> · ${esc(x.out)} · <b>${esc(x.akun)}</b></div><div class="lsub one">${esc(x.akunNm)} · ${x.detil.length} detil</div></td>
      <td class="num" title="Pagu ${rupiah(x.pagu)} − RPD bulan sebelumnya ${rupiah(x.before)}"><b>${rupiah(x.sisa)}</b><div class="lsub">pagu − RPD s.d. ${BLN3[Math.max(0, trM - 1)]}</div></td>
      <td class="num"><b>${rupiah(x.val)}</b><div class="lsub">RPD ${BLN3[trM]}</div></td>
      <td class="num ${x.sesudah < 0 ? "bad" : ""}" data-sesudah>${rupiah(x.sesudah)}${x.sesudah < 0 ? `<div class="lsub bad">tidak boleh minus</div>` : ""}</td>
      <td><div class="trdr"><input type="date" data-trf="tglA" value="${esc(x.tglA)}" min="${W0.a}" max="${W0.b}" aria-label="Tanggal mulai" title="Tanggal mulai (${W0.txt})"><span>s.d.</span><input type="date" data-trf="tglB" value="${esc(x.tglB)}" min="${esc(x.tglA || W0.a)}" max="${W0.b}" aria-label="Tanggal selesai" title="Tanggal selesai (kosong = 1 hari)"></div>${trTglTxt(x.tglA, x.tglB)}</td>
      <td><textarea rows="2" data-trf="nama" title="Bawaan: gabungan nama detil">${esc(x.namaK)}</textarea>${x.namaK !== x.namaDef ? `<button type="button" class="linkbtn" data-trdef>kembalikan ke nama detil</button>` : ""}</td>
      <td><button class="ib del" type="button" data-troff title="Jangan masukkan baris ini">${IC.del}</button></td></tr>`).join("")
    : `<tr><td colspan="8" class="muted" style="text-align:center;padding:20px">Tidak ada RPD di bulan ${BULAN[trM]} ${angYear} (akun 51 &amp; detil yang RPD-nya melebihi pagu tidak dihitung). Isi RPD bulan ini dulu.</td></tr>`;
  $("#trAllA").min = $("#trAllB").min = W0.a; $("#trAllA").max = $("#trAllB").max = W0.b;
  trSumOnly();
}
function trSumOnly(): void {
  const h = trHdr(), rows = trGroups(trM), on = rows.filter(x => !x.off), off = rows.length - on.length;
  const tot = on.reduce((s0, x) => s0 + x.val, 0), up = num(h.up), need = on.filter(x => !x.tglA).length, neg = on.filter(x => x.sesudah < 0).length, bad = on.filter(x => trTglErr(x.tglA, x.tglB)).length, se = trSuratErr();
  $("#trSum").innerHTML = `<span>Rencana TUP <b>Rp ${rupiah(tot)}</b></span><span>UP Satker <b>Rp ${rupiah(up)}</b></span><span class="${tot - up < 0 ? "bad" : ""}">Total TUP <b>Rp ${rupiah(tot - up)}</b></span>${tot - up < 0 ? `<span class="bad">⚠ Total TUP tidak boleh minus — UP Satker melebihi rencana TUP</span>` : ""}${neg ? `<span class="bad">⚠ ${neg} baris sisa pagu setelah TUP minus</span>` : ""}${se ? `<span class="bad">⚠ ${esc(se)}</span>` : ""}${bad ? `<span class="bad">⚠ ${bad} baris tanggal kegiatan di luar rentang</span>` : ""}${need ? `<span class="bad">⚠ ${need} baris belum diisi tanggal kegiatan</span>` : on.length && !bad && !se ? `<span class="ok">✓ Tanggal kegiatan lengkap</span>` : ""}${off ? `<button type="button" class="linkbtn" id="trOn">Tampilkan lagi ${off} baris yang dikeluarkan</button>` : ""}`;
}
const trTglTxt = (a: string, b: string): string => { const e = trTglErr(a, b); return `<div class="lsub ${e ? "bad" : ""}" data-tgltxt>${e ? "⚠ " + esc(e) : esc(fmtRange(a, b)) || "pilih tanggal mulai &amp; selesai"}</div>`; };
function trSet(g: string, k: string, v: string | number | boolean | null): void { const o = (trDB.m[trM] ||= {})[g] ||= {}; if (v === "" || v == null) delete o[k]; else o[k] = v; trSave(); }
function openTupReq(): void {
  trLoad(); trM = Math.max(0, Math.min(11, LS.get("st.trM", new Date().getMonth())));
  $("#trPrev").hidden = true; $("#trPrevDoc").innerHTML = ""; trRender(); $<HTMLDialogElement>("#dTupReq").showModal();
}
/* ---------- isi template .docx ---------- */
const TR_FONT = "Arial", TR_SZ = 18, TR_SZ_TITLE = 24;   // 9 pt isi, 12 pt judul (half-point)
async function buildTupReq(): Promise<Blob> {
  const h = trHdr(), rows = trGroups(trM).filter(x => !x.off), kpa: Partial<Pegawai> = pegawai.find(p => String(p.kode) === String(h.kpa)) || {};
  const zip = await JSZip.loadAsync(TUPREQ_TPL, { base64: true }), xml = await zip.file("word/document.xml")!.async("string");
  const doc = new DOMParser().parseFromString(xml, "application/xml"), W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
  /* elemen anak WordprocessingML dengan nama lokal tertentu */
  const ch = (el: Element, tag: string): Element[] => [...el.children].filter(n => n.localName === tag);
  const ts = (el: Element): Element[] => [...el.getElementsByTagNameNS(W, "t")];
  const txt = (el: Element): string => ts(el).map(t => t.textContent).join("");
  const rTxt = (r: Element): string => ch(r, "t").map(t => t.textContent).join("");
  const isTab = (r: Element): boolean => !!ch(r, "tab").length && !ch(r, "t").length;
  const mk = (tag: string, val?: string | number): Element => { const e = doc.createElementNS(W, "w:" + tag); if (val != null) e.setAttributeNS(W, "w:val", String(val)); return e; };
  const setT = (r: Element, v: string): void => { const t = ch(r, "t"); if (t.length){ t[0].textContent = v; t[0].setAttribute("xml:space", "preserve"); t.slice(1).forEach(x => x.remove()); } else { const n = doc.createElementNS(W, "w:t"); n.setAttribute("xml:space", "preserve"); n.textContent = v; r.appendChild(n); } };
  const body = doc.getElementsByTagNameNS(W, "body")[0], kids = [...body.children];
  const para = (s: string): Element | undefined => kids.find(k => k.localName === "p" && txt(k).includes(s));
  const pNip = para("(21)"), pT1 = para("FORMAT RENCANA"), pT2 = para("DAFTAR RENCANA PENGGUNAAN");
  /* "Label : ....(N)" → "Label : nilai" — semua tab (bertitik) setelah titik dua dibuang */
  const fillColon = (p: Element | undefined, v: string, bold?: boolean): void => { if (!p) return; const rs = ch(p, "r"), ic = rs.findIndex(r => rTxt(r).trim() === ":"); if (ic < 0) return;
    setT(rs[ic], ": "); let set = false;
    for (const r of rs.slice(ic + 1)){ if (ch(r, "tab").length && !ch(r, "t").length){ r.remove(); continue; } if (!rTxt(r)) continue;
      if (!set){ setT(r, v); set = true; if (bold){ const pr = ch(r, "rPr")[0] || r.insertBefore(mk("rPr"), r.firstChild); pr.appendChild(mk("b")); } } else r.remove(); } };
  fillColon(para("Kode Satker"), "690691"); fillColon(para("Nama Satker"), "BPS Kabupaten Maybrat"); fillColon(para("Nomor DIPA"), h.dipa); fillColon(para("Sumber Dana"), h.sd);
  const tot = rows.reduce((s0, x) => s0 + x.val, 0), up = num(h.up);
  fillColon(para("Rencana TUP"), "Rp " + rupiah(tot)); fillColon(para("UP Satker"), "Rp " + rupiah(up)); fillColon(para("Total TUP"), "Rp " + rupiah(tot - up), true);
  { const p = para("(17)"); if (p){ const rs = ch(p, "r").filter(r => rTxt(r)); if (rs[0]){ setT(rs[0], `${h.tempat}, ${fmtDate(isoD(h.tglIso) || new Date())}`); rs.slice(1).forEach(r => r.remove()); } } }
  { const p = para("(19)"); if (p){ const rs = ch(p, "r"); rs.filter(r => rTxt(r).includes("(19)")).forEach(r => r.remove()); rs.filter(isTab).slice(1).forEach(r => r.remove()); } }
  { const p = para("(20)"); if (p){ const rs = ch(p, "r"); rs.filter(isTab).slice(1).forEach(r => r.remove()); const r = rs.find(r => rTxt(r).includes("(20)")); if (r){ setT(r, kpa.nama || ""); const pr = ch(r, "rPr")[0] || r.insertBefore(mk("rPr"), r.firstChild); pr.appendChild(mk("b")); pr.appendChild(mk("u", "single")); } } }
  { const p = pNip; if (p){ const rs = ch(p, "r"), i = rs.findIndex(r => rTxt(r).trim() === "NIP"); if (i >= 0){ setT(rs[i], "NIP. " + (kpa.nip || "")); rs.slice(i + 1).forEach(r => r.remove()); } } }
  // buang "Petunjuk pengisian" (halaman 3–4 template)
  { const all = [...body.children], i = pNip ? all.indexOf(pNip) : -1; if (i >= 0) all.slice(i + 1).filter(n => n.localName !== "sectPr").forEach(n => n.remove()); }
  // tabel
  const tbl = body.getElementsByTagNameNS(W, "tbl")[0], trs = ch(tbl, "tr"), tplRow = trs[3], totRow = trs[trs.length - 1];
  const cellSet = (tc: Element, v: string): void => { const ps = ch(tc, "p"), p = ps[0]; ps.slice(1).forEach(x => x.remove());
    const rs = [...p.getElementsByTagNameNS(W, "r")].filter(r => ch(r, "t").length);
    if (rs.length){ setT(rs[0], v); rs.slice(1).forEach(r => r.remove()); return; }
    const r = doc.createElementNS(W, "w:r"), mark = ch(p, "pPr")[0] && ch(ch(p, "pPr")[0], "rPr")[0];
    if (mark){ const pr = doc.createElementNS(W, "w:rPr"); [...mark.childNodes].forEach(n => pr.appendChild(n.cloneNode(true))); r.appendChild(pr); }
    setT(r, v); p.appendChild(r); };
  const jc = (tc: Element, v: string): void => { const p = ch(tc, "p")[0]; let pp = ch(p, "pPr")[0]; if (!pp){ pp = mk("pPr"); p.insertBefore(pp, p.firstChild); } ch(pp, "jc").forEach(x => x.remove()); const r = ch(pp, "rPr")[0]; pp.insertBefore(mk("jc", v), r || null); };
  // baris nomor kolom: (5) … (13)
  ch(trs[2], "tc").forEach((tc, j) => { cellSet(tc, `(${j + 5})`); jc(tc, "center"); });
  const list = rows.length ? rows : [null];
  list.forEach((x, i) => { const tr = tplRow.cloneNode(true) as Element, tcs = ch(tr, "tc");
    const vals = x ? [String(i + 1), x.keg, x.out, x.akun, rupiah(x.sisa), rupiah(x.val), rupiah(x.sisa - x.val), x.tgl, x.namaK] : ["", "", "", "", "", "", "", "", ""];
    tcs.forEach((tc, j) => { cellSet(tc, vals[j] ?? ""); jc(tc, j <= 3 ? "center" : j <= 6 ? "right" : "left");
      let pr = ch(tc, "tcPr")[0]; if (!pr){ pr = mk("tcPr"); tc.insertBefore(pr, tc.firstChild); } ch(pr, "vAlign").forEach(x => x.remove()); pr.appendChild(mk("vAlign", "center")); });
    let trPr = ch(tr, "trPr")[0]; if (!trPr){ trPr = mk("trPr"); const ex = ch(tr, "tblPrEx")[0]; tr.insertBefore(trPr, ex ? ex.nextSibling : tr.firstChild); }
    if (!ch(trPr, "cantSplit").length) trPr.insertBefore(mk("cantSplit"), trPr.firstChild);
    tbl.insertBefore(tr, totRow); });
  trs.slice(3, trs.length - 1).forEach(r => r.remove());
  { const tcs = ch(totRow, "tc"), sis = rows.reduce((s0, x) => s0 + x.sisa, 0); if (tcs.length >= 4){ cellSet(tcs[1], rupiah(sis)); cellSet(tcs[2], rupiah(tot)); cellSet(tcs[3], rupiah(sis - tot)); [1, 2, 3].forEach(j => jc(tcs[j], "right")); tcs.forEach(tc => { let pr = ch(tc, "tcPr")[0]; if (!pr){ pr = mk("tcPr"); tc.insertBefore(pr, tc.firstChild); } ch(pr, "vAlign").forEach(x => x.remove()); pr.appendChild(mk("vAlign", "center")); }); } }
  /* seragamkan huruf: satu jenis & satu ukuran; judul sedikit lebih besar & tebal */
  const fmtRun = (pr: Element, sz: number, bold: boolean): void => { ch(pr, "rFonts").forEach(x => x.remove()); const f = mk("rFonts"); for (const a of ["ascii", "hAnsi", "cs", "eastAsia"]) f.setAttributeNS(W, "w:" + a, TR_FONT); pr.insertBefore(f, pr.firstChild);
    for (const t of ["sz", "szCs", "color"]) ch(pr, t).forEach(x => x.remove()); pr.appendChild(mk("color", "000000")); pr.appendChild(mk("sz", sz)); pr.appendChild(mk("szCs", sz));
    if (bold && !ch(pr, "b").length) pr.insertBefore(mk("b"), f.nextSibling); };
  const titles = new Set([pT1, pT2].filter((t): t is Element => !!t));
  for (const r of [...body.getElementsByTagNameNS(W, "r")]){ const title = [...titles].some(t => t.contains(r));
    let pr = ch(r, "rPr")[0]; if (!pr){ pr = mk("rPr"); r.insertBefore(pr, r.firstChild); } fmtRun(pr, title ? TR_SZ_TITLE : TR_SZ, title); }
  for (const pp of [...body.getElementsByTagNameNS(W, "pPr")]){ const mr = ch(pp, "rPr")[0]; if (mr) fmtRun(mr, [...titles].some(t => t.contains(pp)) ? TR_SZ_TITLE : TR_SZ, false); }
  for (const t of titles){ const pp = ch(t, "pPr")[0] || t.insertBefore(mk("pPr"), t.firstChild); ch(pp, "jc").forEach(x => x.remove()); const r = ch(pp, "rPr")[0]; pp.insertBefore(mk("jc", "center"), r || null); }
  zip.file("word/document.xml", new XMLSerializer().serializeToString(doc));
  return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
}
const trFile = (): string => `Rencana Penggunaan TUP ${BULAN[trM]} ${angYear}.docx`;
$("#rpdTupReq").onclick = openTupReq;
$("#trClose").onclick = () => $<HTMLDialogElement>("#dTupReq").close();
$("#trMonth").addEventListener("change", e => { trM = +tg(e).value; LS.set("st.trM", trM); $("#trPrev").hidden = true; trRender(); });
for (const [id, k] of [["#trSd", "sd"], ["#trDipa", "dipa"], ["#trUp", "up"], ["#trTempat", "tempat"], ["#trTgl", "tglIso"], ["#trKpa", "kpa"]] as [string, keyof TrHdr][])
  $(id).addEventListener(id === "#trKpa" || id === "#trTgl" ? "change" : "input", e => { const v = tg(e).value; if (k === "up") trDB.hdr.up = num(v); else trDB.hdr[k] = v.trim(); trSave();
    if (k === "up") trSumOnly(); if (k === "tglIso"){ const d = isoD(v); $("#trTglTxt").textContent = d ? fmtDate(d) : ""; trRender(); const se = trSuratErr(); if (se) toast(se, "err"); } });
$("#trRows").addEventListener("input", e => { const f = tg(e).dataset.trf, tr = tg(e).closest<HTMLInputElement>("tr[data-g]"); if (!f || !tr || /^tgl/.test(f)) return;
  trSet(tr.dataset.g ?? "", f, f === "sisa" || f === "val" ? (tg(e).value === "" ? null : num(tg(e).value)) : tg(e).value);
  const x = trGroups(trM).find(y => y.g === tr.dataset.g); if (x){ const c = tr.querySelector<HTMLElement>("[data-sesudah]")!; c.innerHTML = rupiah(x.sesudah) + (x.sesudah < 0 ? `<div class="lsub bad">tidak boleh minus</div>` : ""); c.classList.toggle("bad", x.sesudah < 0); tr.classList.toggle("neg", x.sesudah < 0); }
  trSumOnly(); });
$("#trRows").addEventListener("change", e => { const f = tg(e).dataset.trf, tr = tg(e).closest<HTMLInputElement>("tr[data-g]"); if (!f || !tr || !/^tgl/.test(f)) return; const g = tr.dataset.g ?? "";
  trSet(g, f, tg(e).value);
  const a = tr.querySelector<HTMLInputElement>("[data-trf=tglA]")!, b = tr.querySelector<HTMLInputElement>("[data-trf=tglB]")!;
  if (f === "tglA"){ b.min = a.value; if (b.value && a.value && b.value < a.value){ b.value = a.value; trSet(g, "tglB", a.value); } }
  if (f === "tglB" && a.value && b.value && b.value < a.value){ b.value = a.value; trSet(g, "tglB", a.value); toast("Tanggal selesai tidak boleh sebelum tanggal mulai."); }
  tr.classList.toggle("need", !a.value); const er = trTglErr(a.value, b.value); tr.classList.toggle("tglerr", !!er); tr.querySelector("[data-tgltxt]")!.outerHTML = trTglTxt(a.value, b.value);
  if (er) toast("Tanggal kegiatan: " + er, "err"); trSumOnly(); });
$("#trRows").addEventListener("click", e => {
  const d = tg(e).closest<HTMLInputElement>("[data-trdef]"); if (d){ trSet(d.closest<HTMLInputElement>("tr")?.dataset.g ?? "", "nama", null); trRender(); return; }
  const b = tg(e).closest<HTMLInputElement>("[data-troff]"); if (!b) return; trSet(b.closest<HTMLInputElement>("tr")?.dataset.g ?? "", "off", true); trRender(); toast("Baris dikeluarkan dari surat permintaan TUP."); });
$("#trSum").addEventListener("click", e => { if (tg(e).id !== "trOn") return; for (const o of Object.values(trDB.m[trM] || {})) delete o.off; trSave(); trRender(); });
$("#trAllBtn").onclick = () => { const a = $("#trAllA").value, b = $("#trAllB").value; if (!a) return toast("Pilih dulu tanggal mulai kegiatan.");
  if (b && b < a) return toast("Tanggal selesai tidak boleh sebelum tanggal mulai.");
  { const er = trTglErr(a, b); if (er) return toast("Tanggal kegiatan: " + er, "err"); }
  for (const x of trGroups(trM)) if (!x.off){ trSet(x.g, "tglA", a); trSet(x.g, "tglB", b || ""); } trRender(); toast(`Tanggal kegiatan ${fmtRange(a, b)} diterapkan ke semua baris.`); };
$("#trPrevBtn").onclick = async () => {
  const host = $("#trPrevDoc"); $("#trPrev").hidden = false; host.innerHTML = `<p class="muted" style="padding:16px">Menyiapkan pratinjau…</p>`;
  try{ const blob = await buildTupReq(); host.innerHTML = ""; await docx.renderAsync(blob, host, host, { inWrapper: true, breakPages: true, ignoreLastRenderedPageBreak: true, experimental: true, className: "docx" });
    $("#trPrev").scrollIntoView({ behavior: "smooth", block: "start" }); }
  catch(err){ console.error(err); host.innerHTML = `<p class="bad" style="padding:16px">Gagal membuat pratinjau: ${esc((err as Error).message)}</p>`; }
};
$("#trDl").onclick = async () => {
  const rows = trGroups(trM).filter(x => !x.off); if (!rows.length) return toast("Tidak ada RPD di bulan ini untuk dimintakan TUP.");
  if (!trHdr().kpa) return toast("Belum ada pegawai berperan Kepala Kantor. Atur peran di Database › Pegawai & Mitra.");
  const negR = rows.filter(x => x.sesudah < 0); if (negR.length){ $$<HTMLElement>("#trRows tr.neg")[0]?.scrollIntoView({ block: "center" }); return toast(`Sisa pagu setelah TUP tidak boleh minus (${negR.length} baris). Perbaiki isian RPD-nya di tab RPD.`, "warn"); }
  { const tt = rows.reduce((s0, x) => s0 + x.val, 0) - num(trHdr().up); if (tt < 0){ $("#trUp").focus(); return toast("Total TUP tidak boleh minus: UP Satker melebihi rencana TUP.", "warn"); } }
  { const se = trSuratErr(); if (se){ $("#trTgl").focus(); return toast(se, "err"); } }
  { const bad = rows.filter(x => trTglErr(x.tglA, x.tglB)); if (bad.length){ $$("#trRows tr.tglerr [data-trf=tglA]")[0]?.focus(); return toast(`${bad.length} baris tanggal kegiatan di luar rentang ${trWin().txt}. Perbaiki dulu.`, "err"); } }
  const need = rows.filter(x => !x.tglA).length;
  if (need){ $$("#trRows tr.need [data-trf=tglA]")[0]?.focus(); return toast(`Pilih dulu tanggal kegiatan (${need} baris belum diisi).`); }
  try{ download(await buildTupReq(), trFile()); toast("Surat permintaan TUP diunduh."); }catch(err){ console.error(err); toast("Gagal membuat dokumen: " + (err as Error).message); }
};

