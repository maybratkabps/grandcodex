/* ================= PERMINTAAN REVISI ================= */
let revEdit: string | null = null;
/** isian formulir revisi: tgl, nama, vol, sat, harga, ket (+ kunci detil terpilih) */
interface RevForm { tgl?: string; nama?: string; vol?: string; sat?: string; harga?: string; ket?: string; key: string | null }
function revForm(): RevForm {
  const o: Record<string, string> = {}; $$("#revForm [data-rv]").forEach(e => { if (e.dataset.rv) o[e.dataset.rv] = e.value.trim(); });
  return { ...o, key: keyFromInput($("#revDet")) };
}
const revDetil = (f: RevForm): Detil | undefined => f.key ? detMap()[f.key] : undefined;
const revBaruMode = (): boolean => document.querySelector<HTMLInputElement>('#revForm input[name="revMode"]:checked')?.value === "baru";
const revMakAkun = (): PokAkun | undefined => { const v = normMak($("#revMak").value); return angPok().akun.find(a => normMak(a.mak) === v); };
function revModeUI(): void { const b = revBaruMode(); $("#revDetWrap").hidden = b; $("#revMakWrap").hidden = !b; $("#revNama").placeholder = b ? "Nama detil baru (wajib)" : "(kosong = sama dengan nama lama)"; }
/** nilai sebelum revisi: tersimpan di permintaan, atau (data lama) diambil dari POK */
function revPrevOf(x: Revisi): { vol: number; sat: string; harga: number; jml: number } {
  if (x.baru) return { vol: 0, sat: "", harga: 0, jml: 0 };
  const d = detMap()[x.key];
  return { vol: x.volLama ?? num(d?.v), sat: x.satLama ?? (d?.s || ""), harga: x.hargaLama ?? num(d?.h), jml: x.jmlLama };
}
const revPrevTxt = (v: { vol: number; sat: string; harga: number; jml: number }): string => v.vol ? `${v.vol.toLocaleString("id-ID")} ${esc(v.sat)} × Rp ${rupiah(v.harga)} = Rp ${rupiah(v.jml)}` : "Rp " + rupiah(v.jml);
function revPrevUI(d?: Detil, baru?: boolean): void {   // hanya referensi: teks biasa, tidak bisa diklik / disalin
  $("#revVol0").textContent = baru ? "0" : d ? (num(d.v) ? num(d.v).toLocaleString("id-ID") : "–") : "";
  $("#revSat0").textContent = baru ? "– (detil baru)" : d ? d.s || "–" : "";
  $("#revHarga0").textContent = baru ? "Rp 0" : d ? (num(d.h) ? "Rp " + rupiah(num(d.h)) : "–") : "";
  $("#revJml0").textContent = baru ? "Rp 0" : d ? "Rp " + rupiah(d.j) : "";
}
/** selisih usulan − pagu detil POK: lebih (merah) / kurang (hijau) */
const revLK = (s: number): string => s > 0 ? `<span class="rv-lebih" title="Usulan lebih dari pagu detil POK">Lebih Rp ${rupiah(s)}</span>` : s < 0 ? `<span class="rv-kurang" title="Usulan kurang dari pagu detil POK">Kurang Rp ${rupiah(-s)}</span>` : `<span class="muted">sama</span>`;
const revSys = (): "SAKTI" | "BOS" | "SAKTI+BOS" => (document.querySelector<HTMLInputElement>('#revForm input[name="revSys"]:checked')?.value || "SAKTI") as "SAKTI" | "BOS" | "SAKTI+BOS";
const revSysSet = (v?: string): void => { const el = document.querySelector<HTMLInputElement>(`#revForm input[name="revSys"][value="${v || "SAKTI"}"]`); if (el) el.checked = true; };
const revSysTag = (x: Revisi): string => (x.sistem || "SAKTI").split("+").map(s0 => `<span class="tag">${s0}</span>`).join(" ");
function revPreview(): void {
  const f = revForm(), jb = num(f.vol) * num(f.harga);
  revPrevUI(revBaruMode() ? undefined : revDetil(f), revBaruMode());
  if (revBaruMode()){ const a = revMakAkun(), mk = $("#revMak").value.trim();
    $("#revMakInfo").innerHTML = a ? `${esc(a.nama)} · ${esc(a.ro)} ${esc(roTitle(a.roNama))} · pagu MAK <b>Rp ${rupiah(a.pagu)}</b> · ${a.items.length} detil saat ini` : mk ? `<span class="bad">MAK tidak ada di POK ${esc(angYear)} — pilih dari daftar</span>` : `<span class="muted">Pilih MAK tempat detil baru ditambahkan.</span>`;
    $("#revJml").value = jb ? "Rp " + rupiah(jb) : ""; $("#revSel").innerHTML = jb ? `Keterangan: ${revLK(jb)}` : ""; return; }
  const d = revDetil(f);
  $("#revCur").innerHTML = d ? `Saat ini: <b>${esc(d.u)}</b> ${volTxt(d)} · ${esc(d.a.mak)} · ${esc(d.a.nama)} · <b>Rp ${rupiah(d.j)}</b>${d.blokir ? ` · <span class="bad">blokir</span>` : ""}` : `<span class="muted">Pilih detil POK yang ingin direvisi.</span>`;
  $("#revJml").value = jb ? "Rp " + rupiah(jb) : "";
  $("#revSel").innerHTML = d && jb ? `Keterangan: ${revLK(jb - d.j)}` : "";
}
$("#revForm").addEventListener("input", e => { if (tg(e).id === "revDet") tg(e).dataset.key = ""; revPreview(); });
$("#revForm").addEventListener("change", e => { if (tg(e).name === "revMode"){ revModeUI(); revPreview(); } });
$("#revForm").addEventListener("change", e => { if (tg(e).id === "revDet"){ const k = keyFromInput(tg(e)), d = k ? detMap()[k] : undefined; if (d){ if (!$("#revNama").value) $("#revNama").value = d.u;
    if (!$("#revVol").value && !$("#revHarga").value){ if (num(d.v)) $("#revVol").value = String(num(d.v)); if (num(d.h)) $("#revHarga").value = String(num(d.h)); if (!$("#revSat").value) $("#revSat").value = d.s || ""; } } } revPreview(); });
function revReset(): void { revEdit = null; $$("#revForm [data-rv]").forEach(e => e.value = ""); $("#revDet").value = ""; $("#revDet").dataset.key = ""; $("#revMak").value = ""; document.querySelector<HTMLInputElement>('#revForm input[name="revMode"][value="ubah"]')!.checked = true; revModeUI(); revSysSet(); $("#revTgl").value = today(); $("#revSave").textContent = "Tambah permintaan revisi"; $("#revCancel").hidden = true; revPreview(); }
$("#revSave").onclick = () => {
  const f = revForm();
  if (revBaruMode()){ const a = revMakAkun(); if (!a) return toast("Pilih MAK tujuan dari daftar.", "warn");
    if (!f.nama) return toast("Isi nama detil baru.", "warn"); if (!(num(f.vol) > 0 && num(f.harga) > 0)) return toast("Isi volume dan harga satuan detil baru.", "warn");
    if (!f.ket) return toast("Isi keterangan / alasan revisi.", "warn");
    const old = revDB.find(y => y._id === revEdit), x: Revisi = { _id: revEdit || newId(), tgl: f.tgl || today(), key: old?.baru ? old.key : `baru:${a.mak}#${newId()}`, mak: a.mak, akun: a.nama, namaLama: "(detil baru)", jmlLama: 0, namaBaru: f.nama, vol: num(f.vol), sat: f.sat || "", harga: num(f.harga), jmlBaru: num(f.vol) * num(f.harga), ket: f.ket, status: old?.status || "Diajukan", baru: true, sistem: revSys() };
    if (old?.baru && old.mak !== a.mak) x.key = `baru:${a.mak}#${newId()}`;
    const i = revDB.findIndex(y => y._id === x._id); if (i >= 0) revDB[i] = x; else revDB.push(x);
    persistAng(); toast(i >= 0 ? "Usulan detil baru diperbarui." : `Usulan detil baru ditambahkan di ${a.mak}.`, "ok"); revReset(); renderRev(); return; }
  const d = revDetil(f); if (!d) return toast("Pilih detil POK dari daftar.");
  if (!f.ket) return toast("Isi keterangan / alasan revisi.");
  const x: Revisi = { _id: revEdit || newId(), tgl: f.tgl || today(), key: d.key, mak: d.a.mak, akun: d.a.nama, namaLama: d.u, jmlLama: d.j, volLama: num(d.v), satLama: d.s || "", hargaLama: num(d.h), namaBaru: f.nama || d.u, vol: num(f.vol), sat: f.sat || "", harga: num(f.harga), jmlBaru: num(f.vol) * num(f.harga), ket: f.ket, status: revDB.find(y => y._id === revEdit)?.status || "Diajukan", sistem: revSys() };
  const i = revDB.findIndex(y => y._id === x._id); if (i >= 0) revDB[i] = x; else revDB.push(x);
  persistAng(); toast(i >= 0 ? "Permintaan revisi diperbarui." : "Permintaan revisi ditambahkan."); revReset(); renderRev();
};
$("#revCancel").onclick = revReset;
function renderRev(): void {
  angYearUI();
  if (!$("#revTgl").value) $("#revTgl").value = today();
  const q = acNorm($("#revQ").value.trim()).split(/\s+/).filter(Boolean), stf = $<HTMLSelectElement>("#revStF").value, syf = $<HTMLSelectElement>("#revSysF").value;
  const list = [...revDB].reverse().filter(x => (!stf || x.status === stf) && (!syf || (x.sistem || "SAKTI").includes(syf)) && (!q.length || q.every(t => acNorm([x.namaLama, x.namaBaru, x.mak, x.ket, x.akun].join(" ")).includes(t))));
  $("#revTbl tbody").innerHTML = list.map((x, i) => { const sel = x.jmlBaru - x.jmlLama;
    return `<tr data-rid="${esc(x._id)}"><td class="muted">${revDB.length - revDB.indexOf(x)}</td><td style="font-size:13px;white-space:nowrap">${esc(x.tgl)}</td>
      <td><div class="lt-title" data-ra="edit">${x.baru ? `<span class="tag ok">detil baru</span> ${esc(x.namaBaru)}` : esc(x.namaLama)}${x.auto === "rab" ? ` <span class="tag warn" title="Dibuat otomatis karena kebutuhan RAB melebihi pagu detil — diperbarui mengikuti RAB selama berstatus Diajukan">otomatis RAB</span>` : ""}</div><div class="lsub one">${esc(x.mak)}</div><div class="lsub">Sebelumnya: ${x.baru ? "belum ada di POK (Rp 0)" : revPrevTxt(revPrevOf(x))}</div></td>
      <td><div style="font-weight:500">${esc(x.namaBaru)}</div><div class="lsub">${x.vol} ${esc(x.sat || "")} × Rp ${rupiah(x.harga)} = <b>Rp ${rupiah(x.jmlBaru)}</b></div></td>
      <td class="num">${revLK(sel)}<div class="lsub">${revSysTag(x)}</div></td>
      <td style="font-size:13px">${esc(x.ket)}</td>
      <td><div class="rvst"><button type="button" class="rvb ok ${x.status === "Disetujui" ? "on" : ""}" data-rs="Disetujui" title="${x.status === "Disetujui" ? "Disetujui — klik untuk kembali ke Diajukan" : "Setujui"}" aria-label="Setujui">✓</button><button type="button" class="rvb no ${x.status === "Ditolak" ? "on" : ""}" data-rs="Ditolak" title="${x.status === "Ditolak" ? "Ditolak — klik untuk kembali ke Diajukan" : "Tolak"}" aria-label="Tolak">✕</button><span class="rvs ${x.status === "Disetujui" ? "ok" : x.status === "Ditolak" ? "bad" : "muted"}">${x.status}</span></div></td>
      <td class="acts"><button class="ib" data-ra="edit" title="Edit">${IC.edit}</button><button class="ib del" data-ra="del" title="Hapus">${IC.del}</button></td></tr>`; }).join("")
    || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px">${revDB.length ? "Tidak ada yang cocok." : "Belum ada permintaan revisi."}</td></tr>`;
  const sl = list.reduce((s, x) => s + x.jmlBaru - x.jmlLama, 0);
  renderRevPok();
  { const ok = revDB.filter(x => x.status === "Disetujui"), el = $("#revRemind"); el.hidden = !ok.length;
    el.innerHTML = ok.length ? `🔔 <b>Pengingat:</b> ${ok.length} permintaan revisi sudah <b>disetujui</b> (${["SAKTI", "BOS"].map(s0 => `${s0}: ${ok.filter(x => (x.sistem || "SAKTI").includes(s0)).length}`).join(" · ")}). Pagu POK &amp; RPD di aplikasi <b>tidak berubah otomatis</b> — perbarui di aplikasi SAKTI / BOS, lalu impor POK hasil revisi.` : ""; }
  $("#revInfo").textContent = list.length ? `${list.length} permintaan · total selisih ${sl >= 0 ? "+" : "−"}Rp ${rupiah(Math.abs(sl))}` : "";
}
$("#revQ").addEventListener("input", debounce(() => renderRev(), 150)); $("#revStF").addEventListener("change", renderRev); $("#revSysF").addEventListener("change", renderRev);
$("#revTbl").addEventListener("change", e => { if (!tg(e).hasAttribute("data-rst")) return; const x = revDB.find(y => y._id === tg(e).closest<HTMLInputElement>("tr")?.dataset.rid); if (x){ x.status = tg(e).value as RevStatus; persistAng(); renderRevPok(); } });
$("#revTbl").addEventListener("click", e => { const b = tg(e).closest<HTMLElement>("[data-rs]"); if (!b) return; const x = revDB.find(y => y._id === b.closest<HTMLElement>("tr")?.dataset.rid); if (!x) return;
  const ns = b.dataset.rs as RevStatus; x.status = x.status === ns ? "Diajukan" : ns; persistAng(); renderRev();
  toast(x.status === "Disetujui" ? "Revisi disetujui — sebagai pengingat saja, pagu POK & RPD tidak berubah." : x.status === "Ditolak" ? "Revisi ditolak." : "Status dikembalikan ke Diajukan.", x.status === "Ditolak" ? "warn" : "ok"); });
$("#revTbl").addEventListener("click", e => { const a = tg(e).closest<HTMLInputElement>("[data-ra]")?.dataset.ra; if (!a) return; const x = revDB.find(y => y._id === tg(e).closest<HTMLInputElement>("tr")?.dataset.rid); if (!x) return;
  if (a === "del" && confirm(`Hapus permintaan revisi "${x.namaLama}"?`)){ revDB = revDB.filter(y => y !== x); persistAng(); renderRev(); if (revEdit === x._id) revReset(); }
  if (a === "edit" && x.baru){ revReset(); revEdit = x._id; document.querySelector<HTMLInputElement>('#revForm input[name="revMode"][value="baru"]')!.checked = true; revModeUI();
    revSysSet(x.sistem); $("#revMak").value = x.mak; $("#revNama").value = x.namaBaru; $("#revVol").value = String(x.vol || ""); $("#revSat").value = x.sat || ""; $("#revHarga").value = String(x.harga || ""); $("#revKet").value = x.ket; $("#revTgl").value = x.tgl;
    $("#revSave").textContent = "Simpan perubahan"; $("#revCancel").hidden = false; revPreview(); window.scrollTo({ top: 0, behavior: "smooth" }); return; }
  if (a === "edit"){ revEdit = x._id; const d = detMap()[x.key]; $("#revDet").value = d ? detLabel(d) : `${x.namaLama} — ${x.mak}`; $("#revDet").dataset.key = x.key; revSysSet(x.sistem);
    $("#revNama").value = x.namaBaru; $("#revVol").value = x.vol ? String(x.vol) : ""; $("#revSat").value = x.sat || ""; $("#revHarga").value = x.harga ? String(x.harga) : ""; $("#revKet").value = x.ket; $("#revTgl").value = x.tgl;
    $("#revSave").textContent = "Simpan perubahan"; $("#revCancel").hidden = false; revPreview(); window.scrollTo({ top: 0, behavior: "smooth" }); } });
/* ---------- POK sebelum & sesudah revisi (simulasi) ---------- */
interface RevPokRow { d: Detil; r?: Revisi; nm: string; vol: number; sat: string; harga: number; jml: number }
function revPokData(): { mak: string; a: PokAkun; rows: RevPokRow[]; sb: number; ss: number }[] {
  const st = $<HTMLSelectElement>("#revPokSt").value, all = $("#revPokAll").checked, M = detMap();
  const use = revDB.filter(x => st === "aktif" ? x.status !== "Ditolak" : !st || x.status === st), last: Record<string, Revisi> = {};
  for (const x of use) last[x.key] = x;   // revisi terakhir per detil (detil baru: kunci sendiri)
  const maks = [...new Set(Object.keys(last).map(k => M[k]?.a.mak || last[k].mak))].sort();
  return maks.map(mak => { const ds = pokDetil().filter(d => d.a.mak === mak), a = ds[0]?.a;
    const rows = ds.map((d): RevPokRow => { const r = last[d.key]; return r ? { d, r, nm: r.namaBaru || d.u, vol: num(r.vol), sat: r.sat, harga: num(r.harga), jml: num(r.jmlBaru) } : { d, nm: d.u, vol: num(d.v), sat: d.s || "", harga: num(d.h), jml: d.j }; });
    if (a) for (const r of Object.values(last)) if (r.baru && r.mak === mak) rows.push({ d: { key: r.key, a, u: "(detil baru)", j: 0, blokir: false }, r, nm: r.namaBaru, vol: num(r.vol), sat: r.sat, harga: num(r.harga), jml: num(r.jmlBaru) });
    return { mak, a: a!, rows: all ? rows : rows.filter(x => x.r), sb: ds.reduce((s0, d) => s0 + d.j, 0), ss: rows.reduce((s0, x) => s0 + x.jml, 0) }; }).filter(g => g.a);
}
function renderRevPok(): void {
  const G = revPokData(), vt = (v: number, s: string) => v ? `${v.toLocaleString("id-ID")} ${esc(s)}` : "–";
  $("#revPok").innerHTML = G.length ? G.map(g => `<div class="rvp tblwrap"><table class="ltbl tight"><thead>
      <tr><th rowspan="2" style="width:30%">Detil</th><th colspan="3" class="grp">POK sebelum</th><th colspan="4" class="grp">POK sesudah revisi</th><th rowspan="2" class="num">Selisih</th></tr>
      <tr><th class="num">Volume</th><th class="num">Harga</th><th class="num">Jumlah</th><th>Uraian</th><th class="num">Volume</th><th class="num">Harga</th><th class="num">Jumlah</th></tr></thead><tbody>
      <tr class="rvh"><td colspan="3">${esc(g.mak)} · ${esc(g.a.nama)}<div class="lsub">${esc(g.a.ro)} ${esc(roTitle(g.a.roNama))}</div></td><td class="num">${rupiah(g.sb)}</td><td colspan="3"></td><td class="num">${rupiah(g.ss)}</td><td class="num"><b>${revLK(g.ss - g.sb)}</b></td></tr>
      ${g.rows.map(x => { const s = x.jml - x.d.j;
        return `<tr class="${x.r ? "chg" : ""}"><td>${esc(x.d.u)}${x.r ? `<div class="lsub"><span class="tag">${esc(x.r.status)}</span> ${esc(x.r.ket).slice(0, 80)}</div>` : ""}</td><td class="num">${vt(num(x.d.v), x.d.s || "")}</td><td class="num">${x.d.h ? rupiah(num(x.d.h)) : "–"}</td><td class="num">${rupiah(x.d.j)}</td>
          <td>${x.r?.baru ? `<span class="tag ok">baru</span> ${esc(x.nm)}` : x.r && x.nm !== x.d.u ? esc(x.nm) : `<span class="muted">${x.r ? "(nama tetap)" : "tidak berubah"}</span>`}</td><td class="num">${vt(x.vol, x.sat)}</td><td class="num">${x.harga ? rupiah(x.harga) : "–"}</td><td class="num"><b>${rupiah(x.jml)}</b></td>
          <td class="num">${s ? revLK(s) : "–"}</td></tr>`; }).join("")}
    </tbody></table></div>`).join("") : `<p class="muted">Belum ada permintaan revisi${$<HTMLSelectElement>("#revPokSt").value ? " dengan status ini" : ""}.</p>`;
}
$("#revPokSt").addEventListener("change", () => renderRevPok()); $("#revPokAll").addEventListener("change", () => renderRevPok());
$("#revPokExp").onclick = () => {
  const G = revPokData(); if (!G.length) return toast("Belum ada permintaan revisi untuk diekspor.", "warn");
  const H = ["MAK", "Akun", "Detil", "Vol sebelum", "Satuan sebelum", "Harga sebelum", "Jumlah sebelum", "Uraian sesudah", "Vol sesudah", "Satuan sesudah", "Harga sesudah", "Jumlah sesudah", "Selisih", "Status", "Keterangan"];
  const aoa: unknown[][] = [H];
  for (const g of G){ for (const x of g.rows) aoa.push([g.mak, g.a.nama, x.d.u, num(x.d.v), x.d.s || "", num(x.d.h), x.d.j, x.nm, x.vol, x.sat, x.harga, x.jml, x.jml - x.d.j, x.r?.status || "", x.r?.ket || ""]);
    aoa.push([g.mak, "Jumlah MAK", "", "", "", "", g.sb, "", "", "", "", g.ss, g.ss - g.sb, "", ""], []); }
  const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = [28, 26, 40, 9, 9, 13, 14, 40, 9, 9, 13, 14, 13, 11, 40].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "POK sebelum-sesudah"); XLSX.writeFile(wb, `POK sebelum-sesudah revisi ${angYear}.xlsx`); toast("POK sebelum & sesudah revisi diekspor.", "ok");
};
$("#revExp").onclick = () => {
  if (!revDB.length) return toast("Belum ada permintaan revisi.");
  const H = ["No", "Tanggal", "MAK", "Akun", "Detil lama", "Volume lama", "Satuan lama", "Harga satuan lama (Rp)", "Jumlah lama (Rp)", "Detil usulan", "Volume", "Satuan", "Harga satuan (Rp)", "Jumlah usulan (Rp)", "Selisih (Rp)", "Keterangan / alasan", "Status", "Revisi untuk"];
  const ws = XLSX.utils.aoa_to_sheet([H, ...revDB.map((x, i) => [i + 1, x.tgl, x.mak, x.akun, x.namaLama, ...((v) => [v.vol, v.sat, v.harga])(revPrevOf(x)), x.jmlLama, x.namaBaru, x.vol, x.sat, x.harga, x.jmlBaru, x.jmlBaru - x.jmlLama, x.ket, x.status, (x.sistem || "SAKTI").replace("+", " & ")])]);
  ws["!cols"] = [5, 16, 28, 26, 40, 8, 10, 14, 14, 40, 8, 10, 14, 14, 13, 40, 11].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Permintaan Revisi"); XLSX.writeFile(wb, `Permintaan Revisi POK (${revDB.length}).xlsx`); toast("Permintaan revisi diekspor.");
};

