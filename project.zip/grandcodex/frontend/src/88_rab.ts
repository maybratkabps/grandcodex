/* ================= RENCANA PPIS · RAB (Rencana Anggaran Biaya) =================
   RAB disimpan per tahun anggaran bersama RPD/TUP/Revisi (st.rab.<tahun>).
   Setiap RAB terikat pada satu MAK/RO; setiap baris dibebankan ke satu detil POK di RO itu, dibatasi menurut akun.
   Biaya perjalanan dihitung dengan aturan yang sama dengan Surat Tugas (SK transport kampung, uang harian, inap).
   Kebutuhan melebihi pagu detil → otomatis tercatat di Permintaan Revisi. Perjadin bisa langsung dijadikan Surat Tugas Kolektif. */
const RAB_BAHAN = ["521211", "522191", "521219", "521811"];
interface RabSecDef { id: RabSec; n: string; trip: boolean; ok: (akun: string) => boolean; akTxt: string; jenis?: "Lokal" | "Remote"; /** jenis dikunci oleh judul bagian (Lokal / Remote); kosong = boleh dipilih */ fix?: "Lokal" | "Remote"; peran: RabPeran[] }
const RAB_SECS: RabSecDef[] = [
  { id: "honor", n: "Belanja Honor", trip: false, ok: a => a === "521213", akTxt: "521213", peran: [] },
  { id: "bahan", n: "Belanja Bahan", trip: false, ok: a => RAB_BAHAN.includes(a), akTxt: RAB_BAHAN.join(", "), peran: [] },
  { id: "pel", n: "Pelatihan Petugas", trip: false, ok: a => RAB_BAHAN.includes(a) || /^524/.test(a), akTxt: `${RAB_BAHAN.join(", ")} & 524…`, peran: [] },
  { id: "pemut", n: "Perjadin Pemutakhiran", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Lokal", peran: ["Pengawas", "Pendata"] },
  { id: "lokal", n: "Perjadin Lokal", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Lokal", fix: "Lokal", peran: ["Pengawas", "Pendata"] },
  { id: "remote", n: "Perjadin Remote", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Remote", fix: "Remote", peran: ["Pengawas", "Pendata"] },
  { id: "sup", n: "Perjadin Supervisi", trip: true, ok: a => /^524/.test(a), akTxt: "524…", jenis: "Remote", peran: ["Pelaksana", "Pengawas"] },
  { id: "luar", n: "Perjadin Luar Kota", trip: true, ok: a => a === "524111", akTxt: "524111", jenis: "Remote", peran: ["Pelaksana"] },
];
const RAB_DEF = Object.fromEntries(RAB_SECS.map(s => [s.id, s])) as Record<RabSec, RabSecDef>;
/** tambah cepat: [uraian, satuan, peran untuk hitung orang otomatis] */
const RAB_PRESET: Partial<Record<RabSec, [string, string, string?][]>> = {
  honor: [["Honor pengawas (PML)", "OK", "Pengawas"], ["Honor pendata (PCL)", "OK", "Pendata"], ["Honor pengolahan", "OK"], ["Honor instruktur", "OJ"]],
  bahan: [["Uang pulsa / internet petugas", "OB"], ["ATK & penggandaan", "Paket"], ["Konsumsi rapat", "OK"], ["Spanduk", "Lembar"]],
  pel: [["Konsumsi pelatihan", "OK"], ["Uang harian peserta", "OH"], ["Transport peserta", "OK"], ["Perlengkapan peserta", "Paket"], ["Spanduk", "Lembar"], ["Sewa gedung", "Hari"]],
};
const RAB_VIEWS: [string, string][] = [...RAB_SECS.map((s): [string, string] => [s.id, s.n]), ["rekap", "Rekap RAB"], ["timeline", "Timeline Kegiatan"]];
let rabCur: string | null = LS.get<string | null>("st.rabCur", null), rabView = LS.get<string>("st.rabView", "honor");

const rabDoc = (): RabDoc | null => rabDB.find(d => d._id === rabCur) || null;
/** bulan pelaksanaan RAB: opsional (bln = -1 → belum ditentukan), satu bulan, beberapa bulan, sampai setahun */
const rabNoBln = (d: RabDoc): boolean => !(d.bln >= 0);
const rabBlnTo = (d: RabDoc): number => rabNoBln(d) ? -1 : Math.max(d.bln, d.blnTo ?? d.bln);
const rabMonths = (d: RabDoc): number[] => { const o: number[] = []; if (rabNoBln(d)) return o; for (let m = d.bln; m <= rabBlnTo(d); m++) o.push(m); return o; };
const rabBlnTxt = (d: RabDoc): string => rabNoBln(d) ? "—" : rabBlnTo(d) === d.bln ? BULAN[d.bln] || "" : rabBlnTo(d) - d.bln === 11 ? "Setahun (Januari – Desember)" : `${BULAN[d.bln]} – ${BULAN[rabBlnTo(d)]} (${rabBlnTo(d) - d.bln + 1} bulan)`;
/** nilai dibagi rata ke beberapa bulan (kelipatan 1.000; sisa ke bulan terakhir) */
const rabSplit = (v: number, n: number): number[] => { if (n <= 1) return [v]; const per = Math.floor(v / n / 1000) * 1000, a = Array(n).fill(per); a[n - 1] = v - per * (n - 1); return a; };
/** bagian yang dipakai RAB ini (data lama tanpa pilihan = semua) */
const rabSecsOf = (doc: RabDoc): RabSec[] => doc.secs?.length ? RAB_SECS.map(s => s.id).filter(id => doc.secs!.includes(id)) : RAB_SECS.map(s => s.id);
const rabSecHas = (doc: RabDoc, sec: RabSec): boolean => (RAB_DEF[sec].trip ? doc.trips : doc.items).some(x => x.sec === sec);
let rabSecSel = new Set<RabSec>(), rabSecOpen = false;
/** tampilkan juga bagian yang pagunya tidak ada di POK RO ini (bawaan: disembunyikan, tidak dihapus) */
let rabSecAll = false;
function rabSecPickUI(doc: RabDoc | null, neu: boolean): void {
  const ro = $<HTMLSelectElement>("#rabRo").value, show = neu ? !!ro : rabSecOpen && !!doc;
  $("#rabSecPick").hidden = !show; if (!show) return;
  const cur = neu ? rabSecSel : new Set(rabSecsOf(doc!)), dets = (id: RabSec): Detil[] => pokDetil().filter(d => d.a.ro === (neu ? ro : doc!.ro) && RAB_DEF[id].ok(String(d.a.akun).trim()));
  /* bagian tanpa pagu di POK (tidak ada detil, atau pagunya 0 / diblokir) disembunyikan otomatis — kecuali sudah dipilih / sudah berisi; bisa ditampilkan lagi */
  const info = RAB_SECS.map(s => { const ds = dets(s.id), pg = ds.reduce((t, d) => t + rabPagu(d), 0); return { s, n: ds.length, pg, keep: pg > 0 || cur.has(s.id) || (!neu && !!doc && rabSecHas(doc, s.id)) }; });
  const hid = info.filter(x => !x.keep);
  $("#rabSecList").innerHTML = info.filter(x => x.keep || rabSecAll).map(({ s, n, pg, keep }) => `<label class="${cur.has(s.id) ? "on" : ""}${keep && pg > 0 ? "" : " nopagu"}" title="Akun ${esc(s.akTxt)}"><input type="checkbox" data-rsec="${s.id}" ${cur.has(s.id) ? "checked" : ""}> ${esc(s.n)} <small>${pg > 0 ? `${n} detil · pagu ${rpShort(pg)}` : n ? `${n} detil · pagu 0` : "tidak ada pagu di POK RO ini"}</small></label>`).join("")
    + (hid.length ? `<button type="button" class="rsp-more" data-rsecall title="${esc(hid.map(x => x.s.n).join(", "))}">${rabSecAll ? "Sembunyikan lagi bagian tanpa pagu" : `+ Tampilkan ${hid.length} bagian tanpa pagu`}</button>` : "")
    + (!info.some(x => x.keep) && !rabSecAll ? `<span class="muted" style="font-size:12.5px;align-self:center">RO ini tidak punya pagu untuk bagian RAB mana pun.</span>` : "");
}
const rabRos = (): [string, string][] => [...new Map(angPok().akun.map((a): [string, string] => [a.ro, a.roNama])).entries()].sort((a, b) => a[0].localeCompare(b[0]));
const rabRoNama = (ro: string): string => String(angPok().akun.find(a => a.ro === ro)?.roNama || "").trim();
const rabPagu = (d: Detil): number => d.blokir ? 0 : d.j;
/** detil POK yang boleh dipakai bagian ini: di RO RAB dan akunnya sesuai */
const rabDetils = (doc: RabDoc, sec: RabSec): Detil[] => pokDetil().filter(d => d.a.ro === doc.ro && RAB_DEF[sec].ok(String(d.a.akun).trim()));
const rabLineTot = (l: RabLine): number => Math.max(0, num(l.org || 1)) * num(l.vol) * num(l.harga);
const isoDate = (iso: string): Date | null => { const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
const isoStr = (d: Date): string => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const rabTripEnd = (t: RabTrip): Date | null => { const a = isoDate(t.pergi); return a ? new Date(a.getFullYear(), a.getMonth(), a.getDate() + Math.max(1, num(t.hari) || 1) - 1) : null; };
const rabPegNama = (t: RabTrip): string => (t.c && pegMap()[t.c]?.nama) || t.nama || "";
const rabKamTxt = (t: RabTrip): string => { const M = kamByKey(); return [...t.kam.map(k => M[k] ? title(M[k].kampung) : k.split("|").pop() || k), ...t.kamBad].join(", "); };

const rabKamNm = (k: string): string => { const M = kamByKey(); return M[k] ? title(M[k].kampung) : k.split("|").pop() || k; };
/* ---------- jadwal per kampung per hari; pengawas mengikuti petugas yang dibawahinya ---------- */
/** kampung yang dikunjungi tiap hari tugas: jadwal pengawas tersimpan, atau kampung dibagi rata menurut urutan rute */
function rabDays(t: RabTrip): string[][] {
  const H = Math.max(1, num(t.hari) || 1), n = t.kam.length;
  if (t.plan && t.plan.length === H && t.plan.every(k => t.kam.includes(k))) return t.plan.map(k => [k]);
  return Array.from({ length: H }, (_, i) => !n ? [] : n >= H ? t.kam.slice(Math.floor(i * n / H), Math.floor((i + 1) * n / H)) : [t.kam[Math.floor(i * n / H)]]);
}
/** tanggal (ISO) → kampung hari itu */
function rabDayMap(t: RabTrip): Map<string, string[]> {
  const a = isoDate(t.pergi), m = new Map<string, string[]>(); if (!a) return m;
  rabDays(t).forEach((ks, i) => m.set(isoStr(new Date(a.getFullYear(), a.getMonth(), a.getDate() + i)), ks));
  return m;
}
const rabOverlap = (a: RabTrip, b: RabTrip): number => { const A = rabDayMap(a); let n = 0; for (const d of rabDayMap(b).keys()) if (A.has(d)) n++; return n; };
/** petugas (Pendata, bagian yang sama) yang dibawahi perjalanan pengawas ini; bila pengawas punya >1 perjalanan, petugas ikut yang tanggalnya paling beririsan */
function rabSubs(doc: RabDoc, p: RabTrip): RabTrip[] {
  if (p.peran !== "Pengawas" || !p.c) return [];
  const sibs = doc.trips.filter(t => t.sec === p.sec && t.peran === "Pengawas" && t.c === p.c);
  return doc.trips.filter(t => t.sec === p.sec && t.peran === "Pendata" && t.pml === p.c && t !== p).filter(t => { if (sibs.length < 2) return true; let best = sibs[0], bo = 0; for (const s0 of sibs){ const o = rabOverlap(s0, t); if (o > bo){ bo = o; best = s0; } } return best === p; });
}
/** jadwal pengawas yang mengikuti petugasnya: tiap hari berada di kampung salah satu petugas, mendahulukan petugas yang belum didampingi */
function rabPlanFor(doc: RabDoc, p: RabTrip): { pergi: string; hari: number; kam: string[]; plan: string[] } | null {
  const subs = rabSubs(doc, p).filter(t => t.pergi && t.kam.length).map(t => rabDayMap(t)); if (!subs.length) return null;
  const dates = [...new Set(subs.flatMap(m => [...m.keys()]))].sort(), a = isoDate(dates[0])!, b = isoDate(dates[dates.length - 1])!, H = Math.round((b.getTime() - a.getTime()) / 864e5) + 1;
  const plan: string[] = [], seen = new Set<number>(); let prev = "";
  for (let i = 0; i < H; i++){
    const d = isoStr(new Date(a.getFullYear(), a.getMonth(), a.getDate() + i)), cand = new Map<string, number[]>();
    subs.forEach((m, si) => (m.get(d) || []).forEach(k => { const l = cand.get(k) || []; l.push(si); cand.set(k, l); }));
    let best = prev, bs = -1;
    for (const [k, l] of cand){ const sc = l.filter(x => !seen.has(x)).length * 100 + l.length * 10 + (k === prev ? 1 : 0); if (sc > bs){ bs = sc; best = k; } }
    (cand.get(best) || []).forEach(x => seen.add(x)); plan.push(best); prev = best;
  }
  return { pergi: dates[0], hari: H, kam: [...new Set(plan)], plan };
}
/** periksa aturan "pada tanggal yang sama pengawas & petugasnya di kampung yang sama": tanggal yang melanggar + petugas yang belum didampingi */
function rabPlanCheck(doc: RabDoc, p: RabTrip): { bad: string[]; miss: RabTrip[]; auto: boolean } | null {
  const subs = rabSubs(doc, p).filter(t => t.pergi && t.kam.length); if (!subs.length) return null;
  const P = rabDayMap(p), S = subs.map(t => rabDayMap(t)), bad: string[] = [], hit = new Set<number>();
  for (const [d, ks] of P){ const on = S.map((m, i) => ({ i, ks: m.get(d) })).filter(x => x.ks); if (!on.length) continue;
    const ok = on.filter(x => x.ks!.some(k => ks.includes(k))); ok.forEach(x => hit.add(x.i)); if (!ok.length) bad.push(d); }
  const au = rabPlanFor(doc, p), auto = !!au && au.pergi === p.pergi && au.hari === Math.max(1, num(p.hari) || 1) && JSON.stringify(rabDays(p)) === JSON.stringify(au.plan.map(k => [k]));
  return { bad, miss: subs.filter((_, i) => !hit.has(i)), auto };
}
function rabPlanWarn(doc: RabDoc, p: RabTrip): string {
  const c = rabPlanCheck(doc, p); if (!c || (!c.bad.length && !c.miss.length)) return "";
  const nm = c.miss.map(t => rabPegNama(t).split(",")[0]).join(", ");
  if (c.auto) return c.miss.length ? `tidak sempat mendampingi ${nm} — petugas bertugas bersamaan di kampung berbeda; geser tanggal petugas atau tambah pengawas` : "";
  return [!p.pergi ? "jadwal pengawas belum bertanggal" : "", c.bad.length ? `tidak sekampung dengan petugas pada ${c.bad.map(d => { const x = isoDate(d)!; return `${x.getDate()} ${BLN_S[x.getMonth()]}`; }).join(", ")}` : "", c.miss.length ? `belum mendampingi ${nm}` : ""].filter(Boolean).join("; ") + " — klik “Sesuaikan jadwal pengawas”";
}
/** terapkan jadwal otomatis ke semua pengawas (satu bagian, atau seluruh RAB); hasil: jumlah perjalanan pengawas yang berubah */
function rabPlanApply(doc: RabDoc, sec?: RabSec): number {
  let n = 0;
  for (const p of doc.trips.filter(t => t.peran === "Pengawas" && (!sec || t.sec === sec))){
    const au = rabPlanFor(doc, p); if (!au) continue;
    const same = p.pergi === au.pergi && num(p.hari) === au.hari && JSON.stringify(p.kam) === JSON.stringify(au.kam) && JSON.stringify(p.plan || []) === JSON.stringify(au.plan);
    if (same) continue;
    if (JSON.stringify(p.kam) !== JSON.stringify(au.kam) || num(p.hari) !== au.hari) delete p.rute;
    p.pergi = au.pergi; p.hari = au.hari; p.kam = au.kam; p.kamBad = []; p.plan = au.plan; n++;
  }
  return n;
}

/** perjalanan → rekaman Surat Tugas semu, supaya biaya memakai aturan yang sama (SK transport, uang harian, inap, hotel) */
function rabTripRec(doc: RabDoc, t: RabTrip, auto = false): StRecord {
  const a = isoDate(t.pergi), b = rabTripEnd(t), H = Math.max(1, num(t.hari) || 1), lok = t.jenis === "Lokal", noI = lok || t.jenis === JEN_TU;
  const hotel = noI ? 0 : Math.min(Math.max(0, num(t.hotel)), Math.max(0, H - 1));
  const r: StRecord = { JENIS: t.jenis, KD_NAMA_SPD: t.c, TEMPAT_BERANGKAT: "Kampung Semu", LAMA_JALAN: H, _kampung: t.kam.map(k => ({ k, pp: true })),
    TGL_PERGI: a ? fmtDate(a) : "", TGL_PULANG: b ? fmtDate(b) : "", NILAI_UH: doc.uh ?? defUH(), TDK_INAP_HOTEL: doc.inap ?? defInap(),
    LAMA_UH: lok ? 0 : H, LAMA_INAP: noI ? 0 : Math.max(0, H - 1 - hotel), LAMA_HOTEL: hotel, TARIF_HOTEL: hotel ? num(t.hotelTarif) : 0, MAK: detMap()[t.key]?.a.mak || "" };
  applyKampungToRec(r);
  if (t.rute && !auto){   // lintasan disunting sendiri → menggantikan baris transport otomatis
    for (let i = 1; i <= MAXTR; i++){ delete r["KetTransport_" + i]; delete r["Nilai" + i]; } delete r._riilLok;
    t.rute.filter(([k, v]) => String(k).trim() !== "" || num(v)).slice(0, MAXTR - 1).forEach(([k, v], i) => { r["KetTransport_" + (i + 1)] = String(k).trim() || "Transport"; r["Nilai" + (i + 1)] = num(v); });
  }
  if (auto) return r;
  if (num(t.tr)) for (let i = 1; i <= MAXTR; i++) if (!r["KetTransport_" + i] && !r["Nilai" + i]){ r["KetTransport_" + i] = t.sec === "luar" ? "Tiket / transport luar kota (PP)" : "Transport lain"; r["Nilai" + i] = num(t.tr); break; }
  return r;
}
/** lintasan & transport otomatis (aturan SK Transport) untuk rute kampung perjalanan ini, berurutan */
function rabAutoLegs(doc: RabDoc, t: RabTrip): [string, number][] {
  const r = rabTripRec(doc, t, true), out: [string, number][] = riilFilled(riilRows(r._riilLok)).map(([k, v]): [string, number] => [k, num(v)]);
  for (let i = 1; i <= MAXTR; i++) if (r["KetTransport_" + i] || r["Nilai" + i]) out.push([String(r["KetTransport_" + i] || ""), num(r["Nilai" + i])]);
  return out;
}
const rabLegs = (doc: RabDoc, t: RabTrip): [string, number][] => t.rute || rabAutoLegs(doc, t);
/** perjalanan yang panel lintasannya sedang dibuka */
const rabRuteOpen = new Set<string>();
function rabRuteHtml(doc: RabDoc, t: RabTrip): string {
  const M = kamByKey(), legs = rabLegs(doc, t), sum = legs.reduce((s, x) => s + num(x[1]), 0), open = rabRuteOpen.has(t.id), n = t.kam.length;
  const stops = t.kam.map((k, i) => `<span class="rt-k"><small>${i + 1}</small>${esc(M[k] ? title(M[k].kampung) : k.split("|").pop() || k)}${n > 1 ? `<button type="button" data-kmv="-1" data-ki="${i}" title="Majukan urutan" ${i ? "" : "disabled"}>‹</button><button type="button" data-kmv="1" data-ki="${i}" title="Mundurkan urutan" ${i < n - 1 ? "" : "disabled"}>›</button>` : ""}</span>`);
  const path = n ? [`<b>Semu</b>`, ...stops, `<b>Semu</b>`].join(`<i>→</i>`) : `<span class="muted">isi kampung tujuan untuk melihat rute</span>`;
  return `<div class="rt-rute"><div class="rt-path"><span class="muted">Rute</span>${path}${t.kamBad.length ? `<span class="bad">+ di luar SK: ${esc(t.kamBad.join(", "))}</span>` : ""}
      <button type="button" class="lnk" data-rtog>${open ? "▾" : "▸"} Lintasan &amp; biaya transport (${legs.length} · Rp ${rupiah(sum)})</button>${t.rute ? `<span class="tag warn">disunting</span><button type="button" class="lnk" data-rauto title="Buang suntingan, hitung lagi dari SK Transport">↺ otomatis dari SK</button>` : `<span class="tag">otomatis dari SK</span>`}</div>
    ${open ? `<div class="rt-legs">${legs.map(([k, v], i) => `<div class="rt-leg"><span class="muted">${i + 1}</span><input data-lg="k" data-li="${i}" value="${esc(k)}" placeholder="Keterangan lintasan / transport"><input type="number" min="0" step="1000" data-lg="v" data-li="${i}" value="${num(v) || ""}" placeholder="0"><button type="button" class="ib del" data-lgx="${i}" title="Hapus lintasan">×</button></div>`).join("")
      || `<div class="muted" style="font-size:12.5px">Belum ada lintasan.</div>`}<div><button type="button" class="btn sm" data-lgadd>+ Tambah lintasan / transport</button></div></div>` : ""}</div>`;
}
interface RabCost { tr: number; uh: number; inap: number; hotel: number; jml: number }
function rabTripCost(doc: RabDoc, t: RabTrip): RabCost { const n = compute(rabTripRec(doc, t))._num; return { tr: n.totTr, uh: n.totUH, inap: n.totInap, hotel: n.totHotel, jml: n.jml }; }
/** kebutuhan per detil POK untuk satu RAB */
function rabNeed(doc: RabDoc): Record<string, number> {
  const o: Record<string, number> = {};
  for (const l of doc.items) if (l.key) o[l.key] = (o[l.key] || 0) + rabLineTot(l);
  for (const t of doc.trips) if (t.key) o[t.key] = (o[t.key] || 0) + rabTripCost(doc, t).jml;
  return o;
}
const rabSecTot = (doc: RabDoc, sec: RabSec): number => RAB_DEF[sec].trip ? doc.trips.filter(t => t.sec === sec).reduce((s, t) => s + rabTripCost(doc, t).jml, 0) : doc.items.filter(l => l.sec === sec).reduce((s, l) => s + rabLineTot(l), 0);
const rabTotal = (doc: RabDoc): number => RAB_SECS.reduce((s, x) => s + rabSecTot(doc, x.id), 0);
/** kebutuhan semua RAB tahun ini per detil (+ nama RAB yang memakainya) */
function rabNeedAll(): Record<string, { v: number; docs: string[] }> {
  const o: Record<string, { v: number; docs: string[] }> = {};
  for (const d of rabDB) for (const [k, v] of Object.entries(rabNeed(d))){ const x = o[k] ||= { v: 0, docs: [] }; x.v += v; if (!x.docs.includes(d.nama)) x.docs.push(d.nama); }
  return o;
}
/* kebutuhan > pagu detil → Permintaan Revisi otomatis (status Diajukan, ditandai auto); diperbarui / dihapus mengikuti RAB.
   Yang sudah Disetujui/Ditolak tidak diubah lagi. */
function rabSyncRev(): void {
  const need = rabNeedAll(), M = detMap();
  for (const [k, x] of Object.entries(need)){
    const d = M[k]; if (!d) continue;
    const pg = rabPagu(d), r = revDB.find(y => y.auto === "rab" && y.key === k);
    if (x.v > pg){
      const ket = `Otomatis dari RAB (${x.docs.join("; ")}): kebutuhan Rp ${rupiah(x.v)} melebihi pagu${d.blokir ? " (diblokir)" : ""} Rp ${rupiah(pg)} — kurang Rp ${rupiah(x.v - pg)}.`;
      if (!r) revDB.push({ _id: newId(), tgl: today(), key: k, mak: d.a.mak, akun: d.a.nama, namaLama: d.u, jmlLama: d.j, namaBaru: d.u, vol: 1, sat: "Paket", harga: x.v, jmlBaru: x.v, ket, status: "Diajukan", auto: "rab" });
      else if (r.status === "Diajukan"){ r.vol = 1; r.harga = x.v; r.jmlBaru = x.v; r.ket = ket; }
    } else if (r && r.status === "Diajukan") revDB = revDB.filter(y => y !== r);
  }
  revDB = revDB.filter(y => !(y.auto === "rab" && y.status === "Diajukan" && !need[y.key]));
}
const rabSave = (): void => { rabSyncRev(); persistAng(); };
/** tebak detil dari uraian (kata yang sama), selain itu detil pertama yang boleh */
function rabGuessKey(dets: Detil[], text: string): string {
  const toks = acNorm(text).split(/[^a-z0-9]+/).filter(w => w.length > 2 && !["honor", "biaya", "belanja", "untuk", "dan"].includes(w));
  let best: Detil | undefined, sc = 0;
  for (const d of dets){ const h = acNorm(d.u), s = toks.filter(w => h.includes(w)).length; if (s > sc){ sc = s; best = d; } }
  return (best || dets[0])?.key || "";
}

/* ---------- tampilan ---------- */
/** pilihan jenis per bagian: judul Lokal / Remote → terkunci; Pemutakhiran / Supervisi → Lokal atau Remote; lainnya bebas */
const rabJenisOpts = (sec: RabSec, cur: string): string[] => { const d = RAB_DEF[sec]; if (d.fix) return [d.fix]; const o = sec === "pemut" || sec === "sup" ? ["Lokal", "Remote"] : ["Lokal", "Remote", JEN_TU]; return o.includes(cur) ? o : [...o, cur]; };
/** samakan jenis perjalanan dengan judul bagian yang mengunci (data lama / duplikat) */
function rabFixJenis(): boolean {
  let ch = false;
  rabDB.forEach(d => d.trips.forEach(t => { const f = RAB_DEF[t.sec]?.fix; if (!f || t.jenis === f) return; t.jenis = f; if (f !== "Remote"){ t.hotel = 0; t.hotelTarif = 0; } delete t.rute; ch = true; }));
  return ch;
}
function renderRab(): void {
  if (rabFixJenis()) rabSave();
  angYearUI();
  if (rabCur && !rabDoc()) rabCur = null;
  if (!rabCur && rabDB.length) rabCur = rabDB[rabDB.length - 1]._id;
  const doc = rabDoc(), ros = rabRos();
  $("#rabDocs").innerHTML = rabDB.map(d => `<button type="button" class="rabdoc ${d._id === rabCur ? "on" : ""}" data-rd="${esc(d._id)}"><b>${esc(d.nama || "(tanpa nama)")}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></button>`).join("")
    + `<button type="button" class="rabdoc new" data-rnew><b>+ RAB baru</b><small>pilih MAK / RO dulu</small></button>`;
  const roCur = $<HTMLSelectElement>("#rabRo").value, blnCur = $<HTMLSelectElement>("#rabBln").value, toCur = $<HTMLSelectElement>("#rabBlnTo").value;
  $("#rabRo").innerHTML = `<option value="">— Pilih MAK / RO —</option>` + ros.map(([k, n]) => `<option value="${esc(k)}">${esc(k)} ${esc(roTitle(n).slice(0, 70))}</option>`).join("");
  $("#rabBln").innerHTML = `<option value="-1">— tidak ditentukan —</option>` + BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join("");
  $("#rabBlnTo").innerHTML = BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join("");
  const neu = $("#rabHead").dataset.new === "1" || !doc;
  $("#rabHead").classList.toggle("isnew", neu);
  if (doc && !neu){ $<HTMLSelectElement>("#rabRo").value = doc.ro; $("#rabNama").value = doc.nama; $<HTMLSelectElement>("#rabBln").value = String(doc.bln); $<HTMLSelectElement>("#rabBlnTo").value = String(rabBlnTo(doc)); }
  else { $<HTMLSelectElement>("#rabRo").value = roCur; $<HTMLSelectElement>("#rabBln").value = blnCur || "-1"; $<HTMLSelectElement>("#rabBlnTo").value = toCur && +toCur >= +$<HTMLSelectElement>("#rabBln").value ? toCur : $<HTMLSelectElement>("#rabBln").value; }
  { const a = +$<HTMLSelectElement>("#rabBln").value, b = +$<HTMLSelectElement>("#rabBlnTo").value; $<HTMLSelectElement>("#rabBlnTo").disabled = a < 0; if (a < 0) $<HTMLSelectElement>("#rabBlnTo").value = "";
    $("#rabBlnInfo").textContent = a < 0 ? "Tanpa bulan — boleh diisi nanti" : b > a ? `${b - a + 1} bulan` : "1 bulan";
    [...$<HTMLSelectElement>("#rabBlnTo").options].forEach(o => o.disabled = +o.value < a); }
  $("#rabMake").hidden = !neu; $("#rabNewCancel").hidden = !neu || !doc; $("#rabDocAct").hidden = neu;
  rabSecPickUI(doc, neu);
  $("#rabTabs").hidden = $("#rabBody").hidden = neu;
  $("#rabHint").innerHTML = neu ? `Langkah 1: pilih <b>MAK / RO</b> (mis. 2902.BMA.006) — pagu setiap baris RAB diambil dari detil POK RO ini (T.A. ${esc(angYear)}). Kebutuhan boleh melebihi pagu; kekurangannya otomatis dicatat di <b>Permintaan Revisi</b>.` : "";
  if (neu || !doc){ $("#rabPagu").innerHTML = ""; return; }
  const need = rabNeed(doc), roDet = pokDetil().filter(d => d.a.ro === doc.ro), pg = roDet.reduce((s, d) => s + rabPagu(d), 0), tot = rabTotal(doc);
  const nRev = revDB.filter(r => r.auto === "rab" && Object.keys(need).includes(r.key)).length;
  $("#rabPagu").innerHTML = `<div class="ts"><small>Pagu RO ${esc(doc.ro)}</small><b>Rp ${rupiah(pg)}</b><span>${roDet.length} detil POK</span></div>
    <div class="ts"><small>Total RAB</small><b>Rp ${rupiah(tot)}</b><span>${doc.trips.length} perjalanan · ${doc.items.length} baris biaya</span></div>
    <div class="ts ${pg - tot < 0 ? "bad" : ""}"><small>Sisa pagu RO</small><b>${pg - tot < 0 ? "−" : ""}Rp ${rupiah(Math.abs(pg - tot))}</b><span>${nRev ? `${nRev} detil kurang → <a href="#" data-rgo="revisi">permintaan revisi</a>` : "semua detil cukup"}</span></div>`;
  { const ss = rabSecsOf(doc); if (RAB_DEF[rabView as RabSec] && !ss.includes(rabView as RabSec)) rabView = ss[0] || "rekap";
  $("#rabTabs").innerHTML = RAB_VIEWS.filter(([id]) => !RAB_DEF[id as RabSec] || ss.includes(id as RabSec)).map(([id, n]) => { const s = RAB_DEF[id as RabSec], c = s ? rabSecTot(doc, s.id) : 0;
    return `<button type="button" data-rv="${id}" class="${rabView === id ? "on" : ""}">${esc(n)}${s ? `<i>${c ? rpShort(c).replace("Rp ", "") : "–"}</i>` : ""}</button>`; }).join("")
    + `<button type="button" class="add ${rabSecOpen ? "on" : ""}" data-rsecadd title="Tambah / kurangi bagian RAB">+ Bagian</button>`; }
  renderRabBody(doc);
}
function rabDetOpts(dets: Detil[], cur: string, need: Record<string, { v: number; docs: string[] }>): string {
  const M = detMap(), has = !cur || dets.some(d => d.key === cur);
  return `<option value="">— pilih pagu —</option>` + (has ? "" : `<option value="${esc(cur)}" selected>⚠ ${esc(M[cur]?.u || "detil tidak ada di RO/akun ini")}</option>`)
    + dets.map(d => { const s = rabPagu(d) - (need[d.key]?.v || 0);
      return `<option value="${esc(d.key)}" ${d.key === cur ? "selected" : ""}>${esc(d.u.slice(0, 58))} · ${esc(d.a.akun)} · pagu ${rupiah(rabPagu(d))}${s < 0 ? " · kurang " + rupiah(-s) : ""}</option>`; }).join("");
}
/** tabel cek pagu untuk detil yang dipakai bagian ini */
function rabPaguHtml(doc: RabDoc, keys: string[]): string {
  const M = detMap(), all = rabNeedAll(), mine = rabNeed(doc), ks = [...new Set(keys.filter(Boolean))];
  if (!ks.length) return "";
  return `<div class="rab-cek"><b>Cek pagu</b><table class="ltbl tight"><thead><tr><th>Detil POK</th><th class="num">Pagu</th><th class="num">RAB ini</th><th class="num">RAB lain</th><th class="num">Sisa</th></tr></thead><tbody>${ks.map(k => {
    const d = M[k]; if (!d) return `<tr><td colspan="5" class="bad">Detil tidak ditemukan di POK ${esc(angYear)}</td></tr>`;
    const v = mine[k] || 0, o = (all[k]?.v || 0) - v, s = rabPagu(d) - v - o, rv = revDB.find(r => r.auto === "rab" && r.key === k);
    return `<tr><td>${esc(d.u)}<div class="lsub">${esc(d.a.mak)} · ${esc(d.a.nama)}${d.blokir ? ` · <span class="bad">blokir</span>` : ""}</div></td><td class="num">${rupiah(rabPagu(d))}</td><td class="num">${rupiah(v)}</td><td class="num">${o ? rupiah(o) : "–"}</td>
      <td class="num"><b class="${s < 0 ? "bad" : ""}">${s < 0 ? "−" : ""}${rupiah(Math.abs(s))}</b>${s < 0 ? `<div class="lsub">${rv ? `revisi ${esc(rv.status.toLowerCase())}` : "revisi"}</div>` : ""}</td></tr>`; }).join("")}</tbody></table></div>`;
}
function renderRabBody(doc: RabDoc): void {
  const el = $("#rabBody"), def = RAB_DEF[rabView as RabSec];
  if (rabView === "rekap"){ el.innerHTML = rabRekapHtml(doc); return; }
  if (rabView === "timeline"){ el.innerHTML = rabTimelineHtml(doc); return; }
  if (!def){ rabView = "honor"; renderRabBody(doc); return; }
  const dets = rabDetils(doc, def.id), need = rabNeedAll();
  const head = `<div class="rab-sh"><h3>${esc(def.n)}</h3><span class="muted">Pagu yang bisa dipilih: akun <b>${esc(def.akTxt)}</b> di RO ${esc(doc.ro)}</span></div>`
    + (dets.length ? "" : `<div class="rpd-warn">⚠ RO ${esc(doc.ro)} tidak punya detil POK akun ${esc(def.akTxt)} di T.A. ${esc(angYear)}. Baris tetap bisa diisi, tetapi belum dibebankan ke pagu.</div>`);
  if (!def.trip){
    const L = doc.items.filter(l => l.sec === def.id), tot = L.reduce((s, l) => s + rabLineTot(l), 0);
    el.innerHTML = head + `<div class="rab-pre"><span class="muted">Tambah cepat:</span> ${(RAB_PRESET[def.id] || []).map(([u], i) => `<button type="button" class="btn sm" data-rpre="${i}">+ ${esc(u)}</button>`).join(" ")}</div>
      <div class="tblwrap"><table class="ltbl rabt"><thead><tr><th style="width:30px">No</th><th>Uraian</th><th style="width:74px">Orang</th><th style="width:84px">Volume</th><th style="width:84px">Satuan</th><th style="width:130px">Harga satuan</th><th class="num" style="width:120px">Jumlah</th><th style="width:30%">Dibebankan ke (detil POK)</th><th style="width:34px"></th></tr></thead>
      <tbody>${L.map((l, i) => `<tr data-rl="${esc(l.id)}"><td class="muted">${i + 1}</td><td><input data-lf="uraian" value="${esc(l.uraian)}"></td><td><input type="number" min="0" step="1" data-lf="org" value="${esc(l.org)}"></td><td><input type="number" min="0" step="any" data-lf="vol" value="${esc(l.vol)}"></td><td><input data-lf="sat" list="dl-revsat" value="${esc(l.sat)}"></td><td><input type="number" min="0" step="1000" data-lf="harga" value="${esc(l.harga)}"></td><td class="num" data-o="jml"><b>${rupiah(rabLineTot(l))}</b></td><td><select data-lf="key">${rabDetOpts(dets, l.key, need)}</select></td><td><button type="button" class="ib del" data-rdel title="Hapus baris">${IC.del}</button></td></tr>`).join("")
        || `<tr><td colspan="9" class="muted" style="text-align:center;padding:18px">Belum ada baris. Pakai <b>Tambah cepat</b> atau <b>+ Tambah baris</b>.</td></tr>`}</tbody>
      <tfoot><tr><td></td><td colspan="5"><b>Jumlah ${esc(def.n)}</b></td><td class="num" data-o="tot"><b>${rupiah(tot)}</b></td><td colspan="2"></td></tr></tfoot></table></div>
      <div class="actions" style="justify-content:flex-start;margin-top:8px"><button type="button" class="btn sm" data-radd>+ Tambah baris</button></div>` + rabPaguHtml(doc, L.map(l => l.key));
    return;
  }
  const T = doc.trips.filter(t => t.sec === def.id), costs = T.map(t => rabTripCost(doc, t)), tot = costs.reduce((s, c) => s + c.jml, 0);
  const pmls = T.filter((t, i) => t.peran === "Pengawas" && t.c && T.findIndex(x => x.peran === "Pengawas" && x.c === t.c) === i);
  const conflicts = T.map(t => [rabTripWarn(doc, t), rabPlanWarn(doc, t)].filter(Boolean).join(" · "));
  el.innerHTML = head + `<div class="rab-pre">${def.peran.map(p => `<button type="button" class="btn sm ${p === "Pendata" ? "" : "pri"}" data-radd="${p}">+ ${p}</button>`).join(" ")}
      <span class="spacer"></span><label class="rab-inl">Uang harian/hari<input type="number" min="0" step="1000" id="rabUh" value="${esc(doc.uh ?? "")}" placeholder="${rupiah(defUH())}"></label>
      <label class="rab-inl">Inap tanpa hotel/malam<input type="number" min="0" step="1000" id="rabInap" value="${esc(doc.inap ?? "")}" placeholder="${rupiah(defInap())}"></label></div>
    <div class="hint" style="margin:-2px 0 8px">Transport kampung otomatis dari SK Transport mengikuti <b>urutan rute</b> (Lokal / Translok+Uhar: tarif × hari; Remote: ½ tarif pergi &amp; pulang + lintasan antar kampung). Urutan kampung bisa digeser dengan ‹ ›; tiap lintasan dan biayanya bisa diubah, ditambah atau dihapus lewat <b>Lintasan &amp; biaya transport</b>. Kosongkan uang harian / inap untuk memakai tarif di Pengaturan. Satu pengawas boleh membawahi beberapa petugas: pilih pengawas yang sama pada tiap petugas, lalu klik <b>Sesuaikan jadwal pengawas</b> agar pengawas berada di kampung yang sama dengan petugasnya pada tanggal yang sama.</div>
    <div class="tblwrap"><table class="ltbl rabt rabtrip"><thead><tr><th style="width:30px">No</th><th style="width:132px">Peran</th><th style="width:22%">Petugas</th><th style="width:14%">Pengawas</th><th style="width:20%">Kampung tujuan (urut rute)</th><th style="width:150px">Jenis</th><th style="width:142px">Berangkat</th><th style="width:64px">Hari</th><th class="num" style="width:132px">Biaya</th><th style="width:36px"></th></tr></thead>
    <tbody>${T.map((t, i) => { const c = costs[i], w = conflicts[i], hot = !(def.id === "lokal" || def.id === "pemut");
      return `<tr data-rt="${esc(t.id)}" class="rt1 ${w ? "warn" : ""}"><td class="muted" rowspan="2">${i + 1}</td>
      <td><select data-tf="peran">${def.peran.map(p => `<option ${t.peran === p ? "selected" : ""}>${p}</option>`).join("")}</select></td>
      <td><input data-tf="nama" data-ac="peg" autocomplete="off" value="${esc(rabPegNama(t))}" placeholder="Cari nama…" class="${t.nama && !t.c ? "bad" : ""}"></td>
      <td>${t.peran === "Pendata" ? `<select data-tf="pml"><option value="">—</option>${pmls.map(p => `<option value="${esc(p.c)}" ${p.c === t.pml ? "selected" : ""}>${esc(rabPegNama(p).split(",")[0])}</option>`).join("")}</select>` : (() => { const n = t.peran === "Pengawas" && t.c ? T.filter(x => x.peran === "Pendata" && x.pml === t.c).length : 0; return n ? `<span class="tag" title="Jadwal pengawas mengikuti kampung petugasnya per tanggal">membawahi ${n} petugas</span>` : `<span class="muted">–</span>`; })()}</td>
      <td><input data-tf="kam" list="dl-kampung-nama" value="${esc(rabKamTxt(t))}" placeholder="mis. Isir, Sira" title="Pisahkan dengan koma, urut rute">${t.kamBad.length ? `<div class="lsub bad">di luar SK: ${esc(t.kamBad.join(", "))}</div>` : ""}</td>
      <td><select data-tf="jenis" ${def.fix ? `disabled title="Otomatis ${def.fix} mengikuti judul bagian ${esc(def.n)}"` : ""}>${rabJenisOpts(def.id, t.jenis).map(j => `<option ${t.jenis === j ? "selected" : ""}>${j}</option>`).join("")}</select></td>
      <td><input type="date" data-tf="pergi" value="${esc(t.pergi)}"></td>
      <td><input type="number" min="1" step="1" data-tf="hari" value="${esc(t.hari)}"></td>
      <td class="num" data-o="biaya" rowspan="2">${rabCostHtml(c)}${w ? `<div class="lsub bad" style="white-space:normal">${esc(w)}</div>` : ""}</td>
      <td rowspan="2"><button type="button" class="ib del" data-rdel title="Hapus">${IC.del}</button></td></tr>
      <tr data-rt="${esc(t.id)}" class="rt2 ${w ? "warn" : ""}"><td colspan="7">${rabRuteHtml(doc, t)}<div class="rt2-in">
        ${hot && t.jenis === "Remote" ? `<label>Hotel <input type="number" min="0" step="1" data-tf="hotel" value="${esc(t.hotel || "")}" placeholder="0" style="width:56px"> malam ×<input type="number" min="0" step="1000" data-tf="hotelTarif" value="${esc(t.hotelTarif || "")}" placeholder="tarif" style="width:110px"></label>` : ""}
        <label>${def.id === "luar" ? "Tiket / transport" : "Transport lain"} <input type="number" min="0" step="1000" data-tf="tr" value="${esc(t.tr || "")}" placeholder="0" style="width:110px"></label>
        <label class="rt2-key">Dibebankan ke <select data-tf="key">${rabDetOpts(dets, t.key, need)}</select></label></div></td></tr>`; }).join("")
      || `<tr><td colspan="10" class="muted" style="text-align:center;padding:18px">Belum ada perjalanan. Tambahkan ${def.peran.map(p => `<b>${p}</b>`).join(" / ")} di atas.</td></tr>`}</tbody>
    <tfoot><tr><td></td><td colspan="7"><b>Jumlah ${esc(def.n)}</b> <span class="muted">(${T.length} perjalanan · ${new Set(T.map(t => t.c || t.nama)).size} orang)</span></td><td class="num" data-o="tot"><b>${rupiah(tot)}</b></td><td></td></tr></tfoot></table></div>
    <div class="actions" style="justify-content:flex-start;margin-top:8px"><button type="button" class="btn sm" data-rkey>Samakan pagu semua baris…</button>${def.peran.includes("Pendata") ? ` <button type="button" class="btn sm" data-rpml title="Tanggal &amp; kampung pengawas disusun mengikuti semua petugas yang dibawahinya: pada tanggal yang sama pengawas berada di kampung yang sama dengan petugasnya">Sesuaikan jadwal pengawas</button>` : ""}<span class="spacer"></span><button type="button" class="btn sm pri" data-rst ${T.length ? "" : "disabled"}>Jadikan Surat Tugas…</button></div>` + rabPaguHtml(doc, T.map(t => t.key));
}
const rabCostHtml = (c: RabCost): string => `<b>${rupiah(c.jml)}</b><div class="lsub">${[c.tr ? "transport " + rupiah(c.tr) : "", c.uh ? "UH " + rupiah(c.uh) : "", c.inap ? "inap " + rupiah(c.inap) : "", c.hotel ? "hotel " + rupiah(c.hotel) : ""].filter(Boolean).join("<br>") || "–"}</div>`;
/** bentrok jadwal: dengan surat tugas tersimpan, atau dengan perjalanan lain orang yang sama di RAB ini */
function rabTripWarn(doc: RabDoc, t: RabTrip): string {
  if (t.jenis === "Lokal"){ const M = kamByKey(), bad = t.kam.map(k => M[k]).filter((k): k is Kampung => !!k && !kamLokal(k)); if (bad.length) return `${RAB_DEF[t.sec].fix ? "Bagian ini khusus Lokal" : "Lokal tidak bisa dipilih"}: ${bad.map(k => title(k.kampung)).join(", ")} bukan kampung Lokal`; }
  if (!t.c || !t.pergi) return "";
  const a = isoDate(t.pergi), b = rabTripEnd(t); if (!a || !b) return "";
  const same = doc.trips.find(x => x !== t && x.c === t.c && x.pergi && (() => { const xa = isoDate(x.pergi), xb = rabTripEnd(x); return !!xa && !!xb && xa <= b && a <= xb; })());
  if (same) return `bentrok dengan ${RAB_DEF[same.sec].n} (${fmtDate(isoDate(same.pergi)!)})`;
  const cf = findConflicts(rabTripRec(doc, t), records, null);
  return cf.length ? `sudah ada ST ${cf[0].nomor} (${cf[0].tgl})` : "";
}
function rabRekapHtml(doc: RabDoc): string {
  const M = detMap(), mine = rabNeed(doc), all = rabNeedAll(), tot = rabTotal(doc);
  const secRows = RAB_SECS.map(s => { const n = s.trip ? doc.trips.filter(t => t.sec === s.id).length : doc.items.filter(l => l.sec === s.id).length, v = rabSecTot(doc, s.id);
    return `<tr><td><a href="#" data-rv="${s.id}">${esc(s.n)}</a></td><td class="num">${n || "–"}</td><td class="num">${v ? rupiah(v) : "–"}</td><td class="num muted">${tot && v ? Math.round(v / tot * 100) + "%" : ""}</td></tr>`; }).join("");
  const ks = Object.keys(mine).sort((a, b) => (M[a]?.a.mak || a).localeCompare(M[b]?.a.mak || b));
  const noKey = doc.items.filter(l => !l.key).length + doc.trips.filter(t => !t.key).length;
  const detRows = ks.map(k => { const d = M[k], v = mine[k], o = (all[k]?.v || 0) - v; if (!d) return `<tr><td colspan="6" class="bad">Detil ${esc(k)} tidak ada di POK ${esc(angYear)}</td></tr>`;
    const s = rabPagu(d) - v - o, rv = revDB.find(r => r.auto === "rab" && r.key === k);
    return `<tr><td>${esc(d.u)}<div class="lsub">${esc(d.a.mak)}</div></td><td>${esc(d.a.akun)} <span class="muted">${esc(d.a.nama)}</span></td><td class="num">${rupiah(rabPagu(d))}</td><td class="num">${rupiah(v)}${o ? `<div class="lsub">+ RAB lain ${rupiah(o)}</div>` : ""}</td>
      <td class="num"><b class="${s < 0 ? "bad" : ""}">${s < 0 ? "−" : ""}${rupiah(Math.abs(s))}</b></td><td>${s < 0 ? `<span class="tag warn">revisi ${esc((rv?.status || "Diajukan").toLowerCase())}</span>` : `<span class="tag ok">cukup</span>`}</td></tr>`; }).join("");
  const inRpd = (doc.rpdIn || []).reduce((s, r) => s + r.v, 0);
  return `<div class="rab-sh"><h3>Rekap RAB — ${esc(doc.nama)}</h3><span class="muted">${esc(doc.ro)} ${esc(roTitle(rabRoNama(doc.ro)))} · T.A. ${esc(angYear)}</span></div>
    <div class="rab-rk"><table class="ltbl"><thead><tr><th>Komponen</th><th class="num">Baris</th><th class="num">Jumlah (Rp)</th><th class="num">%</th></tr></thead><tbody>${secRows}</tbody>
      <tfoot><tr><td><b>Total RAB</b></td><td></td><td class="num"><b>${rupiah(tot)}</b></td><td></td></tr></tfoot></table></div>
    ${noKey ? `<div class="rpd-warn">⚠ ${noKey} baris belum dibebankan ke detil POK — tidak ikut cek pagu & RPD.</div>` : ""}
    <h3 style="margin:16px 0 6px;font-size:15px">Kebutuhan per detil POK</h3>
    <div class="tblwrap"><table class="ltbl"><thead><tr><th>Detil POK</th><th>Akun</th><th class="num">Pagu</th><th class="num">Kebutuhan RAB</th><th class="num">Sisa</th><th>Status</th></tr></thead><tbody>${detRows || `<tr><td colspan="6" class="muted">Belum ada baris yang dibebankan ke pagu.</td></tr>`}</tbody></table></div>
    <div class="actions" style="margin-top:12px;justify-content:flex-start;flex-wrap:wrap">
      <button type="button" class="btn pri" data-rxls>Ekspor Excel RAB</button>
      <button type="button" class="btn" data-rrpd title="Kebutuhan baris biaya masuk ke bulan pelaksanaan (bila diisi); perjalanan masuk ke bulan berangkat">${doc.rpdIn?.length ? "Perbarui isian RPD" : "Masukkan ke RPD"}</button>
      <button type="button" class="btn" data-rst ${doc.trips.length ? "" : "disabled"}>Jadikan Surat Tugas…</button>
      <button type="button" class="btn" data-rgo="revisi">Lihat Permintaan Revisi</button>
      ${inRpd ? `<span class="muted" style="font-size:12.5px">Sudah di RPD: Rp ${rupiah(inRpd)}</span>` : ""}</div>`;
}
/** baris timeline: pengawas lalu pendata di bawahnya, lalu pelaksana lain */
function rabTimelineRows(doc: RabDoc): { nama: string; peran: string; trips: RabTrip[] }[] {
  const T = doc.trips.filter(t => t.pergi && (t.c || t.nama)), who = (t: RabTrip) => t.c || "n:" + t.nama, out: { nama: string; peran: string; trips: RabTrip[] }[] = [], done = new Set<string>();
  const add = (k: string, peran: string) => { if (done.has(k)) return; done.add(k); const ts = T.filter(t => who(t) === k).sort((a, b) => a.pergi.localeCompare(b.pergi)); if (ts.length) out.push({ nama: rabPegNama(ts[0]), peran, trips: ts }); };
  for (const p of T.filter(t => t.peran === "Pengawas")){ add(who(p), "Pengawas"); for (const d of T.filter(t => t.peran === "Pendata" && t.pml === p.c)) add(who(d), "Pendata"); }
  for (const t of T) add(who(t), t.peran);
  return out;
}
function rabTimelineHtml(doc: RabDoc): string {
  const rows = rabTimelineRows(doc);
  if (!rows.length) return `<div class="rab-sh"><h3>Timeline Kegiatan</h3></div><p class="muted">Belum ada perjalanan bertanggal. Isi tanggal berangkat di tab Perjadin.</p>`;
  const all = rows.flatMap(r => r.trips), a0 = all.map(t => isoDate(t.pergi)!.getTime()), b0 = all.map(t => rabTripEnd(t)!.getTime());
  const start = new Date(Math.min(...a0)), nDay = Math.min(92, Math.round((Math.max(...b0) - start.getTime()) / 864e5) + 1);
  const days = Array.from({ length: nDay }, (_, i) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + i)), HR = ["Mg", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
  const di = (d: Date) => Math.round((d.getTime() - start.getTime()) / 864e5);
  const body = rows.map(r => { let html = "", col = 0; const ts = r.trips.filter(t => di(isoDate(t.pergi)!) < nDay);
    for (const t of ts){ const s = di(isoDate(t.pergi)!), e = Math.min(nDay - 1, di(rabTripEnd(t)!)); if (s < col) continue;
      if (s > col) html += `<td colspan="${s - col}"></td>`;
      const bad = new Set((rabPlanCheck(doc, t)?.bad || []).map(d => di(isoDate(d)!))), D = rabDays(t).slice(0, e - s + 1).map((ks, i) => ({ l: ks.map(rabKamNm).join(", ") || (i ? "" : rabKamTxt(t)) || RAB_DEF[t.sec].n, b: bad.has(s + i) }));
      for (let i = 0; i < D.length;){ let j = i + 1; while (j < D.length && D[j].l === D[i].l && D[j].b === D[i].b) j++;
        html += `<td colspan="${j - i}" class="tl-ev tl-${t.sec}${D[i].b ? " tl-bad" : ""}" title="${esc(RAB_DEF[t.sec].n + " · " + D[i].l + (D[i].b ? " · tidak sekampung dengan petugas" : ""))}">${esc(D[i].l)}</td>`; i = j; }
      col = e + 1; }
    if (col < nDay) html += `<td colspan="${nDay - col}"></td>`;
    return `<tr><th class="tl-nm ${r.peran === "Pendata" ? "tl-sub" : ""}">${esc(r.nama.split(",")[0])}<small>${esc(r.peran)}</small></th>${html}</tr>`; }).join("");
  const nBad = doc.trips.filter(t => rabPlanWarn(doc, t)).length, hasPml = doc.trips.some(t => t.peran === "Pendata" && t.pml);
  const mon: string[] = []; days.forEach((d, i) => { if (i === 0 || d.getDate() === 1) mon.push(`<th colspan="${Math.min(nDay - i, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate() - d.getDate() + 1)}">${BULAN[d.getMonth()]} ${d.getFullYear()}</th>`); });
  return `<div class="rab-sh"><h3>Timeline Kegiatan</h3><span class="muted">${fmtDate(days[0])} – ${fmtDate(days[nDay - 1])} · ${rows.length} petugas · per kampung per hari</span>${hasPml ? `<span class="spacer"></span><button type="button" class="btn sm ${nBad ? "pri" : ""}" data-rpml="all">Sesuaikan jadwal pengawas</button>` : ""}</div>
    ${nBad ? `<div class="rpd-warn">⚠ ${nBad} jadwal pengawas belum sejalan dengan petugasnya (kotak bergaris merah = pengawas tidak sekampung dengan petugas pada tanggal itu).</div>` : ""}
    <div class="tl-leg">${RAB_SECS.filter(s => s.trip && doc.trips.some(t => t.sec === s.id)).map(s => `<span class="tl-ev tl-${s.id}">${esc(s.n.replace("Perjadin ", ""))}</span>`).join("")}</div>
    <div class="tblwrap"><table class="rab-tl"><thead><tr><th class="tl-nm"></th>${mon.join("")}</tr><tr><th class="tl-nm">Petugas</th>${days.map(d => `<th class="${d.getDay() === 0 ? "sun" : ""}">${HR[d.getDay()]}<br>${d.getDate()}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></div>`;
}

/* ---------- event ---------- */
let _rabT: ReturnType<typeof setTimeout> | undefined;
/** gambar ulang setelah event selesai, lalu kembalikan fokus ke kolom yang sama (baris & nama kolom) */
function rabLater(): void {
  clearTimeout(_rabT);
  _rabT = setTimeout(() => {
    const a = document.activeElement as HTMLElement | null, row = a?.closest<HTMLElement>("[data-rl],[data-rt]"), f = a?.dataset.lf || a?.dataset.tf || (a?.classList.contains("dmy-t") ? "pergi" : "");
    const rk = row ? (row.dataset.rl ? `[data-rl="${row.dataset.rl}"]` : `[data-rt="${row.dataset.rt}"]`) : "";
    renderRab();
    if (rk && f){ const el = document.querySelector<HTMLInputElement>(`#rabBody ${rk} [data-lf="${f}"], #rabBody ${rk} [data-tf="${f}"]`); const t = el?._dmy || el; if (t){ t.focus(); if (t instanceof HTMLInputElement && t.type === "text") try{ t.setSelectionRange(t.value.length, t.value.length); }catch(e){} } }
  }, 0);
}
function rabNew(): void {
  const ro = $<HTMLSelectElement>("#rabRo").value; if (!ro) return toast("Pilih MAK / RO dulu sebelum membuat RAB.", "warn");
  const nama = $("#rabNama").value.trim() || roTitle(rabRoNama(ro));
  const secs = RAB_SECS.map(s => s.id).filter(id => rabSecSel.has(id));
  if (!secs.length) return toast("Pilih minimal satu bagian RAB (mis. Belanja Bahan, Perjadin Pemutakhiran).", "warn");
  const bv = $<HTMLSelectElement>("#rabBln").value, b0 = bv === "" || !(+bv >= 0) ? -1 : +bv, b1 = b0 < 0 ? -1 : Math.max(b0, +$<HTMLSelectElement>("#rabBlnTo").value || 0);
  const d: RabDoc = { _id: newId(), nama, ro, bln: b0, blnTo: b1, uh: null, inap: null, dibuat: today(), items: [], trips: [], secs };
  rabDB.push(d); rabCur = d._id; LS.set("st.rabCur", rabCur); rabView = secs[0]; rabSecSel = new Set(); $("#rabHead").dataset.new = ""; rabSave(); renderRab();
  toast(`RAB "${nama}" dibuat untuk ${ro}: ${secs.map(s0 => RAB_DEF[s0].n).join(", ")}.`, "ok");
}
$("#rabMake").onclick = rabNew;
$("#rabNewCancel").onclick = () => { $("#rabHead").dataset.new = ""; renderRab(); };
$("#rabDocs").addEventListener("click", e => {
  if (tg(e).closest<HTMLElement>("[data-rnew]")){ $("#rabHead").dataset.new = "1"; rabSecSel = new Set(); $("#rabNama").value = ""; $<HTMLSelectElement>("#rabRo").value = ""; renderRab(); $<HTMLSelectElement>("#rabRo").focus(); return; }
  const id = tg(e).closest<HTMLElement>("[data-rd]")?.dataset.rd; if (!id) return;
  rabCur = id; LS.set("st.rabCur", id); $("#rabHead").dataset.new = ""; renderRab();
});
$("#rabHead").addEventListener("change", e => { if ($("#rabHead").dataset.new === "1" && (tg(e).id === "rabBln" || tg(e).id === "rabBlnTo")) renderRab(); });
$("#rabHead").addEventListener("change", e => {
  const doc = rabDoc(); if (!doc || $("#rabHead").dataset.new === "1") return;
  const id = tg(e).id;
  if (id === "rabNama"){ doc.nama = tg(e).value.trim() || doc.nama; }
  if (id === "rabBln"){ doc.bln = +tg(e).value >= 0 ? +tg(e).value : -1; if (doc.bln < 0 || (doc.blnTo ?? -1) < doc.bln) doc.blnTo = doc.bln; }
  if (id === "rabBlnTo" && doc.bln >= 0){ doc.blnTo = Math.max(doc.bln, +tg(e).value || 0); }
  if (id === "rabRo"){ const ro = tg(e).value; if (!ro){ tg(e).value = doc.ro; return; }
    const used = [...doc.items, ...doc.trips].filter(x => x.key).length;
    if (used && !confirm(`Ganti MAK/RO RAB ini ke ${ro}? ${used} baris yang sudah dibebankan ke detil POK ${doc.ro} akan dikosongkan bebannya (bisa dipilih ulang).`)){ tg(e).value = doc.ro; return; }
    doc.ro = ro; for (const x of [...doc.items, ...doc.trips]) x.key = ""; }
  rabSave(); renderRab();
});
$("#rabDel").onclick = () => {
  const doc = rabDoc(); if (!doc || !confirm(`Hapus RAB "${doc.nama}"?`)) return;
  if (doc.rpdIn?.length && confirm("Kurangi juga isian RPD yang dulu dimasukkan dari RAB ini?")) for (const r of doc.rpdIn){ const a = rpdOf(r.key); a[r.m] = Math.max(0, num(a[r.m]) - r.v); }
  rabDB = rabDB.filter(d => d !== doc); rabCur = null; rabSave(); renderRab(); toast("RAB dihapus. Permintaan revisi otomatis ikut diperbarui.");
};
$("#rabDup").onclick = () => {
  const doc = rabDoc(); if (!doc) return;
  const c: RabDoc = { ...clone(doc), _id: newId(), nama: doc.nama + " (salinan)", dibuat: today() }; delete c.rpdIn;
  c.items.forEach(l => l.id = newId()); c.trips.forEach(t => t.id = newId());
  rabDB.push(c); rabCur = c._id; LS.set("st.rabCur", rabCur); rabSave(); renderRab(); toast("Salinan RAB dibuat.");
};
$("#rabSecPick").addEventListener("click", e => { if (!tg(e).closest("[data-rsecall]")) return; rabSecAll = !rabSecAll; const neu = $("#rabHead").dataset.new === "1" || !rabDoc(); rabSecPickUI(rabDoc(), neu); });
$("#rabSecPick").addEventListener("change", e => { const id = tg(e).dataset.rsec as RabSec | undefined; if (!id) return; const on = tg(e).checked, doc = rabDoc();
  if ($("#rabHead").dataset.new === "1" || !doc){ on ? rabSecSel.add(id) : rabSecSel.delete(id); tg(e).closest("label")?.classList.toggle("on", on); return; }
  const cur = rabSecsOf(doc);
  if (!on){ if (rabSecHas(doc, id)){ tg(e).checked = true; return toast(`Bagian ${RAB_DEF[id].n} sudah berisi data — hapus barisnya dulu sebelum menghilangkan bagian ini.`, "warn"); }
    if (cur.length <= 1){ tg(e).checked = true; return toast("RAB minimal punya satu bagian.", "warn"); } doc.secs = cur.filter(x => x !== id); }
  else { doc.secs = [...cur, id]; rabView = id; }
  rabSave(); renderRab(); toast(on ? `Bagian ${RAB_DEF[id].n} ditambahkan.` : `Bagian ${RAB_DEF[id].n} dihilangkan.`);
});
$("#rabRo").addEventListener("change", () => { if ($("#rabHead").dataset.new === "1" || !rabDoc()){ rabSecAll = false; rabSecSel = new Set(); rabSecPickUI(rabDoc(), true); } });
$("#rabTabs").addEventListener("click", e => { if (tg(e).closest("[data-rsecadd]")){ rabSecOpen = !rabSecOpen; renderRab(); return; } });
$("#rabTabs").addEventListener("click", e => { const v = tg(e).closest<HTMLElement>("[data-rv]")?.dataset.rv; if (!v) return; rabView = v; LS.set("st.rabView", v); renderRab(); });
$("#rabPagu").addEventListener("click", e => { if (tg(e).closest("[data-rgo]")){ e.preventDefault(); show("revisi"); } });
/** baris yang sedang diubah */
const rabLineOf = (doc: RabDoc, el: HTMLElement): RabLine | undefined => { const id = el.closest<HTMLElement>("[data-rl]")?.dataset.rl; return doc.items.find(l => l.id === id); };
const rabTripOf = (doc: RabDoc, el: HTMLElement): RabTrip | undefined => { const id = el.closest<HTMLElement>("[data-rt]")?.dataset.rt; return doc.trips.find(t => t.id === id); };
function rabAddTrip(doc: RabDoc, sec: RabSec, peran: RabPeran): void {
  const def = RAB_DEF[sec], same = doc.trips.filter(t => t.sec === sec), last = same[same.length - 1], dets = rabDetils(doc, sec);
  const pml = peran === "Pendata" ? ([...same].reverse().find(t => t.peran === "Pengawas")?.c || "") : "";
  doc.trips.push({ id: newId(), sec, peran, c: "", nama: "", pml, kam: [], kamBad: [], jenis: def.fix || last?.jenis || def.jenis || "Lokal", pergi: last?.pergi || "", hari: last?.hari || (def.jenis === "Lokal" ? 1 : 3), hotel: 0, hotelTarif: 0, tr: 0,
    key: last?.key || rabGuessKey(dets, def.n + " " + (def.jenis === "Lokal" ? "transport lokal" : "perjalanan")), ket: "" });
}
/* rute perjalanan: geser urutan kampung, buka panel lintasan, tambah / hapus lintasan, kembali ke otomatis */
$("#rabBody").addEventListener("click", e => {
  const doc = rabDoc(), b = tg(e).closest<HTMLElement>("[data-kmv],[data-rtog],[data-rauto],[data-lgadd],[data-lgx]"); if (!doc || !b) return;
  const t = rabTripOf(doc, b); if (!t) return; e.stopPropagation(); const d = b.dataset;
  if (d.rtog != null){ rabRuteOpen.has(t.id) ? rabRuteOpen.delete(t.id) : rabRuteOpen.add(t.id); renderRabBody(doc); return; }
  if (d.kmv != null){ const i = Number(d.ki), j = i + Number(d.kmv); if (j < 0 || j >= t.kam.length) return; [t.kam[i], t.kam[j]] = [t.kam[j], t.kam[i]]; if (t.rute){ delete t.rute; toast("Urutan rute berubah — lintasan dihitung ulang dari SK Transport.", "info"); } }
  else if (d.rauto != null) delete t.rute;
  else if (d.lgadd != null){ t.rute ||= rabAutoLegs(doc, t); t.rute.push(["", 0]); rabRuteOpen.add(t.id); }
  else if (d.lgx != null){ t.rute ||= rabAutoLegs(doc, t); t.rute.splice(Number(d.lgx), 1); }
  rabSave(); renderRab();
  if (d.lgadd != null) document.querySelector<HTMLInputElement>(`#rabBody tr.rt2[data-rt="${t.id}"] .rt-leg:last-of-type [data-lg="k"]`)?.focus();
}, true);
$("#rabBody").addEventListener("click", e => {
  const doc = rabDoc(); if (!doc) return; const t0 = tg(e), sec = rabView as RabSec, def = RAB_DEF[sec];
  const rv = t0.closest<HTMLElement>("[data-rv]")?.dataset.rv; if (rv){ e.preventDefault(); rabView = rv; renderRab(); return; }
  if (t0.closest("[data-rgo]")){ show("revisi"); return; }
  if (t0.closest("[data-rxls]")) return rabXlsx(doc);
  if (t0.closest("[data-rrpd]")) return rabToRpd(doc);
  if (t0.closest("[data-rst]")) return rabStOpen(doc);
  const pm = t0.closest<HTMLElement>("[data-rpml]");
  if (pm){ const all = pm.dataset.rpml === "all", n = rabPlanApply(doc, all ? undefined : sec), left = doc.trips.filter(t => (all || t.sec === sec) && rabPlanWarn(doc, t)).length;
    if (n){ rabSave(); renderRab(); }
    toast(n ? `${n} jadwal pengawas disesuaikan dengan petugasnya${left ? ` — ${left} pengawas tetap tidak sempat mendampingi semua petugas` : ""}.` : doc.trips.some(t => (all || t.sec === sec) && t.peran === "Pendata" && t.pml && t.pergi && t.kam.length) ? "Jadwal pengawas sudah sesuai dengan petugasnya." : "Belum ada petugas bertanggal & berkampung yang dibawahi pengawas.", n ? "ok" : "info"); return; }
  const pre = t0.closest<HTMLElement>("[data-rpre]")?.dataset.rpre;
  if (pre != null && def){ const [u, s, peran] = (RAB_PRESET[sec] || [])[+pre]; const nOrg = peran ? new Set(doc.trips.filter(t => t.peran === peran && (t.c || t.nama)).map(t => t.c || t.nama)).size : 0;
    doc.items.push({ id: newId(), sec, uraian: u, org: nOrg || 1, vol: 1, sat: s, harga: 0, key: rabGuessKey(rabDetils(doc, sec), u) }); rabSave(); renderRab();
    if (nOrg) toast(`${nOrg} ${peran!.toLowerCase()} diambil dari Perjadin RAB ini — isi volume & harga.`); return; }
  const add = t0.closest<HTMLElement>("[data-radd]");
  if (add && def){ if (def.trip) rabAddTrip(doc, sec, (add.dataset.radd || def.peran[0]) as RabPeran);
    else doc.items.push({ id: newId(), sec, uraian: "", org: 1, vol: 1, sat: "", harga: 0, key: rabGuessKey(rabDetils(doc, sec), "") });
    rabSave(); renderRab(); const rows = $$(`#rabBody tbody tr${def.trip ? ".rt1" : ""}`); rows[rows.length - 1]?.querySelector<HTMLInputElement>(def.trip ? '[data-tf="nama"]' : '[data-lf="uraian"]')?.focus(); return; }
  if (t0.closest("[data-rdel]")){ const l = rabLineOf(doc, t0), t = rabTripOf(doc, t0);
    if (l) doc.items = doc.items.filter(x => x !== l);
    if (t){ doc.trips = doc.trips.filter(x => x !== t); if (t.peran === "Pengawas") for (const x of doc.trips) if (x.pml === t.c) x.pml = ""; }
    rabSave(); renderRab(); return; }
  if (t0.closest("[data-rkey]") && def){ const dets = rabDetils(doc, sec); if (!dets.length) return toast("Tidak ada detil POK yang bisa dipilih untuk bagian ini.", "warn");
    const cur = doc.trips.find(t => t.sec === sec && t.key)?.key || dets[0].key, list = dets.map((d, i) => `${i + 1}. ${d.u} (${d.a.akun})`).join("\n");
    const v = prompt(`Bebankan semua perjalanan ${def.n} ke detil nomor:\n\n${list}`, String(dets.findIndex(d => d.key === cur) + 1)); const d = dets[(parseInt(v || "", 10) || 0) - 1]; if (!d) return;
    for (const t of doc.trips) if (t.sec === sec) t.key = d.key; rabSave(); renderRab(); toast(`Semua perjalanan dibebankan ke ${d.u}.`); }
});
$("#rabBody").addEventListener("input", e => {
  const doc = rabDoc(); if (!doc) return; const el = tg(e);
  if (el.id === "rabUh" || el.id === "rabInap"){ const v = el.value === "" ? null : num(el.value); if (el.id === "rabUh") doc.uh = v; else doc.inap = v; rabSave(); rabPatch(doc); return; }
  const l = rabLineOf(doc, el), lf = el.dataset.lf;
  if (l && lf && lf !== "key"){ if (lf === "uraian" || lf === "sat") l[lf] = el.value; else if (lf === "org" || lf === "vol" || lf === "harga") l[lf] = num(el.value); rabSave(); rabPatch(doc); return; }
  const t = rabTripOf(doc, el), tf = el.dataset.tf;
  if (t && el.dataset.lg){   // lintasan / biaya transport disunting → rute perjalanan ini jadi versi sendiri
    const first = !t.rute; t.rute ||= rabAutoLegs(doc, t); const row = t.rute[Number(el.dataset.li)]; if (!row) return;
    if (el.dataset.lg === "k") row[0] = el.value; else row[1] = num(el.value);
    rabSave(); rabPatch(doc); if (first) toast("Lintasan disunting — tidak lagi dihitung otomatis dari SK untuk perjalanan ini (klik ↺ untuk kembali).", "info"); return; }
  if (t && (tf === "hari" || tf === "hotel" || tf === "hotelTarif" || tf === "tr")){ t[tf] = num(el.value);
    if (tf === "hari" && t.rute){ delete t.rute; toast("Lama hari berubah — lintasan dihitung ulang dari SK Transport.", "info"); rabSave(); rabLater(); return; }
    rabSave(); rabPatch(doc); }
});
$("#rabBody").addEventListener("change", e => {
  const doc = rabDoc(); if (!doc) return; const el = tg(e);
  const l = rabLineOf(doc, el); if (l && el.dataset.lf === "key"){ l.key = el.value; rabSave(); rabLater(); return; }
  const t = rabTripOf(doc, el), tf = el.dataset.tf; if (!t || !tf) return;
  if (tf === "peran"){ t.peran = el.value as RabPeran; if (t.peran !== "Pendata") t.pml = ""; }
  else if (tf === "nama"){ const c = resolvePeg(el.value); t.c = c || ""; t.nama = c ? "" : el.value.trim(); if (el.value.trim() && !c) toast(`"${el.value.trim()}" tidak ada di Pegawai & Mitra — tetap dihitung, tetapi tidak bisa dijadikan surat tugas.`, "warn"); }
  else if (tf === "pml") t.pml = el.value;
  else if (tf === "kam"){ const p = parseKampungList(el.value); t.kam = p.found.map(kKey); t.kamBad = p.unknown; delete t.plan; if (t.rute){ delete t.rute; toast("Kampung berubah — lintasan dihitung ulang dari SK Transport.", "info"); } }
  else if (tf === "jenis"){ if (RAB_DEF[t.sec].fix) return; t.jenis = el.value === "Remote" ? "Remote" : el.value === JEN_TU ? JEN_TU : "Lokal"; if (t.jenis !== "Remote"){ t.hotel = 0; t.hotelTarif = 0; } if (t.rute){ delete t.rute; toast("Jenis berubah — lintasan dihitung ulang dari SK Transport.", "info"); } }
  else if (tf === "pergi") t.pergi = el.value;
  else if (tf === "key") t.key = el.value;
  else return;
  rabSave(); rabLater();
});
/** perbarui angka (biaya, total, ringkasan) tanpa menggambar ulang kolom isian */
function rabPatch(doc: RabDoc): void {
  for (const l of doc.items){ const c = document.querySelector(`#rabBody tr[data-rl="${l.id}"] [data-o="jml"]`); if (c) c.innerHTML = `<b>${rupiah(rabLineTot(l))}</b>`; }
  for (const t of doc.trips){ const c = document.querySelector(`#rabBody tr[data-rt="${t.id}"] [data-o="biaya"]`); if (c) c.innerHTML = rabCostHtml(rabTripCost(doc, t)); }
  const s = RAB_DEF[rabView as RabSec], ft = document.querySelector('#rabBody tfoot [data-o="tot"]'); if (s && ft) ft.innerHTML = `<b>${rupiah(rabSecTot(doc, s.id))}</b>`;
  clearTimeout(_rabPT); _rabPT = setTimeout(() => { if (!document.activeElement?.closest("#rabBody")) rabLater(); else { const cek = document.querySelector("#rabBody .rab-cek"); if (cek && s){ const keys = s.trip ? doc.trips.filter(t => t.sec === s.id).map(t => t.key) : doc.items.filter(l => l.sec === s.id).map(l => l.key); cek.outerHTML = rabPaguHtml(doc, keys) || "<div class=\"rab-cek\"></div>"; } } }, 400);
}
let _rabPT: ReturnType<typeof setTimeout> | undefined;
$("#rabBody").addEventListener("focusout", () => setTimeout(() => { if (!document.activeElement?.closest("#rabBody") && document.querySelector("#v-rab.on")) renderRab(); }, 150));

/* ---------- RAB → RPD ---------- */
function rabToRpd(doc: RabDoc): void {
  const add: Record<string, { key: string; m: number; v: number }> = {}, skip: string[] = [];
  let noBln = 0;   // isian yang belum punya bulan (RAB tanpa bulan pelaksanaan & perjalanan tanpa tanggal berangkat)
  if (rabNoBln(doc)) noBln += doc.items.filter(l => l.key && rabLineTot(l)).length;
  const put = (key: string, m: number, v: number) => { if (!key || !v) return; if (!(m >= 0)){ noBln++; return; } if (rpdLockM(m)){ if (!skip.includes(BULAN[m])) skip.push(BULAN[m]); return; } const x = add[key + "|" + m] ||= { key, m, v: 0 }; x.v += v; };
  { const ms = rabMonths(doc); for (const l of doc.items){ const parts = rabSplit(rabLineTot(l), ms.length); ms.forEach((m, i) => put(l.key, m, parts[i])); } }
  for (const t of doc.trips){ const a = isoDate(t.pergi); put(t.key, a && String(a.getFullYear()) === angYear ? a.getMonth() : doc.bln, rabTripCost(doc, t).jml); }
  const noBlnTxt = noBln ? `${noBln} isian belum punya bulan (RAB tanpa bulan pelaksanaan) — pilih Bulan mulai, atau isi tanggal berangkat perjalanan` : "";
  const list = Object.values(add); if (!list.length) return toast(noBln ? noBlnTxt + "." : skip.length ? `RPD ${skip.join(", ")} terkunci (triwulan lewat / TUP sudah difinalisasi).` : "Belum ada kebutuhan yang dibebankan ke detil POK.", "warn");
  const tot = list.reduce((s, x) => s + x.v, 0), months = [...new Set(list.map(x => BULAN[x.m]))].join(", ");
  if (!confirm(`Masukkan kebutuhan RAB "${doc.nama}" ke RPD ${angYear}?\n\n${list.length} isian · Rp ${rupiah(tot)} · bulan ${months}${doc.rpdIn?.length ? "\n\nIsian RPD dari RAB ini sebelumnya akan diganti (tidak dobel)." : ""}${skip.length ? `\n\nDilewati (RPD terkunci): ${skip.join(", ")}` : ""}${noBln ? `\n\nDilewati: ${noBlnTxt}.` : ""}`)) return;
  for (const r of doc.rpdIn || []){ const a = rpdOf(r.key); a[r.m] = Math.max(0, num(a[r.m]) - r.v); }
  for (const r of list){ const a = rpdOf(r.key); a[r.m] = num(a[r.m]) + r.v; }
  doc.rpdIn = list; rabSave(); renderRab(); toast(`RAB masuk ke RPD: Rp ${rupiah(tot)} (${months}).`, "ok");
}

/* ---------- RAB → Surat Tugas Kolektif ---------- */
let rabStDoc: RabDoc | null = null;
function rabStOpen(doc: RabDoc): void {
  const secs = RAB_SECS.filter(s => s.trip && doc.trips.some(t => t.sec === s.id)); if (!secs.length) return toast("Belum ada perjalanan di RAB ini.", "warn");
  rabStDoc = doc;
  $("#rsSecs").innerHTML = secs.map(s => `<label class="chk0"><input type="checkbox" data-rss="${s.id}" ${s.id === rabView || !RAB_DEF[rabView as RabSec]?.trip ? "checked" : ""}> ${esc(s.n)} <span class="muted">(${doc.trips.filter(t => t.sec === s.id).length})</span></label>`).join("");
  if (!$$("#rsSecs input:checked").length) $$<HTMLInputElement>("#rsSecs input")[0].checked = true;
  rabStInfo(); $<HTMLDialogElement>("#dRabSt").showModal();
}
const rabStSel = (): RabTrip[] => { const ss = $$("#rsSecs input:checked").map(i => i.dataset.rss); return (rabStDoc?.trips || []).filter(t => ss.includes(t.sec)); };
function rabStInfo(): void {
  const T = rabStSel(), M = detMap(), maks = [...new Set(T.map(t => M[t.key]?.a.mak).filter((m): m is string => !!m))], cur = $<HTMLSelectElement>("#rsMak").value;
  $("#rsMak").innerHTML = maks.map(m => `<option value="${esc(m)}" ${m === cur ? "selected" : ""}>${esc(m)} (${T.filter(t => M[t.key]?.a.mak === m).length})</option>`).join("") || `<option value="">— baris belum dibebankan ke pagu —</option>`;
  const mak = $<HTMLSelectElement>("#rsMak").value, use = T.filter(t => !mak || M[t.key]?.a.mak === mak), noPeg = use.filter(t => !t.c).length, noTgl = use.filter(t => !t.pergi).length;
  const tim = $<HTMLInputElement>("#rsTim").checked, nSurat = tim ? rabStRows(use).length : use.filter(t => t.c).length;
  $("#rsInfo").innerHTML = `${use.length} perjalanan → <b>${nSurat} surat tugas</b> di Surat Tugas Kolektif (MAK ${esc(mak || "–")}).` + (maks.length > 1 ? `<br>⚠ Ada ${maks.length} MAK berbeda — satu kali ekspor untuk satu MAK; ulangi untuk MAK lain.` : "")
    + (noPeg ? `<br><span class="bad">${noPeg} baris tanpa petugas terdaftar dilewati.</span>` : "") + (noTgl ? `<br><span class="bad">${noTgl} baris belum bertanggal — lengkapi di Surat Tugas Kolektif.</span>` : "");
}
/** baris Surat Tugas Kolektif: per orang, atau per tim (pengawas + pendata di bawahnya, Terlampir) */
function rabStRows(use: RabTrip[]): StRecord[] {
  const doc = rabStDoc!, fmt = (iso: string) => { const d = isoDate(iso); return d ? fmtDate(d) : ""; }, end = (t: RabTrip) => { const d = rabTripEnd(t); return d ? fmtDate(d) : ""; };
  const one = (t: RabTrip): StRecord => ({ peg: pegMap()[t.c]?.nama || "", ang: [], angBad: [], kam: t.kam.slice(), kamBad: t.kamBad.slice(), pp: true, pergi: fmt(t.pergi), pulang: end(t), jenis: t.jenis, maksud: `${RAB_DEF[t.sec].n.replace("Perjadin ", "")} — ${doc.nama}` });
  const T = use.filter(t => t.c);
  if (!$<HTMLInputElement>("#rsTim").checked) return T.map(one);
  const out: StRecord[] = [], done = new Set<RabTrip>();
  for (const p of T.filter(t => t.peran === "Pengawas")){
    const mem = T.filter(t => t.peran === "Pendata" && t.pml === p.c && t.sec === p.sec); if (!mem.length) continue;
    const g = [p, ...mem]; g.forEach(x => done.add(x));
    const st = g.map(x => x.pergi).filter(Boolean).sort(), en = g.map(x => rabTripEnd(x)).filter((d): d is Date => !!d).sort((a, b) => +a - +b);
    out.push({ peg: pegMap()[p.c]?.nama || "", ang: mem.map(x => x.c), angBad: [], kam: [...new Set(g.flatMap(x => x.kam))], kamBad: [...new Set(g.flatMap(x => x.kamBad))], pp: true,
      pergi: st[0] ? fmt(st[0]) : "", pulang: en.length ? fmtDate(en[en.length - 1]) : "", jenis: g.some(x => x.jenis === "Remote") ? "Remote" : "Lokal", maksud: `${RAB_DEF[p.sec].n.replace("Perjadin ", "")} — ${doc.nama}` });
  }
  for (const t of T) if (!done.has(t)) out.push(one(t));
  return out;
}
$("#rsSecs").addEventListener("change", rabStInfo); $("#rsMak").addEventListener("change", rabStInfo); $("#rsTim").addEventListener("change", rabStInfo); $("#rsOrang").addEventListener("change", rabStInfo);
$("#rsCancel").onclick = () => $<HTMLDialogElement>("#dRabSt").close();
$("#rsGo").onclick = () => {
  const doc = rabStDoc; if (!doc) return;
  const M = detMap(), mak = $<HTMLSelectElement>("#rsMak").value, use = rabStSel().filter(t => !mak || M[t.key]?.a.mak === mak), rows = rabStRows(use);
  if (!rows.length) return toast("Tidak ada perjalanan dengan petugas terdaftar untuk dijadikan surat tugas.", "warn");
  if (massRows.length && !confirm(`Surat Tugas Kolektif sudah berisi ${massRows.length} baris. Tambahkan ${rows.length} surat dari RAB di bawahnya?`)) return;
  const base = Object.keys(massCommon).length ? massCommon : commonFrom(defaults()), keg = rabRoNama(doc.ro);
  massCommon = { ...base, kegiatan: keg, MAK: mak || base.MAK || "", MAKSUD__TUJUAN: doc.nama, kegLain: !pokJudul(ST_AKUN(false)).has(keg) };
  massRows.push(...rows); fillCommon(massCommon); persistMass();
  $<HTMLDialogElement>("#dRabSt").close(); show("mass"); renderMass();
  toast(`${rows.length} surat tugas dari RAB masuk ke Surat Tugas Kolektif — periksa nomor & tanggal terbit, lalu Simpan.`, "ok");
};

/* ---------- ekspor Excel ---------- */
function rabXlsx(doc: RabDoc): void {
  const M = detMap(), wb = XLSX.utils.book_new(), dn = (k: string) => M[k] ? `${M[k].u} (${M[k].a.mak})` : "";
  const add = (name: string, aoa: unknown[][], w: number[]) => { const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = w.map(x => ({ wch: x })); XLSX.utils.book_append_sheet(wb, ws, name.slice(0, 31)); };
  const mine = rabNeed(doc), all = rabNeedAll();
  add("Rekap", [[`RAB ${doc.nama}`], [`${doc.ro} ${roTitle(rabRoNama(doc.ro))} · T.A. ${angYear}`], [], ["Komponen", "Jumlah (Rp)"], ...RAB_SECS.map(s => [s.n, rabSecTot(doc, s.id)]), ["TOTAL", rabTotal(doc)], [],
    ["Detil POK", "MAK", "Pagu", "Kebutuhan RAB ini", "RAB lain", "Sisa"], ...Object.keys(mine).map(k => { const d = M[k], v = mine[k], o = (all[k]?.v || 0) - v; return [d?.u || k, d?.a.mak || "", d ? rabPagu(d) : 0, v, o, (d ? rabPagu(d) : 0) - v - o]; })], [40, 30, 14, 16, 14, 14]);
  for (const s of RAB_SECS){
    if (!s.trip){ const L = doc.items.filter(l => l.sec === s.id); if (!L.length) continue;
      add(s.n, [["No", "Uraian", "Orang", "Volume", "Satuan", "Harga satuan", "Jumlah", "Dibebankan ke"], ...L.map((l, i) => [i + 1, l.uraian, l.org, l.vol, l.sat, l.harga, rabLineTot(l), dn(l.key)]), ["", "Jumlah", "", "", "", "", rabSecTot(doc, s.id), ""]], [5, 34, 8, 8, 10, 14, 14, 50]); continue; }
    const T = doc.trips.filter(t => t.sec === s.id); if (!T.length) continue;
    add(s.n.replace("Perjadin ", "Perjadin "), [["No", "Peran", "Petugas", "Pengawas", "Kampung tujuan (urut rute)", "Lintasan & transport", "Jenis", "Berangkat", "Kembali", "Hari", "Transport", "Uang harian", "Inap", "Hotel", "Jumlah", "Dibebankan ke"],
      ...T.map((t, i) => { const c = rabTripCost(doc, t), a = isoDate(t.pergi), b = rabTripEnd(t); return [i + 1, t.peran, rabPegNama(t), t.pml ? pegMap()[t.pml]?.nama || "" : "", rabKamTxt(t), rabLegs(doc, t).map(([k, v]) => `${k}: ${rupiah(num(v))}`).join("; "), t.jenis, a ? fmtDate(a) : "", b ? fmtDate(b) : "", num(t.hari), c.tr, c.uh, c.inap, c.hotel, c.jml, dn(t.key)]; }),
      ["", "", "Jumlah", "", "", "", "", "", "", "", "", "", "", "", rabSecTot(doc, s.id), ""]], [5, 10, 30, 24, 30, 60, 13, 18, 18, 6, 12, 12, 10, 10, 13, 44]);
  }
  const rows = rabTimelineRows(doc);
  if (rows.length){ const ts = rows.flatMap(r => r.trips), st = new Date(Math.min(...ts.map(t => isoDate(t.pergi)!.getTime()))), n = Math.min(92, Math.round((Math.max(...ts.map(t => rabTripEnd(t)!.getTime())) - st.getTime()) / 864e5) + 1);
    const days = Array.from({ length: n }, (_, i) => new Date(st.getFullYear(), st.getMonth(), st.getDate() + i));
    add("Timeline", [["Petugas", "Peran", ...days.map(d => `${d.getDate()} ${BLN_S[d.getMonth()]}`)], ...rows.map(r => [r.nama, r.peran, ...days.map(d => { const t = r.trips.find(x => isoDate(x.pergi)! <= d && d <= rabTripEnd(x)!); return t ? (rabDayMap(t).get(isoStr(d)) || []).map(rabKamNm).join(", ") || rabKamTxt(t) || RAB_DEF[t.sec].n : ""; })])], [30, 10, ...days.map(() => 11)]); }
  XLSX.writeFile(wb, `RAB ${doc.nama.replace(/[\\/:*?"<>|]+/g, " ").slice(0, 60)} ${angYear}.xlsx`); toast("RAB diekspor ke Excel.", "ok");
}

/* ================= DAFTAR RAB (seperti Daftar Surat Tugas) ================= */
function rblList(): RabDoc[] {
  const q = acNorm($("#rblQ").value.trim()).split(/\s+/).filter(Boolean), bl = $<HTMLSelectElement>("#rblBln").value, P = pegMap();
  return [...rabDB].reverse().filter(d => (bl === "" || rabMonths(d).includes(+bl)) && (!q.length || q.every(t => acNorm([d.nama, d.ro, rabRoNama(d.ro), ...d.trips.map(x => (x.c && P[x.c]?.nama) || x.nama), ...d.items.map(l => l.uraian), ...[...d.items, ...d.trips].map(x => detMap()[x.key]?.a.mak || "")].join(" ")).includes(t))));
}
function renderRabList(): void {
  angYearUI();
  { const el = $<HTMLSelectElement>("#rblBln"), v = el.value; el.innerHTML = `<option value="">Semua bulan</option>` + BULAN.map((b, i) => `<option value="${i}">${b}</option>`).join(""); el.value = v; }
  const list = rblList(); let sum = 0;
  $("#rblTbl tbody").innerHTML = list.map(d => { const tot = rabTotal(d), pg = pokDetil().filter(x => x.a.ro === d.ro).reduce((s0, x) => s0 + rabPagu(x), 0), sisa = pg - tot; sum += tot;
    const maks = [...new Set([...d.items, ...d.trips].map(x => detMap()[x.key]?.a.mak).filter(Boolean))] as string[];
    return `<tr data-rbl="${esc(d._id)}"><td class="no"><b>${rabDB.length - rabDB.indexOf(d)}</b></td>
      <td><span class="lt-title" data-rba="open" title="Buka RAB">${esc(d.nama || "(tanpa nama)")}</span><div class="lsub one">dibuat ${esc(d.dibuat || "")} · ${d.trips.length} perjalanan · ${d.items.length} baris biaya</div><div class="rbl-secs">${rabSecsOf(d).map(s0 => `<span class="tag">${esc(RAB_DEF[s0].n)}</span>`).join("")}</div></td>
      <td><div style="font-size:13px">${esc(d.ro)}</div><div class="lsub one" title="${esc(maks.join(", "))}">${esc(roTitle(rabRoNama(d.ro)).slice(0, 60))}${maks.length ? ` · ${maks.length} MAK` : ""}</div></td>
      <td>${esc(rabBlnTxt(d))}</td>
      <td class="num"><b>Rp ${rupiah(tot)}</b></td>
      <td class="num"><span class="${sisa < 0 ? "bad" : "ok"}">${sisa < 0 ? "−" : ""}Rp ${rupiah(Math.abs(sisa))}</span></td>
      <td class="acts"><button class="btn sm pri" data-rba="open">Buka</button> <button class="btn sm" data-rba="xls">Excel</button> <button class="ib" data-rba="dup" title="Duplikat">${IC.dup}</button><button class="ib del" data-rba="del" title="Hapus">${IC.del}</button></td></tr>`; }).join("")
    || `<tr><td colspan="7" class="muted" style="text-align:center;padding:24px">${rabDB.length ? "Tidak ada yang cocok." : `Belum ada RAB di T.A. ${esc(angYear)}. Klik <b>+ RAB baru</b>.`}</td></tr>`;
  $("#rblInfo").textContent = list.length ? `${list.length} RAB · total Rp ${rupiah(sum)}` : "";
}
$("#rblQ").addEventListener("input", debounce(() => renderRabList(), 150));
$("#rblBln").addEventListener("change", () => renderRabList());
$("#rblNew").onclick = () => { $("#rabHead").dataset.new = "1"; rabSecSel = new Set(); $("#rabNama").value = ""; show("rab"); $<HTMLSelectElement>("#rabRo").value = ""; renderRab(); };
$("#rblTbl").addEventListener("click", e => {
  const tr = tg(e).closest<HTMLElement>("tr[data-rbl]"), a = tg(e).closest<HTMLElement>("[data-rba]")?.dataset.rba; if (!tr || !a) return;
  const d = rabDB.find(x => x._id === tr.dataset.rbl); if (!d) return;
  if (a === "open"){ rabCur = d._id; LS.set("st.rabCur", d._id); $("#rabHead").dataset.new = ""; show("rab"); return; }
  if (a === "xls") return rabXlsx(d);
  if (a === "dup"){ const c: RabDoc = { ...clone(d), _id: newId(), nama: d.nama + " (salinan)", dibuat: today() }; delete c.rpdIn; c.items.forEach(l => l.id = newId()); c.trips.forEach(t => t.id = newId());
    rabDB.push(c); rabSave(); renderRabList(); return toast("Salinan RAB dibuat."); }
  if (a === "del" && confirm(`Hapus RAB "${d.nama}"?`)){
    if (d.rpdIn?.length && confirm("Kurangi juga isian RPD yang dulu dimasukkan dari RAB ini?")) for (const r of d.rpdIn){ const x = rpdOf(r.key); x[r.m] = Math.max(0, num(x[r.m]) - r.v); }
    rabDB = rabDB.filter(x => x !== d); if (rabCur === d._id) rabCur = null; rabSave(); renderRabList(); toast("RAB dihapus."); }
});
$("#rblExp").onclick = () => {
  const list = rblList(); if (!list.length) return toast("Belum ada RAB untuk diekspor.", "warn");
  const aoa: unknown[][] = [["No", "Nama RAB", "RO", "Judul RO", "Bulan", "Bagian", "Perjalanan", "Baris biaya", "Total RAB", "Pagu RO", "Sisa pagu RO", "Dibuat"]];
  list.forEach((d, i) => { const tot = rabTotal(d), pg = pokDetil().filter(x => x.a.ro === d.ro).reduce((s0, x) => s0 + rabPagu(x), 0);
    aoa.push([i + 1, d.nama, d.ro, roTitle(rabRoNama(d.ro)), rabBlnTxt(d), rabSecsOf(d).map(s0 => RAB_DEF[s0].n).join(", "), d.trips.length, d.items.length, tot, pg, pg - tot, d.dibuat || ""]); });
  const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = [5, 36, 16, 40, 11, 40, 10, 10, 14, 14, 14, 16].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Daftar RAB"); XLSX.writeFile(wb, `Daftar RAB ${angYear}.xlsx`); toast("Daftar RAB diekspor.", "ok");
};
