/* ================= BERANDA ================= */
const BLN3 = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
const recDate = (r: StRecord): Date | null => parseTgl(r.TGL_TERBIT_ST) || parseTgl(r.TGL_PERGI);
const rp = (n: number): string => "Rp " + rupiah(n);
const rpShort = (n: number): string => n >= 1e9 ? "Rp " + (n / 1e9).toLocaleString("id-ID", { maximumFractionDigits: 2 }) + " M" : n >= 1e6 ? "Rp " + (n / 1e6).toLocaleString("id-ID", { maximumFractionDigits: 1 }) + " jt" : rp(n);
/** batang horizontal: [label, nilai, tooltip?] */
function hbars(el: HTMLElement, rows: [string, number, string?][], unit: string): void {
  const max = Math.max(1, ...rows.map(r => r[1]));
  el.innerHTML = rows.length ? rows.map(([l, v, tip]) => `<div class="r" title="${esc(tip || `${l}: ${v} ${unit}`)}"><span class="l">${esc(l)}</span><span class="n">${v} ${unit}</span><span class="t"><i style="width:${(v / max * 100).toFixed(1)}%"></i></span></div>`).join("") : `<p class="muted">Belum ada data.</p>`;
}
let _homeKey = "", _homeIdle = 0;
/* Beranda: ringkasan dari semua fitur. Bagian ringan (kartu angka) langsung; grafik & daftar menyusul saat browser senggang. */
function renderHome(force?: boolean): void {
  const years = [...new Set(records.map(r => recDate(r)?.getFullYear()).filter((y): y is number => !!y))].sort((a, b) => b - a);
  const ysel = $<HTMLSelectElement>("#hYear"), now = new Date(), nowY = now.getFullYear();
  const cur = ysel.value || String(years.includes(nowY) ? nowY : years[0] || nowY);
  ysel.innerHTML = [...years.map(String), "semua"].map(y => `<option value="${y}" ${y === cur ? "selected" : ""}>${y === "semua" ? "Semua tahun" : "Tahun " + y}</option>`).join("");
  const Y = ysel.value, YN = Y === "semua" ? nowY : +Y, t0 = new Date(nowY, now.getMonth(), now.getDate());
  const hr = now.getHours(); $("#hGreet").textContent = (hr < 11 ? "Selamat pagi" : hr < 15 ? "Selamat siang" : hr < 18 ? "Selamat sore" : "Selamat malam") + " · " + fmtDate(now);
  $("#hYearLbl").textContent = Y === "semua" ? "semua tahun" : "tahun " + Y;
  const inY = (d: Date | null): d is Date => !!d && (Y === "semua" || d.getFullYear() === YN);

  // ---- surat tugas (pakai cache perhitungan) ----
  const key = [_dataVer, records.length, Y, t0.toDateString()].join("|"), heavy = force || key !== _homeKey; _homeKey = key;
  let n = 0, total = 0, thisMonth = 0, upcoming = 0, run = 0;
  const yr: StRecord[] = [];
  for (const r of records){
    const a = parseTgl(r.TGL_PERGI), b = parseTgl(r.TGL_PULANG) || a;
    if (a && b && b >= t0){ upcoming++; if (a <= t0) run++; }
    const d = recDate(r); if (!inY(d)) continue;
    yr.push(r); n++; total += computeC(r)._num.jmlTotal;
    if (d.getMonth() === now.getMonth() && d.getFullYear() === nowY) thisMonth++;
  }
  // ---- honor ----
  let hoN = 0, hoB = 0, hoP = 0;
  for (const h of honorDB || []){ const d = parseTgl(h.tglDaftar); if (Y !== "semua" && !inY(d)) continue; const t = hoTot(h); hoN++; hoB += t.bruto; hoP += (h.rows || []).length; }
  // ---- nomor surat ----
  const sY = (suratDB || []).filter(x => Y === "semua" || Number(x.tahun) === YN), sMax = sY.reduce((m, x) => Math.max(m, +x.no || 0), 0);
  // ---- POK perjalanan dinas (POK aktif) ----
  const U = usage(); let pagu = 0, blok = 0, used = 0;
  for (const a of pokDB.akun) if (/^5241/.test(a.akun)){ pagu += a.pagu; blok += a.blokir; used += U[a.mak]?.j || 0; }
  const avail = pagu - blok, sisa = avail - used;
  // ---- RPD / TUP / Revisi (tahun anggaran yang dipakai) ----
  const ay = String(YN), rpd = ay === angYear ? rpdDB : LS.get<RpdDB>(angK("rpd", ay), {}), tupY = ay === angYear ? tupDB : LS.get<TupDB>(angK("tup", ay), {}), revY = ay === angYear ? revDB : LS.get<Revisi[]>(angK("revisi", ay), []);
  const pk = pokGet(ay), pkPagu = pk ? pk.akun.reduce((s0, a) => s0 + a.pagu - a.blokir, 0) : 0;
  let rpdTot = 0, rpdMon = 0; for (const v of Object.values(rpd || {})){ for (let m = 0; m < 12; m++){ const x = num(v[m]); rpdTot += x; if (m === now.getMonth()) rpdMon += x; } }
  const tm = (tupY || {})[now.getMonth()], tupMon = tm ? Object.values(tm.val || {}).reduce((s0, v) => s0 + num(v), 0) : 0;
  const revA = (revY || []).filter(x => x.status === "Diajukan").length, revS = (revY || []).filter(x => x.status === "Disetujui").length;

  const K: [string, string, string, string, boolean?][] = [
    ["list", "Surat tugas", n.toLocaleString("id-ID"), `${thisMonth} dibuat bulan ini`],
    ["list", "Biaya perjalanan", rpShort(total), n ? `rata-rata ${rpShort(total / n)} / surat` : "belum ada"],
    ["list", "Sedang / akan berangkat", upcoming.toLocaleString("id-ID"), run ? `${run} sedang berlangsung` : "perjalanan belum selesai"],
    ["honor", "Honor petugas", rpShort(hoB), `${hoN} daftar · ${hoP} petugas`],
    ["nomor", "Nomor surat", sY.length.toLocaleString("id-ID"), sMax ? `nomor terakhir ${sMax}` : "belum ada"],
    ["pok", "Sisa perjalanan dinas", rpShort(sisa), avail ? `terpakai ${Math.round(used / avail * 100)}% dari pagu` : "POK belum ada", sisa < 0],
    ["rpd", `RPD ${ay}`, rpShort(rpdTot), pkPagu ? `${Math.round(rpdTot / pkPagu * 100)}% dari pagu · ${BLN3[now.getMonth()]} ${rpShort(rpdMon)}` : "POK belum ada"],
    ["tup", `TUP ${BLN3[now.getMonth()]}`, rpShort(tupMon), revA ? `${revA} revisi diajukan` : revS ? `${revS} revisi disetujui` : "tidak ada revisi menunggu"]
  ];
  $("#hKpi").innerHTML = K.map(([go, k, v, sub, bad]) => `<button type="button" class="kpi hk ${bad ? "bad" : ""}" data-go="${go}" title="Buka ${esc(k)}"><small>${esc(k)}</small><b>${v}</b><span class="sub">${esc(sub)}</span></button>`).join("");

  if (!heavy) return;
  renderCal(); renderHomeUp(t0);
  cancelIdle(_homeIdle);
  _homeIdle = onIdle(() => renderHomeCharts(yr, Y, now));
}
const onIdle = (f: () => void): number => ("requestIdleCallback" in window ? requestIdleCallback(f, { timeout: 400 }) : setTimeout(f, 30));
const cancelIdle = (h: number): void => { if (!h) return; "cancelIdleCallback" in window ? cancelIdleCallback(h) : clearTimeout(h); };
/* daftar jadwal ringkas: 5 perjalanan terdekat */
function renderHomeUp(t0: Date): void {
  const P = pegMap(), up = tripsOf().filter(t => t.b >= t0).sort((x, z) => +x.a - +z.a), list = up.slice(0, 5);
  $("#hJadwal").innerHTML = list.length ? list.map(t => { const f = computeC(t.r), tm = teamOf(t.r, P), on = t.a <= t0;
    return `<div class="up" data-open="${esc(t.r._id)}" role="button" tabindex="0"><span class="ud ${on ? "run" : "next"}"><b>${t.a.getDate()}</b>${BLN3[t.a.getMonth()]}</span><span class="ut"><b>${esc(tm.label || (f.NAMA_PELAKSANA_SPD || "").split(",")[0])}</b><small>${esc(f.TEMPAT_TUJUAN || f.MAKSUD__TUJUAN || "")}</small></span><span class="tag ${on ? "ok" : ""}">${on ? "berlangsung" : "akan datang"}</span></div>`; }).join("")
    + (up.length > 5 ? `<button class="btn sm" type="button" data-go="list" style="margin-top:6px">Lihat semua (${up.length})</button>` : "")
    : `<p class="muted" style="margin:6px 0">Tidak ada perjalanan yang sedang / akan berlangsung.</p>`;
}
function renderHomeCharts(yr: StRecord[], Y: string, now: Date): void {
  _homeIdle = 0;
  const mon = Array.from({ length: 12 }, () => ({ n: 0, j: 0 })), P = pegMap(), people: Record<string, { nama: string; n: number; hari: number }> = {}, kegs: Record<string, number> = {};
  for (const r of yr){ const d = recDate(r); if (d){ mon[d.getMonth()].n++; mon[d.getMonth()].j += computeC(r)._num.jmlTotal; }
    const kg = String(r.kegiatan || "").trim() || "(tanpa kegiatan)"; kegs[kg] = (kegs[kg] || 0) + 1;
    for (const ps of personsOf(r, P)){ const o = people[ps.key] ||= { nama: ps.nama, n: 0, hari: 0 }; o.n++; o.hari += num(r.LAMA_JALAN); } }
  hbars($("#hKeg"), Object.entries(kegs).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]): [string, number, string] => [k, v, `${k}: ${v} surat`]), "surat");
  hbars($("#hPeg"), Object.values(people).sort((a, b) => b.n - a.n || b.hari - a.hari).slice(0, 5).map((o): [string, number, string] => [o.nama.split(",")[0], o.n, `${o.nama}: ${o.n} surat · ${o.hari} hari bertugas`]), "surat");
  const mx = Math.max(1, ...mon.map(m => m.n)), peak = mon.findIndex(m => m.n === mx);
  $("#hMonth").innerHTML = mon.map((m, i) => `<div class="col" title="${BLN3[i]}: ${m.n} surat · ${rp(m.j)}"><span class="v">${m.n && (i === peak || i === now.getMonth()) ? m.n : ""}</span><div class="b" style="height:${(m.n / mx * 100).toFixed(1)}%"></div></div>`).join("");
  $("#hMonthLbl").innerHTML = BLN3.map(x => `<span>${x}</span>`).join("");
  $("#hMonthNote").textContent = mon[peak].n ? `· tertinggi ${BLN3[peak]} (${mon[peak].n} surat)` : "";
  // aktivitas terakhir dari semua fitur
  const act: { t: Date | null; ico: string; go: string; id?: string; a: string; b: string }[] = [];
  for (const r of records.slice(-8)){ const f = computeC(r); act.push({ t: parseTgl(r.TGL_TERBIT_ST) || recDate(r), ico: "ST", go: "", id: r._id, a: f.NOMOR_ST, b: `${(f.NAMA_PELAKSANA_SPD || "-").split(",")[0]} · ${String(f.MAKSUD__TUJUAN || "").slice(0, 70)}` }); }
  for (const h of (honorDB || []).slice(-4)) act.push({ t: parseTgl(h.tglDaftar), ico: "HO", go: "honor", a: h.judul2 || "Daftar honor", b: `${(h.rows || []).length} petugas · Rp ${rupiah(hoTot(h).bruto)}` });
  for (const x of (suratDB || []).slice(-4)) act.push({ t: parseTgl(x.tgl), ico: "NS", go: "nomor", a: `${x.jenis || "Surat"} No. ${x.no}`, b: String(x.perihal || "").slice(0, 70) });
  for (const x of (revDB || []).slice(-3)) act.push({ t: parseTgl(x.tgl), ico: "RV", go: "revisi", a: `Revisi: ${x.namaLama || ""}`.slice(0, 80), b: `${x.status} · selisih Rp ${rupiah((x.jmlBaru || 0) - (x.jmlLama || 0))}` });
  act.sort((x, z) => +(z.t || 0) - +(x.t || 0));
  $("#hRecent").innerHTML = act.slice(0, 6).map(x => `<div class="act" ${x.id ? `data-open="${esc(x.id)}"` : `data-go="${x.go}"`} role="button" tabindex="0"><span class="ai ai-${x.ico}">${x.ico}</span><span class="at"><b>${esc(x.a)}</b><small>${esc(x.b)}</small></span><span class="muted ad">${x.t ? x.t.getDate() + " " + BLN3[x.t.getMonth()] : ""}</span></div>`).join("") || `<p class="muted">Belum ada aktivitas.</p>`;
}
/* ---------- timeline kalender ---------- */
let calM: Date | null = null, calSel: string | null = null;
const HARI = ["Sen","Sel","Rab","Kam","Jum","Sab","Min"], BLN = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
/** perjalanan: surat + tanggal pergi (a) & pulang (b) */
interface Trip { r: StRecord; a: Date; b: Date }
function tripsOf(): Trip[] {
  const out: Trip[] = [];
  for (const r of records){ const a = parseTgl(r.TGL_PERGI); if (!a) continue; let b = parseTgl(r.TGL_PULANG) || a; if (b < a) b = a; out.push({ r, a, b }); }
  return out;
}
function renderCal(): void {
  const now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (!calM) calM = new Date(now.getFullYear(), now.getMonth(), 1);
  const y = calM.getFullYear(), m = calM.getMonth();
  $("#calTitle").textContent = BLN[m] + " " + y;
  const start = new Date(y, m, 1 - ((new Date(y, m, 1).getDay() + 6) % 7)), days: Date[] = [];
  for (let i = 0; i < 42; i++) days.push(new Date(start.getFullYear(), start.getMonth(), start.getDate() + i));
  const end = days[41], trips = tripsOf().filter(t => t.b >= start && t.a <= end), P = pegMap();
  const st = (t: Trip) => t.b < t0 ? "done" : t.a > t0 ? "next" : "run";
  const TM = new Map(trips.map(t => [t.r, teamOf(t.r, P)])), tm = (r: StRecord) => TM.get(r)!, name = (r: StRecord) => tm(r).label;
  const order = (x: Trip, z: Trip) => tm(x.r).prio - tm(z.r).prio || +x.a - +z.a;
  let html = HARI.map(h => `<div class="dow">${h}</div>`).join("");
  for (const d of days){
    const ev = trips.filter(t => t.a <= d && t.b >= d).sort(order);
    const key = d.toDateString(), cls = ["d", ev.some(t => st(t) === "run") ? "h-run" : "", ev.some(t => st(t) === "next") ? "h-next" : "", ev.some(t => st(t) === "done") ? "h-done" : "", d.getMonth() !== m ? "out" : "", key === t0.toDateString() ? "today" : "", calSel === key ? "sel" : ""].join(" ");
    html += `<div class="${cls}" data-day="${d.getFullYear()}-${d.getMonth()}-${d.getDate()}" title="${ev.length ? ev.length + " perjalanan" : ""}"><div class="dn">${d.getDate()}${ev.length ? `<small>${ev.length}</small>` : ""}</div>${ev.slice(0, 3).map(t => `<div class="ev ${st(t)}${tm(t.r).prio === 2 ? " mitra" : ""}" title="${esc(name(t.r) + " · " + (t.r.MAKSUD__TUJUAN || ""))}">${esc(name(t.r))}</div>`).join("")}${ev.length > 3 ? `<div class="more">+${ev.length - 3} lainnya — klik</div>` : ""}</div>`;
  }
  $("#cal").innerHTML = html;
  const inMonth = trips.filter(t => t.b >= new Date(y, m, 1) && t.a <= new Date(y, m + 1, 0)).length;
  $("#calDay").innerHTML = `<p class="muted" style="margin:0;font-size:13px">Bulan ini ${inMonth} perjalanan. Tiap tanggal menampilkan 3 surat (pegawai didahulukan) — klik tanggal untuk melihat semua.</p>`;
}
function openCalDay(dt: Date): void {
  const P = pegMap(), now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const ev = tripsOf().filter(t => t.a <= dt && t.b >= dt).map(t => ({ ...t, tm: teamOf(t.r, P) })).sort((x, z) => x.tm.prio - z.tm.prio || +x.a - +z.a);
  type TripT = Trip & { tm: Team };
  const st = (t: TripT): [string, string] => t.b < t0 ? ["done", "selesai"] : t.a > t0 ? ["next", "akan datang"] : ["run", "berlangsung"];
  const nPeg = new Set(ev.flatMap(t => t.tm.peg)).size, nMit = new Set(ev.flatMap(t => t.tm.mit)).size;
  $("#cdTitle").textContent = fmtDate(dt);
  $("#cdSum").innerHTML = ev.length ? `<b>${ev.length}</b> surat tugas · <b>${nPeg}</b> pegawai · <b>${nMit}</b> mitra bertugas` : "Tidak ada perjalanan pada tanggal ini.";
  const item = (t: TripT): string => { const f = compute(t.r), [c, lbl] = st(t);
    return `<div class="cd-it" data-open="${esc(t.r._id)}"><div class="cd-top"><span class="ev ${c}">${lbl}</span><span class="muted">${esc(f.NOMOR_ST)}</span><span class="muted" style="margin-left:auto;white-space:nowrap">${esc(t.r.TGL_PERGI)}${t.r.TGL_PULANG && t.r.TGL_PULANG !== t.r.TGL_PERGI ? " – " + esc(t.r.TGL_PULANG) : ""}</span></div>
      <div class="cd-m">${esc(f.MAKSUD__TUJUAN)}</div>
      <div class="cd-n">${t.tm.names.map(x => `<span class="${x.peg ? "pg" : "mt"}">${esc(x.nama)}</span>`).join("")}</div>
      <div class="muted" style="font-size:12px">${esc(f.TEMPAT_TUJUAN || "")}</div></div>`; };
  const grp = (title: string, list: TripT[]): string => list.length ? `<div class="cd-g">${title} <span class="muted">(${list.length})</span></div>` + list.map(item).join("") : "";
  $("#cdList").innerHTML = grp("Surat tugas pegawai", ev.filter(t => t.tm.prio < 2)) + grp("Surat tugas mitra", ev.filter(t => t.tm.prio === 2));
  $<HTMLDialogElement>("#dCalDay").showModal();
}
$("#calPrev").onclick = () => { const c = calM || new Date(); calM = new Date(c.getFullYear(), c.getMonth() - 1, 1); calSel = null; renderCal(); };
$("#calNext").onclick = () => { const c = calM || new Date(); calM = new Date(c.getFullYear(), c.getMonth() + 1, 1); calSel = null; renderCal(); };
$("#calToday").onclick = () => { calM = null; calSel = null; renderCal(); };
$("#cal").addEventListener("click", e => { const d = tg(e).closest<HTMLInputElement>("[data-day]"); if (!d) return; const [y, m, dd] = (d.dataset.day ?? "").split("-").map(Number), dt = new Date(y, m, dd);
  calSel = dt.toDateString(); renderCal(); openCalDay(dt); });
$("#cdClose").onclick = () => $<HTMLDialogElement>("#dCalDay").close();
$("#cdList").addEventListener("click", e => { const it = tg(e).closest<HTMLInputElement>("[data-open]"); if (!it) return; const rec = records.find(r => r._id === it.dataset.open); if (!rec) return;
  $<HTMLDialogElement>("#dCalDay").close(); homeView(rec); });
/** Beranda hanya untuk melihat: surat tugas dibuka sebagai pratinjau (tidak bisa diedit dari sini) */
function homeView(rec: StRecord): void { openPreview([rec], `Lihat surat tugas ${compute(rec).NOMOR_ST} — hanya lihat; ubah lewat Daftar Surat Tugas`); }
$("#hYear").addEventListener("change", () => {
  const Y = $<HTMLSelectElement>("#hYear").value, now = new Date();
  if (Y !== "semua"){ const y = +Y;
    if (y === now.getFullYear()) calM = new Date(y, now.getMonth(), 1);
    else { const ms = tripsOf().filter(t => t.a.getFullYear() === y).map(t => t.a.getMonth()); calM = new Date(y, ms.length ? Math.max(...ms) : 0, 1); }
    calSel = null; }
  renderHome(true);
});
$("#v-home").addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && tg(e).matches("[role=button]")){ e.preventDefault(); tg(e).click(); } });
$("#v-home").addEventListener("click", e => {
  const go = tg(e).closest<HTMLInputElement>("[data-go]"); if (go){ if (go.dataset.go === "form") newForm(); show(go.dataset.go ?? "home"); window.scrollTo(0, 0); if (go.dataset.act) $("#" + go.dataset.act)?.click(); return; }
  const tr = tg(e).closest<HTMLInputElement>("[data-open]"); if (tr){ const rec = records.find(r => r._id === tr.dataset.open); if (rec) homeView(rec); }
});
/* mode gelap / terang — pilihan disimpan di browser, bawaan mengikuti perangkat */
/* Tema: skema warna lengkap (latar, kartu, menu, garis, teks, aksen) versi terang & gelap,
   ukuran teks dan jenis huruf. Mode terang dibuat lembut: tanpa putih murni & hitam pekat. */
/** skema warna: nama, hue & saturasi latar, warna aksen [terang, gelap] */
interface Scheme { n: string; h: number; s: number; a: [string, string] }
const SCHEMES: Record<string, Scheme> = {
  biru:   { n: "Biru BPS", h: 214, s: 30, a: ["#2563a8", "#7cb0ee"] },
  langit: { n: "Biru Langit", h: 199, s: 40, a: ["#0e7490", "#5ccbe8"] },
  hijau:  { n: "Hijau Daun", h: 142, s: 22, a: ["#1f7a45", "#6fd39a"] },
  teal:   { n: "Toska", h: 172, s: 25, a: ["#0f766e", "#4fd1c0"] },
  hutan:  { n: "Hutan", h: 95, s: 20, a: ["#4d6b1c", "#a9d662"] },
  ungu:   { n: "Ungu", h: 262, s: 25, a: ["#6d3fc9", "#b49bf7"] },
  lavender:{ n: "Lavender", h: 285, s: 28, a: ["#8a4fb8", "#d2a8f2"] },
  rose:   { n: "Merah Marun", h: 345, s: 22, a: ["#b4234a", "#f58aa3"] },
  peach:  { n: "Peach", h: 20, s: 45, a: ["#c0532b", "#f5a27c"] },
  oranye: { n: "Oranye", h: 24, s: 40, a: ["#c2410c", "#fb923c"] },
  sepia:  { n: "Sepia (krem)", h: 36, s: 38, a: ["#8a5a2b", "#d9a86c"] },
  emas:   { n: "Emas", h: 45, s: 45, a: ["#94660a", "#e8bf5a"] },
  slate:  { n: "Abu Netral", h: 220, s: 8, a: ["#3d4a5c", "#c3ccd8"] },
  navy:   { n: "Navy Malam", h: 224, s: 40, a: ["#1d4ed8", "#6b9dfa"] }
};
const SCH_KEYS = ["accent", "accent-soft", "accent-ink", "bg", "card", "side", "side-on", "line", "ro", "field", "ink", "muted", "warn-soft", "ok-soft", "danger-soft"];
const hsl = (h: number, s: number, l: number): string => `hsl(${h} ${s}% ${l}%)`;
/* intensitas cahaya 0–100 (bawaan 50): menggeser kecerahan latar, kartu, menu & garis */
const lightK = () => { const v = +LS.get("st.light", 50); return Number.isFinite(v) ? Math.max(0, Math.min(100, v)) : 50; };
function schemeVars(sc: Scheme, dark: boolean, lv: number = lightK()): Record<string, string> {
  const { h, s } = sc, o = (lv - 50) / 50, L = (base: number, amt: number) => Math.max(2, Math.min(99.5, base + o * amt));
  const hsl = (hh: number, ss: number, l: number) => `hsl(${hh} ${ss}% ${(+l).toFixed(1)}%)`, Lb = (b: number) => L(b, dark ? 6 : 5), Lc = (b: number) => L(b, dark ? 6 : o < 0 ? 6 : (b > 98 ? 1.2 : 4.5));
  return dark ? {
    bg: hsl(h, s * .55, Lb(7)), card: hsl(h, s * .5, Lc(10.5)), side: hsl(h, s * .55, Lb(8.5)), "side-on": hsl(h, s * .6, Lc(15)), field: hsl(h, s * .5, Lb(8.5)),
    line: hsl(h, s * .4, Lc(19)), ro: hsl(h, s * .45, Lc(13)), ink: hsl(h, 12, 91), muted: hsl(h, 8, 64),
    accent: sc.a[1], "accent-soft": hsl(h, Math.min(60, s * 1.4), 17), "accent-ink": hsl(h, 30, 8),
    "warn-soft": "hsl(40 45% 14%)", "ok-soft": "hsl(145 35% 13%)", "danger-soft": "hsl(0 40% 15%)"
  } : {   // terang lembut: latar sedikit berwarna, kartu putih gading, teks abu tua (bukan hitam)
    bg: hsl(h, s * .9, Lb(94.5)), card: hsl(h, s * .6, Lc(98.6)), side: hsl(h, s * .8, Lb(92.5)), "side-on": hsl(h, s, Lb(87.5)), field: hsl(h, s * .5, Lc(99)),
    line: hsl(h, s * .55, Lb(86.5)), ro: hsl(h, s * .7, Lb(92)), ink: hsl(h, 18, 17), muted: hsl(h, 9, 42),
    accent: sc.a[0], "accent-soft": hsl(h, Math.min(70, s * 1.6), 92), "accent-ink": "#ffffff",
    "warn-soft": "hsl(42 80% 93%)", "ok-soft": "hsl(145 45% 92%)", "danger-soft": "hsl(0 70% 95%)"
  };
}
/* jarak tepi kiri-kanan (px) & lebar isi halaman */
const padX = () => { const v = +LS.get("st.padx", 12); return Number.isFinite(v) ? Math.max(0, Math.min(48, v)) : 12; };
const FONT_SIZES: [string, string, number, string][] = [["kecil", "A", .92, "Kecil"], ["normal", "A", 1, "Normal"], ["besar", "A", 1.1, "Besar"], ["xbesar", "A", 1.22, "Sangat besar"]];
const FONTS: Record<string, [string, string]> = {
  sistem:  ["Sistem (bawaan)", 'ui-sans-serif,-apple-system,"Segoe UI Variable Text","Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif'],
  verdana: ["Verdana — mudah dibaca", 'Verdana,"DejaVu Sans",Geneva,sans-serif'],
  tahoma:  ["Tahoma — ringkas", 'Tahoma,"Segoe UI",Geneva,sans-serif'],
  trebuc:  ["Trebuchet — luwes", '"Trebuchet MS","Segoe UI",sans-serif'],
  calibri: ["Calibri — kantor", 'Calibri,Carlito,"Segoe UI",sans-serif'],
  arial:   ["Arial", 'Arial,"Liberation Sans",Helvetica,sans-serif'],
  georgia: ["Georgia — serif", 'Georgia,"Times New Roman","DejaVu Serif",serif'],
  mono:    ["Monospace", 'ui-monospace,"Cascadia Mono",Consolas,"DejaVu Sans Mono",monospace']
};
function applyTheme(t: string | null): void {
  const root = document.documentElement; if (t) root.dataset.theme = t; else delete root.dataset.theme;
  const dark = t ? t === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
  document.body.classList.toggle("is-dark", dark);
  root.style.colorScheme = dark ? "dark" : "light";
  const sc = SCHEMES[LS.get("st.scheme", "biru")] || SCHEMES.biru;
  for (const k of SCH_KEYS) root.style.removeProperty("--" + k);
  for (const [k, v] of Object.entries(schemeVars(sc, dark))) root.style.setProperty("--" + k, v);
  const fz = FONT_SIZES.find(f => f[0] === LS.get("st.fsize", "normal")) || FONT_SIZES[1]; root.style.setProperty("--zoom", String(fz[2]));
  const fo = FONTS[LS.get("st.font", "sistem")] || FONTS.sistem; root.style.setProperty("--font", fo[1]);
  root.style.setProperty("--padx", padX() + "px"); root.style.setProperty("--maxw", ({ penuh: "none", lebar: "1480px", normal: "1240px" } as Record<string, string>)[LS.get("st.maxw", "penuh")] || "none");
  $("#themeBtn .tlabel").textContent = "Tema";
  renderThemePop();
}
function renderThemePop(): void {
  const t = LS.get<string | null>("st.theme", null) || "auto", cur = LS.get("st.scheme", "biru"), dark = document.body.classList.contains("is-dark");
  $$("#tpMode [data-tm]").forEach(b => b.classList.toggle("on", b.dataset.tm === t));
  $("#tpSch").innerHTML = Object.entries(SCHEMES).map(([k, v]) => { const c = schemeVars(v, dark);
    return `<button type="button" data-sch="${k}" class="${k === cur ? "on" : ""}" title="${v.n}"><span class="sw" style="background:${c.bg};border-color:${c.line}"><span style="background:${c.card}"></span><i style="background:${c.accent}"></i></span><span>${v.n}</span></button>`; }).join("");
  const px = padX(); $("#tpPad").value = String(px); $("#tpPadV").textContent = px + " px" + (px === 12 ? " (bawaan)" : "");
  $$("#tpW [data-tw]").forEach(b => b.classList.toggle("on", b.dataset.tw === LS.get("st.maxw", "penuh")));
  const lv = lightK(); $("#tpLight").value = String(lv); $("#tpLightV").textContent = lv === 50 ? "Normal" : lv < 50 ? `Lebih redup (${lv})` : `Lebih terang (${lv})`;
  const fs = LS.get("st.fsize", "normal");
  $("#tpSize").innerHTML = FONT_SIZES.map(([k, a, z, n]) => `<button type="button" data-fs="${k}" class="${k === fs ? "on" : ""}" title="${n}"><span style="font-size:${Math.round(13 * z)}px">${a}</span><small>${n}</small></button>`).join("");
  const fo = LS.get("st.font", "sistem");
  $("#tpFont").innerHTML = Object.entries(FONTS).map(([k, [n, f]]) => `<option value="${k}" ${k === fo ? "selected" : ""} style="font-family:${f.replace(/"/g, "'")}">${n}</option>`).join("");
}
const themePopOpen = (on: boolean): void => { $("#themePop").hidden = !on; $("#themeBtn").setAttribute("aria-expanded", String(on)); if (on){ const r = $("#themeBtn").getBoundingClientRect(); $("#themePop").style.top = (r.bottom + 8) + "px"; $("#themePop").style.right = Math.max(8, innerWidth - r.right) + "px"; } };
$("#themeBtn").onclick = e => { e.stopPropagation(); themePopOpen(Boolean($("#themePop").hidden)); };
$("#themePop").addEventListener("click", e => { e.stopPropagation();
  const m = tg(e).closest<HTMLInputElement>("[data-tm]")?.dataset.tm; if (m){ if (m === "auto") LS.del("st.theme"); else LS.set("st.theme", m); applyTheme(m === "auto" ? null : m); toast(`Mode ${m === "light" ? "terang" : m === "dark" ? "gelap" : "otomatis (ikut perangkat)"} dipakai.`); return; }
  const k = tg(e).closest<HTMLInputElement>("[data-sch]")?.dataset.sch; if (k){ LS.set("st.scheme", k); applyTheme(LS.get("st.theme", null)); toast(`Skema warna ${SCHEMES[k].n} dipakai.`); return; }
  const tw = tg(e).closest<HTMLInputElement>("[data-tw]")?.dataset.tw; if (tw){ LS.set("st.maxw", tw); applyTheme(LS.get("st.theme", null)); toast(`Lebar isi halaman ${tw} dipakai.`); return; }
  const fs = tg(e).closest<HTMLInputElement>("[data-fs]")?.dataset.fs; if (fs){ LS.set("st.fsize", fs); applyTheme(LS.get("st.theme", null)); themePopOpen(true); toast(`Ukuran teks ${(FONT_SIZES.find(f => f[0] === fs) || FONT_SIZES[1])[3].toLowerCase()} dipakai.`); return; }
  if (tg(e).closest<HTMLInputElement>("#tpReset")){ for (const x of ["st.theme", "st.scheme", "st.fsize", "st.font", "st.light", "st.padx", "st.maxw"]) LS.del(x); applyTheme(null); themePopOpen(true); toast("Tema dikembalikan ke bawaan."); } });
$("#tpPad").addEventListener("input", e => { LS.set("st.padx", +tg(e).value); applyTheme(LS.get("st.theme", null)); });
$("#tpPad").addEventListener("change", e => toast(`Jarak tepi ${tg(e).value} px dipakai.`));
$("#tpPad").addEventListener("dblclick", () => { LS.set("st.padx", 12); applyTheme(LS.get("st.theme", null)); });
$("#tpLight").addEventListener("input", e => { LS.set("st.light", +tg(e).value); applyTheme(LS.get("st.theme", null)); });
$("#tpLight").addEventListener("change", e => toast(`Intensitas cahaya ${+tg(e).value === 50 ? "normal" : +tg(e).value < 50 ? "lebih redup" : "lebih terang"} dipakai.`));
$("#tpLight").addEventListener("dblclick", () => { LS.set("st.light", 50); applyTheme(LS.get("st.theme", null)); });
$("#tpFont").addEventListener("change", e => { LS.set("st.font", tg(e).value); applyTheme(LS.get("st.theme", null)); toast(`Huruf ${(FONTS[tg(e).value] || FONTS.sistem)[0].split(" —")[0]} dipakai.`); });
document.addEventListener("click", () => { if (!$("#themePop").hidden) themePopOpen(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#themePop").hidden){ themePopOpen(false); $("#themeBtn").focus(); } });
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => { if (!LS.get("st.theme", null)) applyTheme(null); });
applyTheme(LS.get("st.theme", null));
/* kolom angka: roda mouse tidak mengubah nilai */
document.addEventListener("wheel", e => { const a = document.activeElement; if (a instanceof HTMLInputElement && a.type === "number" && tg(e) === a) a.blur(); }, { passive: true });
/* tooltip untuk elemen ber-data-tip */
document.addEventListener("mouseover", e => { const t = tg(e).closest<HTMLInputElement>("[data-tip]"), tip = $("#tip"); if (!t){ tip.classList.remove("on"); return; } tip.textContent = t.dataset.tip ?? ""; tip.classList.add("on"); });
document.addEventListener("mousemove", e => { const tip = $("#tip"); if (!tip.classList.contains("on")) return; const x = Math.min(innerWidth - tip.offsetWidth - 8, e.clientX + 14), y = Math.min(innerHeight - tip.offsetHeight - 8, e.clientY + 14); tip.style.left = x + "px"; tip.style.top = y + "px"; });

/* ================= pop up setelah simpan ================= */
function afterSave(title: string, msg: string, alt?: string): void {
  $("#svTitle").textContent = title; $("#svMsg").textContent = msg;
  $("#svAlt").textContent = alt === "list" ? "Lihat di Daftar" : "Surat tugas baru"; $("#svAlt").dataset.alt = alt || "new";
  $<HTMLDialogElement>("#dSaved").showModal();
}
$$("#dSaved [data-sv]").forEach(b => b.onclick = () => {
  $<HTMLDialogElement>("#dSaved").close(); const a = b.dataset.sv;
  if (a === "home"){ show("home"); window.scrollTo(0, 0); }
  else if (a === "alt"){ if (b.dataset.alt === "list"){ show("list"); } else { newForm(); show("form"); } window.scrollTo(0, 0); }
});

/* ================= KOTAK PENCARIAN (autocomplete) ================= */
/* data-ac="kode" → kode klasifikasi; "pel" → semua pegawai & mitra + Terlampir; "peg" → pegawai & mitra; "off" → hanya pegawai (PPK, Kepala, Bendahara) */
/** keadaan kotak pencarian yang sedang terbuka */
const AC: { el: HTMLInputElement | null; items: AcItem[]; idx: number; quiet: boolean } = { el: null, items: [], idx: 0, quiet: false };
const acNorm = (t: unknown): string => String(t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
function acHi(text: string, toks: string[]): string { let h = esc(text); for (const t of toks) if (t.length > 1) h = h.replace(new RegExp("(" + t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "ig"), "<mark>$1</mark>"); return h; }
function acSource(kind: string | undefined, q: string): AcItem[] {
  if (kind === "detil") return detilAc(q);
  const toks = acNorm(q).split(/[\s,;/]+/).filter(Boolean);
  if (kind === "pokj"){   // judul kegiatan = RO di POK (kode RO + nama RO), bukan detil MAK
    const U = usage(), ro = new Map<string, { ro: string; nama: string; keg: string; maks: string[]; sisa: number }>();
    const akP = ST_AKUN(acPel(AC.el));
    for (const a of pokDB.akun){ if (!akP.includes(a.akun)) continue;
      const o = ro.get(a.ro) || { ro: a.ro, nama: String(a.roNama).trim(), keg: a.kegNama, maks: [], sisa: 0 }; o.maks.push(a.mak); o.sisa += a.pagu - a.blokir - (U[a.mak]?.j || 0); ro.set(a.ro, o); }
    return [...ro.values()].filter(o => { const h = acNorm(o.ro + " " + o.nama + " " + o.keg); return !toks.length || toks.every(t => h.includes(t)); })
      .sort((x, y) => x.ro.localeCompare(y.ro))
      .map(o => ({ v: o.nama, mak: o.maks.length === 1 ? o.maks[0] : null, ro: o.ro, maks: o.maks, html: `<b>${acHi(o.ro, toks)}</b><span class="d">${acHi(o.nama, toks)}<small>${esc(o.keg)} · ${o.maks.length} MAK · sisa Rp ${rupiah(o.sisa)}</small></span>`, score: 0 }));
  }
  if (kind === "makpj" || kind === "makho"){
    const allow = kind === "makho" ? HO_AKUN : ST_AKUN(acPel(AC.el)), U = usage(), res: AcItem[] = [];
    const kf = kind === "makpj" && AC.el?.dataset.kegFrom ? ($(AC.el.dataset.kegFrom)?.value || "").trim() : "", roF = kf && pokJudul(allow).has(kf) ? kf : "";
    for (const a of pokDB.akun){
      if (!allow.includes(a.akun)) continue;
      const sisa = a.pagu - a.blokir - (U[a.mak]?.j || 0), names = a.items.map(i => String(i.u).trim());
      const hayA = acNorm([a.mak, a.kompNama, a.roNama, a.kegNama, a.nama, ...names].join(" "));
      if (roF && String(a.roNama).trim() !== roF) continue;
      {
        if (toks.length && !toks.every(t => hayA.includes(t))) continue;
        res.push({ v: a.mak, html: `<b>${acHi(a.mak, toks)}</b><span class="d">${esc(names.join("; ") || a.kompNama)}<small>${esc(a.nama)} · ${esc(a.roNama)} · sisa Rp ${rupiah(sisa)}</small></span>`, score: 0 });
      }
    }
    return res.sort((x, y) => x.score - y.score).slice(0, 150);
  }
  if (kind === "rpdsup"){   // supplier RPD: tautkan ke RAB (nama) atau Surat Tugas
    const res: AcItem[] = [];
    for (const d of [...rabDB].reverse()){ const h = acNorm([d.nama, d.ro, "rab"].join(" ")); if (toks.length && !toks.every(t => h.includes(t))) continue;
      res.push({ v: d.nama, key: "rab:" + d._id, html: `<span class="d"><b><span class="tag">RAB</span> ${acHi(d.nama, toks)}</b><small>${esc(d.ro)} · Rp ${rupiah(rabTotal(d))}</small></span>`, score: 0 }); }
    for (const r of [...records].reverse()){ if (res.length > 120) break; const F = compute(r), nm = String(F.NAMA_PELAKSANA_SPD || "").split(",")[0];
      const h = acNorm([F.NOMOR_ST, nm, F.MAKSUD__TUJUAN, F.TEMPAT_TUJUAN, "st surat tugas"].join(" ")); if (toks.length && !toks.every(t => h.includes(t))) continue;
      res.push({ v: `ST ${F.NOMOR_ST} — ${nm}`, key: "st:" + r._id, html: `<span class="d"><b><span class="tag">ST</span> ${acHi(F.NOMOR_ST, toks)}</b><small>${esc(nm)} · ${esc(String(F.MAKSUD__TUJUAN || "").slice(0, 60))}</small></span>`, score: 0 }); }
    return res;
  }
  if (kind === "makall"){   // semua MAK POK tahun anggaran (Permintaan Revisi: detil baru)
    const res: AcItem[] = [];
    for (const a of angPok().akun){ const h = acNorm([a.mak, a.nama, a.roNama, a.kompNama, a.kegNama].join(" "));
      if (toks.length && !toks.every(t => h.includes(t))) continue;
      res.push({ v: a.mak, html: `<b>${acHi(a.mak, toks)}</b><span class="d">${acHi(a.nama, toks)}<small>${esc(roTitle(a.roNama))} · ${esc(a.kompNama)} · pagu Rp ${rupiah(a.pagu)}</small></span>`, score: 0 });
      if (res.length > 150) break; }
    return res;
  }
  if (kind === "kam"){   // kampung SK Transport: nama / distrik
    const res: AcItem[] = [];
    for (const k of kampungDB){ const h = acNorm(k.kampung + " " + k.distrik), nm = acNorm(k.kampung), q0 = toks.join(" ");
      if (toks.length && !toks.every(t => h.includes(t))) continue;
      res.push({ v: kamLabel(k), html: `<b>${acHi(title(k.kampung), toks)}</b><span class="d">${acHi(title(k.distrik), toks)}<small>Rp ${rupiah(k.tarif)}${k.ket ? " · " + esc(k.ket) : ""}</small></span>`, score: !toks.length ? 1 : nm.startsWith(q0) ? 0 : 1 }); }
    return res.sort((a, b) => a.score - b.score).slice(0, 60);
  }
  if (kind === "kode"){
    const res: AcItem[] = [];
    for (const c of kodeDB.codes){
      const code = c.k.toLowerCase(), hay = acNorm(c.k + " " + c.k.replace(".", "") + " " + c.d + " " + kodeGroup(c.k));
      if (toks.length && !toks.every(t => hay.includes(t) || code.replace(".", "").includes(t.replace(".", "")))) continue;
      const q0 = toks.join(" ");
      const score = !toks.length ? 5 : code === q0 ? 0 : code.startsWith(q0) || code.split(".")[1]?.startsWith(q0) ? 1 : acNorm(c.d).startsWith(q0) ? 2 : 3 + (c.l || 0) * 0.1;
      res.push({ v: c.k, html: `<b>${acHi(c.k, toks)}</b><span class="d">${acHi(c.d, toks)}<small>${esc(kodeGroup(c.k))}</small></span>`, score });
      if (!toks.length && res.length > 80) break;
    }
    return res.sort((a, b) => a.score - b.score).slice(0, 60);
  }
  const rk = kind && kind.startsWith("role:") ? kind.slice(5).split("|") as RoleCode[] : null, holders = rk ? roleHolders(rk) : [];
  const list = rk && holders.length ? holders : pegawai.filter(p => kind === "pel" ? true : kind === "peg" ? !isSystemPeg(p) : !isMitra(p) && !isSystemPeg(p));
  const res: AcItem[] = [];
  for (const p of list){
    const hay = acNorm([p.nama, p.jabatan, p.nip, p.pangkat, p.gol].join(" "));
    if (toks.length && !toks.every(t => hay.includes(t))) continue;
    const nm = acNorm(p.nama), q0 = toks.join(" ");
    const score = (isSystemPeg(p) ? -1 : 0) + (!toks.length ? (isMitra(p) ? 2 : 1) : nm.startsWith(q0) ? 0 : nm.includes(q0) ? 1 : 2) + (isMitra(p) ? 0.5 : 0);
    res.push({ v: p.nama, mitra: isMitra(p), html: `<span class="d"><b>${acHi(p.nama, toks)}</b>${(p.roles || []).length ? ` <span class="rlbadge">${esc((p.roles || []).map(r => ROLE_NAME[r] || r).join(" · "))}</span>` : ""}<small>${esc([p.jabatan, p.nip && !/^-|terlampir/i.test(p.nip) ? "NIP " + p.nip : "", [p.pangkat, p.gol].filter(x => x && x !== "-").join(" ")].filter(Boolean).join(" · "))}</small></span>`, score });
  }
  return res.sort((a, b) => a.score - b.score).slice(0, 80);
}
function acRender(): void {
  const box = $("#acBox"), el = AC.el; if (!el) return;
  const ac = el.dataset.ac ?? "", rk = ac.startsWith("role:") ? ac.slice(5).split("|") as RoleCode[] : null;
  const rnote = rk ? (roleHolders(rk).length ? `<div class="hd">Pegawai dengan peran ${esc(rk.map(r => ROLE_NAME[r]).join(" / "))}</div>` : `<div class="hd bad">Belum ada pegawai berperan ${esc(rk.map(r => ROLE_NAME[r]).join(" / "))} — atur di Database → Pegawai</div>`) : "";
  if (!AC.items.length){ box.innerHTML = rnote + `<div class="hd">Tidak ada yang cocok</div>`; }
  else {
    let lastM: boolean | undefined | null = null;
    box.innerHTML = AC.items.map((it, i) => { let hd = "";
      if ((["pel", "peg", "off"].includes(ac) || ac.startsWith("role:")) && it.mitra !== lastM){ hd = `<div class="hd">${it.mitra ? "Mitra" : "Pegawai"}</div>`; lastM = it.mitra; }
      return hd + `<div class="it ${i === AC.idx ? "on" : ""}" data-i="${i}" role="option">${it.html}</div>`; }).join("");
    if (rnote) box.innerHTML = rnote + box.innerHTML.replace(/^<div class="hd">Pegawai<\/div>/, "");
  }
  const r = el.getBoundingClientRect(), w = Math.max(r.width, ["kode", "pokj", "makpj", "makho", "detil", "kam", "makall", "rpdsup"].includes(ac) ? 480 : 320);
  box.style.width = Math.min(w, innerWidth - 16) + "px";
  box.style.left = Math.max(8, Math.min(r.left, innerWidth - Math.min(w, innerWidth - 16) - 8)) + "px";
  const below = innerHeight - r.bottom;
  if (below < 220 && r.top > below){ box.style.top = ""; box.style.bottom = (innerHeight - r.top + 4) + "px"; } else { box.style.bottom = ""; box.style.top = (r.bottom + 4) + "px"; }
  box.hidden = false;
  const on = box.querySelector(".it.on"); if (on) on.scrollIntoView({ block: "nearest" });
}
function acOpen(el: HTMLInputElement, showAll: boolean): void { AC.el = el; AC.items = acSource(el.dataset.ac, showAll ? "" : el.value); AC.idx = 0; acRender(); }
function acClose(): void { $("#acBox").hidden = true; AC.el = null; }
function acPick(i: number): void {
  const it = AC.items[i], el = AC.el; if (!it || !el) return;
  AC.quiet = true; el.value = it.v; if (it.key) el.dataset.key = it.key;
  if (it.ro && el.dataset.makTarget){ const t = $(el.dataset.makTarget);   // RO dipilih → MAK: satu-satunya MAK di RO itu, atau dikosongkan bila bukan dari RO ini
    if (t){ const nv = it.mak || ((it.maks || []).includes(normMak(t.value)) ? t.value : ""); if (nv !== t.value){ t.value = nv; t.dispatchEvent(new Event("input", { bubbles: true })); t.dispatchEvent(new Event("change", { bubbles: true })); }
      if (!it.mak) setTimeout(() => { t.focus(); acOpen(t, true); }, 50); } }
  el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true }));
  AC.quiet = false; acClose();
}
document.addEventListener("focusin", e => { const t = tg(e).closest?.<HTMLInputElement>("[data-ac]"); if (t) acOpen(t, true); else if (!tg(e).closest<HTMLInputElement>("#acBox")) acClose(); });
document.addEventListener("input", e => { if (AC.quiet) return; const t = tg(e).closest?.<HTMLInputElement>("[data-ac]"); if (t) acOpen(t, false); }, true);
document.addEventListener("keydown", e => {
  if (!AC.el || tg(e) !== AC.el || $("#acBox").hidden) return;
  if (e.key === "ArrowDown"){ e.preventDefault(); AC.idx = Math.min(AC.items.length - 1, AC.idx + 1); acRender(); }
  else if (e.key === "ArrowUp"){ e.preventDefault(); AC.idx = Math.max(0, AC.idx - 1); acRender(); }
  else if (e.key === "Enter" && AC.items.length){ e.preventDefault(); e.stopImmediatePropagation(); acPick(AC.idx); }
  else if (e.key === "Escape"){ acClose(); }
  else if (e.key === "Tab") acClose();
}, true);
$("#acBox").addEventListener("mousedown", e => { e.preventDefault(); const it = tg(e).closest<HTMLInputElement>(".it"); if (it) acPick(Number(it.dataset.i)); });
document.addEventListener("click", e => { if (AC.el && !tg(e).closest<HTMLInputElement>("#acBox") && tg(e) !== AC.el) acClose(); });
addEventListener("scroll", e => { if (AC.el && !tg(e).closest?.("#acBox")) acRender(); }, true);
addEventListener("resize", () => AC.el && acRender());

