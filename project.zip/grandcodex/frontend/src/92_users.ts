/* ================= AKUN & HAK AKSES (RBAC) =================
   Server menyisipkan user yang login (__GC_USER). Menu yang tidak diizinkan dibuang dari bilah samping,
   show() menolak membukanya, dan Manajemen User (khusus Admin) mengatur akun lewat /api/users. */
interface FiturDef { v: string; n: string; grp: string }
/** daftar fitur = tombol menu di bilah samping (dibaca sebelum menu dipangkas), kecuali Beranda & Manajemen User */
const FITUR: FiturDef[] = $$("nav button[data-v]").filter(b => b.dataset.v !== "home" && b.dataset.v !== "users").map(b => ({ v: b.dataset.v || "", n: b.dataset.title || b.querySelector("span")?.textContent || "",
  grp: b.closest(".navgroup")?.querySelector(".grp span")?.textContent || "Lainnya" }));
const fiturNama = (v: string): string => FITUR.find(f => f.v === v)?.n || v;

/* menu dinamis: buang yang tidak boleh dibuka, lalu grup yang jadi kosong */
$$("nav button[data-v]").forEach(b => { if (!can(b.dataset.v || "")) b.remove(); });
$$("nav .navgroup").forEach(g => { if (!g.querySelector("button[data-v]")) g.remove(); });
$$("[data-go]").forEach(b => { const go = b.dataset.go || ""; if (FITUR.some(f => f.v === go) && !can(go)) b.remove(); });
$("#suName").textContent = GC_USER.username; $("#suRole").textContent = GC_USER.role;

async function gcApi<T = { ok?: boolean }>(url: string, method = "GET", body?: unknown): Promise<T> {
  const r = await fetch(url, { method, headers: body === undefined ? undefined : { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  if (r.status === 401){ gcToLogin(); throw new Error("Sesi berakhir"); }
  const j = await r.json().catch(() => ({})) as T & { error?: string };
  if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
  return j;
}
$("#suOut").onclick = async () => { if (!confirm(`Keluar dari akun ${GC_USER.username}?`)) return; try{ await fetch("api/logout", { method: "POST" }); }catch(e){} gcToLogin(); };

/* ---------- ganti password sendiri ---------- */
const dPw = $<HTMLDialogElement>("#dPw");
$("#suPw").onclick = () => { $("#pwOld").value = $("#pwNew").value = $("#pwNew2").value = ""; dPw.showModal(); $("#pwOld").focus(); };
$("#pwCancel").onclick = () => dPw.close();
$("#pwForm").addEventListener("submit", async e => { e.preventDefault();
  const baru = $("#pwNew").value; if (baru.length < 4) return toast("Password baru minimal 4 karakter.", "warn"); if (baru !== $("#pwNew2").value) return toast("Ulangan password baru tidak sama.", "warn");
  try{ await gcApi("api/password", "POST", { lama: $("#pwOld").value, baru }); dPw.close(); toast("Password diganti.", "ok"); }catch(x){ toast((x as Error).message, "err"); } });

/* ---------- Manajemen User (Admin) ---------- */
let usrList: GcUser[] = [], usrEdit: string | null = null;
async function renderUsers(): Promise<void> {
  if (!isAdmin) return;
  try{ usrList = await gcApi<GcUser[]>("api/users"); }catch(e){ toast("Daftar user gagal dimuat: " + (e as Error).message, "err"); return; }
  $("#usrBody").innerHTML = usrList.map((u, i) => `<tr data-usr="${esc(u.username)}"><td class="muted">${i + 1}</td><td><b>${esc(u.username)}</b>${u.username.toLowerCase() === GC_USER.username.toLowerCase() ? ` <span class="tag">Anda</span>` : ""}</td>
    <td><span class="tag ${u.role === "Admin" ? "ok" : ""}">${esc(u.role)}</span></td>
    <td>${u.role === "Admin" ? `<span class="muted">Semua fitur</span>` : u.fitur.length ? `<div class="usr-f">${u.fitur.map(f => `<span class="tag">${esc(fiturNama(f))}</span>`).join("")}</div>` : `<span class="muted">Hanya Beranda</span>`}</td>
    <td class="muted" style="font-size:12.5px">${esc(u.diubah || "")}</td>
    <td class="acts"><button class="btn sm" type="button" data-ua="edit">Ubah</button> <button class="btn sm del" type="button" data-ua="del">Hapus</button></td></tr>`).join("");
}
function usrFiturHtml(sel: Set<string>): string {
  const grp = [...new Set(FITUR.map(f => f.grp))];
  return grp.map(g => `<fieldset><legend>${esc(g)}</legend>${FITUR.filter(f => f.grp === g).map(f => `<label><input type="checkbox" value="${esc(f.v)}" ${sel.has(f.v) ? "checked" : ""}> ${esc(f.n)}</label>`).join("")}</fieldset>`).join("");
}
function usrRoleSync(): void { const adm = $<HTMLSelectElement>("#usrRole").value === "Admin"; $("#usrFitur").classList.toggle("all", adm);
  $("#usrHint").textContent = adm ? "Admin bisa membuka semua fitur dan mengelola user." : "Beranda selalu bisa dibuka. Centang menu lain yang boleh dipakai user ini."; }
function usrOpen(u: GcUser | null): void {
  usrEdit = u ? u.username : null; $("#usrH").textContent = u ? `Ubah user ${u.username}` : "Tambah user";
  $("#usrName").value = u?.username || ""; $("#usrName").disabled = !!u; $("#usrPass").value = ""; $("#usrPass").placeholder = u ? "kosongkan bila tidak diganti" : "minimal 4 karakter";
  $<HTMLSelectElement>("#usrRole").value = u?.role || "User"; $("#usrFitur").innerHTML = usrFiturHtml(new Set(u?.fitur || [])); usrRoleSync();
  $<HTMLDialogElement>("#dUser").showModal(); (u ? $("#usrPass") : $("#usrName")).focus();
}
$("#usrAdd").onclick = () => usrOpen(null);
$("#usrCancel").onclick = () => $<HTMLDialogElement>("#dUser").close();
$("#usrRole").onchange = usrRoleSync;
$("#usrAll").onclick = () => $$<HTMLInputElement>("#usrFitur input").forEach(c => c.checked = true);
$("#usrNone").onclick = () => $$<HTMLInputElement>("#usrFitur input").forEach(c => c.checked = false);
$("#usrForm").addEventListener("submit", async e => { e.preventDefault();
  const username = $("#usrName").value.trim(), password = $("#usrPass").value, role = $<HTMLSelectElement>("#usrRole").value, fitur = $$<HTMLInputElement>("#usrFitur input:checked").map(c => c.value);
  if (!usrEdit && !/^[A-Za-z0-9._-]{3,32}$/.test(username)) return toast("Username 3–32 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.", "warn");
  if ((!usrEdit || password) && password.length < 4) return toast("Password minimal 4 karakter.", "warn");
  try{
    if (usrEdit) await gcApi("api/users/" + encodeURIComponent(usrEdit), "PUT", { role, fitur, password });
    else await gcApi("api/users", "POST", { username, password, role, fitur });
    $<HTMLDialogElement>("#dUser").close(); toast(usrEdit ? `User ${usrEdit} diperbarui — berlaku saat ia memuat ulang halaman.` : `User ${username} ditambahkan.`, "ok"); renderUsers();
  }catch(x){ toast((x as Error).message, "err"); } });
$("#usrBody").addEventListener("click", async e => {
  const b = tg(e).closest<HTMLElement>("[data-ua]"), name = b?.closest<HTMLElement>("[data-usr]")?.dataset.usr, u = usrList.find(x => x.username === name); if (!b || !u) return;
  if (b.dataset.ua === "edit") return usrOpen(u);
  if (!confirm(`Hapus user ${u.username}? Ia langsung tidak bisa masuk lagi.`)) return;
  try{ await gcApi("api/users/" + encodeURIComponent(u.username), "DELETE"); toast(`User ${u.username} dihapus.`, "ok"); renderUsers(); }catch(x){ toast((x as Error).message, "err"); } });
