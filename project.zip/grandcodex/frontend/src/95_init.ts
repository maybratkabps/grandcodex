/* ================= nav & init ================= */
/** true saat tombol kembali/maju browser: show() tidak menambah riwayat */
let _navPop = false;
const grpOf = (g: Element) => ({ head: g.querySelector<HTMLElement>(".grp")!, items: g.querySelector<HTMLElement>(".grp-items")! });
function show(v: string): void {
  if (!can(v)){ toast("Anda tidak punya akses ke menu itu. Hubungi Admin untuk membukanya.", "warn"); v = "home"; }
  if (v === "users") renderUsers();
  $$("nav button[data-v]").forEach(b => b.classList.toggle("on", b.dataset.v === v));
  for (const g of $$("nav .navgroup")){ const inG = !!g.querySelector(`[data-v="${v}"]`); grpOf(g).head.classList.toggle("has-on", inG); if (inG && grpOf(g).items.hidden) setGrpOpen(g, true); }
  const nbtn = $(`nav button[data-v="${v}"]`), nb = nbtn && nbtn.querySelector("span"); if (nb) $("#pageTitle").textContent = nbtn.dataset.title || nb.textContent;
  const grpL = nbtn?.closest<HTMLInputElement>(".navgroup")?.querySelector(".grp span")?.textContent; $("#pageSub").textContent = grpL && nb ? `${grpL} › ${nb.textContent}` : "BPS Kabupaten Maybrat";
  if (!_navPop && location.hash !== "#" + v) try{ history.pushState({ v }, "", "#" + v); }catch(e){}
  window.scrollTo({ top: 0 });
  document.body.classList.remove("open"); $$(".view").forEach(s => s.classList.toggle("on", s.id === "v-" + (v === "up" ? "tup" : v))); if (v === "mass") updateMassInfo(); if (v === "pok") renderPOK(); if (v === "tpl" && !tplState) loadTplEditor(); if (v === "home") renderHome(); if (v === "honor" && !hoCur) renderHonorList(); if (v === "rpd") renderRpd(); if (v === "tup" || v === "up"){ if (tupMode !== v) tupOpen.clear(); tupMode = v; renderTup(); } if (v === "revisi") renderRev(); if (v === "rab") renderRab(); if (v === "rablist") renderRabList(); if (v === "set") renderDefTarif(); if (v === "nomor"){ if (!nsIn("tgl").value) nsReset(); renderNsFmt(); renderSurat(); nsPreview(); } }
$$("nav button[data-v]").forEach(b => b.onclick = () => show(b.dataset.v ?? "home"));
function setGrpOpen(g: HTMLElement, open: boolean): void { grpOf(g).items.hidden = !open; grpOf(g).head.setAttribute("aria-expanded", open ? "true" : "false"); LS.set("st.nav." + g.dataset.grp, open); }
for (const g of $$("nav .navgroup")){
  grpOf(g).head.onclick = () => setGrpOpen(g, grpOf(g).items.hidden === true);
  setGrpOpen(g, !!LS.get("st.nav." + g.dataset.grp, g.dataset.grp === "st"));
}
const isMobile = () => matchMedia("(max-width:900px)").matches;
if (LS.get("st.sideCollapsed", false)) document.body.classList.add("collapsed");
$("#burger").onclick = () => {
  if (isMobile()) document.body.classList.toggle("open");
  else { document.body.classList.toggle("collapsed"); LS.set("st.sideCollapsed", document.body.classList.contains("collapsed")); }
};
$("#scrim").onclick = () => document.body.classList.remove("open");
/* ================= POK tab ================= */
let pokOpen = new Set<string>();
function pokSetYear(y0: string | number): void { const y = String(y0), p = pokGet(y); if (!p) return; pokYear = y; pokDB = p; LS.set("st.pokYear", y); _use = null; _kIdx = null; _dataVer++; pokOpen.clear(); renderAll(); toast(`POK aktif: T.A. ${y} — dipakai untuk Surat Tugas & Honor.`); }
function renderPokImpYear(): void {
  const el = $<HTMLSelectElement>("#pokImpYear"), cur = el.value, cy = new Date().getFullYear();
  const ys = [...new Set([...pokYears(), ...[cy - 1, cy, cy + 1, cy + 2].map(String)])].sort();
  el.innerHTML = `<option value="">— Pilih tahun POK —</option>` + ys.map(y => `<option value="${y}">T.A. ${y}${pokYearsL.includes(y) ? " (ganti)" : " (baru)"}</option>`).join("");
  el.value = ys.includes(cur) ? cur : ""; $("#pokImpBtn").classList.toggle("off", !el.value);
}
$("#pokImpYear").addEventListener("change", e => $("#pokImpBtn").classList.toggle("off", !tg(e).value));
$("#pokImpBtn").addEventListener("click", e => { if (!$("#pokImpYear").value){ e.preventDefault(); $("#pokImpYear").focus(); toast("Pilih dulu tahun POK yang akan diimpor."); } });
function renderPokYears(): void {
  renderPokImpYear();
  const cy = String(new Date().getFullYear());
  $("#pokYears").innerHTML = pokYears().map(y => { const p0 = pokGet(y), m0: PokMeta = p0?.meta || {}, on = y === pokYear;
    return `<div class="pyc ${on ? "on" : ""}" data-py="${esc(y)}" title="${on ? "POK aktif" : "Klik untuk menjadikan POK aktif"}"><b>T.A. ${esc(y)}</b>${on ? `<span class="tag ok">aktif</span>` : ""}${y === cy ? `<span class="tag">tahun berjalan</span>` : ""}${m0.draft ? `<span class="tag warn">rancangan</span>` : ""}
      <small>${(p0?.akun || []).length} akun${m0.tanggal ? " · per " + esc(m0.tanggal) : m0.draft ? " · salinan POK " + esc(m0.dasar || "") : ""}</small>${on ? "" : `<button type="button" class="x" data-pydel="${esc(y)}" title="Hapus POK T.A. ${esc(y)}">×</button>`}</div>`; }).join("")
    + `<span class="muted" style="font-size:12px;align-self:center">Impor POK tahun lain tidak mengubah POK aktif.</span>`;
}
$("#pokYears").addEventListener("click", e => {
  const del = tg(e).closest<HTMLInputElement>("[data-pydel]")?.dataset.pydel;
  if (del){ if (!confirm(`Hapus POK T.A. ${del} dari aplikasi?\nRPD/TUP/Revisi tahun ${del} tetap tersimpan.`)) return; pokDrop(del); if (typeof angYear !== "undefined" && angYear === del) angSetYear(pokYear, true); renderPOK(); toast(`POK T.A. ${del} dihapus.`); return; }
  const y = tg(e).closest<HTMLInputElement>("[data-py]")?.dataset.py; if (y && y !== pokYear) pokSetYear(y);
});
function renderPOK(): void {
  renderPokYears();
  const U = usage(), q = $("#qpok").value.trim().toLowerCase(), pj = $("#pokPerjadin").checked;
  const m = pokDB.meta || {};
  $("#pokMeta").textContent = [m.satker, "T.A. " + (m.tahun || pokYear), m.tanggal && "per " + m.tanggal, m.draft && "rancangan (salinan POK " + m.dasar + ")"].filter(Boolean).join(" · ");
  const all = pokDB.akun, perj = all.filter(a => /^5241/.test(a.akun));
  const sum = (arr: PokAkun[], f: (a: PokAkun) => number) => arr.reduce((s, a) => s + f(a), 0);
  const used = (a: PokAkun) => U[a.mak]?.j || 0;
  const outside = records.filter(r => r.MAK && !pokMap()[normMak(r.MAK)]).length;
  $("#pokKpi").innerHTML = [
    ["Alokasi (semua akun)", "Rp " + rupiah(m.alokasi || sum(all, a => a.pagu))],
    ["Pagu perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.pagu))],
    ["Blokir perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.blokir))],
    ["Terpakai oleh ST", "Rp " + rupiah(sum(perj, used))],
    ["Sisa perjalanan dinas", "Rp " + rupiah(sum(perj, a => a.pagu - a.blokir - used(a)))],
    ["ST dengan MAK di luar POK", outside + " surat"]
  ].map(([k, v]) => `<div class="kpi"><small>${k}</small><b>${v}</b></div>`).join("");
  const rows = all.filter(a => (!pj || /^5241/.test(a.akun)) && (!q || [a.mak, a.nama, a.roNama, a.kompNama, a.kegNama, ...a.items.map(i => i.u)].join(" ").toLowerCase().includes(q)));
  $("#tPok tbody").innerHTML = rows.map(a => {
    const u = used(a), sisa = a.pagu - a.blokir - u, avail = a.pagu - a.blokir, pct = avail > 0 ? Math.min(100, u / avail * 100) : (u ? 100 : 0);
    const main = `<tr class="pk" data-mak="${esc(a.mak)}"><td style="white-space:nowrap"><b>${esc(a.mak)}</b></td><td>${esc(a.nama)}<div class="muted" style="font-size:12px">${esc(a.roNama)} · ${esc(a.kompNama)}</div></td>
      <td class="num">${rupiah(a.pagu)}</td><td class="num">${a.blokir ? rupiah(a.blokir) : "–"}</td><td class="num">${rupiah(u)}<div class="muted" style="font-size:11px">${U[a.mak]?.n || 0} ST</div></td>
      <td class="num"><b class="${sisa < 0 ? "bad" : ""}">${rupiah(sisa)}</b><div class="bar"><i class="${sisa < 0 ? "over" : ""}" style="width:${pct.toFixed(0)}%"></i></div></td>
      <td><button class="btn sm" data-use="${esc(a.mak)}">Pakai</button></td></tr>`;
    const det = pokOpen.has(a.mak) ? `<tr class="items"><td></td><td colspan="6">${a.items.map(i => `<div>• ${esc(i.u)} — Rp ${rupiah(i.j)}${i.b ? ' <span class="tag warn">blokir</span>' : ""}</div>`).join("")}</td></tr>` : "";
    return main + det;
  }).join("") || `<tr><td colspan="7" class="muted">Tidak ada MAK yang cocok.</td></tr>`;
}
$("#qpok").addEventListener("input", () => renderPOK());
$("#pokPerjadin").addEventListener("change", () => renderPOK());
$("#tPok").addEventListener("click", e => {
  const use = tg(e).dataset.use;
  if (use){ form.MAK.value = use; refresh(); show("form"); showSub("data"); window.scrollTo(0, 0); toast("MAK " + use + " dipakai di Surat Tugas Personal."); return; }
  const tr = tg(e).closest<HTMLInputElement>("tr.pk"); if (!tr) return;
  const k = tr.dataset.mak ?? ""; pokOpen.has(k) ? pokOpen.delete(k) : pokOpen.add(k); renderPOK();
});
/** PDF → baris teks berkolom (spasi meniru posisi x) untuk parsePOK */
async function pdfToLines(buf: Uint8Array): Promise<string[]> {
  if (!pdfjsLib.GlobalWorkerOptions.workerSrc) pdfjsLib.GlobalWorkerOptions.workerSrc = "vendor/pdf.worker.min.js";
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise, lines: string[] = [];
  for (let p = 1; p <= pdf.numPages; p++){
    const tc = await (await pdf.getPage(p)).getTextContent();
    const items = tc.items.filter((i): i is PdfTextItem => "str" in i && i.str != null && i.str.trim() !== "").map(i => ({ x: i.transform[4], y: i.transform[5], w: i.width, s: i.str }));
    items.sort((a, b) => b.y - a.y || a.x - b.x);
    const rows: { y: number; items: { x: number; y: number; w: number; s: string }[] }[] = [];
    for (const it of items){ const r = rows.find(r => Math.abs(r.y - it.y) <= 2.5); if (r) r.items.push(it); else rows.push({ y: it.y, items: [it] }); }
    rows.sort((a, b) => b.y - a.y);
    const cws = items.filter(i => i.s.trim().length > 2).map(i => i.w / i.s.length).sort((a, b) => a - b);
    const cw = cws.length ? cws[Math.floor(cws.length / 2)] : 4;      // median character width on this page
    for (const r of rows){
      r.items.sort((a, b) => a.x - b.x);
      let out = "", end: number | null = null;
      for (const it of r.items){
        const col = Math.round(it.x / cw);
        if (end == null) out = " ".repeat(Math.max(0, col));
        else {
          const gap = it.x - end;
          if (gap > 1.5 * cw) out += " ".repeat(Math.max(2, col - out.length));
          else if (gap > 0.2 * cw && !/\s$/.test(out) && !/^\s/.test(it.s)) out += " ";
        }
        out += it.s; end = it.x + it.w;
      }
      lines.push(out);
    }
  }
  return lines;
}
$("#fPok").addEventListener("change", async e => {
  const f = tg(e).files?.[0]; if (!f) return;
  try{
    const ySel = $("#pokImpYear").value; if (!ySel) return toast("Pilih dulu tahun POK yang akan diimpor.");
    toast("Membaca POK…");
    let res: Pok;
    if (/\.pdf$/i.test(f.name)) res = parsePOK(await pdfToLines(new Uint8Array(await f.arrayBuffer())));
    else { const wb = XLSX.read(await f.arrayBuffer(), { type: "array" }); res = parsePOKRows(XLSX.utils.sheet_to_json<XCell[]>(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true, defval: null })); }
    if (!res.akun.length) throw new Error("tidak ada akun yang terbaca — pastikan file adalah Rincian Kertas Kerja Satker (unduhan Excel SAKTI)");
    if (res.meta.tahun && String(res.meta.tahun) !== ySel && !confirm(`File ini tertulis T.A. ${res.meta.tahun}, tetapi Anda memilih T.A. ${ySel}. Tetap simpan sebagai T.A. ${ySel}?`)) return;
    res.meta.tahun = ySel; res.meta.satker ||= pokDB.meta?.satker || "BPS KABUPATEN MAYBRAT";
    const tot = res.akun.reduce((s, a) => s + a.pagu, 0);
    const check = res.meta.alokasi ? (tot === res.meta.alokasi ? "cocok dengan alokasi" : `⚠ total Rp ${rupiah(tot)} ≠ alokasi Rp ${rupiah(res.meta.alokasi)}`) : "";
    const y = ySel; const ada = pokYearsL.includes(y), aktif = y === pokYear;
    const msg = `POK T.A. ${y} terbaca: ${res.akun.length} akun, ${res.akun.reduce((s0, a) => s0 + a.items.length, 0)} detil, total pagu Rp ${rupiah(tot)} ${check}.\nTanggal POK: ${res.meta.tanggal || "-"}\n\n`
      + (aktif ? `Ganti POK T.A. ${y} (POK aktif) dengan file ini?` : ada ? `Ganti POK T.A. ${y} yang tersimpan dengan file ini?\nPOK aktif T.A. ${pokYear} TIDAK berubah.` : `Simpan sebagai POK T.A. ${y}?\nPOK aktif T.A. ${pokYear} TIDAK berubah.`);
    if (!confirm(msg)) return;
    const oldP = pokGet(y); res._v2 = res._v3 = true;
    if (aktif){ pokDB = res; persist(); } else { pokSave(y, res); _dataVer++; }
    const nMv = typeof angRemap === "function" ? angRemap(y, oldP, res) : 0;
    if (aktif){ renderAll(); toast(`POK T.A. ${y} diperbarui.` + (nMv ? ` ${nMv} nama detil diperbaiki, isian RPD/TUP ikut dipindahkan.` : "")); }
    else { renderPOK(); toast(`POK T.A. ${y} disimpan. POK aktif tetap T.A. ${pokYear}.` + (nMv ? ` ${nMv} nama detil diperbaiki, isian RPD/TUP ikut dipindahkan.` : "")); }
    if (typeof angYear !== "undefined" && angYear === y){ _dataVer++; angRefresh(); }
  }catch(err){ console.error(err); toast("Gagal membaca POK: " + (err as Error).message); }
  finally{ tg(e).value = ""; }
});
function renderAll(): void { buildLists(); renderList(); renderPeg(); renderKam(); renderTarif(); renderKode(); renderMass(); renderPOK(); }
// migrasi: total transport tidak lagi disimpan terpisah — selalu dihitung dari baris
{ let n = 0; for (const r of records) if ("TOTAL_TRANS" in r){ delete r.TOTAL_TRANS; n++; } if (n) persist(); }
// migrasi: surat Lokal yang baris transportnya masih format lama (tanpa "hari x") dihitung ulang
{ let n = 0;
  for (const r of records){
    if (!isLokal(r) || !normChips(r._kampung).length) continue;
    const rows = [...Array(MAXTR)].map((_, i) => r["KetTransport_" + (i + 1)] || "");
    if (rows.some(k => /^Biaya Transport Lokal dari /.test(k) && !/\(\d+ hari x /.test(k))){ applyKampungToRec(r); n++; }
  }
  if (n){ persist(); setTimeout(() => toast(`${n} surat Lokal diperbarui: transport lokal sekarang dikali banyak hari.`), 600); }
}
// migrasi: transport lokal kampung berlabel Lokal pindah dari baris transport rincian ke Daftar Pengeluaran Riil (2. Uang Transport Lokal).
// Baris dipindahkan apa adanya (nilai tidak dihitung ulang); rincian khusus per anggota ikut dipindah.
{ let n = 0;
  const split = (rows: [string, unknown][]): { lok: RiilRow[]; rest: [string, unknown][] } => ({ lok: riilFilled(riilRows(rows.filter(([k]) => RIIL_LOK_RE.test(String(k ?? ""))))), rest: rows.filter(([k]) => !RIIL_LOK_RE.test(String(k ?? ""))) });
  for (const r of records){
    if (!isLokal(r) || r._riilLok) continue;
    const rows: [string, unknown][] = []; for (let i = 1; i <= MAXTR; i++) rows.push([r["KetTransport_" + i] ?? "", r["Nilai" + i] ?? ""]);
    const main = split(rows), po = (Object.values(r._perOrang || {}) as StRecord[]).filter(o => Array.isArray(o.trans));
    if (!main.lok.length && !po.some(o => split(o.trans).lok.length)) continue;
    for (const o of po){ const s = split(o.trans); o.riilLok = s.lok; o.trans = s.rest; }
    for (let i = 1; i <= MAXTR; i++){ delete r["KetTransport_" + i]; delete r["Nilai" + i]; }
    main.rest.filter(([k, v]) => k !== "" || (v !== "" && v != null)).forEach(([k, v], i) => { if (k !== "") r["KetTransport_" + (i + 1)] = k; if (v !== "" && v != null) r["Nilai" + (i + 1)] = v; });
    if (main.lok.length) r._riilLok = main.lok;
    n++;
  }
  if (n){ persist(); setTimeout(() => toast(`${n} surat Lokal diperbarui: transport lokal sekarang tercatat di Daftar Pengeluaran Riil (jumlah tidak berubah).`), 900); }
}
{ const miss = records.some(r => !r._id); if (miss){ ensureIds(); persist(); } }
// migrasi: rincian biaya dipisah dari data surat (st.records → st.records + st.rincian)
if (LS.get<unknown>("st.records", null) != null && LS.get<unknown>("st.rincian", null) == null) persist();
{ let n = 0; for (const r of records) if ("SIFAT" in r){ delete r.SIFAT; n++; } if (n) persist(); }
if (!LS.get("st.rolesInit", false) && !pegawai.some(p => (p.roles || []).length)){
  const P = pegMap(), add = (c: unknown, k: RoleCode) => { const p = P[codeOf(c)]; if (!p || isSystemPeg(p) || isMitra(p)) return; p.roles = [...new Set([...(p.roles || []), k])]; };
  for (const r of records){ add(r.No_PPK, "PPK"); add(r.No_Bend, "BEND");
    for (const f of ["KD_NAMA_KA_PLT_PLH", "KDSPPD"]){ const p = P[codeOf(r[f])]; if (p) add(r[f], /^kepala\b/i.test(String(p.jabatan || "")) ? "KEPALA" : "PLT"); } }
  for (const p of pegawai){ const rs = p.roles; if (rs) p.roles = ROLES.map(([x]) => x).filter(x => rs.includes(x)); }
  LS.set("st.rolesInit", true); persist();
}
if (!LS.get("st.batas1jt", false)){ const t = tarifDB.find(t => t.grup === RULES_GRUP && t.nama.startsWith("BATAS TRANSPORT")); if (t && num(t.nilai) === 5000000){ t.nilai = 1000000; persist(); } LS.set("st.batas1jt", true); }
// migrasi sekali: POK lama (hasil baca PDF) diganti POK Excel bawaan per tahun; isian RPD/TUP/Revisi ikut dipindah ke kunci baru
if (LS.get("st.pokXlsx", 0) < 2 && SEED.pokY){
  for (const [y, v] of Object.entries(SEED.pokY)){ const old = pokGet(y);
    if (old && old.meta?.src === "xlsx" && !(old.meta.tanggal === v.meta.tanggal && (old.meta.seed || 0) < (v.meta.seed || 0))) continue;   // POK Excel impor sendiri: biarkan
    const nw = clone(v); if (old) angRemap(y, old, nw); pokSave(y, nw); if (y === pokYear) pokDB = pokGet(y) || pokDB; }
  LS.set("st.pokXlsx", 2); _use = null; _kIdx = null; _dataVer++;
}
renderAll(); tplInfo(); newForm();
{ const h0 = location.hash.slice(1); show($(`nav button[data-v="${h0}"]`) && h0 !== "form" ? h0 : "home"); }
window.addEventListener("popstate", () => { const v = location.hash.slice(1) || "home"; if (!$(`nav button[data-v="${v}"]`)) return; _navPop = true; try{ show(v); } finally{ _navPop = false; } });
$("#toast").addEventListener("click", () => $("#toast").classList.remove("on"));
$("#toTop").onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });
window.addEventListener("scroll", debounce(() => $("#toTop").classList.toggle("on", window.scrollY > 700), 80), { passive: true });
fillCommon(Object.keys(massCommon).length ? massCommon : commonFrom(defaults()));
_mY = yrOf(mIn("TGL_TERBIT_ST").value);
for (const k of ["No_PPK","KD_NAMA_KA_PLT_PLH","KDSPPD"]){ const e = mIn(k); if (e && e.value){ const c = resolvePeg(e.value); if (c) e.value = pegLabel(c); } }
massRows.forEach(r => { if (/^\d+\s*—/.test(r.peg || "")){ const c = resolvePeg(r.peg); if (c) r.peg = pegLabel(c); } });
updateMassInfo();
window.__app = { compute, buildDocx, buildMerged, records: () => records, fillForm, readForm, massRecords };
