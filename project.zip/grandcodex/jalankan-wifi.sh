#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-3000}"
HOST="${HOST:-0.0.0.0}"

echo "=================================================="
echo " Menjalankan GrandCodex di Jaringan Wi-Fi / LAN"
echo "=================================================="
echo "Akses dari komputer ini:"
echo "  -> http://localhost:${PORT}"
echo ""
echo "Akses dari perangkat lain di Wi-Fi yang sama:"

IPS=$(hostname -I 2>/dev/null || true)
if [ -n "$IPS" ]; then
  for ip in $IPS; do
    # Tampilkan hanya alamat IPv4
    if [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      echo "  -> http://${ip}:${PORT}"
    fi
  done
else
  echo "  -> http://<IP-KOMPUTER-ANDA>:${PORT}"
fi

echo "=================================================="
echo "Tekan Ctrl+C untuk menghentikan server."
echo ""

cd "$DIR/backend"
exec env HOST="$HOST" PORT="$PORT" node server.js
